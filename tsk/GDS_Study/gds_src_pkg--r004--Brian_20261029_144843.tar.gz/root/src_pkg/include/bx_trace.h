/* BUILD_ID="Brian_20261029_144843" */
/* bx_trace.h - BXTRACE(): structured trace events for GDS sequence reconstruction.
 *
 * Host event (stderr, one line):
 *   BXTRACE|<monotonic_us>|CPU:core=<n>:tid=<t>|<component>|<step>|<file>:<line>|<message>
 * Device (SM) event, printed on host from kernel-written records:
 *   BXTRACE|<host_emit_us>|GPU:sm=<s>:warpslot=<w>:lane=<l>|SM|ProbeWarp|<file>:<line>|label=... gtimer_ns=...
 *
 * <file> is the basename of the source file, <line> the line of the BXTRACE/probe call site.
 * gtimer_ns is the GPU %globaltimer value; host_emit_us is when the host printed the record.
 */
#ifndef BX_TRACE_H
#define BX_TRACE_H

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>
#include <sys/syscall.h>

#if defined(__has_include)
#if __has_include(<nvtx3/nvToolsExt.h>)
#include <nvtx3/nvToolsExt.h>
#define BX_HAVE_NVTX 1
#endif
#endif
#ifndef BX_HAVE_NVTX
#define BX_HAVE_NVTX 0
#endif

static inline long bx_now_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000L + ts.tv_nsec / 1000L;
}

static inline long bx_tid(void) {
    return (long)syscall(SYS_gettid);
}

/* Basename of a __FILE__ path, so trace lines stay short and stable across build dirs. */
static inline const char *bx_basename(const char *path) {
    const char *s = strrchr(path, '/');
    return s ? s + 1 : path;
}

/* Explicit location variant, used when the call site is a helper function. */
#define BXTRACE_LOC(file, line, comp, step, ...)                                          \
    do {                                                                                  \
        fprintf(stderr, "BXTRACE|%ld|CPU:core=%d:tid=%ld|%s|%s|%s:%d|",                   \
                bx_now_us(), sched_getcpu(), bx_tid(), (comp), (step), (file), (line));  \
        fprintf(stderr, __VA_ARGS__);                                                     \
        fprintf(stderr, "\n");                                                            \
    } while (0)

/* Default: location of the macro use site. */
#define BXTRACE(comp, step, ...) \
    BXTRACE_LOC(bx_basename(__FILE__), __LINE__, comp, step, __VA_ARGS__)

/* NVTX ranges: host-timeline intervals in nsys. They do not name GPU subsystems. */
#if BX_HAVE_NVTX
#define BXRANGE_PUSH(name) nvtxRangePushA(name)
#define BXRANGE_POP()      nvtxRangePop()
#else
#define BXRANGE_PUSH(name) ((void)0)
#define BXRANGE_POP()      ((void)0)
#endif

/* Device probe record. Filled inside kernels by bx_dev_probe() (bx_trace_dev.cuh). */
typedef struct bx_dev_rec {
    unsigned long long gtimer_ns;  /* %globaltimer: GPU clock in ns */
    unsigned int smid;             /* %smid: streaming multiprocessor index */
    unsigned int warpid;           /* %warpid: warp slot within the SM */
    unsigned int laneid;           /* %laneid of the reporting thread */
    unsigned int line;             /* source line of the probe call site */
    int tag;                       /* caller-defined probe point id */
} bx_dev_rec_t;

/* file: __FILE__ of the .cu that contains the kernel; line comes from the record. */
static inline void bx_trace_gpu_rec(const bx_dev_rec_t *r, const char *label, const char *file) {
    fprintf(stderr,
            "BXTRACE|%ld|GPU:sm=%u:warpslot=%u:lane=%u|SM|ProbeWarp|%s:%u|label=%s tag=%d gtimer_ns=%llu\n",
            bx_now_us(), r->smid, r->warpid, r->laneid, bx_basename(file), r->line,
            label, r->tag, r->gtimer_ns);
}

#endif /* BX_TRACE_H */
