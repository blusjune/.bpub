# BUILD_ID="Brian_20261029_144843"
"""Unit tests for trace2mermaid. Run: python3 -m unittest discover -s tests -v"""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import trace2mermaid as t2m  # noqa: E402

SAMPLE = """\
BXTRACE|100|CPU:core=5:tid=1|CPU_APP|Main|bx_gds_basic.cu:300|scenario=FS_GDS storage=fs mode=gds target=/x size=1024 iters=1 offset=0
BXTRACE|105|CPU:core=5:tid=1|CPU_APP|Phase|bx_gds_basic.cu:301|name=init
BXTRACE|110|CPU:core=5:tid=1|POSIX_FS|Open|bx_gds_basic.cu:310|fd=3 flags=O_RDWR|O_CREAT|O_DIRECT
BXTRACE|115|CPU:core=5:tid=1|CPU_APP|Phase|bx_gds_basic.cu:320|name=write
BXTRACE|120|CPU:core=5:tid=1|CUDA_RT|LaunchProbe|bx_gds_basic.cu:200|label=after_write tag=1 grid=4 block=128
BXTRACE|125|GPU:sm=2:warpslot=0:lane=0|SM|ProbeWarp|bx_gds_basic.cu:42|label=after_write tag=1 gtimer_ns=9
BXTRACE|125|GPU:sm=3:warpslot=0:lane=0|SM|ProbeWarp|bx_gds_basic.cu:42|label=after_write tag=1 gtimer_ns=9
BXTRACE|125|GPU:sm=3:warpslot=1:lane=0|SM|ProbeWarp|bx_gds_basic.cu:42|label=after_write tag=1 gtimer_ns=9
BXTRACE|130|CPU:core=5:tid=1|CUDA_RT|ProbeKernelDone|bx_gds_basic.cu:210|label=after_write tag=1 warp_records=3
BXTRACE|140|CPU:core=5:tid=1|CPU_APP|Verify|bx_gds_basic.cu:350|iter=0 ok=1
this line is not a trace line
"""

RAW_SAMPLE = """\
BXTRACE|100|CPU:core=5:tid=1|CPU_APP|Main|bx_gds_basic.cu:300|scenario=RAW_POSIX storage=raw mode=posix target=/dev/nvme1n1p5 size=1024 iters=1 offset=4096
BXTRACE|110|CPU:core=5:tid=1|BLK_DEV|Open|bx_gds_basic.cu:150|fd=3 flags=O_RDWR|O_DIRECT
BXTRACE|115|CPU:core=5:tid=1|BLK_DEV|GetSize|bx_gds_basic.cu:152|ioctl_rc=0 device_bytes=2048
BXTRACE|120|CPU:core=5:tid=1|POSIX_BOUNCE|pwrite|bx_gds_basic.cu:192|iter=0 ret=1024 offset=4096
"""


class Trace2MermaidTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.log = Path(self.tmp.name) / "trace.log"
        self.log.write_text(SAMPLE)

    def tearDown(self):
        self.tmp.cleanup()

    def test_parse_extracts_source_location_and_keeps_pipes(self):
        events = t2m.parse(self.log)
        self.assertEqual(len(events), 10)
        self.assertEqual(events[0].src, "bx_gds_basic.cu:300")
        self.assertEqual(events[2].msg, "fd=3 flags=O_RDWR|O_CREAT|O_DIRECT")

    def test_old_format_lines_still_parse_with_empty_src(self):
        old = self.log.with_name("old.log")
        old.write_text("BXTRACE|1|CPU:core=0:tid=1|CUDA_RT|SetDevice|cudaError=0(no error)\n")
        events = t2m.parse(old)
        self.assertEqual(events[0].src, "")
        self.assertEqual(events[0].msg, "cudaError=0(no error)")

    def test_scenario_is_shown_and_used_for_file_name(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertIn("%% scenario=FS_GDS", out)
        n = t2m.convert(self.log)
        self.assertEqual(n, 10)
        self.assertTrue(self.log.with_name("trace_sequence_FS_GDS.mmd").exists())

    def test_phases_are_separate_blocks(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertIn("%% ===== PHASE init =====", out)
        self.assertIn("Note over CPU_APP: PHASE write", out)
        self.assertNotIn("CPU_APP->>CPU_APP", out)
        self.assertNotIn("Phase", out.replace("PHASE", ""))

    def test_participants_show_execution_location(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertIn("participant CPU_APP as User app (CPU)", out)
        self.assertIn("participant SM as GPU SM probe (GPU)", out)
        self.assertIn("participant POSIX_FS as POSIX file API (CPU kernel)", out)
        self.assertIn("participant CUDA_RT as CUDA runtime (CPU)", out)

    def test_raw_scenario_uses_block_device_participant(self):
        raw = self.log.with_name("raw.log")
        raw.write_text(RAW_SAMPLE)
        out = t2m.to_mermaid(t2m.parse(raw))
        self.assertIn("%% scenario=RAW_POSIX", out)
        self.assertIn("participant BLK_DEV as Block device node (CPU kernel)", out)
        self.assertIn("BLK_DEV", out)
        self.assertTrue(t2m.convert(raw) and raw.with_name("trace_sequence_RAW_POSIX.mmd").exists())

    def test_unknown_component_is_labelled_unknown_location(self):
        self.assertEqual(t2m.participant_label("FOO_BAR"), "FOO_BAR (location unknown)")

    def test_cuda_runtime_declared_when_only_sm_events_exist(self):
        sm_only = self.log.with_name("sm_only.log")
        sm_only.write_text("BXTRACE|3|GPU:sm=2:warpslot=0:lane=0|SM|ProbeWarp|bx_gds_basic.cu:42|label=x tag=1 gtimer_ns=9\n")
        out = t2m.to_mermaid(t2m.parse(sm_only))
        self.assertIn("participant CUDA_RT as CUDA runtime (CPU)", out)
        self.assertIn("CUDA_RT->>SM:", out)

    def test_every_event_has_comment_with_file_line(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertIn("%% bx_gds_basic.cu:310  POSIX_FS.Open", out)
        self.assertIn("%% bx_gds_basic.cu:300  CPU_APP.Main", out)

    def test_notes_show_file_line_on_arrows_and_app(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertIn("Note right of POSIX_FS: bx_gds_basic.cu:310", out)
        self.assertIn("[bx_gds_basic.cu:300]", out)

    def test_no_notes_option_keeps_comments(self):
        out = t2m.to_mermaid(t2m.parse(self.log), notes=False)
        self.assertNotIn("Note right of", out)
        self.assertIn("%% bx_gds_basic.cu:310", out)

    def test_sm_group_is_one_arrow_with_probe_line_note(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertEqual(out.count("CUDA_RT->>SM:"), 1)
        self.assertIn("ProbeWarp x3 on SM 2,3", out)
        self.assertIn("Note right of SM: bx_gds_basic.cu:42", out)

    def test_expand_sm_draws_one_arrow_per_warp_with_notes(self):
        out = t2m.to_mermaid(t2m.parse(self.log), expand_sm=True)
        self.assertEqual(out.count("CPU_APP->>SM:"), 3)
        self.assertEqual(out.count("Note right of SM: bx_gds_basic.cu:42"), 3)

    def test_clean_removes_mermaid_breaking_characters(self):
        self.assertNotIn(";", t2m.clean("a;b#c<d>e\"f|g"))
        self.assertNotIn("|", t2m.clean("a|b"))


if __name__ == "__main__":
    unittest.main()
