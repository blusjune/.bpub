# BUILD_ID="Brian_20261029_144843"
"""Tests for the automatic GDS support decision (pure logic, no GPU)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "subtests"))
import subtest_support as sup  # noqa: E402

STATIC_OK = {"libcufile": True, "nvidia_fs": True}
PROBE_OK = {"rc": 0, "verify_ok": True, "compat_direct": False, "verdict": "NATIVE_GDS"}


class DecideTest(unittest.TestCase):
    def test_native_when_static_ok_and_strict_probe_passes(self):
        d = sup.decide(STATIC_OK, PROBE_OK)
        self.assertEqual(d["policy"], "native")
        self.assertEqual(d["compat"], 0)

    def test_fallback_when_nvidia_fs_missing(self):
        d = sup.decide({"libcufile": True, "nvidia_fs": False}, PROBE_OK)
        self.assertEqual((d["policy"], d["compat"]), ("fallback", 1))
        self.assertTrue(any("nvidia-fs" in r for r in d["reasons"]))

    def test_fallback_when_libcufile_missing(self):
        d = sup.decide({"libcufile": False, "nvidia_fs": True}, PROBE_OK)
        self.assertEqual(d["policy"], "fallback")

    def test_fallback_when_strict_probe_fails(self):
        bad = dict(PROBE_OK, rc=1)
        d = sup.decide(STATIC_OK, bad)
        self.assertEqual(d["policy"], "fallback")
        self.assertTrue(any("strict probe failed" in r for r in d["reasons"]))

    def test_fallback_when_probe_reports_compatible_mode(self):
        d = sup.decide(STATIC_OK, dict(PROBE_OK, compat_direct=True))
        self.assertEqual(d["policy"], "fallback")

    def test_fallback_when_probe_not_run(self):
        d = sup.decide(STATIC_OK, None)
        self.assertEqual(d["policy"], "fallback")
        self.assertIn("strict probe not run", d["reasons"])

    def test_forced_policies(self):
        self.assertEqual(sup.forced("native")["compat"], 0)
        self.assertEqual(sup.forced("fallback")["compat"], 1)

    def test_labels_name_the_path(self):
        self.assertIn("strict", sup.label(sup.forced("native")))
        self.assertIn("compatibility", sup.label(sup.forced("fallback")))

    def test_render_contains_decision(self):
        md = sup.render_md(sup.decide(STATIC_OK, PROBE_OK), "h", "t")
        self.assertIn("**NATIVE**", md)
        self.assertIn("allow_compat_mode = 0", md)


if __name__ == "__main__":
    unittest.main()
