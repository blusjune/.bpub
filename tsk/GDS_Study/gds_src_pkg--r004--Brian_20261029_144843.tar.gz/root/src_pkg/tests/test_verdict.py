# BUILD_ID="Brian_20261029_144843"
"""Tests for native vs compat verdicts, cuFile evidence scanning, and nvidia-fs counter parsing."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "subtests"))
import subtest_verdict as v  # noqa: E402

CUFILE_LOG = """\
27-10-2026 23:35:36:259 INFO   cufio-drv:828 pci_p2pdma not supported errornum: 801
27-10-2026 23:35:36:521 WARN   0:184 failed to open /proc/driver/nvidia-fs/devcount  error: No such file or directory
27-10-2026 23:35:36:521 NOTICE  cufio-drv:851 running in compatible mode
27-10-2026 23:35:36:521 INFO   0:1512 properties.use_compat_mode : true
27-10-2026 23:35:36:521 INFO   cufio-drv:253 NVMe P2PDMA        : Unsupported
27-10-2026 23:35:36:522 WARN   cufio-plat:457 GPU index 0 NVIDIA GB10: Model Not Supported
"""

NATIVE_LOG = """\
27-10-2026 23:35:36:521 INFO   cufio-drv:253 NVMe               : Supported
27-10-2026 23:35:36:521 INFO   0:1512 properties.use_compat_mode : true
"""


class EvidenceTest(unittest.TestCase):
    def test_categories_separate_self_report_from_config_echo(self):
        with tempfile.TemporaryDirectory() as d:
            sdir = Path(d)
            (sdir / "cufile_1.log").write_text(CUFILE_LOG)
            ev = v.scan_cufile_logs(sdir)
            self.assertEqual(len(ev["compat_direct"]), 1)
            self.assertEqual(len(ev["compat_config"]), 1)
            self.assertEqual(len(ev["devcount"]), 1)
            self.assertEqual(len(ev["model"]), 1)
            self.assertEqual(len(ev["unsupported"]), 1)

    def test_trace_and_run_logs_are_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            sdir = Path(d)
            (sdir / "trace.log").write_text("running in compatible mode\n")
            (sdir / "run.log").write_text("running in compatible mode\n")
            ev = v.scan_cufile_logs(sdir)
            self.assertEqual(ev["compat_direct"], [])


class ParseTest(unittest.TestCase):
    def test_parses_name_value_pairs_with_per_file_prefix(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d) / "nvidia-fs"
            base.mkdir()
            (base / "stats").write_text("Read: 10 Write: 5\nerror: 0\n")
            (base / "version").write_text("major: 2\n")
            stats = v.read_nvfs_stats(base)
            self.assertEqual(stats["stats:Read"], 10)
            self.assertEqual(stats["stats:Write"], 5)
            self.assertEqual(stats["version:major"], 2)

    def test_missing_base_returns_empty(self):
        self.assertEqual(v.read_nvfs_stats(Path("/nonexistent/nvfs")), {})

    def test_io_deltas_only_read_write_keys(self):
        before = {"Read": 0, "Write": 4, "error": 0}
        after = {"Read": 4096, "Write": 4, "error": 3}
        self.assertEqual(v.io_deltas(before, after), {"Read": 4096})


def ev(**kw):
    base = {name: [] for name in v.PATTERNS}
    base.update({k: [("f.log", "x")] for k in kw.get("hit", [])})
    return base


class VerdictTest(unittest.TestCase):
    def test_direct_self_report_wins_even_without_counters(self):
        r = v.classify("gds", 0, True, False, {}, {}, ev(hit=["compat_direct"]))
        self.assertEqual(r["verdict"], "COMPAT_FALLBACK")
        self.assertIn("direct self-report", r["reason"])
        self.assertEqual(r["basis"], "cuFile log")

    def test_direct_self_report_with_counters_is_flagged(self):
        r = v.classify("gds", 0, True, True, {"Read": 0}, {"Read": 9}, ev(hit=["compat_direct"]))
        self.assertEqual(r["verdict"], "COMPAT_FALLBACK")
        self.assertTrue(r["notes"])

    def test_native_when_counters_increase_and_no_compat_report(self):
        r = v.classify("gds", 0, True, True, {"Read": 0}, {"Read": 1 << 30}, ev())
        self.assertEqual(r["verdict"], "NATIVE_GDS")

    def test_compat_when_counters_unchanged(self):
        r = v.classify("gds", 0, True, True, {"Read": 7}, {"Read": 7}, ev())
        self.assertEqual(r["verdict"], "COMPAT_FALLBACK")

    def test_compat_when_nvidia_fs_not_loaded_and_devcount_noted(self):
        r = v.classify("gds", 0, True, False, {}, {}, ev(hit=["devcount"]))
        self.assertEqual(r["verdict"], "COMPAT_FALLBACK")
        self.assertIn("not loaded", r["reason"])
        self.assertTrue(r["notes"])

    def test_undetermined_when_stats_unparseable(self):
        r = v.classify("gds", 0, True, True, {}, {}, ev())
        self.assertEqual(r["verdict"], "UNDETERMINED")

    def test_run_failure_overrides_everything(self):
        r = v.classify("gds", 1, True, True, {"Read": 0}, {"Read": 9}, ev())
        self.assertEqual(r["verdict"], "RUN_FAILED")

    def test_posix_is_not_gds(self):
        r = v.classify("posix", 0, True, True, {}, {}, ev())
        self.assertEqual(r["verdict"], "NOT_GDS")


class ReportTest(unittest.TestCase):
    def test_report_has_sections_and_support_lines(self):
        with tempfile.TemporaryDirectory() as d:
            sdir = Path(d)
            (sdir / "cufile_1.log").write_text(CUFILE_LOG)
            evidence = v.scan_cufile_logs(sdir)
            cls = v.classify("gds", 0, True, False, {}, {}, evidence)
            path = v.write_report(sdir, "FS_GDS", {
                "host": "h", "started": "t", "command": "c",
                "summary": {"rc": 0, "result_verify": "ok"}, "verdict": cls,
                "nvfs_loaded": False, "nvfs_before_count": 0, "nvfs_after_count": 0,
                "evidence": evidence, "cufile_json": "x"})
            self.assertEqual(path.name, "test_result_FS_GDS.md")
            text = path.read_text()
            self.assertIn("**COMPAT_FALLBACK**", text)
            self.assertIn("### 1. cuFile self-report", text)
            self.assertIn("running in compatible mode", text)
            self.assertIn("Model Not Supported", text)
            self.assertIn("### 5. Configuration echo (not evidence)", text)


if __name__ == "__main__":
    unittest.main()
