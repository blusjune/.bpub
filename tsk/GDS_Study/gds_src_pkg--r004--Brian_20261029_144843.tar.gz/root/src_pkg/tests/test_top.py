# BUILD_ID="Brian_20261029_144843"
"""CLI tests: --help shows BUILD_ID first and the typical usage; suite --list works. No GPU needed."""
import os
import subprocess
import sys
import unittest
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent
TOP = PKG / "bx_gds_run_top.py"


def run_top(*args):
    env = dict(os.environ, BX_IN_VENV="1")   # avoid re-exec into the venv during tests
    return subprocess.run([sys.executable, str(TOP), *args], capture_output=True, text=True, env=env, cwd=PKG)


class CliTest(unittest.TestCase):
    def test_help_starts_with_build_id_and_lists_typical_usage(self):
        r = run_top("--help")
        self.assertEqual(r.returncode, 0)
        self.assertTrue(r.stdout.splitlines()[0].startswith('BUILD_ID="'))
        self.assertIn("typical usage", r.stdout)
        self.assertIn("suite smoke", r.stdout)
        self.assertIn("--gds-policy fallback", r.stdout)

    def test_subcommand_help_has_examples(self):
        r = run_top("roundtrip", "--help")
        self.assertEqual(r.returncode, 0)
        self.assertTrue(r.stdout.splitlines()[0].startswith('BUILD_ID="'))
        self.assertIn("examples:", r.stdout)

    def test_suite_list_names_every_suite(self):
        r = run_top("suite", "--list")
        self.assertEqual(r.returncode, 0)
        for name in ["unit", "selftest", "smoke", "fs-standard", "fs-profile", "raw-standard", "full"]:
            self.assertIn(f"suite {name}:", r.stdout)

    def test_suite_dry_run_needs_no_gpu(self):
        r = run_top("suite", "fs-standard", "--workdir", "/tmp/bx_dry", "--dry-run")
        self.assertEqual(r.returncode, 0)
        self.assertIn("scenario FS_GDS", r.stdout)

    def test_raw_suite_refuses_without_device(self):
        r = run_top("suite", "raw-standard")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("--raw-device", r.stderr)

    def test_raw_roundtrip_refuses_without_consent(self):
        r = run_top("roundtrip", "--storage", "raw", "--mode", "gds", "--raw-device", "/dev/null")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("i-accept-overwrite", r.stderr)


if __name__ == "__main__":
    unittest.main()
