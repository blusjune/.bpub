# BUILD_ID="Brian_20261029_144843"
"""Tests for the pre-set suites: plans, de-duplication, raw gating data, and summary output."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "subtests"))
import subtest_suite as st  # noqa: E402


class PlanTest(unittest.TestCase):
    def kinds(self, name):
        return [k for k, _ in st.plan(name)]

    def test_every_documented_suite_exists(self):
        for name in ["unit", "selftest", "smoke", "fs-standard", "fs-profile", "raw-standard", "full"]:
            self.assertIn(name, st.SUITES)

    def test_singletons_run_once_in_full(self):
        k = self.kinds("full")
        for single in ["unit", "env_chk", "build", "support"]:
            self.assertEqual(k.count(single), 1, single)

    def test_smoke_is_env_then_two_scenarios(self):
        p = st.plan("smoke")
        self.assertEqual([k for k, _ in p][:3], ["env_chk", "build", "support"])
        scen = [s for k, s in p if k == "scenarios"]
        self.assertEqual([(s["storage"], s["mode"]) for s in scen], [("fs", "posix"), ("fs", "gds")])
        self.assertEqual(scen[0]["size"], 64 * st.MiB)

    def test_fs_standard_covers_three_sizes_and_both_modes(self):
        scen = [s for k, s in st.plan("fs-standard") if k == "scenarios"]
        self.assertEqual(len(scen), 6)
        self.assertEqual({s["size"] for s in scen}, {256 * st.MiB, st.GiB, 4 * st.GiB})
        self.assertTrue(all(s["drop_caches"] for s in scen))
        self.assertEqual({s["mode"] for s in scen}, {"posix", "gds"})

    def test_fs_profile_enables_nvtx_with_one_iteration(self):
        scen = [s for k, s in st.plan("fs-profile") if k == "scenarios"]
        self.assertTrue(all(s["nvtx"] and s["iters"] == 1 for s in scen))

    def test_raw_standard_needs_raw_and_has_raw_scenarios(self):
        self.assertTrue(st.SUITES["raw-standard"]["needs_raw"])
        scen = [s for k, s in st.plan("raw-standard") if k == "scenarios"]
        self.assertTrue(all(s["storage"] == "raw" for s in scen))

    def test_full_includes_raw_and_fs(self):
        storages = {s["storage"] for k, s in st.plan("full") if k == "scenarios"}
        self.assertEqual(storages, {"fs", "raw"})

    def test_unit_suite_has_no_scenarios(self):
        self.assertEqual(self.kinds("unit"), ["unit"])

    def test_unknown_suite_raises(self):
        with self.assertRaises(KeyError):
            st.plan("nope")

    def test_describe_lists_steps(self):
        text = st.describe("smoke")
        self.assertIn("scenario FS_GDS", text)
        self.assertIn("env_chk", text)


class SummaryTest(unittest.TestCase):
    def test_summary_table_and_notes(self):
        with tempfile.TemporaryDirectory() as d:
            rows = [{"scenario": "FS_GDS", "size": 1, "iters": 1, "gds_policy": "fallback",
                     "verdict": "COMPAT_FALLBACK", "result_write_us_avg": "10",
                     "result_read_us_avg": "5", "result_verify": "ok", "rc": 0}]
            path = Path(st.write_summary(Path(d), "smoke", rows, ["skipped RAW_GDS: no --raw-device"]))
            text = path.read_text()
            self.assertIn("| FS_GDS |", text)
            self.assertIn("COMPAT_FALLBACK", text)
            self.assertIn("skipped RAW_GDS", text)


if __name__ == "__main__":
    unittest.main()
