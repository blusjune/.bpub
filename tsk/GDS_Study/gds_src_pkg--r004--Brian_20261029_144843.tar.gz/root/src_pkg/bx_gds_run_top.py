#!/usr/bin/env python3
# BUILD_ID="Brian_20261029_144843"
"""bx_gds_run_top.py - top-level entry point for the GDS experiment package.

The package runs inside its own virtual environment (root/.pyve). Create it once with `setup`.
GDS support is checked automatically: if native GDS is available, GDS scenarios run strict
(allow_compat_mode=false); otherwise they run as the compatibility fallback (allow_compat_mode=true).
Every GDS run writes test_result_<SCENARIO>.md with the verdict and its evidence.

Run `./bx_gds_run_top.py --help` for typical usage, and `<command> --help` for per-command examples.
"""
import argparse
import datetime
import json
import os
import re
import shutil
import socket
import subprocess
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parent     # .../root/src_pkg
ROOT = PKG.parent                         # .../root
VENV = ROOT / ".pyve"


def _reexec_in_venv() -> None:
    """Re-run this script with root/.pyve/bin/python3 when the venv exists and is not active."""
    py = VENV / "bin" / "python3"
    if os.environ.get("BX_IN_VENV") == "1" or not py.exists():
        return
    if Path(sys.prefix).resolve() == VENV.resolve():
        return
    os.environ["BX_IN_VENV"] = "1"
    os.execv(str(py), [str(py), str(Path(__file__).resolve())] + sys.argv[1:])


_reexec_in_venv()

sys.path.insert(0, str(PKG / "subtests"))
import subtest_env_chk    # noqa: E402
import subtest_env_dump   # noqa: E402
import subtest_roundtrip  # noqa: E402
import subtest_suite      # noqa: E402
import subtest_support    # noqa: E402
import subtest_verdict    # noqa: E402
import trace2mermaid      # noqa: E402


def build_id_line() -> str:
    """Return the BUILD_ID comment line of this file (read from the stamped header)."""
    for line in Path(__file__).read_text(errors="replace").splitlines()[:3]:
        m = re.search(r'BUILD_ID="([^"]+)"', line)
        if m:
            return f'BUILD_ID="{m.group(1)}"'
    return 'BUILD_ID="unknown"'


class BuildIdParser(argparse.ArgumentParser):
    """ArgumentParser whose --help output starts with the BUILD_ID line."""

    def print_help(self, file=None):
        print(build_id_line(), file=file or sys.stdout)
        super().print_help(file)


TYPICAL_USAGE = """\
typical usage (run from root/src_pkg):

  one-time setup
    ./bx_gds_run_top.py setup                       create root/.pyve and install numpy
    ./bx_gds_run_top.py setup --with-cupy           also install cupy-cuda13x

  check the system
    ./bx_gds_run_top.py env_chk                     libraries, versions, nvidia-fs, venv; summary
    ./bx_gds_run_top.py support --workdir /data/bx_gds
                                                    decide native GDS or compatibility fallback

  build only
    ./bx_gds_run_top.py build

  one scenario (GDS policy auto: native when supported, otherwise fallback)
    ./bx_gds_run_top.py roundtrip --storage fs --mode gds   --workdir /data/bx_gds --size 1073741824 --iters 10
    ./bx_gds_run_top.py roundtrip --storage fs --mode posix --workdir /data/bx_gds --size 1073741824 --iters 10
    ./bx_gds_run_top.py roundtrip --storage fs --mode gds --gds-policy fallback --workdir /data/bx_gds
    ./bx_gds_run_top.py roundtrip --storage fs --mode gds --gds-policy native   --workdir /data/bx_gds
    ./bx_gds_run_top.py roundtrip --storage raw --mode gds --raw-device /dev/nvme1n1p5 \\
        --size 268435456 --iters 5 --i-accept-overwrite

  pre-set suites (each writes exe_out/<host>/<ts>/suite_<name>.md)
    ./bx_gds_run_top.py suite --list
    ./bx_gds_run_top.py suite selftest                         no GPU needed
    ./bx_gds_run_top.py suite smoke --workdir /data/bx_gds
    ./bx_gds_run_top.py suite fs-standard --workdir /data/bx_gds
    ./bx_gds_run_top.py suite fs-profile --workdir /data/bx_gds
    ./bx_gds_run_top.py suite raw-standard --raw-device /dev/nvme1n1p5 --i-accept-overwrite
    ./bx_gds_run_top.py suite full --workdir /data/bx_gds --raw-device /dev/nvme1n1p5 --i-accept-overwrite
    ./bx_gds_run_top.py suite fs-standard --workdir /data/bx_gds --dry-run   print the plan only

  profiling with Nsight Systems (NVTX ranges come from --nvtx)
    nsys profile -t cuda,nvtx,osrt -o fs_gds ./bx_gds_run_top.py roundtrip \\
        --storage fs --mode gds --workdir /data/bx_gds --size 1073741824 --iters 1 --nvtx

  sequence diagrams and reports from an existing run
    ./bx_gds_run_top.py mermaid --run-dir ../exe_out/<host>/<timestamp>

  packaging (stamps BUILD_ID and increments the revision; run from root/src_pkg)
    python3 tools/make_package.py

raw block scenarios overwrite the device region. They need --raw-device /dev/<node>,
--i-accept-overwrite, and a region reserved for this test.
"""


def new_run_dir() -> Path:
    host = socket.gethostname()
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run = ROOT / "exe_out" / host / ts
    run.mkdir(parents=True, exist_ok=True)
    return run


def build(run_dir: Path) -> Path:
    if shutil.which("nvcc") is None:
        raise SystemExit("nvcc not found in PATH")
    out_dir = run_dir / "build"
    out_dir.mkdir(parents=True, exist_ok=True)
    binary = out_dir / "bx_gds_basic"
    cmd = ["nvcc", "-O2", "-std=c++14", f"-I{PKG / 'include'}",
           str(PKG / "src" / "bx_gds_basic.cu"), "-o", str(binary),
           "-lcufile", "-lcudart", "-ldl"]
    (out_dir / "build_command.txt").write_text(" ".join(cmd) + "\n")
    r = subprocess.run(cmd, capture_output=True, text=True)
    (out_dir / "build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0:
        raise SystemExit(f"build failed, see {out_dir / 'build.log'}")
    return binary


def ensure_binary(run_dir: Path) -> Path:
    binary = run_dir / "build" / "bx_gds_basic"
    return binary if binary.exists() else build(run_dir)


def check_raw_consent(storage: str, raw_device, accept: bool) -> None:
    if storage == "raw" and not accept:
        raise SystemExit("raw block scenarios overwrite the device region; pass --i-accept-overwrite "
                         "to confirm the region is dedicated to this test")


def static_support() -> dict:
    return {"libcufile": subtest_env_chk.check_cufile_lib().status == "OK",
            "nvidia_fs": subtest_env_chk.check_nvidia_fs().status == "OK"}


def resolve_gds_policy(gds_policy: str, run_dir: Path, binary: Path, workdir) -> dict:
    """native/fallback are forced. auto runs the static checks and one strict probe."""
    if gds_policy in ("native", "fallback"):
        decision = subtest_support.forced(gds_policy)
    else:
        probe_root = run_dir / "support"
        probe_root.mkdir(parents=True, exist_ok=True)
        s = subtest_roundtrip.run(probe_root, binary, "fs", "gds", subtest_support.PROBE_SIZE, 1, 0,
                                  0, 0, False, False, False, workdir=workdir or probe_root,
                                  policy="probe (strict, allow_compat_mode=false)")
        evidence = subtest_verdict.scan_cufile_logs(probe_root / "FS_GDS")
        probe = {"rc": s["rc"], "verify_ok": s.get("result_verify") == "ok",
                 "compat_direct": bool(evidence["compat_direct"]), "verdict": s.get("verdict")}
        decision = subtest_support.decide(static_support(), probe)
    (run_dir / "support").mkdir(parents=True, exist_ok=True)
    (run_dir / "support" / "decision.json").write_text(json.dumps(decision, indent=2, default=str) + "\n")
    host = socket.gethostname()
    stamp = datetime.datetime.now().isoformat(timespec="seconds")
    (run_dir / "support" / "support.md").write_text(subtest_support.render_md(decision, host, stamp))
    return decision


def run_spec(run_dir: Path, binary: Path, spec: dict, decision: dict, args) -> dict:
    """One scenario run. decision supplies allow_compat_mode for GDS runs."""
    if spec["mode"] == "gds":
        compat = decision["compat"]
        policy = subtest_support.label(decision)
    else:
        compat = 1
        policy = "posix baseline"
    return subtest_roundtrip.run(
        run_dir, binary, spec["storage"], spec["mode"], spec["size"], spec["iters"],
        spec.get("offset", 0), compat, args.p2p, spec.get("drop_caches", False),
        getattr(args, "keep", False), spec.get("nvtx", False),
        workdir=getattr(args, "workdir", None), device=getattr(args, "raw_device", None),
        policy=policy)


def add_scenario_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--workdir", type=Path,
                   help="directory for FS test files and the support probe (fs scenarios)")
    p.add_argument("--raw-device", help="block device node for raw scenarios, e.g. /dev/nvme1n1p5")
    p.add_argument("--raw-offset", type=int, default=0,
                   help="byte offset inside the raw region (multiple of 4096)")
    p.add_argument("--i-accept-overwrite", action="store_true",
                   help="required for raw scenarios: the region may be overwritten")
    p.add_argument("--gds-policy", choices=["auto", "native", "fallback"], default="auto",
                   help="auto: probe and choose; native: strict cuFile; fallback: compatibility mode")
    p.add_argument("--p2p", type=int, choices=[0, 1], default=0, help="cufile use_pci_p2pdma")
    p.add_argument("--keep", action="store_true", help="keep FS test files")


def add_roundtrip_args(p: argparse.ArgumentParser) -> None:
    add_scenario_args(p)
    p.add_argument("--size", type=int, default=1 << 30, help="bytes per transfer, multiple of 4096")
    p.add_argument("--iters", type=int, default=10)
    p.add_argument("--drop-caches", action="store_true",
                   help="sudo drop_caches before the run (O_DIRECT already bypasses page cache)")
    p.add_argument("--nvtx", action="store_true", help="enable cuFile internal NVTX ranges")


def cmd_setup(args) -> None:
    py_venv = VENV / "bin" / "python3"
    if VENV.exists() and args.force:
        shutil.rmtree(VENV)
    if not VENV.exists():
        subprocess.run([sys.executable, "-m", "venv", str(VENV)], check=True)
        print(f"created venv: {VENV}")
    else:
        print(f"venv exists: {VENV} (use --force to recreate)")
    if not args.no_pip:
        subprocess.run([str(py_venv), "-m", "pip", "install", "--upgrade", "pip"], check=False)
        reqs = [PKG / "requirements.txt"] + ([PKG / "requirements-gpu.txt"] if args.with_cupy else [])
        for req in reqs:
            subprocess.run([str(py_venv), "-m", "pip", "install", "-r", str(req)], check=True)
    print(f"ready. Use: {py_venv} or just ./bx_gds_run_top.py (it re-execs into the venv)")


def run_unit(run_dir: Path) -> dict:
    out = run_dir / "unit"
    out.mkdir(parents=True, exist_ok=True)
    r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"],
                       cwd=PKG, capture_output=True, text=True)
    (out / "unit.log").write_text(r.stdout + r.stderr)
    last = (r.stderr.strip().splitlines() or ["?"])[-1]
    print(f"unit tests: rc={r.returncode} ({last})")
    return {"scenario": "unit-tests", "rc": r.returncode, "verdict": "PASS" if r.returncode == 0 else "FAIL"}


def run_selftest_mermaid(run_dir: Path) -> dict:
    out = run_dir / "selftest"
    out.mkdir(parents=True, exist_ok=True)
    sample = PKG / "tests" / "data" / "sample_FS_GDS_trace.log"
    trace2mermaid.convert(sample, out / "trace_sequence_FS_GDS.mmd", False, True)
    ok = "sequenceDiagram" in (out / "trace_sequence_FS_GDS.mmd").read_text()
    print(f"selftest mermaid: {'ok' if ok else 'FAILED'} -> {out}")
    return {"scenario": "selftest-mermaid", "rc": 0 if ok else 1, "verdict": "PASS" if ok else "FAIL"}


def cmd_suite(args) -> None:
    if args.list:
        for name in subtest_suite.SUITES:
            print(subtest_suite.describe(name))
            print()
        return
    if not args.name:
        raise SystemExit("name a suite, or use --list. Example: ./bx_gds_run_top.py suite smoke --workdir /data/bx_gds")
    if args.name not in subtest_suite.SUITES:
        raise SystemExit(f"unknown suite {args.name!r}; choose from {', '.join(subtest_suite.SUITES)}")
    suite = subtest_suite.SUITES[args.name]
    if args.dry_run:
        print(subtest_suite.describe(args.name))
        return
    if suite["needs_raw"] and not args.raw_device:
        raise SystemExit(f"suite {args.name} needs --raw-device /dev/<node> and --i-accept-overwrite")
    if args.raw_device and not args.i_accept_overwrite:
        raise SystemExit("raw scenarios overwrite the device region; pass --i-accept-overwrite")
    if not args.workdir and any(s["storage"] == "fs" for k, s in subtest_suite.plan(args.name) if k == "scenarios"):
        raise SystemExit(f"suite {args.name} needs --workdir for FS test files")

    run = new_run_dir()
    rows, notes, decision, binary = [], [], None, None
    stages = subtest_suite.plan(args.name)
    for kind, payload in stages:
        if kind == "unit":
            rows.append(run_unit(run))
        elif kind == "selftest":
            rows.append(run_selftest_mermaid(run))
        elif kind == "env_chk":
            text = subtest_env_chk.run(run, socket.gethostname(), datetime.datetime.now().isoformat(timespec="seconds"))
            print(text, end="")
        elif kind == "build":
            binary = build(run)
            print(f"built: {binary}")
        elif kind == "support":
            binary = binary or ensure_binary(run)
            decision = resolve_gds_policy(args.gds_policy, run, binary, args.workdir)
            print(f"GDS decision: {decision['policy'].upper()} ({'; '.join(decision['reasons'])})")
        elif kind == "scenarios":
            if payload["storage"] == "raw" and not args.raw_device:
                notes.append(f"skipped {payload['storage'].upper()}_{payload['mode'].upper()}: no --raw-device")
                continue
            binary = binary or ensure_binary(run)
            if decision is None:
                decision = resolve_gds_policy(args.gds_policy, run, binary, args.workdir)
            payload = dict(payload)
            if payload["storage"] == "raw":
                payload["offset"] = args.raw_offset
            s = run_spec(run, binary, payload, decision, args)
            rows.append(s)
            print(f"{s['scenario']}: verdict={s.get('verdict', 'n/a')} rc={s['rc']} verify={s.get('result_verify')}")
    scen = [r for r in rows if "storage" in r]
    if scen:
        trace_logs = sorted(run.glob("*/trace.log"))
        for log in trace_logs:
            trace2mermaid.convert(log, None, False, True)
    path = subtest_suite.write_summary(run, args.name, rows, notes)
    print(f"suite {args.name} done. summary: {path}")
    print(f"run directory: {run}")


def main() -> None:
    ap = BuildIdParser(
        description="GDS experiment top-level driver",
        epilog=TYPICAL_USAGE,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = ap.add_subparsers(dest="stage", required=True)

    sp = sub.add_parser("setup", help="create root/.pyve and install Python packages",
                        epilog="examples:\n  ./bx_gds_run_top.py setup\n  ./bx_gds_run_top.py setup --with-cupy\n  ./bx_gds_run_top.py setup --force --with-cupy",
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    sp.add_argument("--with-cupy", action="store_true", help="also install cupy-cuda13x")
    sp.add_argument("--force", action="store_true", help="recreate the venv")
    sp.add_argument("--no-pip", action="store_true", help="create the venv only")

    sub.add_parser("env", help="capture environment state (raw dumps)")

    sub.add_parser("env_chk", help="check CUDA, cuFile, nvidia-fs, cupy and other tools; print a summary",
                   epilog="examples:\n  ./bx_gds_run_top.py env_chk",
                   formatter_class=argparse.RawDescriptionHelpFormatter)

    sup = sub.add_parser("support", help="decide native GDS or compatibility fallback (strict probe)",
                         epilog="examples:\n  ./bx_gds_run_top.py support --workdir /data/bx_gds",
                         formatter_class=argparse.RawDescriptionHelpFormatter)
    sup.add_argument("--workdir", type=Path, help="directory for the probe file (default: run directory)")

    sub.add_parser("build", help="compile bx_gds_basic into a new run directory",
                   epilog="examples:\n  ./bx_gds_run_top.py build",
                   formatter_class=argparse.RawDescriptionHelpFormatter)

    rt = sub.add_parser("roundtrip", help="run one scenario",
                        epilog=("examples:\n"
                                "  ./bx_gds_run_top.py roundtrip --storage fs --mode gds --workdir /data/bx_gds --size 1073741824 --iters 10\n"
                                "  ./bx_gds_run_top.py roundtrip --storage fs --mode posix --workdir /data/bx_gds --size 1073741824 --iters 10\n"
                                "  ./bx_gds_run_top.py roundtrip --storage fs --mode gds --gds-policy fallback --workdir /data/bx_gds\n"
                                "  ./bx_gds_run_top.py roundtrip --storage raw --mode gds --raw-device /dev/nvme1n1p5 --size 268435456 --iters 5 --i-accept-overwrite"),
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    rt.add_argument("--storage", choices=["fs", "raw"], required=True)
    rt.add_argument("--mode", choices=["gds", "posix"], required=True)
    rt.add_argument("--run-dir", type=Path, help="reuse an existing run directory")
    add_roundtrip_args(rt)

    su = sub.add_parser("suite", help="run a pre-set suite (see --list)",
                        epilog=("examples:\n"
                                "  ./bx_gds_run_top.py suite --list\n"
                                "  ./bx_gds_run_top.py suite selftest\n"
                                "  ./bx_gds_run_top.py suite smoke --workdir /data/bx_gds\n"
                                "  ./bx_gds_run_top.py suite fs-standard --workdir /data/bx_gds\n"
                                "  ./bx_gds_run_top.py suite fs-profile --workdir /data/bx_gds\n"
                                "  ./bx_gds_run_top.py suite raw-standard --raw-device /dev/nvme1n1p5 --i-accept-overwrite\n"
                                "  ./bx_gds_run_top.py suite full --workdir /data/bx_gds --raw-device /dev/nvme1n1p5 --i-accept-overwrite\n"
                                "  ./bx_gds_run_top.py suite fs-standard --workdir /data/bx_gds --dry-run"),
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    su.add_argument("name", nargs="?", help="suite name")
    su.add_argument("--list", action="store_true", help="list suites and their steps")
    su.add_argument("--dry-run", action="store_true", help="print the plan and exit")
    add_scenario_args(su)
    su.set_defaults(size=None)

    mm = sub.add_parser("mermaid", help="convert <SCENARIO>/trace.log files in a run directory",
                        epilog="examples:\n  ./bx_gds_run_top.py mermaid --run-dir ../exe_out/spark-7121/20261027_120000",
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    mm.add_argument("--run-dir", type=Path, required=True)
    mm.add_argument("--expand-sm", action="store_true", help="one arrow per warp record")

    args = ap.parse_args()

    if args.stage == "setup":
        cmd_setup(args)

    elif args.stage == "env":
        run = new_run_dir()
        subtest_env_dump.run(run)
        print(run)

    elif args.stage == "env_chk":
        run = new_run_dir()
        stamp = datetime.datetime.now().isoformat(timespec="seconds")
        text = subtest_env_chk.run(run, socket.gethostname(), stamp)
        print(text, end="")
        print(f"saved: {run / 'env_chk'}")

    elif args.stage == "support":
        run = new_run_dir()
        binary = ensure_binary(run)
        decision = resolve_gds_policy("auto", run, binary, args.workdir)
        print(f"GDS decision: {decision['policy'].upper()}  (allow_compat_mode={decision['compat']})")
        for r in decision["reasons"]:
            print(f"  - {r}")
        print(f"saved: {run / 'support'}")

    elif args.stage == "build":
        print(build(new_run_dir()))

    elif args.stage == "roundtrip":
        check_raw_consent(args.storage, args.raw_device, args.i_accept_overwrite)
        run = args.run_dir or new_run_dir()
        binary = ensure_binary(run)
        decision = resolve_gds_policy(args.gds_policy, run, binary, args.workdir) if args.mode == "gds" \
            else subtest_support.forced("fallback")
        spec = {"storage": args.storage, "mode": args.mode, "size": args.size, "iters": args.iters,
                "drop_caches": args.drop_caches, "nvtx": args.nvtx, "offset": args.raw_offset}
        s = run_spec(run, binary, spec, decision, args)
        print(json.dumps(s, indent=2))
        print(f"run directory: {run}")

    elif args.stage == "suite":
        cmd_suite(args)

    elif args.stage == "mermaid":
        logs = sorted(args.run_dir.glob("*/trace.log"))
        if not logs:
            raise SystemExit(f"no */trace.log under {args.run_dir}")
        for log in logs:
            n = trace2mermaid.convert(log, None, args.expand_sm, True)
            print(f"{n} events -> {log.parent}")


if __name__ == "__main__":
    main()
