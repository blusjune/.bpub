# BUILD_ID="Brian_20261029_144843"
"""subtest_env_dump: record host, GPU, PCIe, storage and GDS state into run_dir/env/.

gdscheck may live only under /usr/local/cuda/gds/tools; add that to PATH if it reports tool_not_found.
Failures are recorded, not fatal: the goal is an honest snapshot of the node.
"""
import json
import shutil
import subprocess
from pathlib import Path

CHECKS = [
    ("uname", ["uname", "-a"]),
    ("os_release", ["cat", "/etc/os-release"]),
    ("nvidia_smi", ["nvidia-smi"]),
    ("nvidia_topo", ["nvidia-smi", "topo", "-m"]),
    ("lspci_tree", ["lspci", "-tv"]),
    ("lspci_acs", ["sh", "-c", "lspci -vvv 2>/dev/null | grep -iE 'NVIDIA|ACSCtl' || echo 'no output (may need root)'"]),
    ("gdscheck", ["gdscheck", "-p"]),
    ("nvidia_fs_module", ["sh", "-c", "lsmod | grep -i nvidia_fs || echo 'nvidia_fs not loaded'"]),
    ("nvidia_fs_proc", ["sh", "-c", "ls -l /proc/driver/nvidia-fs 2>/dev/null || echo 'no /proc/driver/nvidia-fs'"]),
    ("cufile_json", ["sh", "-c", "cat /usr/local/cuda/gds/cufile.json 2>/dev/null || cat /etc/cufile.json 2>/dev/null || echo 'no cufile.json found'"]),
    ("nvcc_version", ["nvcc", "--version"]),
]


def run(run_dir: Path) -> dict:
    env_dir = run_dir / "env"
    env_dir.mkdir(parents=True, exist_ok=True)
    index = {}
    for name, cmd in CHECKS:
        if cmd[0] != "sh" and shutil.which(cmd[0]) is None:
            index[name] = "tool_not_found"
            (env_dir / f"{name}.txt").write_text(f"{cmd[0]} not found in PATH\n")
            continue
        r = subprocess.run(cmd, capture_output=True, text=True)
        (env_dir / f"{name}.txt").write_text(
            f"$ {' '.join(cmd)}\nrc={r.returncode}\n{r.stdout}{r.stderr}"
        )
        index[name] = r.returncode
    (env_dir / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    return index
