# BUILD_ID="Brian_20261029_144843"
"""subtest_support: decide automatically whether native GDS can be used on this system.

Decision inputs
  static : libcufile present, nvidia-fs module loaded (from subtest_env_chk checks)
  probe  : one strict cuFile round trip (allow_compat_mode=false, 4 KiB, 1 iteration).
           Strict mode fails when cuFile cannot use the native path, so the probe is the
           authoritative check. A probe that reports 'running in compatible mode' is a failure.

Outcome
  native   -> GDS scenarios run with allow_compat_mode=false (strict, native path required)
  fallback -> GDS scenarios run with allow_compat_mode=true  (POSIX compatibility mode)
"""
from datetime import datetime

PROBE_SIZE = 4096


def decide(static: dict, probe) -> dict:
    """Pure decision. static: {'libcufile': bool, 'nvidia_fs': bool}.
    probe: None, or {'rc': int, 'verify_ok': bool, 'compat_direct': bool, 'verdict': str}."""
    reasons = []
    if not static.get("libcufile"):
        reasons.append("libcufile not found in the loader cache")
    if not static.get("nvidia_fs"):
        reasons.append("nvidia-fs module not loaded (native GDS cannot run)")
    if probe is None:
        reasons.append("strict probe not run")
    else:
        if probe.get("rc") != 0 or not probe.get("verify_ok"):
            reasons.append(f"strict probe failed (rc={probe.get('rc')}, verify_ok={probe.get('verify_ok')})")
        if probe.get("compat_direct"):
            reasons.append("cuFile reported 'running in compatible mode' during the strict probe")
    native = not reasons
    return {
        "policy": "native" if native else "fallback",
        "compat": 0 if native else 1,
        "reasons": reasons or ["all checks passed: strict probe ran on the native path"],
        "static": static,
        "probe": probe,
    }


def forced(policy: str) -> dict:
    """Decision for an explicit --gds-policy native|fallback (no probe)."""
    if policy == "native":
        return {"policy": "native", "compat": 0, "reasons": ["forced by --gds-policy native"],
                "static": None, "probe": None}
    return {"policy": "fallback", "compat": 1, "reasons": ["forced by --gds-policy fallback"],
            "static": None, "probe": None}


def label(decision: dict) -> str:
    if decision["policy"] == "native":
        return "native (strict, allow_compat_mode=false)"
    return "fallback (compatibility mode, allow_compat_mode=true)"


def render_md(decision: dict, host: str, stamp: str) -> str:
    lines = [
        "# GDS support decision",
        "",
        f"- Host: {host}",
        f"- Time: {stamp}",
        f"- Decision: **{decision['policy'].upper()}**  (allow_compat_mode = {decision['compat']})",
        "",
        "## Reasons",
        "",
    ]
    lines += [f"- {r}" for r in decision["reasons"]]
    lines += ["", "## Static checks", ""]
    if decision.get("static"):
        lines += [f"- {k}: {v}" for k, v in decision["static"].items()]
    else:
        lines.append("- not evaluated (forced policy)")
    lines += ["", "## Strict probe", ""]
    p = decision.get("probe")
    if p:
        lines += [f"- rc: {p.get('rc')}", f"- verify ok: {p.get('verify_ok')}",
                  f"- cuFile reported compatible mode: {p.get('compat_direct')}",
                  f"- verdict: {p.get('verdict')}"]
    else:
        lines.append("- not run")
    lines.append("")
    return "\n".join(lines)
