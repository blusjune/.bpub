# BUILD_ID="Brian_20261029_144843"
"""subtest_verdict: decide whether a GDS scenario ran natively or fell back to compatibility mode,
and write test_result_<SCENARIO>.md into the scenario directory.

Evidence, in order of weight:
  1. cuFile's own statement in its log: 'running in compatible mode' (NOTICE). This is the direct
     self-report of the library. It is not triggered by the configuration echo lines.
  2. nvidia-fs module state: not loaded, or /proc/driver/nvidia-fs/devcount cannot be opened.
  3. nvidia-fs IO counters under /proc/driver/nvidia-fs, sampled before and after the run.
     Read/write counters increase only when the native path moves data.
  4. Platform support lines in the cuFile log ('Unsupported', 'Model Not Supported'). These explain
     why the native path is unavailable; they are reported, not used as the verdict by themselves.

Caveat: the counter layout is parsed generically and has NOT been verified on any node yet.
"""
import re
from datetime import datetime
from pathlib import Path

NVFS_BASE = Path("/proc/driver/nvidia-fs")
NUM_RE = re.compile(r"([A-Za-z_][\w ./()-]*?)\s*[:=]\s*(\d+)\b")
SKIP_LOGS = {"trace.log", "run.log"}
EVIDENCE_LIMIT = 40

PATTERNS = {
    # direct self-report of the library
    "compat_direct": re.compile(r"running in compatible mode", re.I),
    # configuration echo: present in every run, NOT evidence of fallback
    "compat_config": re.compile(r"(use|force)_compat_mode", re.I),
    # platform support explanation
    "unsupported": re.compile(r"\bUnsupported\b"),
    "model": re.compile(r"Model Not Supported", re.I),
    # nvidia-fs absence
    "devcount": re.compile(r"failed to open /proc/driver/nvidia-fs", re.I),
}


def nvfs_present(base: Path = NVFS_BASE) -> bool:
    return base.exists()


def read_nvfs_stats(base: Path = NVFS_BASE) -> dict:
    """Parse 'name: number' pairs from every readable file under the nvidia-fs proc directory."""
    out = {}
    if not base.exists():
        return out
    files = [base] if base.is_file() else sorted(p for p in base.rglob("*") if p.is_file())
    for f in files:
        try:
            text = f.read_text(errors="replace")
        except OSError:
            continue
        prefix = "" if f == base else f"{f.relative_to(base)}:"
        for line in text.splitlines():
            for key, val in NUM_RE.findall(line):
                out[f"{prefix}{key.strip()}"] = int(val)
    return out


def io_deltas(before: dict, after: dict) -> dict:
    """Counter increases for keys that look like read or write counters."""
    deltas = {}
    for k, v in after.items():
        if re.search(r"read|write", k, re.I):
            d = v - before.get(k, 0)
            if d != 0:
                deltas[k] = d
    return deltas


def scan_cufile_logs(scenario_dir: Path) -> dict:
    """Collect categorized evidence lines from cuFile log files in the scenario directory."""
    evidence = {name: [] for name in PATTERNS}
    for f in sorted(scenario_dir.glob("*.log")):
        if f.name in SKIP_LOGS:
            continue
        try:
            lines = f.read_text(errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            for name, pat in PATTERNS.items():
                if pat.search(line) and len(evidence[name]) < EVIDENCE_LIMIT:
                    evidence[name].append((f.name, line.strip()[:240]))
    return evidence


def classify(mode: str, rc: int, verify_ok: bool, nvfs_loaded: bool,
             before: dict, after: dict, evidence: dict) -> dict:
    """Return {'verdict', 'reason', 'io_deltas', 'notes', 'basis'}."""
    deltas = io_deltas(before, after)
    notes = []
    direct = bool(evidence.get("compat_direct"))
    dev_missing = bool(evidence.get("devcount"))

    def done(verdict, reason, basis):
        return {"verdict": verdict, "reason": reason, "io_deltas": deltas,
                "notes": notes, "basis": basis}

    if mode != "gds":
        return done("NOT_GDS", "POSIX baseline, no cuFile path", "scenario is not a GDS scenario")
    if rc != 0 or not verify_ok:
        return done("RUN_FAILED", f"rc={rc}, verify_ok={verify_ok}; verdict on GDS path not meaningful",
                    "run did not complete and verify")

    if direct:
        if deltas:
            notes.append("nvidia-fs counters increased although cuFile reports compatible mode; "
                         "treat the counters as unexplained until checked")
        return done("COMPAT_FALLBACK",
                    "cuFile log reports 'running in compatible mode' (direct self-report by the library)",
                    "cuFile log")
    if not nvfs_loaded:
        if dev_missing:
            notes.append("cuFile could not open /proc/driver/nvidia-fs/devcount")
        return done("COMPAT_FALLBACK",
                    "nvidia-fs is not loaded, so native GDS cannot run; cuFile used POSIX compatibility mode",
                    "nvidia-fs module state")
    if not before and not after:
        return done("UNDETERMINED", "nvidia-fs is loaded but its stats could not be parsed",
                    "none conclusive")
    if deltas:
        return done("NATIVE_GDS", "nvidia-fs read/write counters increased and cuFile did not report compat mode",
                    "nvidia-fs counters")
    return done("COMPAT_FALLBACK",
                "nvidia-fs is loaded but its read/write counters did not change during the run",
                "nvidia-fs counters (unchanged)")


def write_report(scenario_dir: Path, scenario: str, info: dict) -> Path:
    """Write test_result_<SCENARIO>.md. info keys: host, started, command, summary, verdict,
    nvfs_loaded, nvfs_before_count, nvfs_after_count, evidence, cufile_json."""
    v = info["verdict"]
    s = info["summary"]
    ev = info["evidence"]
    lines = [
        f"# test_result_{scenario}",
        "",
        f"- Generated: {datetime.now().isoformat(timespec='seconds')}",
        f"- Host: {info['host']}",
        f"- Scenario: **{scenario}**",
        f"- Started: {info['started']}",
        f"- Command: `{info['command']}`",
        f"- Requested path: {info.get('policy') or 'unspecified'}",
        f"- Return code: {s.get('rc')}",
        f"- Verify: {s.get('result_verify', 'n/a')}",
        f"- Mean write (us): {s.get('result_write_us_avg', 'n/a')}",
        f"- Mean read (us): {s.get('result_read_us_avg', 'n/a')}",
        "",
        "## Verdict",
        "",
        f"**{v['verdict']}**",
        "",
        f"Reason: {v['reason']}",
        f"Basis: {v['basis']}",
        "",
    ]
    meaning = {
        "NATIVE_GDS": "Native GDS: the nvidia-fs path moved data for this run.",
        "COMPAT_FALLBACK": "Compatibility mode: this run did NOT use the native GDS path. Results measure the POSIX fallback.",
        "UNDETERMINED": "Could not decide. Do not report this run as native or compat.",
        "RUN_FAILED": "The run failed or did not verify. Do not use it as evidence.",
        "NOT_GDS": "Not a GDS scenario.",
    }
    lines.append(meaning.get(v["verdict"], ""))
    lines += [
        "",
        "## Evidence",
        "",
        "### 1. cuFile self-report",
        "",
    ]
    lines += _bullets(ev.get("compat_direct"), "no 'running in compatible mode' line found")
    lines += ["", "### 2. nvidia-fs module state", "",
              f"- nvidia-fs module loaded: {info['nvfs_loaded']}"]
    lines += _bullets(ev.get("devcount"), "no devcount failure line found")
    lines += ["", "### 3. nvidia-fs IO counters", "",
              f"- counters parsed before/after: {info['nvfs_before_count']} / {info['nvfs_after_count']}", ""]
    if v["io_deltas"]:
        lines += ["| counter | delta |", "|---|---|"]
        lines += [f"| {k} | {d} |" for k, d in v["io_deltas"].items()]
    else:
        lines.append("No read/write counter increased.")
    lines += ["", "### 4. Platform support (cuFile log)", ""]
    lines += _bullets(ev.get("model"), "no 'Model Not Supported' line found")
    lines += _bullets(ev.get("unsupported"), "no 'Unsupported' line found")
    lines += ["", "### 5. Configuration echo (not evidence)", ""]
    lines += _bullets(ev.get("compat_config"), "no configuration echo found")
    if v["notes"]:
        lines += ["", "## Notes", ""] + [f"- {n}" for n in v["notes"]]
    lines += [
        "",
        "## Method and limits",
        "",
        "- Verdict priority: cuFile self-report, then nvidia-fs module state, then IO counters.",
        "- The configuration echo lines appear in every run and do not count as evidence.",
        "- The nvidia-fs counter layout was parsed generically. Not yet verified on any node.",
        "- A zero counter delta is evidence of compat mode only if no other process used nvidia-fs during the run.",
        f"- cuFile configuration used for this run: `{info['cufile_json']}`.",
        "- Raw dumps: `run.log`, `trace.log`, `summary.json`, `command.txt` in this directory.",
        "",
    ]
    path = scenario_dir / f"test_result_{scenario}.md"
    path.write_text("\n".join(lines))
    return path


def _bullets(items, empty_text: str) -> list:
    if not items:
        return [f"- {empty_text}"]
    return [f"- `{name}`: {text}" for name, text in items]
