#!/usr/bin/env python3
# BUILD_ID="Brian_20261027_223042"
"""make_package.py - stamp BUILD_ID into development sources and create the package tarball.

BUILD_ID format : Brian_%Y%m%d_%H%M%S   (local time at packaging)
Tarball name    : ${file_name_radix}--r<3-digit-revision>--${BUILD_ID}.tar.gz
                  e.g. gds_src_pkg--r001--Brian_20261027_134000.tar.gz
Revision        : kept in tools/revision.txt; each packaging increments it (r001, r002, ...).

Stamping rule:
  - Every development source file (.py .cu .cuh .h .mmd .sh) under src_pkg gets
    BUILD_ID="<id>" as its first comment line (after a shebang, if present).
  - An existing BUILD_ID line in the first three lines is replaced, not duplicated.
  - Markdown, JSON and other non-source files are not stamped.

Usage:
  python3 tools/make_package.py                       # writes ./dist if /mnt/user-data/outputs is absent
  python3 tools/make_package.py --out-dir /path/out
  python3 tools/make_package.py --build-id Brian_20261027_133500   # reuse an existing id
  python3 tools/make_package.py --no-stamp            # tarball only
  python3 tools/make_package.py --revision 7          # set the revision explicitly
"""
import argparse
import re
import sys
import datetime
import tarfile
from pathlib import Path


def build_id_line() -> str:
    """Return the BUILD_ID comment line of this file (read from the stamped header)."""
    for line in Path(__file__).read_text(errors="replace").splitlines()[:3]:
        m = re.search(r'BUILD_ID="([^"]+)"', line)
        if m:
            return f'BUILD_ID="{m.group(1)}"'
    return 'BUILD_ID="unknown"'


class BuildIdParser(argparse.ArgumentParser):
    """ArgumentParser whose --help output starts with the BUILD_ID line."""

    def print_help(self, file=None):
        print(build_id_line(), file=file or sys.stdout)
        super().print_help(file)

PKG = Path(__file__).resolve().parent.parent   # .../root/src_pkg
FILE_NAME_RADIX = "gds_src_pkg"
STAMP_SUFFIXES = {".py", ".cu", ".cuh", ".h", ".mmd", ".sh"}
SKIP_DIRS = {"__pycache__", "build", "exe_out", "dist"}
DEFAULT_OUT = Path("/mnt/user-data/outputs")
REVISION_FILE = PKG / "tools" / "revision.txt"


def make_build_id(now=None) -> str:
    now = now or datetime.datetime.now()
    return now.strftime("Brian_%Y%m%d_%H%M%S")


def comment_line(suffix: str, body: str) -> str:
    if suffix in (".cu", ".cuh", ".h"):
        return f"/* {body} */"
    if suffix == ".mmd":
        return f"%% {body}"
    return f"# {body}"          # .py, .sh


def stamp_file(path: Path, build_id: str) -> bool:
    lines = path.read_text(errors="replace").splitlines(keepends=True)
    new = comment_line(path.suffix, f'BUILD_ID="{build_id}"') + "\n"
    head = [i for i, line in enumerate(lines[:3]) if "BUILD_ID=" in line]
    if head:
        lines[head[0]] = new
    else:
        lines.insert(1 if lines and lines[0].startswith("#!") else 0, new)
    path.write_text("".join(lines))
    return True


def source_files(root: Path):
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.suffix not in STAMP_SUFFIXES:
            continue
        if any(part in SKIP_DIRS for part in p.relative_to(root).parts):
            continue
        yield p


def next_revision(explicit=None, path: Path = REVISION_FILE) -> int:
    """Increment the stored revision (or take the explicit one) and store it back."""
    if explicit is not None:
        n = explicit
    else:
        last = int(path.read_text().strip()) if path.exists() else 0
        n = last + 1
    if not 1 <= n <= 999:
        raise SystemExit(f"revision must be 1..999, got {n}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"{n}\n")
    return n


def make_tarball(root: Path, out_dir: Path, build_id: str, revision: int) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    tar_path = out_dir / f"{FILE_NAME_RADIX}--r{revision:03d}--{build_id}.tar.gz"
    def keep(ti: tarfile.TarInfo):
        parts = Path(ti.name).parts
        return None if any(p in SKIP_DIRS for p in parts) else ti
    with tarfile.open(tar_path, "w:gz") as tf:
        tf.add(root, arcname="root/src_pkg", filter=keep)
    return tar_path


def main() -> None:
    ap = BuildIdParser(description="stamp BUILD_ID and create the package tarball")
    ap.add_argument("--out-dir", type=Path)
    ap.add_argument("--build-id")
    ap.add_argument("--no-stamp", action="store_true")
    ap.add_argument("--revision", type=int, help="explicit revision number (1..999)")
    args = ap.parse_args()

    build_id = args.build_id or make_build_id()
    out_dir = args.out_dir or (DEFAULT_OUT if DEFAULT_OUT.exists() else Path.cwd() / "dist")
    revision = next_revision(args.revision)
    print(f"revision: r{revision:03d}")

    if not args.no_stamp:
        stamped = [p.relative_to(PKG).as_posix() for p in source_files(PKG) if stamp_file(p, build_id)]
        print(f"stamped {len(stamped)} files with BUILD_ID={build_id}")
        for name in stamped:
            print(f"  {name}")

    tar_path = make_tarball(PKG, out_dir, build_id, revision)
    print(f"package: {tar_path}")


if __name__ == "__main__":
    main()
