#!/usr/bin/env python3
# BUILD_ID="Brian_20261027_223042"
"""bx_gds_run_top.py - top-level entry point for the GDS experiment package.

Scenarios (each writes to exe_out/<host>/<ts>/<SCENARIO>/):
  FS_GDS     file system data, cuFile (GDS) path
  FS_POSIX   file system data, POSIX bounce baseline
  RAW_GDS    raw block device region, cuFile (GDS) path     DESTROYS data in the region
  RAW_POSIX  raw block device region, POSIX bounce baseline  DESTROYS data in the region

Stages:
  env        capture host, GPU, PCIe, storage and GDS state
  env_chk    check CUDA, cuFile, nvidia-fs, cupy, nsys and other libraries/tools; print a summary
  build      compile src/bx_gds_basic.cu with nvcc
  roundtrip  run one scenario (--storage fs|raw, --mode gds|posix)
  all        env -> build -> FS_GDS, FS_POSIX -> (RAW_GDS, RAW_POSIX if --raw-device) -> mermaid
  mermaid    convert every <SCENARIO>/trace.log under a run directory

Examples:
  # File system scenarios only
  ./bx_gds_run_top.py all --workdir /data/bx_gds --size 1073741824 --iters 10 --drop-caches --nvtx

  # Raw block scenarios too (region must be dedicated to this test)
  ./bx_gds_run_top.py all --workdir /data/bx_gds --raw-device /dev/nvme1n1p5 --raw-offset 0 \
      --size 1073741824 --iters 10 --i-accept-overwrite

  # One raw GDS run
  ./bx_gds_run_top.py roundtrip --storage raw --mode gds --raw-device /dev/nvme1n1p5 \
      --size 268435456 --iters 5 --i-accept-overwrite

  # Mermaid for an existing run directory
  ./bx_gds_run_top.py mermaid --run-dir ../exe_out/dgxspark/20261024_120000
"""
import argparse
import re
import sys
import datetime
import json
import shutil
import socket
import subprocess
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parent   # .../root/src_pkg
ROOT = PKG.parent                       # .../root
sys.path.insert(0, str(PKG / "subtests"))
import subtest_env_chk    # noqa: E402
import subtest_env_dump   # noqa: E402
import subtest_roundtrip  # noqa: E402
import trace2mermaid      # noqa: E402


def build_id_line() -> str:
    """Return the BUILD_ID comment line of this file (read from the stamped header)."""
    for line in Path(__file__).read_text(errors="replace").splitlines()[:3]:
        m = re.search(r'BUILD_ID="([^"]+)"', line)
        if m:
            return f'BUILD_ID="{m.group(1)}"'
    return 'BUILD_ID="unknown"'


class BuildIdParser(argparse.ArgumentParser):
    """ArgumentParser whose --help output starts with the BUILD_ID line."""

    def print_help(self, file=None):
        print(build_id_line(), file=file or sys.stdout)
        super().print_help(file)


def new_run_dir() -> Path:
    host = socket.gethostname()
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run = ROOT / "exe_out" / host / ts
    run.mkdir(parents=True, exist_ok=True)
    return run


def build(run_dir: Path) -> Path:
    if shutil.which("nvcc") is None:
        raise SystemExit("nvcc not found in PATH")
    out_dir = run_dir / "build"
    out_dir.mkdir(parents=True, exist_ok=True)
    binary = out_dir / "bx_gds_basic"
    cmd = ["nvcc", "-O2", "-std=c++14", f"-I{PKG / 'include'}",
           str(PKG / "src" / "bx_gds_basic.cu"), "-o", str(binary),
           "-lcufile", "-lcudart", "-ldl"]
    (out_dir / "build_command.txt").write_text(" ".join(cmd) + "\n")
    r = subprocess.run(cmd, capture_output=True, text=True)
    (out_dir / "build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0:
        raise SystemExit(f"build failed, see {out_dir / 'build.log'}")
    return binary


def ensure_binary(run_dir: Path) -> Path:
    binary = run_dir / "build" / "bx_gds_basic"
    return binary if binary.exists() else build(run_dir)


def check_raw_consent(args) -> None:
    if args.storage_raw_requested and not args.i_accept_overwrite:
        raise SystemExit("raw block scenarios overwrite the device region; "
                         "pass --i-accept-overwrite to confirm the region is dedicated to this test")


def add_roundtrip_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--workdir", type=Path, help="directory for FS test files (fs scenarios)")
    p.add_argument("--raw-device", help="block device node for raw scenarios, e.g. /dev/nvme1n1p5")
    p.add_argument("--raw-offset", type=int, default=0,
                   help="byte offset inside the raw device region (multiple of 4096)")
    p.add_argument("--i-accept-overwrite", action="store_true",
                   help="required for raw scenarios: confirms the region may be overwritten")
    p.add_argument("--size", type=int, default=1 << 30, help="bytes per transfer, multiple of 4096")
    p.add_argument("--iters", type=int, default=10)
    p.add_argument("--compat", type=int, choices=[0, 1], default=1,
                   help="cufile allow_compat_mode (0 = strict GDS, no fallback)")
    p.add_argument("--p2p", type=int, choices=[0, 1], default=0, help="cufile use_pci_p2pdma")
    p.add_argument("--drop-caches", action="store_true",
                   help="sudo drop_caches before the run (O_DIRECT already bypasses page cache)")
    p.add_argument("--keep", action="store_true", help="keep FS test files")
    p.add_argument("--nvtx", action="store_true", help="enable cuFile internal NVTX ranges")


def run_scenario(run_dir, binary, storage, mode, args):
    return subtest_roundtrip.run(
        run_dir, binary, storage, mode, args.size, args.iters, args.raw_offset,
        args.compat, args.p2p, args.drop_caches, args.keep, args.nvtx,
        workdir=args.workdir, device=args.raw_device)


def main() -> None:
    ap = BuildIdParser(description="GDS experiment top-level driver",
                                 epilog=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="stage", required=True)
    sub.add_parser("env", help="capture environment state")
    sub.add_parser("env_chk", help="check GDS libraries and tools and print a summary")
    sub.add_parser("build", help="compile bx_gds_basic")
    rt = sub.add_parser("roundtrip", help="run one scenario")
    rt.add_argument("--storage", choices=["fs", "raw"], required=True)
    rt.add_argument("--mode", choices=["gds", "posix"], required=True)
    rt.add_argument("--run-dir", type=Path, help="reuse an existing run directory")
    add_roundtrip_args(rt)
    al = sub.add_parser("all", help="env + build + all configured scenarios + mermaid")
    add_roundtrip_args(al)
    mm = sub.add_parser("mermaid", help="convert <SCENARIO>/trace.log files to mermaid")
    mm.add_argument("--run-dir", type=Path, required=True)
    mm.add_argument("--expand-sm", action="store_true")
    args = ap.parse_args()

    if args.stage == "env":
        run = new_run_dir()
        subtest_env_dump.run(run)
        print(run)

    elif args.stage == "env_chk":
        run = new_run_dir()
        stamp = datetime.datetime.now().isoformat(timespec="seconds")
        text = subtest_env_chk.run(run, socket.gethostname(), stamp)
        print(text, end="")
        print(f"saved: {run / 'env_chk'}")

    elif args.stage == "build":
        print(build(new_run_dir()))

    elif args.stage == "roundtrip":
        args.storage_raw_requested = args.storage == "raw"
        check_raw_consent(args)
        run = args.run_dir or new_run_dir()
        binary = ensure_binary(run)
        s = run_scenario(run, binary, args.storage, args.mode, args)
        print(json.dumps(s, indent=2))

    elif args.stage == "all":
        run = new_run_dir()
        subtest_env_dump.run(run)
        binary = build(run)
        plan = [("fs", "gds"), ("fs", "posix")]
        args.storage_raw_requested = args.raw_device is not None
        check_raw_consent(args)
        if args.raw_device:
            plan += [("raw", "gds"), ("raw", "posix")]
        results = {}
        for storage, mode in plan:
            s = run_scenario(run, binary, storage, mode, args)
            results[s["scenario"]] = s
        (run / "manifest.json").write_text(json.dumps(results, indent=2) + "\n")
        for log in sorted(run.glob("*/trace.log")):
            trace2mermaid.convert(log, None, False, True)   # 'all' has no --expand-sm
        print(run)

    elif args.stage == "mermaid":
        logs = sorted(args.run_dir.glob("*/trace.log"))
        if not logs:
            raise SystemExit(f"no */trace.log under {args.run_dir}")
        for log in logs:
            n = trace2mermaid.convert(log, None, args.expand_sm, True)
            print(f"{n} events -> {log.parent}")


if __name__ == "__main__":
    main()
