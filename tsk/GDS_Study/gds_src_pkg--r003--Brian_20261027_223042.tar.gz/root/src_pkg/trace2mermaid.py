#!/usr/bin/env python3
# BUILD_ID="Brian_20261027_223042"
"""trace2mermaid.py - convert a BXTRACE log into a mermaid sequenceDiagram, one scenario per file.

Input : trace.log from bx_gds_basic (non-BXTRACE lines ignored; old 6-field lines accepted)
Output: trace_sequence_<SCENARIO>.mmd next to the input (or trace_sequence.mmd for old logs),
        unless -o is given

Usage:
  python3 trace2mermaid.py <SCENARIO_DIR>/trace.log
  python3 trace2mermaid.py trace.log -o out.mmd --expand-sm
  python3 trace2mermaid.py trace.log --no-time --no-notes

Drawing rules:
  - The scenario name comes from the Main event (scenario=...) and is shown as a comment.
  - Phase markers (init, write, read, verify, cleanup) are drawn as notes over the user app,
    with a %% separator line, so phases are visually separate.
  - Each event gets a %% comment with its source location (file:line).
  - Host API events are drawn as CPU_APP->>component calls, with a "Note right of" file:line.
  - CPU_APP events are notes on the app participant, with file:line appended.
  - SM records are grouped per consecutive run with the same label into one arrow
    CUDA_RT->>SM, with a note listing the probe call-site line(s). --expand-sm draws one arrow per warp.
  - Delta times use host timestamps; SM record times are host emit times, not GPU time.
"""
import argparse
import sys
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


def build_id_line() -> str:
    """Return the BUILD_ID comment line of this file (read from the stamped header)."""
    for line in Path(__file__).read_text(errors="replace").splitlines()[:3]:
        m = re.search(r'BUILD_ID="([^"]+)"', line)
        if m:
            return f'BUILD_ID="{m.group(1)}"'
    return 'BUILD_ID="unknown"'


class BuildIdParser(argparse.ArgumentParser):
    """ArgumentParser whose --help output starts with the BUILD_ID line."""

    def print_help(self, file=None):
        print(build_id_line(), file=file or sys.stdout)
        super().print_help(file)

PREFIX = "BXTRACE|"
SM_RE = re.compile(r"sm=(\d+):warpslot=(\d+):lane=(\d+)")
SRC_RE = re.compile(r"^[\w.\-]+:\d+$")
SCENARIO_RE = re.compile(r"scenario=(\w+)")
PHASE_RE = re.compile(r"name=(\w+)")
APP = "CPU_APP"
SM = "SM"

# component -> (display name, execution location). Location is shown in every participant label.
COMPONENTS = {
    "CPU_APP":      ("User app", "CPU"),
    "CUDA_RT":      ("CUDA runtime", "CPU"),
    "CUFILE_LIB":   ("cuFile library", "CPU user space"),
    "POSIX_FS":     ("POSIX file API", "CPU kernel"),
    "POSIX_BOUNCE": ("POSIX bounce I/O", "CPU"),
    "BLK_DEV":      ("Block device node", "CPU kernel"),
    "SM":           ("GPU SM probe", "GPU"),
    # components below are not emitted by bx_gds_basic yet; listed so the names stay consistent
    "CE":           ("GPU copy engine", "GPU"),
    "NVFS_KMOD":    ("nvidia-fs module", "CPU kernel"),
    "NVME_DRIVER":  ("NVMe driver", "CPU kernel"),
    "SSD_DMA":      ("NVMe SSD DMA engine", "SSD"),
    "PCIE_ROOT":    ("PCIe root complex", "hardware"),
    "IOMMU":        ("IOMMU", "hardware"),
}


def participant_label(comp: str) -> str:
    name, loc = COMPONENTS.get(comp, (comp, "location unknown"))
    return f"{name} ({loc})"


@dataclass
class Event:
    ts: int
    where: str
    comp: str
    step: str
    src: str   # "file.cu:line", or "" for old-format lines
    msg: str

    @property
    def is_sm(self) -> bool:
        return self.where.startswith("GPU:")

    @property
    def is_phase(self) -> bool:
        return self.comp == APP and self.step == "Phase"


def parse(path: Path) -> List[Event]:
    events = []
    for raw in path.read_text(errors="replace").splitlines():
        if not raw.startswith(PREFIX):
            continue
        parts = raw.split("|", 6)
        if len(parts) == 7 and SRC_RE.match(parts[5]):
            _, ts, where, comp, step, src, msg = parts
        else:
            parts = raw.split("|", 5)   # old format: message may contain '|'
            if len(parts) != 6:
                continue
            _, ts, where, comp, step, msg = parts
            src = ""
        try:
            ts_i = int(ts)
        except ValueError:
            continue
        events.append(Event(ts_i, where, comp, step, src, msg))
    return events


def scenario_of(events: List[Event]) -> Optional[str]:
    for e in events:
        if e.comp == APP and e.step == "Main":
            m = SCENARIO_RE.search(e.msg)
            if m:
                return m.group(1)
    return None


def clean(text: str, limit: int = 90) -> str:
    """Make text safe for mermaid sequence labels."""
    text = text.replace("|", "/")
    for ch in ';#<>"':
        text = text.replace(ch, " ")
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 3] + "..."


def sm_group_key(e: Event) -> str:
    return " ".join(e.msg.split()[:2])   # label=<x> tag=<n>


def sm_index(e: Event):
    m = SM_RE.search(e.where)
    return (int(m.group(1)), int(m.group(2))) if m else (-1, -1)


def to_mermaid(events: List[Event], expand_sm: bool = False,
               show_time: bool = True, notes: bool = True) -> str:
    scenario = scenario_of(events)
    order = [APP]
    for e in events:
        if e.is_phase:
            continue
        target = SM if e.is_sm else e.comp
        if target not in order:
            order.append(target)
    # SM arrows are drawn from CUDA_RT (the launcher), so it must be declared even if no host event names it
    if SM in order and "CUDA_RT" not in order:
        order.insert(order.index(SM), "CUDA_RT")

    lines = ["sequenceDiagram", "    autonumber"]
    if scenario:
        lines.insert(1, f"    %% scenario={scenario}")
    for p in order:
        lines.append(f"    participant {p} as {participant_label(p)}")

    prev_ts = None
    i, n = 0, len(events)
    while i < n:
        e = events[i]
        delta = f"+{e.ts - prev_ts}us " if (show_time and prev_ts is not None) else ""

        if e.is_phase:
            m = PHASE_RE.search(e.msg)
            phase = m.group(1) if m else "unknown"
            lines.append(f"    %% ===== PHASE {phase} =====")
            lines.append(f"    Note over {APP}: PHASE {phase}")
            prev_ts = e.ts
            i += 1
            continue

        if e.is_sm:
            key = sm_group_key(e)
            group = []
            j = i
            while j < n and events[j].is_sm and sm_group_key(events[j]) == key:
                group.append(events[j])
                j += 1
            src_lines = sorted({g.src for g in group if g.src})
            src_txt = ", ".join(src_lines) if src_lines else "src unknown"
            if expand_sm:
                for g in group:
                    sm, slot = sm_index(g)
                    lines.append(f"    %% {g.src or 'src unknown'}  ProbeWarp sm={sm} slot={slot}")
                    lines.append(f"    {APP}->>{SM}: {delta}warp sm={sm} slot={slot} {clean(key)}")
                    if notes:
                        lines.append(f"    Note right of {SM}: {g.src or 'src unknown'}")
                    delta = ""
            else:
                sms = sorted({sm_index(g)[0] for g in group})
                lines.append(f"    %% {src_txt}  ProbeWarp x{len(group)}")
                lines.append(f"    CUDA_RT->>{SM}: {delta}ProbeWarp x{len(group)} on SM "
                             f"{','.join(str(s) for s in sms)} ({clean(key)})")
                if notes:
                    lines.append(f"    Note right of {SM}: {src_txt}")
            prev_ts = group[-1].ts
            i = j
            continue

        src_txt = e.src or "src unknown"
        lines.append(f"    %% {src_txt}  {clean(e.comp)}.{clean(e.step)}")
        if e.comp == APP:
            extra = f"  [{src_txt}]" if notes else ""
            lines.append(f"    Note over {APP}: {delta}{clean(e.step)} {clean(e.msg)}{extra}")
        else:
            lines.append(f"    {APP}->>{e.comp}: {delta}{clean(e.step)} {clean(e.msg)}")
            if notes:
                lines.append(f"    Note right of {e.comp}: {src_txt}")
        prev_ts = e.ts
        i += 1

    return "\n".join(lines) + "\n"


def convert(trace: Path, out: Path = None, expand_sm: bool = False,
            show_time: bool = True, notes: bool = True) -> int:
    events = parse(trace)
    if not events:
        raise SystemExit(f"no BXTRACE events in {trace}")
    if out is None:
        sc = scenario_of(events)
        out = trace.with_name(f"trace_sequence_{sc}.mmd" if sc else "trace_sequence.mmd")
    out.write_text(to_mermaid(events, expand_sm, show_time, notes))
    return len(events)


def main() -> None:
    ap = BuildIdParser(description="BXTRACE log -> mermaid sequence diagram",
                                 epilog=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("trace", type=Path)
    ap.add_argument("-o", "--out", type=Path)
    ap.add_argument("--expand-sm", action="store_true", help="one arrow per warp record")
    ap.add_argument("--no-time", action="store_true", help="omit delta-time labels")
    ap.add_argument("--no-notes", action="store_true", help="omit file:line notes (keep %% comments)")
    args = ap.parse_args()
    count = convert(args.trace, args.out, args.expand_sm, not args.no_time, not args.no_notes)
    print(f"{count} events -> {args.out or args.trace.parent}")


if __name__ == "__main__":
    main()
