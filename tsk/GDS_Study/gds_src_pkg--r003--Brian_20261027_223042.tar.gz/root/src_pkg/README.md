# src_pkg: GDS (GPU Direct Storage) experiment package

## Layout
- bx_gds_run_top.py                 top-level driver (env, build, roundtrip, all)
- include/bx_trace.h                BXTRACE(): host event with CPU core and thread id; NVTX range macros;
                                    device record struct and host formatter
- include/bx_trace_dev.cuh          bx_dev_probe(): reads %smid, %warpid, %laneid, %globaltimer in kernels
- src/bx_gds_basic.cu               cuFile (gds) or POSIX bounce (posix) round trip with probes
- subtests/subtest_env_dump.py      host, GPU, PCIe, storage, GDS state
- subtests/subtest_roundtrip.py     generates cufile.json from the installed config, runs binary

Outputs: ../exe_out/<hostname>/<timestamp>/ (never in src_pkg).

## Scenarios
Each scenario has its own directory, trace.log, and sequence diagram.
- FS_GDS    file system data, cuFile path        (docs/diagrams/fs_gds_scenario.mmd)
- FS_POSIX  file system data, POSIX bounce        (baseline)
- RAW_GDS   raw block device region, cuFile path  (docs/diagrams/raw_gds_scenario.mmd), DESTROYS region data
- RAW_POSIX raw block device region, POSIX bounce (baseline), DESTROYS region data

The Main event carries scenario=..., storage=..., mode=...; Phase events mark init, write, read, verify, cleanup.
trace2mermaid writes trace_sequence_<SCENARIO>.mmd per directory.
Raw scenarios require --raw-device /dev/<node> and --i-accept-overwrite.

## Trace line formats
Host event:
    BXTRACE|<monotonic_us>|CPU:core=<n>:tid=<t>|<component>|<step>|<file>:<line>|<message>
Device (SM) event, printed by the host from kernel-written records:
    BXTRACE|<host_emit_us>|GPU:sm=<smid>:warpslot=<w>:lane=<l>|SM|ProbeWarp|<file>:<line>|label=... tag=... gtimer_ns=...
<file> is the source basename; <line> is the BXTRACE or BX_DEV_PROBE call site.
Old 6-field logs remain readable by trace2mermaid.py (src shown as "src unknown").
`gtimer_ns` is the GPU clock. `host_emit_us` is when the host printed the record, not when the warp ran.
Clock alignment between the two is not established by this code; treat cross-clock ordering as approximate.

## Execution location and observability
| Component       | Where it executes                              | Observable with BXTRACE | Observable with                    |
|-----------------|------------------------------------------------|-------------------------|------------------------------------|
| CPU_APP         | host thread, core recorded                     | yes (core, tid)         | -                                  |
| CUDA_RT         | host call; the work runs on the GPU            | call + return only      | nsys (CUDA API and kernel rows)     |
| SM (probe)      | GPU streaming multiprocessor, warp slot        | yes (smid, warpslot)    | nsys, Nsight Compute                |
| Copy engine     | GPU DMA engine for cudaMemcpy                  | no                      | nsys (memcpy rows, bytes, duration) |
| CUFILE_LIB      | host user library                              | call + return           | NVTX ranges (--nvtx)                |
| NVFS_KMOD       | host kernel module (nvidia-fs)                 | no                      | ftrace / perf, /proc/driver/nvidia-fs |
| POSIX_FS / BOUNCE | host kernel (page cache bypassed by O_DIRECT) | call + return           | strace, perf                        |
| SSD DMA         | NVMe controller DMA                            | no                      | blktrace / iostat, NVMe tracepoints |
| PCIe root / IOMMU / MMU | hardware / kernel translation          | no                      | lspci (ACS), IOMMU config, perf, PCIe analyzer |

NVTX ranges mark host-side intervals on the nsys timeline. They do not carry GPU subsystem identity.
The only GPU-internal location available from user code here is the SM and warp slot (from PTX special registers).

## Status
- CUfileDrvProps_t field names verified against the installed cufile.h.
- cufile.json keys (allow_compat_mode, use_pci_p2pdma, profile.nvtx) verified against the installed cufile.json.
- Not yet compiled on the target nodes: the probe kernel and the NVTX include path (nvtx3/nvToolsExt.h).
  If nvtx3 is not present, BXRANGE macros become no-ops automatically.

## Additional components
- trace2mermaid.py                 BXTRACE log -> mermaid sequenceDiagram (also: bx_gds_run_top.py mermaid)
- tests/test_trace2mermaid.py      unit tests: python3 -m unittest discover -s tests -v
- docs/diagrams/architecture_layers.mmd   layered view (unverified nodes marked)
- docs/diagrams/scenario_gds_write.mmd, scenario_gds_read.mmd   hypothesized API-level flows
- docs/diagrams/scenario_posix_bounce.mmd  code-accurate posix path
- docs/doe/DOE.md                  design of experiments for both nodes
- docs/report/GDS_technical_report.md   draft report; [CITE] entries pending

## Run order
1. ./bx_gds_run_top.py env
2. ./bx_gds_run_top.py all --workdir <nvme mount> --size 1073741824 --iters 10 --drop-caches --nvtx
   (add --raw-device /dev/<node> --i-accept-overwrite to include RAW_GDS and RAW_POSIX)
3. ./bx_gds_run_top.py mermaid --run-dir ../exe_out/<host>/<ts>
4. python3 -m unittest discover -s tests -v   (any time, no GPU needed)

Status of the raw scenarios: the code path is written, but cuFile support for a raw block device fd
and the device node to use on each node are not verified. Check the first run's cuFile log and trace.

## Handoff
See docs/HANDOFF.md for instructions, status, lessons learned, and open items.

## Packaging and BUILD_ID
- Every development source file (.py, .cu, .cuh, .h, .mmd, .sh) carries `BUILD_ID="Brian_%Y%m%d_%H%M%S"` as its first comment line.
- Create the package with `python3 tools/make_package.py`. It stamps the sources and writes `gds_src_pkg--r<NNN>--<BUILD_ID>.tar.gz`.
- The tarball contains `src_pkg/` only. Run results under `exe_out/` are not packaged.
