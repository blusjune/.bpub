# BUILD_ID="Brian_20261027_223042"
"""subtest_env_chk: check the libraries and tools the GDS experiments need, and render a summary.

Statuses:  OK (present, version read)  WARN (present but not verifiable / optional)  MISSING (required)
Nothing here changes the system. All checks are read-only.
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

CUFILE_JSON_CANDIDATES = [Path("/usr/local/cuda/gds/cufile.json"), Path("/etc/cufile.json")]
GDSCHECK_CANDIDATES = [Path("/usr/local/cuda/gds/tools/gdscheck.py"), Path("/usr/local/cuda/gds/tools/gdscheck")]


def _run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr).strip()
    except FileNotFoundError:
        return None, "not found"
    except subprocess.TimeoutExpired:
        return None, "timeout"


def _ldconfig_find(name: str) -> list:
    rc, out = _run(["ldconfig", "-p"])
    if rc != 0:
        return []
    return [line.split("=>")[-1].strip() for line in out.splitlines() if name in line]


def _check(name, status, version="", detail=""):
    return {"name": name, "status": status, "version": version, "detail": detail}


def check_python():
    return _check("python", "OK", sys.version.split()[0], sys.executable)


def check_nvcc():
    if shutil.which("nvcc") is None:
        return _check("CUDA toolkit (nvcc)", "MISSING", "", "nvcc not in PATH")
    _, out = _run(["nvcc", "--version"])
    m = re.search(r"release (\d+\.\d+)", out)
    return _check("CUDA toolkit (nvcc)", "OK", m.group(1) if m else "unknown", "nvcc --version parsed")


def check_gpu():
    if shutil.which("nvidia-smi") is None:
        return _check("NVIDIA driver / GPU", "MISSING", "", "nvidia-smi not in PATH")
    rc, out = _run(["nvidia-smi", "--query-gpu=name,driver_version,compute_cap", "--format=csv,noheader"])
    if rc != 0 or not out:
        return _check("NVIDIA driver / GPU", "MISSING", "", out or "no output")
    first = out.splitlines()[0]
    parts = [p.strip() for p in first.split(",")]
    return _check("NVIDIA driver / GPU", "OK", parts[1] if len(parts) > 1 else "unknown", " | ".join(parts))


def check_cudart():
    paths = _ldconfig_find("libcudart.so")
    if not paths:
        return _check("CUDA runtime (libcudart)", "MISSING", "", "not in ldconfig cache")
    m = re.search(r"libcudart\.so\.([\d.]+)", paths[0])
    return _check("CUDA runtime (libcudart)", "OK", m.group(1) if m else "unknown", paths[0])


def check_cufile_lib():
    paths = _ldconfig_find("libcufile.so")
    if not paths:
        return _check("cuFile library (libcufile)", "MISSING", "", "not in ldconfig cache; install GDS (gds-tools)")
    m = re.search(r"libcufile\.so\.([\d.]+)", paths[0])
    soname = m.group(1) if m else "unknown"
    # libcufile.so.0 is only the soname; the package version is the meaningful one
    pkg_ver = _gds_tools_version()
    version = pkg_ver if (pkg_ver and "." not in soname) else soname
    return _check("cuFile library (libcufile)", "OK", version, f"{paths[0]} (soname {soname})")


def _gds_tools_version():
    rc, out = _run(["dpkg-query", "-W", "-f", "${Package} ${Version}\\n", "gds-tools-*"])
    for line in out.splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[0].startswith("gds-tools-"):
            return parts[1]
    return None


def check_cufile_header():
    hdr = Path("/usr/local/cuda/include/cufile.h")
    if not hdr.exists():
        return _check("cuFile header", "MISSING", "", str(hdr))
    text = hdr.read_text(errors="replace")
    m = re.search(r"#define\s+CUFILE_VERSION\s+(\S+)", text)
    if m:
        return _check("cuFile header", "OK", m.group(1), str(hdr))
    return _check("cuFile header", "WARN", "unknown", f"{hdr} present, no CUFILE_VERSION macro")


def check_gds_packages():
    rc, out = _run(["dpkg-query", "-W", "-f", "${Package} ${Version}\\n", "*gds*"])
    lines = [l for l in out.splitlines() if l.strip() and "no packages" not in l.lower()] if rc is not None else []
    if not lines:
        return _check("GDS packages (dpkg)", "WARN", "", "no *gds* package found by dpkg-query")
    return _check("GDS packages (dpkg)", "OK", lines[0].split()[-1], "; ".join(lines[:4]))


def _gdscheck_path():
    if shutil.which("gdscheck"):
        return shutil.which("gdscheck")
    for p in GDSCHECK_CANDIDATES:
        if p.exists():
            return str(p)
    return None


def check_gdscheck():
    path = _gdscheck_path()
    if path is None:
        return _check("gdscheck", "WARN", "", "not found in PATH or /usr/local/cuda/gds/tools")
    cmd = [sys.executable, path, "-p"] if path.endswith(".py") else [path, "-p"]
    rc, out = _run(cmd, timeout=60)
    status = "OK" if rc == 0 else "WARN"
    return _check("gdscheck -p", status, "", f"rc={rc}; full output saved in env_chk/gdscheck.txt")


def check_nvidia_fs():
    rc, out = _run(["sh", "-c", "lsmod | grep -i '^nvidia_fs' || true"])
    loaded = bool(out.strip())
    proc = Path("/proc/driver/nvidia-fs").exists()
    if loaded and proc:
        return _check("nvidia-fs module", "OK", "", "loaded; /proc/driver/nvidia-fs present")
    if loaded:
        return _check("nvidia-fs module", "WARN", "", "loaded but /proc/driver/nvidia-fs missing")
    return _check("nvidia-fs module", "MISSING", "", "not loaded: native GDS cannot run, compat mode only")


def check_cufile_json():
    for p in CUFILE_JSON_CANDIDATES:
        if p.exists():
            return _check("cufile.json", "OK", "", str(p))
    return _check("cufile.json", "WARN", "", "no default cufile.json found")


def _py_module(mod: str, expr: str):
    rc, out = _run([sys.executable, "-c", f"import {mod}; print({expr})"], timeout=60)
    if rc == 0 and out:
        return out.splitlines()[-1]
    return None


def check_cupy():
    ver = _py_module("cupy", "cupy.__version__")
    if ver is None:
        return _check("cupy", "MISSING", "", "import cupy failed (pip install cupy-cuda13x or matching CUDA)")
    rt = _py_module("cupy", "cupy.cuda.runtime.runtimeGetVersion()")
    detail = f"cuda runtime seen by cupy: {rt}" if rt else "runtime version not readable"
    return _check("cupy", "OK", ver, detail)


def check_numpy():
    ver = _py_module("numpy", "numpy.__version__")
    if ver is None:
        return _check("numpy", "WARN", "", "not importable (only needed for Python analysis helpers)")
    return _check("numpy", "OK", ver, "")


def check_nvtx_header():
    p = Path("/usr/local/cuda/include/nvtx3/nvToolsExt.h")
    if p.exists():
        return _check("NVTX header (nvtx3)", "OK", "", str(p))
    return _check("NVTX header (nvtx3)", "WARN", "", "not found; BXRANGE macros become no-ops")


def check_nsys():
    if shutil.which("nsys") is None:
        return _check("nsys (Nsight Systems)", "WARN", "", "not in PATH; needed for copy-engine and DMA-side views")
    _, out = _run(["nsys", "--version"])
    m = re.search(r"(\d+\.\d+(\.\d+)?)", out)
    return _check("nsys (Nsight Systems)", "OK", m.group(1) if m else "unknown", "")


def check_mermaid_cli():
    if shutil.which("mmdc") is None:
        return _check("mmdc (mermaid CLI)", "WARN", "", "optional: needed to render .mmd to svg/png")
    _, out = _run(["mmdc", "--version"])
    return _check("mmdc (mermaid CLI)", "OK", out.splitlines()[0] if out else "unknown", "")


CHECKS = [check_python, check_nvcc, check_gpu, check_cudart, check_cufile_lib, check_cufile_header,
          check_gds_packages, check_gdscheck, check_nvidia_fs, check_cufile_json,
          check_cupy, check_numpy, check_nvtx_header, check_nsys, check_mermaid_cli]

REQUIRED_FOR_NATIVE = {"CUDA toolkit (nvcc)", "NVIDIA driver / GPU", "cuFile library (libcufile)", "nvidia-fs module"}


def run_checks() -> list:
    results = []
    for fn in CHECKS:
        try:
            results.append(fn())
        except Exception as e:  # a broken check must not stop the report
            results.append(_check(fn.__name__, "WARN", "", f"check raised {type(e).__name__}: {e}"))
    return results


def render(checks: list, host: str, stamp: str) -> str:
    counts = {"OK": 0, "WARN": 0, "MISSING": 0}
    for c in checks:
        counts[c["status"]] += 1
    missing_required = [c["name"] for c in checks if c["status"] == "MISSING" and c["name"] in REQUIRED_FOR_NATIVE]
    ready = "READY for GDS runs" if not missing_required else "NOT READY: " + ", ".join(missing_required)
    lines = [f"GDS environment check  host={host}  time={stamp}", "=" * 78]
    for c in checks:
        ver = c["version"] or "-"
        lines.append(f"[{c['status']:<7}] {c['name']:<30} {ver:<16} {c['detail']}")
    lines += ["=" * 78,
              f"Summary: {counts['OK']} OK, {counts['WARN']} WARN, {counts['MISSING']} MISSING",
              f"Status : {ready}",
              "Note   : native GDS also needs a supported GPU and storage; check gdscheck -p output.",
              ]
    return "\n".join(lines) + "\n"


def run(run_dir: Path, host: str, stamp: str) -> str:
    out_dir = run_dir / "env_chk"
    out_dir.mkdir(parents=True, exist_ok=True)
    checks = run_checks()
    text = render(checks, host, stamp)
    (out_dir / "summary.txt").write_text(text)
    (out_dir / "checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    path = _gdscheck_path()
    if path:
        cmd = [sys.executable, path, "-p"] if path.endswith(".py") else [path, "-p"]
        _, gout = _run(cmd, timeout=60)
        (out_dir / "gdscheck.txt").write_text(gout + "\n")
    return text
