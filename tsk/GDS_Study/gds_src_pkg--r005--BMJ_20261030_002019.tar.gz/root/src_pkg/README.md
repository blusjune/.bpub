# GDS study r005 — task-261022-01

**Purpose:** CUDA/cuFile and POSIX baseline round-trip experiments on DGX Spark (compatibility) and Intel + RTX PRO 6000 (potential native GDS), with BXTRACE/NVTX and trace-to-Mermaid analysis. This is research instrumentation, **not a PCIe bus analyzer**.

## Directory layout

```text
root/
  .pyve/                      # preserved at user's request
  src_pkg/
    bx_gds_run_top.py         # ONLY top-level orchestration CLI
    trace2mermaid.py
    src/bx_gds_basic.cu       # API-level CUDA/C++ read/write/verify + GPU SM probe
    include/bx_trace.h
    include/bx_trace_dev.cuh
    subtests/                 # env, observe, raw safety, roundtrip, support, verdict, suite
    tests/                    # unit + adversarial verification
    docs/report/              # GDS technical report
    docs/diagrams/            # layered, scenario and evidence-specific mermaid scripts
    docs/doe/                 # DoE plan
    tools/make_package.py
  exe_out/                    # every run, build, trace, DoE, report and package artifact
```

**Do not place test files inside `src_pkg`.** Set `--workdir` within `root/exe_out` (or omit it; it defaults to the per-run `exe_out/.../data`). For a different NVMe filesystem, mount it to a subdirectory of `root/exe_out`, subject to local administrative policy. The `root/.pyve` directory is intentionally retained rather than relocated.

## Quick start — both nodes

```bash
cd root/src_pkg
./bx_gds_run_top.py --help
./bx_gds_run_top.py setup --no-pip             # optional: creates root/.pyve, no download
./bx_gds_run_top.py env_chk                   # read-only basic preflight
./bx_gds_run_top.py observe                   # read-only PCIe/NVMe/Kernel evidence under exe_out
./bx_gds_run_top.py suite selftest           # unit + Mermaid, no GPU needed
./bx_gds_run_top.py build                    # requires CUDA nvcc + libcufile
```

**Node3 DGX Spark** — Force cuFile compatibility mode; does *not* test direct SSD↔GPU P2P:

```bash
./bx_gds_run_top.py roundtrip --storage fs --mode gds \
  --gds-policy fallback --size 4194304 --iters 3 --nvtx
```

**Node2 Intel + RTX PRO 6000** — Check GDS capability first; strict cuFile success is still not on-wire P2P proof:

```bash
./bx_gds_run_top.py observe
./bx_gds_run_top.py support
./bx_gds_run_top.py roundtrip --storage fs --mode gds \
  --gds-policy native --size 16777216 --iters 5 --nsys
```

Optional `--trace-cmd` replaces `--nsys` for a run, and records NVMe-adjacent Linux block request/complete tracepoints under the run directory. It needs tracing privileges and cannot be combined with `--nsys` in r005. Block tracepoints do not reveal PCIe payload TLP routing or identify every SSD DMA transaction.

By default, `--p2p` is selected from the `gdscheck -p` NVMe capability row: if Linux P2PDMA is available and legacy nvidia-fs is absent, the strict probe uses P2PDMA. When no supported mode is positively detected, it conservatively tests the legacy setting and reports the result. An explicit `--p2p 1` should only be selected when the node is configured and `gdscheck -p` confirms the Linux NVMe P2PDMA route. For unsupported or misconfigured nodes this setting may cause failures. In kernels >=6.17 NVIDIA documents NVFS/SGL concerns: prefer a validated P2PDMA path where supported (see Release Notes).

**KV cache size sweep (QD=1 only, not LMCache or vLLM integration):**

```bash
./bx_gds_run_top.py kv-doe --sizes-kib 4,64,1024,8192 --iters 5 --mode both
```

**All preset tests**, including a heavy filesystem suite; RAW is skipped unless explicitly selected. Cache dropping is suppressed by default (even in the predefined `fs-standard` suite) and requires an explicit `--allow-drop-caches` flag because it is system-wide and disruptive:

```bash
./bx_gds_run_top.py all --dry-run
./bx_gds_run_top.py all
```

**Dedicated RAW partition (DESTRUCTIVE!)**: `--raw-device` must be a disposable *partition*, not a whole disk, and cannot be mounted, swap, mapped, over capacity or misaligned. This requires an explicit approval flag. It is still an inherently destructive experimental operation; never use it against any partition containing valued data.

```bash
# Example syntax only. Replace with a verified disposable unmounted partition.
./bx_gds_run_top.py roundtrip --storage raw --mode posix \
  --raw-device /dev/nvme1n1p5 --i-accept-overwrite --size 4194304
```

Use `mermaid --run-dir <path-inside-exe_out>` to convert BXTRACE logs to `.mmd` files.

## Scientific verification contract

- `OBSERVED`: CPU API call/return events, GPU SM probe records, CUDA/NVTX profiling rows, return value/data integrity, collected capabilities.
- `INFERRED`: Kernel driver interaction inferred from Linux/NVIDIA documentation, but not instrumented in this run.
- `UNOBSERVED`: PCIe Memory Read/Write TLP, SSD DMA engine internals, GPU BAR/Fabric/MC microarchitecture, MMU/IOMMU translation and ACS routing.
- `allow_compat_mode=true` **allows fallback**; `force_compat_mode=true` **forces compatibility**. `--gds-policy fallback` sets both plus `CUFILE_FORCE_COMPAT_MODE=1`.
- `nvidia-fs` absent does **not** prove compatibility: Linux P2PDMA native GDS can operate without it. Global NVFS counters alone are not per-process physical proof.
- Status labels never claim validated PCIe P2P on the basis of `cuFileRead` success, SM probe, `gdscheck` support or global counters.

## Adversarial verification

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
./bx_gds_run_top.py suite selftest
```

`tests/test_adversarial.py` attacks path classification, forced compatibility, raw overrun, whole-disk/mounted/swap/holder scenarios, contradictory evidence and bad CLI inputs. Unit tests mock sysfs and **never touch a real block device**. Tests of actual CUDA/cuFile and physical PCIe require the target nodes.

## Packaging

```bash
PYTHONDONTWRITEBYTECODE=1 python3 tools/make_package.py
```

This stamps source/script first comments with `BUILD_ID="BMJ_YYYYMMDD_HHMMSS"`, increments `tools/revision.txt`, and puts archives under `root/exe_out/packages`. All runtime artifacts stay outside src_pkg; the source revision metadata is an intentional source modification.

See `docs/report/GDS_technical_report.md` for grounded mechanisms/references and `docs/doe/DOE.md` for the full follow-up experiment plan.
