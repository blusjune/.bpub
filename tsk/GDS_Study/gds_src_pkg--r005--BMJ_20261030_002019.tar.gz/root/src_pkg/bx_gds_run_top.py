#!/usr/bin/env python3
# BUILD_ID="BMJ_20261030_002019"
"""bx_gds_run_top.py - top-level entry point for the GDS experiment package.

The virtual environment remains root/.pyve by user request; all other runtime outputs are in root/exe_out.
Auto mode uses a strict cuFile probe to choose an operational policy, not to prove PCIe DMA.
The fallback policy sets force_compat_mode=true; allow_compat_mode alone is insufficient.
Every GDS run writes test_result_<SCENARIO>.md with the verdict and its evidence.

Run `./bx_gds_run_top.py --help` for typical usage, and `<command> --help` for per-command examples.
"""
import argparse
import datetime
import json
import os
import re
import shutil
import socket
import subprocess
import sys
sys.dont_write_bytecode = True  # keep __pycache__ out of src_pkg
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
from pathlib import Path

PKG = Path(__file__).resolve().parent     # .../root/src_pkg
ROOT = PKG.parent                         # .../root
VENV = ROOT / ".pyve"


def _reexec_in_venv() -> None:
    """Re-run this script with root/.pyve/bin/python3 when the venv exists and is not active."""
    py = VENV / "bin" / "python3"
    if os.environ.get("BX_IN_VENV") == "1" or not py.exists():
        return
    if Path(sys.prefix).resolve() == VENV.resolve():
        return
    os.environ["BX_IN_VENV"] = "1"
    os.execv(str(py), [str(py), str(Path(__file__).resolve())] + sys.argv[1:])


_reexec_in_venv()

sys.path.insert(0, str(PKG / "subtests"))
import subtest_env_chk    # noqa: E402
import subtest_env_dump   # noqa: E402
import subtest_roundtrip  # noqa: E402
import subtest_suite      # noqa: E402
import subtest_support    # noqa: E402
import subtest_verdict    # noqa: E402
import trace2mermaid      # noqa: E402
import subtest_raw_guard  # noqa: E402
import subtest_observe    # noqa: E402


def build_id_line() -> str:
    """Return the BUILD_ID comment line of this file (read from the stamped header)."""
    for line in Path(__file__).read_text(errors="replace").splitlines()[:3]:
        m = re.search(r'BUILD_ID="([^"]+)"', line)
        if m:
            return f'BUILD_ID="{m.group(1)}"'
    return 'BUILD_ID="unknown"'


class BuildIdParser(argparse.ArgumentParser):
    """ArgumentParser whose --help output starts with the BUILD_ID line."""

    def print_help(self, file=None):
        print(build_id_line(), file=file or sys.stdout)
        super().print_help(file)


TYPICAL_USAGE = """\
typical usage (run from root/src_pkg):

  one-time setup
    ./bx_gds_run_top.py setup                       create root/.pyve and install numpy
    ./bx_gds_run_top.py setup --with-cupy           also install cupy-cuda13x

  check the system
    ./bx_gds_run_top.py env_chk                     libraries, versions, nvidia-fs, venv; summary
    ./bx_gds_run_top.py support --workdir ../exe_out/nvme_test
                                                    decide native GDS or compatibility fallback

  build only
    ./bx_gds_run_top.py build
    ./bx_gds_run_top.py observe                   read-only PCIe/SSD/GDS inventory
    ./bx_gds_run_top.py kv-doe --sizes-kib 4,64,1024,8192 --iters 5

  one scenario (GDS policy auto: native when supported, otherwise fallback)
    ./bx_gds_run_top.py roundtrip --storage fs --mode gds   --workdir ../exe_out/nvme_test --size 1073741824 --iters 10
    ./bx_gds_run_top.py roundtrip --storage fs --mode posix --workdir ../exe_out/nvme_test --size 1073741824 --iters 10
    ./bx_gds_run_top.py roundtrip --storage fs --mode gds --gds-policy fallback --workdir ../exe_out/nvme_test
    ./bx_gds_run_top.py roundtrip --storage fs --mode gds --gds-policy native   --workdir ../exe_out/nvme_test
    ./bx_gds_run_top.py roundtrip --storage raw --mode gds --raw-device /dev/nvme1n1p5 \\
        --size 268435456 --iters 5 --i-accept-overwrite

  pre-set suites (each writes exe_out/<host>/<ts>/suite_<name>.md)
    ./bx_gds_run_top.py suite --list
    ./bx_gds_run_top.py all --dry-run
    ./bx_gds_run_top.py suite selftest                         no GPU needed
    ./bx_gds_run_top.py suite smoke --workdir ../exe_out/nvme_test
    ./bx_gds_run_top.py suite fs-standard --workdir ../exe_out/nvme_test
    ./bx_gds_run_top.py suite fs-profile --workdir ../exe_out/nvme_test
    ./bx_gds_run_top.py suite raw-standard --raw-device /dev/nvme1n1p5 --i-accept-overwrite
    ./bx_gds_run_top.py suite full --workdir ../exe_out/nvme_test --raw-device /dev/nvme1n1p5 --i-accept-overwrite
    ./bx_gds_run_top.py suite fs-standard --workdir ../exe_out/nvme_test --dry-run   print the plan only

  profiling with Nsight Systems (NVTX ranges come from --nvtx)
    nsys profile -t cuda,nvtx,osrt -o fs_gds ./bx_gds_run_top.py roundtrip \\
        --storage fs --mode gds --workdir ../exe_out/nvme_test --size 1073741824 --iters 1 --nvtx

  sequence diagrams and reports from an existing run
    ./bx_gds_run_top.py mermaid --run-dir ../exe_out/<host>/<timestamp>

  packaging (stamps BUILD_ID and increments the revision; run from root/src_pkg)
    python3 tools/make_package.py

raw block scenarios overwrite the device region. They need --raw-device /dev/<node>,
--i-accept-overwrite, and a region reserved for this test.
"""


def new_run_dir() -> Path:
    host = socket.gethostname()
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    run = ROOT / "exe_out" / host / ts
    run.mkdir(parents=True, exist_ok=True)
    return run


def build(run_dir: Path) -> Path:
    if shutil.which("nvcc") is None:
        raise SystemExit("nvcc not found in PATH")
    out_dir = run_dir / "build"
    out_dir.mkdir(parents=True, exist_ok=True)
    binary = out_dir / "bx_gds_basic"
    cmd = ["nvcc", "-O2", "-std=c++14", f"-I{PKG / 'include'}",
           str(PKG / "src" / "bx_gds_basic.cu"), "-o", str(binary),
           "-lcufile", "-lcudart", "-ldl"]
    (out_dir / "build_command.txt").write_text(" ".join(cmd) + "\n")
    tmp = out_dir / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, TMPDIR=str(tmp), CUDA_CACHE_PATH=str(out_dir / "cuda_cache"))
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=out_dir, env=env)
    (out_dir / "build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0:
        raise SystemExit(f"build failed, see {out_dir / 'build.log'}")
    return binary


def ensure_binary(run_dir: Path) -> Path:
    binary = run_dir / "build" / "bx_gds_basic"
    return binary if binary.exists() else build(run_dir)


def check_raw_consent(storage: str, raw_device, accept: bool, offset: int = 0, size: int = 4096) -> None:
    if storage == "raw":
        try:
            subtest_raw_guard.validate_raw_device(raw_device, offset, size, accept)
        except (ValueError, OSError) as ex:
            raise SystemExit(f"raw safety gate: {ex}") from ex


def parse_gdscheck_nvme_modes(output: str) -> set:
    """Only the NVMe driver capability row, NOT 'NVMe P2PDMA: Unsupported'."""
    for line in output.splitlines():
        match = re.match(r"^\s*NVMe\s*:\s*(.*?)\s*$", line, flags=re.IGNORECASE)
        if match:
            return {s.strip().lower() for s in match.group(1).split(',')}
    return set()


def static_support() -> dict:
    gpu = subtest_env_chk.check_gpu()
    gdscheck_path = subtest_env_chk._gdscheck_path()
    modes, gdserror = set(), None
    if gdscheck_path:
        cmd = ([sys.executable, gdscheck_path, "-p"] if gdscheck_path.endswith('.py')
               else [gdscheck_path, "-p"])
        gdsrc, gdsout = subtest_env_chk._run(cmd, timeout=60)
        modes = parse_gdscheck_nvme_modes(gdsout) if gdsrc == 0 else set()
        if gdsrc != 0:
            gdserror = f'gdscheck rc={gdsrc}'
    return {"libcufile": subtest_env_chk.check_cufile_lib()["status"] == "OK",
            "nvidia_fs": subtest_env_chk.check_nvidia_fs()["status"] == "OK",
            "gpu": gpu["detail"], "spark": "GB10" in gpu["detail"].upper(),
            "nvme_modes": sorted(modes), "p2pdma_supported": "p2pdma" in modes,
            "gdscheck_error": gdserror}


def resolve_gds_policy(gds_policy: str, run_dir: Path, binary: Path, workdir, p2p_override=None) -> dict:
    """native/fallback are forced. auto runs the static checks and one strict probe."""
    static = static_support()
    selected_p2p = int(p2p_override) if p2p_override is not None else int(bool(
        static.get("p2pdma_supported") and not static.get("nvidia_fs")))
    if static.get("spark") and gds_policy == "native":
        raise SystemExit("DGX Spark GB10 does not support native GDS; select fallback")
    if gds_policy in ("native", "fallback"):
        decision = subtest_support.forced(gds_policy)
    else:
        if static.get("spark"):
            decision = subtest_support.decide(static, None)
            decision["p2p"] = 0
            (run_dir / "support").mkdir(parents=True, exist_ok=True)
            (run_dir / "support" / "decision.json").write_text(json.dumps(decision, indent=2) + "\n")
            (run_dir / "support" / "support.md").write_text(subtest_support.render_md(
                decision, socket.gethostname(), datetime.datetime.now().isoformat(timespec="seconds")))
            return decision
        probe_root = run_dir / "support"
        probe_root.mkdir(parents=True, exist_ok=True)
        s = subtest_roundtrip.run(probe_root, binary, "fs", "gds", subtest_support.PROBE_SIZE, 1, 0,
                                  0, selected_p2p, False, False, False, workdir=workdir or probe_root,
                                  policy="probe (strict, allow_compat_mode=false)", force_compat=False)
        evidence = subtest_verdict.scan_cufile_logs(probe_root / "FS_GDS")
        probe = {"rc": s["rc"], "verify_ok": s.get("result_verify") == "ok",
                 "compat_direct": bool(evidence["compat_direct"]), "verdict": s.get("verdict")}
        decision = subtest_support.decide(static, probe)
    decision["p2p"] = selected_p2p
    (run_dir / "support").mkdir(parents=True, exist_ok=True)
    (run_dir / "support" / "decision.json").write_text(json.dumps(decision, indent=2, default=str) + "\n")
    host = socket.gethostname()
    stamp = datetime.datetime.now().isoformat(timespec="seconds")
    (run_dir / "support" / "support.md").write_text(subtest_support.render_md(decision, host, stamp))
    return decision


def run_spec(run_dir: Path, binary: Path, spec: dict, decision: dict, args) -> dict:
    """One scenario run. decision supplies allow_compat_mode for GDS runs."""
    if spec["mode"] == "gds":
        compat = decision["compat"]
        policy = subtest_support.label(decision)
    else:
        compat = 1
        policy = "posix baseline"
    return subtest_roundtrip.run(
        run_dir, binary, spec["storage"], spec["mode"], spec["size"], spec["iters"],
        spec.get("offset", 0), compat,
        (args.p2p if args.p2p is not None else decision.get("p2p", 0)),
        (spec.get("drop_caches", False) and getattr(args, "allow_drop_caches", False))
        if getattr(args, "stage", "") in ("suite", "all") else spec.get("drop_caches", False),
        getattr(args, "keep", False), spec.get("nvtx", False),
        workdir=getattr(args, "workdir", None), device=getattr(args, "raw_device", None),
        policy=policy, force_compat=decision.get("force_compat", False),
        raw_consent=getattr(args, "i_accept_overwrite", False), nsys=getattr(args, "nsys", False),
        trace_cmd=getattr(args, "trace_cmd", False))


def add_scenario_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--workdir", type=Path,
                   help="FS test file directory under root/exe_out (default: per-run data directory)")
    p.add_argument("--raw-device", help="block device node for raw scenarios, e.g. /dev/nvme1n1p5")
    p.add_argument("--raw-offset", type=int, default=0,
                   help="byte offset inside the raw region (multiple of 4096)")
    p.add_argument("--i-accept-overwrite", action="store_true",
                   help="required for raw scenarios: the region may be overwritten")
    p.add_argument("--gds-policy", choices=["auto", "native", "fallback"], default="auto",
                   help="auto: strict probe; native: force strict; fallback: FORCE compatibility mode")
    p.add_argument("--p2p", type=int, choices=[0, 1], default=None,
                   help="0: NVFS, 1: Linux PCI P2PDMA (default: choose from gdscheck NVMe modes)")
    p.add_argument("--keep", action="store_true", help="keep FS test files")
    p.add_argument("--nsys", action="store_true", help="capture Nsight Systems CUDA/NVTX timeline under exe_out")
    p.add_argument("--trace-cmd", action="store_true",
                   help="optional block-layer trace-cmd recording (requires permissions; not PCIe wire proof)")


def add_roundtrip_args(p: argparse.ArgumentParser) -> None:
    add_scenario_args(p)
    p.add_argument("--size", type=int, default=1 << 30, help="bytes per transfer, multiple of 4096")
    p.add_argument("--iters", type=int, default=10)
    p.add_argument("--drop-caches", action="store_true",
                   help="sudo drop_caches before the run (O_DIRECT already bypasses page cache)")
    p.add_argument("--nvtx", action="store_true", help="enable cuFile internal NVTX ranges")


def cmd_setup(args) -> None:
    py_venv = VENV / "bin" / "python3"
    if VENV.exists() and args.force:
        shutil.rmtree(VENV)
    if not VENV.exists():
        subprocess.run([sys.executable, "-m", "venv", str(VENV)], check=True)
        print(f"created venv: {VENV}")
    else:
        print(f"venv exists: {VENV} (use --force to recreate)")
    if not args.no_pip:
        cache = ROOT / "exe_out" / "pip-cache"
        cache.mkdir(parents=True, exist_ok=True)
        pip_env = dict(os.environ, PIP_CACHE_DIR=str(cache), PYTHONDONTWRITEBYTECODE="1")
        subprocess.run([str(py_venv), "-m", "pip", "install", "--upgrade", "pip"], check=False, env=pip_env)
        reqs = [PKG / "requirements.txt"] + ([PKG / "requirements-gpu.txt"] if args.with_cupy else [])
        for req in reqs:
            subprocess.run([str(py_venv), "-m", "pip", "install", "-r", str(req)], check=True, env=pip_env)
    print(f"ready. Use: {py_venv} or just ./bx_gds_run_top.py (it re-execs into the venv)")


def run_unit(run_dir: Path) -> dict:
    out = run_dir / "unit"
    out.mkdir(parents=True, exist_ok=True)
    r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"],
                       cwd=PKG, capture_output=True, text=True)
    (out / "unit.log").write_text(r.stdout + r.stderr)
    last = (r.stderr.strip().splitlines() or ["?"])[-1]
    print(f"unit tests: rc={r.returncode} ({last})")
    return {"scenario": "unit-tests", "rc": r.returncode, "verdict": "PASS" if r.returncode == 0 else "FAIL"}


def run_selftest_mermaid(run_dir: Path) -> dict:
    out = run_dir / "selftest"
    out.mkdir(parents=True, exist_ok=True)
    sample = PKG / "tests" / "data" / "sample_FS_GDS_trace.log"
    trace2mermaid.convert(sample, out / "trace_sequence_FS_GDS.mmd", False, True)
    ok = "sequenceDiagram" in (out / "trace_sequence_FS_GDS.mmd").read_text()
    print(f"selftest mermaid: {'ok' if ok else 'FAILED'} -> {out}")
    return {"scenario": "selftest-mermaid", "rc": 0 if ok else 1, "verdict": "PASS" if ok else "FAIL"}


def cmd_suite(args) -> None:
    if args.list:
        for name in subtest_suite.SUITES:
            print(subtest_suite.describe(name))
            print()
        return
    if not args.name:
        raise SystemExit("name a suite, or use --list. Example: ./bx_gds_run_top.py suite smoke --workdir ../exe_out/nvme_test")
    if args.name not in subtest_suite.SUITES:
        raise SystemExit(f"unknown suite {args.name!r}; choose from {', '.join(subtest_suite.SUITES)}")
    suite = subtest_suite.SUITES[args.name]
    if args.dry_run:
        print(subtest_suite.describe(args.name))
        return
    if suite["needs_raw"] and not args.raw_device:
        raise SystemExit(f"suite {args.name} needs --raw-device /dev/<node> and --i-accept-overwrite")
    if args.raw_device and not args.i_accept_overwrite:
        raise SystemExit("raw scenarios overwrite the device region; pass --i-accept-overwrite")

    run = new_run_dir()
    args.workdir = args.workdir or run / "data"
    rows, notes, decision, binary = [], [], None, None
    stages = subtest_suite.plan(args.name)
    for kind, payload in stages:
        if kind == "unit":
            rows.append(run_unit(run))
        elif kind == "selftest":
            rows.append(run_selftest_mermaid(run))
        elif kind == "env_chk":
            text = subtest_env_chk.run(run, socket.gethostname(), datetime.datetime.now().isoformat(timespec="seconds"))
            print(text, end="")
        elif kind == "build":
            binary = build(run)
            print(f"built: {binary}")
        elif kind == "support":
            binary = binary or ensure_binary(run)
            decision = resolve_gds_policy(args.gds_policy, run, binary, args.workdir, args.p2p)
            print(f"GDS decision: {decision['policy'].upper()} ({'; '.join(decision['reasons'])})")
        elif kind == "scenarios":
            if payload["storage"] == "raw" and not args.raw_device:
                notes.append(f"skipped {payload['storage'].upper()}_{payload['mode'].upper()}: no --raw-device")
                continue
            binary = binary or ensure_binary(run)
            if decision is None:
                decision = resolve_gds_policy(args.gds_policy, run, binary, args.workdir, args.p2p)
            payload = dict(payload)
            if payload["storage"] == "raw":
                payload["offset"] = args.raw_offset
                check_raw_consent("raw", args.raw_device, args.i_accept_overwrite,
                                  args.raw_offset, payload["size"])
            s = run_spec(run, binary, payload, decision, args)
            rows.append(s)
            print(f"{s['scenario']}: verdict={s.get('verdict', 'n/a')} rc={s['rc']} verify={s.get('result_verify')}")
    scen = [r for r in rows if "storage" in r]
    if scen:
        trace_logs = sorted(run.glob("*/trace.log"))
        for log in trace_logs:
            trace2mermaid.convert(log, None, False, True)
    path = subtest_suite.write_summary(run, args.name, rows, notes)
    print(f"suite {args.name} done. summary: {path}")
    print(f"run directory: {run}")
    if any(r.get("rc", 0) != 0 or r.get("result_verify", "ok") != "ok" for r in rows):
        raise SystemExit("suite had failed scenarios or verification errors (see summary)")


def main() -> None:
    ap = BuildIdParser(
        description="GDS experiment top-level driver",
        epilog=TYPICAL_USAGE,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = ap.add_subparsers(dest="stage", required=True)

    sp = sub.add_parser("setup", help="create root/.pyve and install Python packages",
                        epilog="examples:\n  ./bx_gds_run_top.py setup\n  ./bx_gds_run_top.py setup --with-cupy\n  ./bx_gds_run_top.py setup --force --with-cupy",
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    sp.add_argument("--with-cupy", action="store_true", help="also install cupy-cuda13x")
    sp.add_argument("--force", action="store_true", help="recreate the venv")
    sp.add_argument("--no-pip", action="store_true", help="create the venv only")

    sub.add_parser("env", help="capture environment state (raw dumps)")

    sub.add_parser("env_chk", help="check CUDA, cuFile, nvidia-fs, cupy and other tools; print a summary",
                   epilog="examples:\n  ./bx_gds_run_top.py env_chk",
                   formatter_class=argparse.RawDescriptionHelpFormatter)

    sup = sub.add_parser("support", help="decide native GDS or compatibility fallback (strict probe)",
                         epilog="examples:\n  ./bx_gds_run_top.py support --workdir ../exe_out/nvme_test",
                         formatter_class=argparse.RawDescriptionHelpFormatter)
    sup.add_argument("--workdir", type=Path, help="directory for the probe file (default: run directory)")

    sub.add_parser("observe", help="read-only PCIe/NVMe/IOMMU topology and tools capture under exe_out")

    sub.add_parser("all", help="alias for suite full (RAW requires explicit guarded partition)",
                   epilog="example: ./bx_gds_run_top.py all --workdir ../exe_out/experiment-data",
                   formatter_class=argparse.RawDescriptionHelpFormatter)
    # 'all' accepts the same option set as suites, but is kept destructive-RAW opt-in only.
    add_scenario_args(sub.choices["all"])
    sub.choices["all"].add_argument("--dry-run", action="store_true")
    sub.choices["all"].add_argument("--allow-drop-caches", action="store_true")
    sub.choices["all"].set_defaults(name="full", list=False, size=None)

    kv = sub.add_parser("kv-doe", help="KV block size sweep, serial QD=1; NOT a concurrent LMCache benchmark",
                        epilog="example: ./bx_gds_run_top.py kv-doe --sizes-kib 4,64,1024,8192 --iters 5 --mode both",
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    kv.add_argument("--sizes-kib", default="4,64,1024,8192", help="comma separated positive 4KiB-aligned sizes")
    kv.add_argument("--iters", type=int, default=5)
    kv.add_argument("--mode", choices=["both", "gds", "posix"], default="both")
    kv.add_argument("--workdir", type=Path, help="must be under root/exe_out")
    kv.add_argument("--gds-policy", choices=["auto", "native", "fallback"], default="auto")
    kv.add_argument("--p2p", type=int, choices=[0, 1], default=None)
    kv.add_argument("--nvtx", action="store_true")
    kv.set_defaults(keep=False, nsys=False, trace_cmd=False,
                    i_accept_overwrite=False, raw_device=None)

    sub.add_parser("build", help="compile bx_gds_basic into a new run directory",
                   epilog="examples:\n  ./bx_gds_run_top.py build",
                   formatter_class=argparse.RawDescriptionHelpFormatter)

    rt = sub.add_parser("roundtrip", help="run one scenario",
                        epilog=("examples:\n"
                                "  ./bx_gds_run_top.py roundtrip --storage fs --mode gds --workdir ../exe_out/nvme_test --size 1073741824 --iters 10\n"
                                "  ./bx_gds_run_top.py roundtrip --storage fs --mode posix --workdir ../exe_out/nvme_test --size 1073741824 --iters 10\n"
                                "  ./bx_gds_run_top.py roundtrip --storage fs --mode gds --gds-policy fallback --workdir ../exe_out/nvme_test\n"
                                "  ./bx_gds_run_top.py roundtrip --storage raw --mode gds --raw-device /dev/nvme1n1p5 --size 268435456 --iters 5 --i-accept-overwrite"),
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    rt.add_argument("--storage", choices=["fs", "raw"], required=True)
    rt.add_argument("--mode", choices=["gds", "posix"], required=True)
    rt.add_argument("--run-dir", type=Path, help="reuse an existing run directory")
    add_roundtrip_args(rt)

    su = sub.add_parser("suite", help="run a pre-set suite (see --list)",
                        epilog=("examples:\n"
                                "  ./bx_gds_run_top.py suite --list\n"
                                "  ./bx_gds_run_top.py suite selftest\n"
                                "  ./bx_gds_run_top.py suite smoke --workdir ../exe_out/nvme_test\n"
                                "  ./bx_gds_run_top.py suite fs-standard --workdir ../exe_out/nvme_test\n"
                                "  ./bx_gds_run_top.py suite fs-profile --workdir ../exe_out/nvme_test\n"
                                "  ./bx_gds_run_top.py suite raw-standard --raw-device /dev/nvme1n1p5 --i-accept-overwrite\n"
                                "  ./bx_gds_run_top.py suite full --workdir ../exe_out/nvme_test --raw-device /dev/nvme1n1p5 --i-accept-overwrite\n"
                                "  ./bx_gds_run_top.py suite fs-standard --workdir ../exe_out/nvme_test --dry-run"),
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    su.add_argument("name", nargs="?", help="suite name")
    su.add_argument("--list", action="store_true", help="list suites and their steps")
    su.add_argument("--dry-run", action="store_true", help="print the plan and exit")
    su.add_argument("--allow-drop-caches", action="store_true",
                    help="explicitly permit sudo -n drop_caches during suite; disruptive system-wide action")
    add_scenario_args(su)
    su.set_defaults(size=None)

    mm = sub.add_parser("mermaid", help="convert <SCENARIO>/trace.log files in a run directory",
                        epilog="examples:\n  ./bx_gds_run_top.py mermaid --run-dir ../exe_out/spark-7121/20261027_120000",
                        formatter_class=argparse.RawDescriptionHelpFormatter)
    mm.add_argument("--run-dir", type=Path, required=True)
    mm.add_argument("--expand-sm", action="store_true", help="one arrow per warp record")

    args = ap.parse_args()

    if args.stage == "setup":
        cmd_setup(args)

    elif args.stage == "env":
        run = new_run_dir()
        subtest_env_dump.run(run)
        print(run)

    elif args.stage == "env_chk":
        run = new_run_dir()
        stamp = datetime.datetime.now().isoformat(timespec="seconds")
        text = subtest_env_chk.run(run, socket.gethostname(), stamp)
        print(text, end="")
        print(f"saved: {run / 'env_chk'}")

    elif args.stage == "support":
        run = new_run_dir()
        binary = ensure_binary(run)
        decision = resolve_gds_policy("auto", run, binary, args.workdir)
        print(f"GDS decision: {decision['policy'].upper()}  (allow_compat_mode={decision['compat']})")
        for r in decision["reasons"]:
            print(f"  - {r}")
        print(f"saved: {run / 'support'}")

    elif args.stage == "build":
        print(build(new_run_dir()))

    elif args.stage == "roundtrip":
        check_raw_consent(args.storage, args.raw_device, args.i_accept_overwrite, args.raw_offset, args.size)
        run = args.run_dir or new_run_dir()
        if not run.resolve().is_relative_to((ROOT / "exe_out").resolve()):
            raise SystemExit("--run-dir must be inside root/exe_out")
        args.workdir = args.workdir or run / "data"
        binary = ensure_binary(run)
        decision = resolve_gds_policy(args.gds_policy, run, binary, args.workdir, args.p2p) if args.mode == "gds" \
            else subtest_support.forced("fallback")
        spec = {"storage": args.storage, "mode": args.mode, "size": args.size, "iters": args.iters,
                "drop_caches": args.drop_caches, "nvtx": args.nvtx, "offset": args.raw_offset}
        s = run_spec(run, binary, spec, decision, args)
        print(json.dumps(s, indent=2))
        print(f"run directory: {run}")
        if s["rc"] != 0 or s.get("result_verify") != "ok":
            raise SystemExit("roundtrip failed or did not verify; see summary.json")

    elif args.stage in ("suite", "all"):
        cmd_suite(args)

    elif args.stage == "observe":
        run = new_run_dir()
        data = subtest_observe.collect(run)
        print(json.dumps(data, indent=2))
        print(f"saved: {run / 'observability'}")

    elif args.stage == "kv-doe":
        import csv
        if args.iters < 1:
            raise SystemExit("--iters must be >= 1")
        try:
            sizes = [int(k) * 1024 for k in args.sizes_kib.split(",")]
        except ValueError as e:
            raise SystemExit("--sizes-kib requires integers") from e
        if not sizes or len(sizes) > 32 or any(n < 4096 or n % 4096 for n in sizes):
            raise SystemExit("sizes must be 4 KiB aligned, >=4 KiB, at most 32 values")
        if any(n > 64 * 1024 * 1024 for n in sizes):
            raise SystemExit("KV sweep limits per-I/O size to 64 MiB")
        run = new_run_dir()
        args.workdir = args.workdir or run / "data"
        binary = ensure_binary(run)
        decision = resolve_gds_policy(args.gds_policy, run, binary, args.workdir, args.p2p) if args.mode != 'posix' \
            else subtest_support.forced('fallback')
        rows = []
        for sz in sizes:
            for mode in (["posix", "gds"] if args.mode == 'both' else [args.mode]):
                spec = {'storage': 'fs', 'mode': mode, 'size': sz, 'iters': args.iters, 'offset': 0}
                # Reuse one subtest directory per mode with unique size-scoped subdirectory.
                cell = run / 'kv_cells' / f'{sz}_{mode}'
                cell.mkdir(parents=True, exist_ok=True)
                r = run_spec(cell, binary, spec, decision, args)
                rows.append(r)
                trace_file = cell / f'FS_{mode.upper()}' / 'trace.log'
                if trace_file.exists():
                    trace2mermaid.convert(trace_file, None, False, True)
        output = run / 'kv_doE_qd1.csv'
        fields = ['scenario', 'size', 'iters', 'rc', 'result_verify', 'result_write_us_avg',
                  'result_read_us_avg', 'verdict', 'gds_policy']
        with output.open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(rows)
        (run / 'kv_doE_limits.md').write_text(
            '# KV-size sweep limitations\n\nSerial synchronous round-trip, QD=1, not concurrent LMCache. '
            'File I/O per block; not a real token-level trace. Throughput is not a prediction of '
            'production inter-turn KV offload. Direct PCIe DMA is not proven by cuFile success.\n')
        print(f"KV QD1 sweep: {output}")
        print(f"run directory: {run}")
        if any(r.get("rc") != 0 or r.get("result_verify") != "ok" for r in rows):
            raise SystemExit("one or more KV sweep cells failed; see CSV and per-cell logs")

    elif args.stage == "mermaid":
        if not args.run_dir.resolve().is_relative_to((ROOT / "exe_out").resolve()):
            raise SystemExit("Mermaid source run directory must be inside root/exe_out")
        logs = sorted(args.run_dir.glob("*/trace.log"))
        if not logs:
            raise SystemExit(f"no */trace.log under {args.run_dir}")
        for log in logs:
            n = trace2mermaid.convert(log, None, args.expand_sm, True)
            print(f"{n} events -> {log.parent}")


if __name__ == "__main__":
    main()
