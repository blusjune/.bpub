# BUILD_ID="BMJ_20261030_002019"
"""Conservative, provenance-aware cuFile run classification.

No user-space BXTRACE, nvfs global counter, or gdscheck capability listing can
prove a particular PCIe DMA transaction. PCI bus analyzers or validated per-I/O
kernel telemetry are needed for that. Never infer fallback from absent nvidia-fs.
"""
import re
from datetime import datetime
from pathlib import Path

NVFS_BASE = Path('/proc/driver/nvidia-fs')
NUM_RE = re.compile(r'([A-Za-z_][\w ./()-]*?)\s*[:=]\s*(\d+)\b')
SKIP_LOGS = {'trace.log', 'run.log'}
EVIDENCE_LIMIT = 40
PATTERNS = {
    'compat_direct': re.compile(r'running in compatible mode|using compatibility mode', re.I),
    'compat_config': re.compile(r'(use|force|allow)_compat_mode', re.I),
    'unsupported': re.compile(r'\bUnsupported\b', re.I),
    'model': re.compile(r'Model Not Supported', re.I),
    'devcount': re.compile(r'failed to open /proc/driver/nvidia-fs', re.I),
    'p2pdma': re.compile(r'p2pdma|pci_p2pdma', re.I),
}


def nvfs_present(base: Path = NVFS_BASE) -> bool:
    return base.exists()


def read_nvfs_stats(base: Path = NVFS_BASE) -> dict:
    result = {}
    if not base.exists():
        return result
    files = [base] if base.is_file() else sorted(p for p in base.rglob('*') if p.is_file())
    for file in files:
        try:
            data = file.read_text(errors='replace')
        except OSError:
            continue
        prefix = '' if file == base else f'{file.relative_to(base)}:'
        for line in data.splitlines():
            for key, val in NUM_RE.findall(line):
                result[f'{prefix}{key.strip()}'] = int(val)
    return result


def io_deltas(before: dict, after: dict) -> dict:
    return {k: v - before[k] for k, v in after.items()
            if k in before and re.search('read|write', k, re.I) and v > before[k]}


def scan_cufile_logs(scenario_dir: Path) -> dict:
    evidence = {k: [] for k in PATTERNS}
    for file in sorted(scenario_dir.glob('*.log')):
        if file.name in SKIP_LOGS:
            continue
        try:
            lines = file.read_text(errors='replace').splitlines()
        except OSError:
            continue
        for line in lines:
            for category, pattern in PATTERNS.items():
                if pattern.search(line) and len(evidence[category]) < EVIDENCE_LIMIT:
                    evidence[category].append((file.name, line.strip()[:240]))
    return evidence


def classify(mode: str, rc: int, verify_ok: bool, nvfs_loaded: bool,
             before: dict, after: dict, evidence: dict,
             strict_requested: bool = False, force_compat: bool = False) -> dict:
    deltas = io_deltas(before, after)
    notes = []

    def result(name, reason, basis):
        return {'verdict': name, 'reason': reason, 'basis': basis,
                'io_deltas': deltas, 'notes': notes}

    if mode != 'gds':
        return result('NOT_GDS', 'POSIX baseline did not call cuFile', 'scenario mode')
    if rc != 0 or not verify_ok:
        return result('RUN_FAILED', f'rc={rc}, verified={verify_ok}; physical path not determined', 'exit/verification')
    if force_compat:
        if deltas:
            notes.append('Unexpected global nvidia-fs counter change; investigate concurrent traffic')
        return result('COMPAT_FORCED', 'force_compat_mode=true was applied by the runner', 'controlled configuration')
    if evidence.get('compat_direct'):
        if deltas:
            notes.append('cuFile compat report conflicts with global NVFS counters; concurrent I/O possible')
        return result('COMPAT_FALLBACK', 'cuFile explicitly reported compatibility mode', 'cuFile runtime log')
    if deltas:
        return result('NATIVE_GDS_INDICATED',
                      'nvidia-fs global I/O counters increased; likely native NVFS but not per-process proof',
                      'shared nvidia-fs counters')
    if strict_requested:
        return result('NATIVE_GDS_CANDIDATE',
                      'strict cuFile succeeded and verified without observed compat log; P2P not proven',
                      'strict cuFile API and result')
    if not nvfs_loaded:
        notes.append('nvidia-fs absent does not rule out native Linux PCI P2PDMA')
    return result('UNDETERMINED', 'insufficient positive path evidence; neither native nor fallback proved',
                  'no conclusive telemetry')


def _bullets(items, empty):
    return [f'- `{name}`: {line}' for name, line in items] if items else [f'- {empty}']


def write_report(scenario_dir: Path, scenario: str, info: dict) -> Path:
    v, s, evidence = info['verdict'], info['summary'], info['evidence']
    lines = [f'# test_result_{scenario}', '', f'- Generated: {datetime.now().isoformat(timespec="seconds")}',
             f'- Host: {info["host"]}', f'- Scenario: **{scenario}**', f'- Started: {info["started"]}',
             f'- Command: `{info["command"]}`', f'- Selected policy: {info.get("policy") or "unspecified"}',
             f'- Return code: {s.get("rc")}', f'- Verify: {s.get("result_verify", "n/a")}',
             f'- Write mean (us): {s.get("result_write_us_avg", "n/a")}',
             f'- Read mean (us): {s.get("result_read_us_avg", "n/a")}',
             '', '## Verdict', '', f'**{v["verdict"]}**', '',
             f'Reason: {v["reason"]}', f'Basis: {v["basis"]}', '',
             'This is an evidence classification, not proof of PCIe P2P payload routing.',
             '', '## Evidence', '', '### 1. cuFile self-report', '']
    lines += _bullets(evidence.get('compat_direct'), 'No explicit compatible-mode line found')
    lines += ['', '### 2. nvidia-fs module state', '', f'- nvidia-fs present: {info["nvfs_loaded"]}']
    lines += _bullets(evidence.get('devcount'), 'No devcount error found')
    lines += ['', '### 3. nvidia-fs global I/O counters', '',
              f'- Parsed before/after: {info["nvfs_before_count"]} / {info["nvfs_after_count"]}', '']
    if v['io_deltas']:
        lines += ['| Counter | Delta |', '|---|---:|']
        lines += [f'| {key} | {delta} |' for key, delta in v['io_deltas'].items()]
    else:
        lines += ['No positive counter delta found (not proof of compatibility).']
    lines += ['', '### 4. Platform support / P2PDMA log lines', '']
    lines += _bullets(evidence.get('model'), 'No unsupported GPU model text')
    lines += _bullets(evidence.get('unsupported'), 'No unsupported feature text')
    lines += _bullets(evidence.get('p2pdma'), 'No p2pdma log line')
    lines += ['', '### 5. Configuration echo (not evidence of actual path)', '']
    lines += _bullets(evidence.get('compat_config'), 'No config echo')
    if v['notes']:
        lines += ['', '## Notes', ''] + [f'- {x}' for x in v['notes']]
    lines += ['', '## Method and limits', '',
              '- Strict success is an API-level candidate, not direct DMA proof.',
              '- Missing nvidia-fs does not preclude Linux PCI P2PDMA.',
              '- nvidia-fs proc counters are global, and concurrent processes can change them.',
              '- For physical path claims, capture validated per-I/O kernel evidence and PCIe topology.',
              f'- cuFile config: `{info["cufile_json"]}`',
              '- Logs: run.log, trace.log, summary.json, command.txt.', '']
    output = scenario_dir / f'test_result_{scenario}.md'
    output.write_text('\n'.join(lines))
    return output
