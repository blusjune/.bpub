# BUILD_ID="BMJ_20261030_002019"
"""Fail-closed safeguards for destructive raw block experiments. No writes here.

This is not a guarantee against hardware/udev races; recheck the target before each run.
Only unmounted, non-swap partitions with no mapped holders are permitted. Whole disks
are deliberately unsupported. The operator must reserve the partition exclusively.
"""
import os
import stat
from pathlib import Path

ALIGN = 4096


def check_geometry(offset: int, size: int, capacity: int) -> None:
    if offset < 0 or size <= 0 or offset % ALIGN or size % ALIGN:
        raise ValueError("raw offset/size must be positive, nonnegative and 4096-byte aligned")
    if capacity <= 0 or offset > capacity or size > capacity - offset:
        raise ValueError("raw I/O region exceeds block partition capacity")


def validate_raw_device(device: str, offset: int, size: int, consent: bool,
                        sys_root=Path('/sys'), proc_root=Path('/proc')) -> dict:
    if not consent:
        raise ValueError('raw overwrite requires --i-accept-overwrite')
    if not device or not str(device).startswith('/dev/'):
        raise ValueError('raw target must be an absolute /dev/ block partition')
    target = Path(device).resolve(strict=True)
    st = target.stat()
    if not stat.S_ISBLK(st.st_mode):
        raise ValueError('raw target is not a block device')
    devnum = f'{os.major(st.st_rdev)}:{os.minor(st.st_rdev)}'
    link = sys_root / 'dev/block' / devnum
    if not link.exists():
        raise ValueError('sysfs block device metadata missing: refuse to write')
    blk = link.resolve(strict=True)
    if not (blk / 'partition').is_file():
        raise ValueError('whole block disks are prohibited; use a dedicated partition')
    if (blk / 'holders').exists() and any((blk / 'holders').iterdir()):
        raise ValueError('partition has device-mapper/RAID holders')
    try:
        sectors = int((blk / 'size').read_text().strip())
    except (ValueError, OSError) as exc:
        raise ValueError('cannot determine partition capacity') from exc
    check_geometry(offset, size, sectors * 512)
    # Linux mountinfo field 3 is the major:minor of the filesystem backing device.
    for line in (proc_root / 'self/mountinfo').read_text().splitlines():
        parts = line.split()
        if len(parts) > 2 and parts[2] == devnum:
            raise ValueError('raw partition is mounted; refuse to overwrite')
    # Reject swap devices, including via symlink aliases.
    for line in (proc_root / 'swaps').read_text().splitlines()[1:]:
        fields = line.split()
        if not fields:
            continue
        try:
            swap_st = Path(fields[0]).stat()
            if stat.S_ISBLK(swap_st.st_mode) and swap_st.st_rdev == st.st_rdev:
                raise ValueError('raw partition is active swap')
        except FileNotFoundError:
            raise ValueError('cannot resolve swap entry: refuse to write')
    return {'device': str(target), 'devnum': devnum, 'capacity_bytes': sectors * 512,
            'offset': offset, 'size': size, 'guard': 'partition-unmounted-noholders-noswap'}
