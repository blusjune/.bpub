# BUILD_ID="BMJ_20261030_002019"
"""Read-only hardware context capture. No PCIe bus packets are observed here.

Commands are bounded, errors recorded, and generated data lives only in exe_out.
NVMe block tracepoints and Nsight are optional complementary evidence sources.
"""
import json
import shutil
import subprocess
from pathlib import Path

COMMANDS = {
    'pci_tree': ['lspci', '-tv'],
    'pci_verbose': ['lspci', '-vv'],
    'block_topology': ['lsblk', '-J', '-o', 'NAME,PATH,TYPE,SIZE,FSTYPE,MOUNTPOINTS,PKNAME,MAJ:MIN'],
    'gpu': ['nvidia-smi', '-q'],
    'kernel': ['uname', '-a'],
    'modules': ['lsmod'],
    'nvme': ['nvme', 'list'],
    'trace_events': ['trace-cmd', 'list', '-e'],
}


def collect(run_dir: Path, commands=None) -> dict:
    output = run_dir / 'observability'
    output.mkdir(parents=True, exist_ok=True)
    specs = dict(COMMANDS if commands is None else commands)
    gdspath = shutil.which('gdscheck')
    if not gdspath:
        for candidate in ['/usr/local/cuda/gds/tools/gdscheck.py', '/usr/local/cuda/gds/tools/gdscheck']:
            if Path(candidate).exists():
                gdspath = candidate
                break
    if gdspath:
        specs['gdscheck'] = ['python3', gdspath, '-p'] if gdspath.endswith('.py') else [gdspath, '-p']
    result = {'classification': 'CAPABILITY_AND_TOPOLOGY_ONLY_NOT_DMA_PROOF', 'commands': {}}
    for label, argv in specs.items():
        exe = shutil.which(argv[0])
        if not exe:
            result['commands'][label] = {'status': 'not_installed', 'command': argv}
            continue
        try:
            cp = subprocess.run(argv, capture_output=True, text=True, timeout=20)
            (output / f'{label}.txt').write_text(cp.stdout + '\n--- stderr ---\n' + cp.stderr)
            result['commands'][label] = {'status': 'completed', 'rc': cp.returncode,
                                          'command': argv, 'file': f'{label}.txt'}
        except (OSError, subprocess.TimeoutExpired) as ex:
            result['commands'][label] = {'status': 'error', 'error': str(ex), 'command': argv}
    for name, source in {'cmdline': '/proc/cmdline',
                         'nvme_multipath': '/sys/module/nvme_core/parameters/multipath'}.items():
        p = Path(source)
        try:
            (output / f'{name}.txt').write_text(p.read_text())
            result['commands'][name] = {'status': 'completed', 'file': f'{name}.txt'}
        except OSError as ex:
            result['commands'][name] = {'status': 'unavailable', 'error': str(ex)}
    (output / 'manifest.json').write_text(json.dumps(result, indent=2) + '\n')
    return result
