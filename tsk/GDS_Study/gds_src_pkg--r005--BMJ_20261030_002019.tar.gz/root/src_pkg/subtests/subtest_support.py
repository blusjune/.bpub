# BUILD_ID="BMJ_20261030_002019"
"""Separate operating policy from proof of a specific physical data path.

Native GDS can use either legacy nvidia-fs or Linux PCI P2PDMA. Strict cuFile
success establishes an operational candidate, NOT proof of on-wire PCIe P2P.
"""
PROBE_SIZE = 4096


def decide(static: dict, probe) -> dict:
    reasons = []
    if static.get('spark'):
        reasons.append('DGX Spark GB10: NVIDIA supports cuFile compatibility mode only')
    if not static.get('libcufile'):
        reasons.append('libcufile not detected')
    if probe is None:
        reasons.append('strict cuFile probe not run')
    else:
        if probe.get('rc') != 0 or not probe.get('verify_ok'):
            reasons.append('strict cuFile probe failed or did not verify')
        if probe.get('compat_direct'):
            reasons.append('cuFile reported compatibility mode during strict probe')
    # Missing nvidia-fs is NOT a reason: modern PCI P2PDMA can run without it.
    native_candidate = not reasons
    return {'policy': 'native' if native_candidate else 'fallback',
            'compat': 0 if native_candidate else 1,
            'force_compat': not native_candidate,
            'evidence_level': 'STRICT_CUFILE_SUCCESS_ONLY' if native_candidate else 'NO_NATIVE_CANDIDATE',
            'reasons': reasons or ['strict cuFile probe succeeded; physical P2P not yet established'],
            'static': static, 'probe': probe}


def forced(policy: str) -> dict:
    if policy not in ('native', 'fallback'):
        raise ValueError('policy must be native or fallback')
    strict = policy == 'native'
    return {'policy': policy, 'compat': 0 if strict else 1,
            'force_compat': not strict,
            'evidence_level': 'OPERATOR_SELECTED_NOT_MEASURED',
            'reasons': [f'operator selected --gds-policy {policy}; not proof of actual data path'],
            'static': None, 'probe': None}


def label(decision: dict) -> str:
    if decision['policy'] == 'native':
        return 'strict cuFile candidate (allow_compat_mode=false, physical P2P unverified)'
    return 'forced compatibility (force_compat_mode=true)'


def render_md(decision: dict, host: str, stamp: str) -> str:
    out = ['# GDS operational decision', '', f'- Host: {host}', f'- Time: {stamp}',
           f'- Selected policy: **{decision["policy"].upper()}**',
           f'- allow_compat_mode: {decision["compat"]}',
           f'- force_compat_mode: {decision["force_compat"]}',
           f'- Evidence level: **{decision["evidence_level"]}**',
           '- A selected policy or successful API call is NOT evidence of PCIe P2P packets.',
           '', '## Reasons', '']
    out.extend('- ' + s for s in decision['reasons'])
    out += ['', '## Static environment', '', '```json',
            __import__('json').dumps(decision['static'], indent=2), '```',
            '', '## Probe', '', '```json',
            __import__('json').dumps(decision['probe'], indent=2), '```', '']
    return '\n'.join(out)
