# BUILD_ID="BMJ_20261030_002019"
"""subtest_suite: pre-set run suites. Each suite is a list of parts; each part is a list of steps.

Step kinds
  unit             python -m unittest (no GPU)
  selftest         mermaid generation from the bundled sample trace (no GPU)
  env_chk          library and tool check
  build            compile bx_gds_basic
  support          automatic GDS support decision (strict probe)
  scenarios        one or more scenario runs (spec dicts)
Singleton kinds (env_chk, build, support, unit, selftest) run once per suite even when several
parts request them.
"""
from datetime import datetime

MiB = 1 << 20
GiB = 1 << 30


def spec(storage, mode, size, iters, drop=False, nvtx=False, offset=0):
    return {"storage": storage, "mode": mode, "size": size, "iters": iters,
            "drop_caches": drop, "nvtx": nvtx, "offset": offset}


def pair(storage, size, iters, drop=False, nvtx=False):
    """POSIX baseline first, then the GDS scenario, so the two can be read side by side."""
    return [spec(storage, "posix", size, iters, drop, nvtx),
            spec(storage, "gds", size, iters, drop, nvtx)]


PARTS = {
    "unit": [("unit", None)],
    "selftest": [("selftest", None)],
    "env": [("env_chk", None), ("build", None), ("support", None)],
    "smoke": [("scenarios", s) for s in pair("fs", 64 * MiB, 2)],
    "fs": [("scenarios", s) for size in (256 * MiB, GiB, 4 * GiB) for s in pair("fs", size, 10, drop=True)],
    "fsprof": [("scenarios", s) for s in pair("fs", GiB, 1, nvtx=True)],
    "raw": [("scenarios", s) for s in [spec("raw", "posix", GiB, 10), spec("raw", "gds", GiB, 10)]],
}

SUITES = {
    "unit": {"desc": "Python unit tests. No GPU, no storage.",
             "parts": ["unit"], "needs_raw": False},
    "selftest": {"desc": "Unit tests plus mermaid generation from the bundled sample trace. No GPU.",
                 "parts": ["unit", "selftest"], "needs_raw": False},
    "smoke": {"desc": "Environment check, build, support probe, 64 MiB FS POSIX and GDS, 2 iterations.",
              "parts": ["env", "smoke"], "needs_raw": False},
    "fs-standard": {"desc": "FS POSIX and GDS at 256 MiB, 1 GiB, 4 GiB; 10 iterations; drop caches before each run.",
                    "parts": ["env", "fs"], "needs_raw": False},
    "fs-profile": {"desc": "FS POSIX and GDS at 1 GiB, 1 iteration, NVTX ranges on (wrap with nsys).",
                   "parts": ["env", "fsprof"], "needs_raw": False},
    "raw-standard": {"desc": "RAW POSIX and GDS at 1 GiB, 10 iterations. DESTROYS the raw region.",
                     "parts": ["env", "raw"], "needs_raw": True},
    "full": {"desc": "unit + env + smoke + fs-standard + raw-standard (raw skipped without --raw-device).",
             "parts": ["unit", "env", "smoke", "fs", "raw"], "needs_raw": False},
}

SINGLETONS = {"unit", "selftest", "env_chk", "build", "support"}


def plan(name: str) -> list:
    """Flattened, de-duplicated list of (kind, payload). Singletons keep their first position."""
    if name not in SUITES:
        raise KeyError(f"unknown suite {name!r}; choose from {', '.join(SUITES)}")
    steps, seen = [], set()
    for part in SUITES[name]["parts"]:
        for kind, payload in PARTS[part]:
            if kind in SINGLETONS:
                if kind in seen:
                    continue
                seen.add(kind)
            steps.append((kind, payload))
    return steps


def describe(name: str) -> str:
    s = SUITES[name]
    lines = [f"suite {name}: {s['desc']}"]
    for kind, payload in plan(name):
        if kind == "scenarios":
            lines.append(f"  - scenario {payload['storage'].upper()}_{payload['mode'].upper()}: "
                         f"size={payload['size']} iters={payload['iters']} "
                         f"drop_caches={payload['drop_caches']} nvtx={payload['nvtx']}")
        else:
            lines.append(f"  - {kind}")
    return "\n".join(lines)


def write_summary(run_dir, name: str, rows: list, stage_notes: list) -> str:
    """Markdown table of every scenario in the suite, plus notes about skipped or failed steps."""
    lines = [
        f"# suite {name}",
        "",
        f"- Generated: {datetime.now().isoformat(timespec='seconds')}",
        f"- Run directory: `{run_dir}`",
        "",
        "| scenario | size | iters | GDS policy | verdict | write us (avg) | read us (avg) | verify | rc |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        lines.append(f"| {r.get('scenario')} | {r.get('size')} | {r.get('iters')} | "
                     f"{r.get('gds_policy', 'n/a')} | {r.get('verdict', 'n/a')} | "
                     f"{r.get('result_write_us_avg', 'n/a')} | {r.get('result_read_us_avg', 'n/a')} | "
                     f"{r.get('result_verify', 'n/a')} | {r.get('rc', 'n/a')} |")
    if stage_notes:
        lines += ["", "## Notes", ""] + [f"- {n}" for n in stage_notes]
    lines.append("")
    path = run_dir / f"suite_{name}.md"
    path.write_text("\n".join(lines))
    return str(path)
