# BUILD_ID="BMJ_20261030_002019"
"""subtest_roundtrip: one scenario round trip.

Scenarios:
  FS_GDS     file system target, cuFile path
  FS_POSIX   file system target, POSIX bounce path
  RAW_GDS    raw block device region, cuFile path      (overwrites the region)
  RAW_POSIX  raw block device region, POSIX bounce     (overwrites the region)

Writes into run_dir/<SCENARIO>/: cufile.json (GDS only), command.txt, trace.log, run.log, summary.json.
A raw device is never deleted or truncated by this code; the region is only written and read.
"""
import json
import os
import socket
import subprocess
import time
import shutil

import subtest_raw_guard as raw_guard
from datetime import datetime
from pathlib import Path

import subtest_verdict as verdict

TIMEOUT_S = 900
BASE_CFG_CANDIDATES = [
    Path("/usr/local/cuda/gds/cufile.json"),
    Path("/etc/cufile.json"),
]


def scenario_name(storage: str, mode: str) -> str:
    if storage not in ("fs", "raw"):
        raise ValueError(f"storage must be fs or raw, got {storage!r}")
    if mode not in ("gds", "posix"):
        raise ValueError(f"mode must be gds or posix, got {mode!r}")
    return f"{'RAW' if storage == 'raw' else 'FS'}_{'GDS' if mode == 'gds' else 'POSIX'}"


def _text(x) -> str:
    if x is None:
        return ""
    return x.decode(errors="replace") if isinstance(x, bytes) else x


def _strip_line_comments(text: str) -> str:
    # cufile.json uses full-line // comments, which are not valid JSON.
    return "\n".join(l for l in text.splitlines() if not l.lstrip().startswith("//"))


def write_cufile_config(path: Path, compat: int, p2p: int, log_dir: Path, nvtx: bool, force_compat: bool = False) -> None:
    """Start from the installed cufile.json, override only experiment keys."""
    base = next((p for p in BASE_CFG_CANDIDATES if p.exists()), None)
    if base is None:
        raise SystemExit("no base cufile.json found in /usr/local/cuda/gds or /etc")
    cfg = json.loads(_strip_line_comments(base.read_text()))
    cfg["properties"]["allow_compat_mode"] = bool(compat)
    cfg["properties"]["force_compat_mode"] = bool(force_compat)
    cfg["properties"]["use_pci_p2pdma"] = bool(p2p)
    cfg.setdefault("block", {}).setdefault("nvme", {})["use_pci_p2pdma"] = bool(p2p)
    cfg["logging"]["dir"] = str(log_dir)
    cfg["logging"]["level"] = "INFO"
    cfg.setdefault("profile", {})["nvtx"] = bool(nvtx)
    path.write_text(json.dumps(cfg, indent=2) + "\n")


def drop_page_cache() -> dict:
    r = subprocess.run(["sudo", "-n", "sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches"],
                       capture_output=True, text=True)
    return {"rc": r.returncode, "stderr": r.stderr.strip()}


def run(run_dir: Path, binary: Path, storage: str, mode: str, size: int, iters: int,
        offset: int, compat: int, p2p: int, drop_caches: bool, keep: bool, nvtx: bool,
        workdir: Path = None, device: str = None, policy: str = "",
        force_compat: bool = False, raw_consent: bool = False, nsys: bool = False,
        trace_cmd: bool = False) -> dict:
    scenario = scenario_name(storage, mode)
    out = run_dir / scenario
    out.mkdir(parents=True, exist_ok=True)

    if storage == "raw":
        if not device or not str(device).startswith("/dev/"):
            raise SystemExit("raw storage needs --raw-device /dev/<block device>")
        guard = raw_guard.validate_raw_device(device, offset, size, raw_consent)
        target = Path(guard["device"])
        keep = True   # never delete a block device
    else:
        if workdir is None:
            raise SystemExit("fs storage needs --workdir")
        # All generated test files must reside beneath root/exe_out.
        exe_out = Path(__file__).resolve().parents[2] / "exe_out"
        if not workdir.resolve().is_relative_to(exe_out.resolve()):
            raise SystemExit("--workdir must be within root/exe_out (mount a test filesystem there if needed)")
        workdir.mkdir(parents=True, exist_ok=True)
        target = workdir / f"bx_gds_{scenario}_{int(time.time())}.bin"

    # All runtime temporary data / generated CUDA cache must stay under exe_out.
    for name in ("tmp", "cuda_cache", "xdg_cache"):
        (out / name).mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, TMPDIR=str(out / "tmp"),
               CUDA_CACHE_PATH=str(out / "cuda_cache"),
               XDG_CACHE_HOME=str(out / "xdg_cache"),
               PYTHONDONTWRITEBYTECODE="1")
    if mode == "gds":
        cfg = out / "cufile.json"
        write_cufile_config(cfg, compat, p2p, out, nvtx, force_compat)
        env["CUFILE_ENV_PATH_JSON"] = str(cfg)
        env["CUFILE_FORCE_COMPAT_MODE"] = "1" if force_compat else "0"
        env["CUFILE_ALLOW_COMPAT_MODE"] = "1" if compat else "0"
        env["CUFILE_USE_PCIP2PDMA"] = "1" if p2p else "0"
    if storage == "raw":
        env["BX_RAW_GUARD_OK"] = "1"
        env["BX_RAW_APPROVED_RDEV"] = guard["devnum"]

    cmd = [str(binary), scenario, str(target), str(size), str(iters), str(offset)]
    if nsys and trace_cmd:
        raise SystemExit("--nsys and --trace-cmd cannot be combined in this version")
    if trace_cmd:
        if not shutil.which("trace-cmd"):
            raise SystemExit("--trace-cmd needs trace-cmd and kernel tracing permissions")
        cmd = ["trace-cmd", "record", "-o", str(out / "block_nvme.dat"),
               "-e", "block:block_rq_issue", "-e", "block:block_rq_complete", "--", *cmd]
    if nsys:
        if not shutil.which("nsys"):
            raise SystemExit("--nsys needs Nsight Systems (nsys) installed")
        cmd = ["nsys", "profile", "-t", "cuda,nvtx,osrt", "--force-overwrite=true",
               "-o", str(out / "capture"), *cmd]
    (out / "command.txt").write_text(" ".join(cmd) + "\n")

    summary = {"scenario": scenario, "storage": storage, "mode": mode, "target": str(target),
               "offset": offset, "size": size, "iters": iters, "compat": compat,
               "p2p": p2p, "force_compat": force_compat, "nvtx": nvtx, "nsys": nsys, "trace_cmd": trace_cmd, "gds_policy": policy or ("n/a" if mode != "gds" else "unspecified")}
    if drop_caches:
        summary["drop_caches"] = drop_page_cache()
        if summary["drop_caches"]["rc"] != 0:
            raise SystemExit("drop_caches requested but not permitted; no benchmark run (see stderr)")

    started = datetime.now().isoformat(timespec="seconds")
    nvfs_loaded = verdict.nvfs_present()
    nvfs_before = verdict.read_nvfs_stats() if mode == "gds" else {}

    t0 = time.time()
    try:
        r = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=TIMEOUT_S)
        rc, stdout, stderr = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        rc, stdout, stderr = -999, _text(e.stdout), _text(e.stderr)

    (out / "trace.log").write_text(stderr)
    (out / "run.log").write_text(stdout)
    summary.update(rc=rc, wall_s=round(time.time() - t0, 3))

    for line in stdout.splitlines():
        if line.startswith("RESULT|"):
            for kv in line.split("|")[1:]:
                k, _, v = kv.partition("=")
                summary[f"result_{k}"] = v

    if mode == "gds":
        nvfs_after = verdict.read_nvfs_stats()
        evidence = verdict.scan_cufile_logs(out)
        v = verdict.classify(mode, rc, summary.get("result_verify") == "ok",
                             nvfs_loaded, nvfs_before, nvfs_after, evidence,
                             strict_requested=(compat == 0), force_compat=force_compat)
        summary["verdict"] = v["verdict"]
        summary["verdict_reason"] = v["reason"]
        summary["io_deltas"] = v["io_deltas"]
        verdict.write_report(out, scenario, {
            "host": socket.gethostname(),
            "started": started,
            "command": " ".join(cmd),
            "policy": policy,
            "summary": summary,
            "verdict": v,
            "nvfs_loaded": nvfs_loaded,
            "nvfs_before_count": len(nvfs_before),
            "nvfs_after_count": len(nvfs_after),
            "evidence": evidence,
            "cufile_json": str(out / "cufile.json"),
        })

    if storage == "fs" and keep:
        summary["kept_file"] = str(target)
    elif storage == "fs" and target.exists():
        target.unlink()

    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary
