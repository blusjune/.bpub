# BUILD_ID="BMJ_20261030_002019"
"""Adversarial verification: fail closed; negative cases must not be mislabelled native."""
import json
import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG / 'subtests'))
import subtest_raw_guard as guard
import subtest_support as support
import subtest_verdict as verdict
import subtest_roundtrip as roundtrip


class GuardGeometryTests(unittest.TestCase):
    def test_negative_unaligned_boundary_and_overflow(self):
        for off, size, capacity in [(-4096, 4096, 65536), (0, 0, 65536),
                                    (4097, 4096, 65536), (0, 512, 65536),
                                    (4096, 65536, 65536), (1 << 80, 4096, 1 << 40)]:
            with self.subTest(off=off, size=size, capacity=capacity):
                with self.assertRaises(ValueError):
                    guard.check_geometry(off, size, capacity)

    def test_exact_end_accepted(self):
        guard.check_geometry(4096, 4096, 8192)

    def test_consent_and_regular_file_and_missing(self):
        with self.assertRaisesRegex(ValueError, 'i-accept-overwrite'):
            guard.validate_raw_device('/dev/null', 0, 4096, False)
        with self.assertRaisesRegex(ValueError, 'not a block device'):
            guard.validate_raw_device('/dev/null', 0, 4096, True)
        with self.assertRaises((FileNotFoundError, ValueError)):
            guard.validate_raw_device('/dev/this_dev_does_not_exist_789456', 0, 4096, True)

    def fake_partition(self, mount=False, swap=False, holders=False, whole=False):
        # Simulate a partition through injected sysfs / proc fixtures, NOT privileged disk activity.
        temp = tempfile.TemporaryDirectory()
        root = Path(temp.name)
        node = root / 'sys/devices/pci/mockpart'
        node.mkdir(parents=True)
        devdir = root / 'sys/dev/block'
        devdir.mkdir(parents=True)
        (devdir / '8:1').symlink_to(node)
        (node / 'size').write_text('1024')
        if not whole:
            (node / 'partition').write_text('1')
        (node / 'holders').mkdir()
        if holders:
            (node / 'holders' / 'crypt').touch()
        (root / 'proc/self').mkdir(parents=True)
        (root / 'proc/self/mountinfo').write_text('12 1 8:1 / /mnt rw - ext4 /dev/mockp1 rw\n' if mount else '')
        (root / 'proc/swaps').write_text('Filename Type Size Used Priority\n' +
                                         ('/dev/null partition 4096 0 -2\n' if swap else ''))
        return temp, root

    def check_fake(self, **kwargs):
        temp, root = self.fake_partition(**kwargs)
        orig = Path.stat
        def patched(self, *args, **opts):
            if str(self) == '/dev/null':
                return SimpleNamespace(st_mode=stat.S_IFBLK, st_rdev=os.makedev(8, 1))
            return orig(self, *args, **opts)
        try:
            with patch.object(Path, 'stat', patched):
                return guard.validate_raw_device('/dev/null', 0, 4096, True,
                                                  sys_root=root / 'sys', proc_root=root / 'proc')
        finally:
            temp.cleanup()

    def test_fake_unmounted_partition_can_pass(self):
        self.assertEqual(self.check_fake()['devnum'], '8:1')

    def test_mounted_block_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'mounted'):
            self.check_fake(mount=True)

    def test_swap_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'swap'):
            self.check_fake(swap=True)

    def test_holders_rejected(self):
        with self.assertRaisesRegex(ValueError, 'holders'):
            self.check_fake(holders=True)

    def test_whole_disk_rejected(self):
        with self.assertRaisesRegex(ValueError, 'whole block disks'):
            self.check_fake(whole=True)


class PlatformPolicyTests(unittest.TestCase):
    def test_gdscheck_p2pdma_capability_parsing_resists_unsupported_row(self):
        import bx_gds_run_top as top
        self.assertEqual(top.parse_gdscheck_nvme_modes('NVMe P2PDMA : Unsupported'), set())
        modes = top.parse_gdscheck_nvme_modes('NVMe : p2pdma, compat\nNVMe P2PDMA : Supported')
        self.assertEqual(modes, {'p2pdma', 'compat'})

    def test_spark_native_cli_resolution_is_blocked_before_probe(self):
        import bx_gds_run_top as top
        with tempfile.TemporaryDirectory() as d, patch.object(top, 'static_support',
                return_value={'libcufile': True, 'nvidia_fs': False,
                              'gpu': 'NVIDIA GB10', 'spark': True}):
            with self.assertRaisesRegex(SystemExit, 'DGX Spark'):
                top.resolve_gds_policy('native', Path(d), Path('/bin/true'), Path(d))


class PathEvidenceTests(unittest.TestCase):
    def test_absence_of_nvfs_does_not_deny_p2pdma(self):
        static = {'libcufile': True, 'nvidia_fs': False, 'spark': False}
        probe = {'rc': 0, 'verify_ok': True, 'compat_direct': False}
        self.assertEqual(support.decide(static, probe)['policy'], 'native')

    def test_gb10_hard_blocks_auto_native(self):
        static = {'libcufile': True, 'nvidia_fs': True, 'spark': True}
        probe = {'rc': 0, 'verify_ok': True, 'compat_direct': False}
        self.assertEqual(support.decide(static, probe)['policy'], 'fallback')

    def test_fallback_is_truly_forced_in_configuration(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            base = out / 'base.json'
            base.write_text(json.dumps({'properties': {}, 'logging': {}, 'block': {}}))
            with patch.object(roundtrip, 'BASE_CFG_CANDIDATES', [base]):
                roundtrip.write_cufile_config(out / 'forced.json', 1, 0, out, False, True)
            d = json.loads((out / 'forced.json').read_text())
            self.assertTrue(d['properties']['force_compat_mode'])
            self.assertTrue(d['properties']['allow_compat_mode'])
            self.assertFalse(d['properties']['use_pci_p2pdma'])

    def test_forced_compat_overrides_no_log(self):
        r = verdict.classify('gds', 0, True, False, {}, {}, {}, force_compat=True)
        self.assertEqual(r['verdict'], 'COMPAT_FORCED')

    def test_global_nvfs_counter_is_not_physical_proof(self):
        r = verdict.classify('gds', 0, True, True, {'Read': 0}, {'Read': 1024}, {})
        self.assertEqual(r['verdict'], 'NATIVE_GDS_INDICATED')
        self.assertNotEqual(r['verdict'], 'NATIVE_GDS')

    def test_no_counters_and_no_nvfs_is_not_compat(self):
        r = verdict.classify('gds', 0, True, False, {}, {}, {})
        self.assertEqual(r['verdict'], 'UNDETERMINED')

    def test_strict_success_without_positive_telemetry_is_candidate(self):
        r = verdict.classify('gds', 0, True, False, {}, {}, {}, strict_requested=True)
        self.assertEqual(r['verdict'], 'NATIVE_GDS_CANDIDATE')

    def test_conflicting_evidence_prefers_cufile_self_report(self):
        r = verdict.classify('gds', 0, True, True, {'Read': 0}, {'Read': 10},
                             {'compat_direct': [('cufile.log', 'running in compatible mode')]})
        self.assertEqual(r['verdict'], 'COMPAT_FALLBACK')
        self.assertTrue(r['notes'])

    def test_failed_verification_cannot_pass_even_when_counters_move(self):
        r = verdict.classify('gds', 0, False, True, {'Read': 0}, {'Read': 10}, {})
        self.assertEqual(r['verdict'], 'RUN_FAILED')


if __name__ == '__main__':
    unittest.main()
