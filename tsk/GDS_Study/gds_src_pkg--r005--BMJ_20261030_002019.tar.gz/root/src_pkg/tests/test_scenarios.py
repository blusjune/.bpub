# BUILD_ID="BMJ_20261030_002019"
"""Tests for scenario naming and the raw-device safety gate. Run with the other unit tests."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "subtests"))
import subtest_roundtrip as rt  # noqa: E402


class ScenarioTest(unittest.TestCase):
    def test_scenario_names(self):
        self.assertEqual(rt.scenario_name("fs", "gds"), "FS_GDS")
        self.assertEqual(rt.scenario_name("fs", "posix"), "FS_POSIX")
        self.assertEqual(rt.scenario_name("raw", "gds"), "RAW_GDS")
        self.assertEqual(rt.scenario_name("raw", "posix"), "RAW_POSIX")

    def test_bad_storage_or_mode_is_rejected(self):
        with self.assertRaises(ValueError):
            rt.scenario_name("nfs", "gds")
        with self.assertRaises(ValueError):
            rt.scenario_name("fs", "direct")

    def test_raw_requires_device_path(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(SystemExit):
                rt.run(Path(d), Path("/bin/true"), "raw", "gds", 4096, 1, 0,
                       1, 0, False, False, False, device=None)
            with self.assertRaises(SystemExit):
                rt.run(Path(d), Path("/bin/true"), "raw", "gds", 4096, 1, 0,
                       1, 0, False, False, False, device="/tmp/not_a_device")

    def test_fs_requires_workdir(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(SystemExit):
                rt.run(Path(d), Path("/bin/true"), "fs", "posix", 4096, 1, 0,
                       1, 0, False, False, False, workdir=None)


if __name__ == "__main__":
    unittest.main()
