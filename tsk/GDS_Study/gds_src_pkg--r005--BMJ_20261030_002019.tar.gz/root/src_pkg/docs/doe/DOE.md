# DoE — GDS vs POSIX: source-derived r005 plan

Status: **design only; no hardware data collected for this revision.** All measurements and intermediate results go under `root/exe_out/`. The existing `kv-doe` runner is a QD=1 synchronous transfer-size sweep, not full multi-factor DoE.

| Independent factor | Levels to investigate | Control / risk |
|---|---|---|
| Platform | DGX Spark GB10, Intel + RTX PRO 6000 | Spark compat only; Node2 native unproven |
| I/O path | forced compat, strict cuFile candidate, POSIX | Native evidence graded separately |
| Storage | XFS / ext4 on NVMe, disposable raw partition | Raw destructive, guard must pass; no OS disk |
| I/O direction | GPU→SSD, SSD→GPU | Separate write/read timing and completion |
| Block size | 4, 16, 64, 256 KiB; 1, 4, 8, 16 MiB | Aligned and page-size effects |
| Queue depth | 1, 2, 4, 8, 16, 32 | **Not yet implemented** in test harness |
| Concurrency | 1, 2, 4, 8 host producers | **Not yet implemented** |
| Cache state | cold/warm, prefilled vs sparse file | O_DIRECT bypasses page cache, not all buffering |
| CPU/GPU parallelism | decode active vs idle | **Not yet implemented** |
| Cache reuse | high-prefix-hit vs low-hit traces | **Not yet implemented**, requires real KV workload |

Responses: success/verify rate, elapsed Read and Write, IOPS, payload bandwidth, CPU utilization, Nsight CUDA/NVTX timeline, NVMe block-layer command-to-completion latency where captured, GPU-copy bytes (compat), and location/topology evidence. Durability semantics need independent flush/FUA control.

## Scientific reporting

Perform at least 5 independent randomized/interleaved repetitions for each cell after warm-up; report median, p95 and confidence bands. Do not treat 5 iterations in a single process as 5 independent experiments. Separate estimated, observed and inferred values. Filter out failed runs and list failures explicitly. `kv-doe` produces simple QD=1 CSV per run and **does not yet implement** randomized concurrency or percentile confidence intervals.

## Validity checks

1. Preserve `root/.pyve` in place, write all experiment artifacts under `root/exe_out`.
2. Always run adversarial tests and `observe` on each node before GPU experiment.
3. Node2: verify `gdscheck -p`, installed CUDA/GDS, filesystem, GPU generation and PCIe routes; do not infer support from `nvidia-fs` alone.
4. Node3: force compatibility; never classify native without a vendor-supported route.
5. Reject unsafe raw targets and I/O size overflow before `open`/write; avoid parallel raw jobs.
6. Hardware evidence: BXTRACE is API evidence, `nsys` is CUDA-level evidence, NVMe tracepoints show block commands, **PCIe protocol proof needs validated transport instrumentation**.

## Commands

```bash
./bx_gds_run_top.py observe
./bx_gds_run_top.py suite selftest
./bx_gds_run_top.py kv-doe --sizes-kib 4,64,1024,8192 --mode both --iters 5
```

References and limitations: `docs/report/GDS_technical_report.md`.
