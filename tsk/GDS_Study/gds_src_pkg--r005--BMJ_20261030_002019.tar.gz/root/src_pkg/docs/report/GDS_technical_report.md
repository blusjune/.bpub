# Understanding GPUDirect Storage (GDS) — technical report r005

Task: `task-261022-01`  
Scope: general GDS, API-to-hardware mapping, two-node experimentation and LLM KV-cache movement.  
Status: **design and code review verified; CUDA compilation / physical P2P measurements pending**.

## Executive conclusions (KR + technical terms)

GPUDirect Storage(GDS)는 CPU software가 I/O를 준비하는 **control plane**과 SSD DMA Engine이 GPU memory에 직접 접근하는 **data plane**을 분리합니다. Direct GDS에서는 CPU DRAM의 payload bounce copy를 회피할 수 있습니다. 단, NVMe Submission/Completion Queue, filesystem metadata, interrupt 및 API 호출은 여전히 CPU/system memory를 사용할 수 있습니다 [1][2].

- **DGX Spark / GB10 (node3)**: NVIDIA는 *compatibility mode only*로 명시합니다. `nvidia-fs`를 로드하지 않아야 합니다 [3]. `cuFileRead()` 성공은 native P2P를 뜻하지 않습니다.
- **Intel + RTX PRO 6000 (node2)**: 별도 확인이 필요합니다. NVMe P2PDMA는 `nvidia-fs`가 없어도 작동할 수 있으므로 모듈의 유무로 native/compat를 확정하지 않습니다 [2][4]. GPU/driver/kernel/firmware/PCIe topology와 `gdscheck -p`, 실제 per-I/O telemetry를 확인해야 합니다.
- **KV Cache Offload/Onboard**: GDS는 GPU memory ↔ NVMe 사이의 payload staging 비용이 병목일 때 효과적입니다. 모든 KV Cache I/O에서 우월한 것은 아닙니다. Block size, batching, concurrency, queue depth, NVMe random read IOPS, attention scheduling, replay/eviction 정책이 결과를 지배합니다. 이 프로젝트의 KV DoE는 **단일 동기식 QD=1 microbenchmark**이며 실제 LMCache/vLLM trace와 다릅니다.

## 1. GDS란 무엇인가?

`libcufile.so`의 `cuFileHandleRegister()`, `cuFileBufRegister()`, `cuFileRead()` 및 `cuFileWrite()` API가 GPU 버퍼를 I/O 대상으로 제공합니다 [1][5]. Legacy GDS는 `nvidia-fs.ko` 인터페이스를 사용합니다. 지원되는 x86 NVMe 구성에서 Linux upstream `PCI P2PDMA`는 `nvidia-fs`와 전용 NVMe patch 없이 가능한 별도 native 경로입니다 [2][4].

## 2. 설계 철학과 제약

1. **Zero-host-bounce**: SSD ↔ GPU data payload에서 별도 CPU DRAM staging copy 제거
2. **Preserve storage stack**: Filesystem extent → block request → NVMe command 생성은 CPU/kernel에서 수행
3. **Orthogonal planes**: Host CPU MMU(virtual→physical), IOMMU(DMA translation/protection), GPU GMMU(kernel GPU VA) 및 GPU BAR/DMA address mapping은 별도의 기능. *모든 I/O가 MMU→IOMMU→GMMU 순서로 통과하는 것은 아닙니다.*
4. **Topology-aware**: 같은 PCIe switch 아래에서도 ACS Redirect, root-port routing, IOMMU, driver 지원으로 P2P가 제한될 수 있음 [4][6]
5. **Compatibility is distinct from native**: `allow_compat_mode=true`는 fallback 허용, `force_compat_mode=true`는 compatibility 강제 [5][7]. `--gds-policy fallback`은 양쪽을 명시적으로 설정합니다.
6. **Conservative evidence**: API 성공/전역 NVFS counter/`gdscheck` capability alone은 특정 PCIe P2P transaction의 물리적 증거가 아님.

## 3. API-level scenarios

| Case | API | Typical payload path | Key extra work | Code |
|---|---|---|---|---|
| init | `cudaMalloc`, `cuFileDriverOpen`, `cuFileBufRegister`, `cuFileHandleRegister` | No SSD payload | Pin/map GPU buffer, file handle setup | `src/bx_gds_basic.cu` |
| Direct read | `cuFileRead` | NVMe DMA Memory Write TLP → GPU PCIe EP → GPU memory | CPU prepares SQ/PRP or SGL, completion | FS_GDS / RAW_GDS (support conditional) |
| Direct write | `cuFileWrite` | SSD DMA Memory Read Request ← GPU EP Completion Data | GPU producer synchronization required | FS_GDS / RAW_GDS |
| Unregistered buffer | `cuFileRead` without registration | May stage through internal registered GPU buffer | Additional device copy; implementation-dependent | static Mermaid only |
| Forced compat | `cuFileRead/Write`, `force_compat_mode` | SSD DMA ↔ CPU RAM ↔ CUDA copy ↔ GPU | Extra RAM staging/PCIe or fabric use | `--gds-policy fallback` |
| POSIX baseline | `pread/pwrite`, `cudaMemcpy` | CPU DRAM staging | Explicit `cudaMemcpy` and CPU I/O | FS_POSIX / RAW_POSIX |
| Stream/async | `cuFileReadAsync`, CUDA stream | Depends on platform support | Ordering with subsequent kernels | Design-only; no code implementation |

**Important**: GPU SM probe events only prove the location and timing of an executed probe kernel. They DO NOT measure storage DMA TLPs, PCIe Root Complex arbitration or IOMMU TLB misses. Sequence diagrams generated from BXTRACE label *API observations*; annotated hardware diagrams show architectural inference, not captured wire traffic.

## 4. LLM inference: KV Cache offload/onboard

### Offload (GPU → SSD)

CUDA attention memory is generated/updated on GPU. After producer completion and visibility requirements are met, KV blocks are gathered or already laid out contiguously in one or more registered GPU buffers; `cuFileWrite()` moves them to a preallocated NVMe-backed file/region. The SSD Controller is the typical PCIe DMA Initiator and performs DMA Reads of GPU-exposed memory. Write durability (filesystem flush, NVMe FUA, `fsync` requirements) is a separate policy question, not implied solely by the timing of user-level `cuFileWrite()`.

### Onboard (SSD → GPU)

Lookup block metadata, select prefetched KV blocks, issue `cuFileRead()` into registered GPU memory, synchronize consumption with CUDA. NVMe DMA Writes target GPU-exposed memory; GPU SMs consume it only when the supported CUDA/GDS memory visibility contract is satisfied. A cache miss may stall attention decoding until transfer completion. GDS is most attractive when staging avoids host bounce cost and multiple requests allow overlapping compute and I/O.

### Test hypotheses and limitations

- `4 KiB / 64 KiB / 1 MiB / 8 MiB` block sizes (with further DoE points) may show the control-plane fixed cost vs amortized throughput knee.
- `QD=1` from `kv-doe` is intentionally **not a production model**. To predict large-batch serving, add overlapped/async I/O, queue depth, mixed read/write, multi-tenant contention, prefix-reuse distribution, cache residency and eviction.
- Actual KV tensor shape includes layers, KV heads, head-dim, dtype, token block layout and packing; this microbenchmark merely transfers patterned bytes, not model-generated KV tensors.
- Different bandwidth ceilings: SSD NAND throughput/IOPS, PCIe link, root/switch, GPU external DMA mapping, GDS overhead, CUDA copy (compat) and CPU filesystem work; measure each rather than assume.

## 5. Hardware/Software sequence diagrams

Render the supplied Mermaid scripts in `docs/diagrams/`:

- `architecture_layers.mmd`: layered architecture and address translation boundary
- `scenario_gds_read.mmd`, `scenario_gds_write.mmd`: direct-path architectural model
- `scenario_posix_bounce.mmd`: explicit POSIX staging baseline
- `fs_gds_scenario.mmd`, `raw_gds_scenario.mmd`: filesystem/raw device control path
- `evidence_boundaries.mmd`: observed vs inferred components, counterevidence
- `kv_offload_onboard.mmd`: KV-cache staging/sync policy

Trace-generated diagrams derive only from `BXTRACE` events (`trace2mermaid.py`); they cannot reconstruct uninstrumented SSD/IOMMU/GPU memory-controller events. The code uses host-side `BXTRACE` and CUDA SM probes with NVTX API ranges; `nsys` adds CUDA/NVTX timing, not PCIe bus protocol proof.

## 6. Evidence grading and node plan

| Result label | Meaning | Physical P2P proven? |
|---|---|---|
| `COMPAT_FORCED` | Config and environment force compat path | No |
| `COMPAT_FALLBACK` | cuFile explicitly self-reported compatibility | No |
| `NATIVE_GDS_CANDIDATE` | Strict cuFile success, no compat self-report; positive bus proof absent | **No** |
| `NATIVE_GDS_INDICATED` | Shared nvidia-fs counters increased; possible concurrent traffic | **No** |
| `UNDETERMINED` | Missing/unreliable attribution | No |
| `RUN_FAILED` | I/O failed or data mismatch | No |

Node3: execute `suite smoke` with forced compatibility; compare cuFile vs POSIX staged path. Node2: collect `observe`, use `gdscheck -p`, inspect driver support, run strict probe, verify logs; if the environment supports NVMe P2PDMA, setting `--p2p 1` is conditional and should not be done blindly. Attach `nsys` GPU timelines (optional `--nsys`) and Linux `block:block_rq_issue`, `block:block_rq_complete` via optional `--trace-cmd` when privileged kernel tracing is available. This is not a PCIe packet trace. For **physical** PCIe DMA routing, a verified platform-specific hardware counter or PCIe analyzer may be required.

### Raw device safety

The runner denies whole block disks, mounted partitions, active swap, device holders, misaligned/overflow ranges and missing operator consent. A user must provide a **dedicated disposable partition** and exclusive access. Direct invoking the CUDA binary with RAW mode is disallowed by its guard unless the launcher supplies the guard environment variable. The check cannot eliminate hot-plug or TOCTOU races, and is not a substitute for operator isolation. Read-only data collection remains safe by default.

### Output isolation

Source/docs/tests live in `root/src_pkg`. All runtime products must be in `root/exe_out`; file-backed tests must place `--workdir` inside that tree. To benchmark a separate SSD filesystem, the administrator may mount the test filesystem at a subdirectory **inside** `root/exe_out` (not an arbitrary outside path). `root/.pyve` remains at its original location by explicit user exception.

## 7. Verified state vs unverified state

**Verified**: Python CLI/unit/adversarial tests on this development host; raw safety fixture tests, code/header checks and generated archive integrity.  
**Not verified**: real CUDA compilation on DGX Spark or RTX PRO 6000, actual cuFile I/O, NVMe tracepoint collection, PCIe P2P throughput, inter-turn KV cache integration.  
**No claim**: sample perf numbers, theoretical BW estimates or user-space trace events constitute measured hardware DMA path.

## References (official first-party sources)

1. NVIDIA, [GPUDirect Storage Design Guide](https://docs.nvidia.com/gpudirect-storage/design-guide/).
2. NVIDIA, [GDS Overview Guide](https://docs.nvidia.com/gpudirect-storage/overview-guide/): legacy NVFS and upstream NVMe PCI P2PDMA.
3. NVIDIA, [GDS Release Notes](https://docs.nvidia.com/gpudirect-storage/release-notes/index.html): DGX Spark compatibility only; Linux >=6.17 NVFS/SGL caveat; PCI P2PDMA differences.
4. NVIDIA, [GDS Installation and Troubleshooting Guide](https://docs.nvidia.com/gpudirect-storage/troubleshooting-guide/): NVMe P2PDMA support, required driver configuration, `gdscheck` and topology.
5. NVIDIA, [cuFile API Reference](https://docs.nvidia.com/gpudirect-storage/api-reference-guide/): Compatibility Mode, `force_compat_mode`, APIs.
6. Linux Kernel Documentation, [PCI Peer-to-Peer DMA Support](https://docs.kernel.org/driver-api/pci/p2pdma.html): switch/ACS/root routing and safety constraints.
7. NVIDIA, [GDS Benchmarking and Configuration Guide](https://docs.nvidia.com/gpudirect-storage/configuration-guide/): `allow_compat_mode`, `force_compat_mode`, `use_pci_p2pdma`.
