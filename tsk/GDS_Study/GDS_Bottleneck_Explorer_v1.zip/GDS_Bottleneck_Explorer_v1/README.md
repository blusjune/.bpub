# GDS Bottleneck Explorer

Private, browser-local scenario model for LLM KV cache onboard/offload on DGX Spark and discrete RTX Pro 6000 systems. This application does not connect to hardware or collect benchmarks. All initial numeric performance inputs are assumptions. User-declared measured inputs remain distinct from calculated results.

## Run

The deployment is buildless. Serve `dist/` with a static HTTP server. The hosted entry point is `dist/index.html`; no dependencies or external CDN requests are required.

## Validate

```bash
node --test tests/model.test.mjs
node --check dist/app.mjs
node --check dist/model.mjs
```

## Scope

- Read/write direction, POSIX buffered, O_DIRECT staging and GDS/cuFile routes.
- Spark compatibility-only enforcement and unified LPDDR path; discrete RTX GDDR path.
- Size, QD, SSD BW/latency/IOPS, root/link/memory/copy BW, CPU/FS/mapping cost.
- Resource ceilings, unloaded latency, finite KV batch time and compute-overlap window.
- Three-route size sweep, baseline A comparison and provenance-aware JSON import/export.
- User-entered end-to-end measurement comparison is suspended after benchmark condition changes.

See the application's Model & Evidence panel for formulas, assumptions, limits, and official NVIDIA references. Topology is conceptual and must be calibrated. Direct DMA verification is a user declaration; neither GPU generation nor installed cuFile implies support. IOMMU/alignment fallback is an explicit conservative scenario, not a prediction of driver success. SSD completion does not imply fsync or power-loss persistence. Token throughput and p99 latency are outside this model.

## Validation record

18 Node tests passed, including a 216-scenario parameter matrix covering both environments, all routes, both directions, sizes, QD and cache hits. Browser checks covered 4 KiB QD1 latency bottleneck, QD changes, baseline capture and environment switch, Spark compatibility, offload write BW, direct DMA declaration, IOMMU fallback, cache hits, measured-value labels, stale measurement handling, JSON download and successful restore. No hardware benchmark was performed.

## Privacy

Owner-private hosting is required. No public access change is authorized. Scenario data is saved only to this browser's localStorage and optional downloaded JSON. There is no application backend, telemetry, hardware agent, API credential, or external runtime dependency.
