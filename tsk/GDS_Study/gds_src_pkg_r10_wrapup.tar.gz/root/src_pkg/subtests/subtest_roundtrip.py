"""subtest_roundtrip: one scenario round trip.

Scenarios:
  FS_GDS     file system target, cuFile path
  FS_POSIX   file system target, POSIX bounce path
  RAW_GDS    raw block device region, cuFile path      (overwrites the region)
  RAW_POSIX  raw block device region, POSIX bounce     (overwrites the region)

Writes into run_dir/<SCENARIO>/: cufile.json (GDS only), command.txt, trace.log, run.log, summary.json.
A raw device is never deleted or truncated by this code; the region is only written and read.
"""
import json
import os
import subprocess
import time
from pathlib import Path

TIMEOUT_S = 900
BASE_CFG_CANDIDATES = [
    Path("/usr/local/cuda/gds/cufile.json"),
    Path("/etc/cufile.json"),
]


def scenario_name(storage: str, mode: str) -> str:
    if storage not in ("fs", "raw"):
        raise ValueError(f"storage must be fs or raw, got {storage!r}")
    if mode not in ("gds", "posix"):
        raise ValueError(f"mode must be gds or posix, got {mode!r}")
    return f"{'RAW' if storage == 'raw' else 'FS'}_{'GDS' if mode == 'gds' else 'POSIX'}"


def _text(x) -> str:
    if x is None:
        return ""
    return x.decode(errors="replace") if isinstance(x, bytes) else x


def _strip_line_comments(text: str) -> str:
    # cufile.json uses full-line // comments, which are not valid JSON.
    return "\n".join(l for l in text.splitlines() if not l.lstrip().startswith("//"))


def write_cufile_config(path: Path, compat: int, p2p: int, log_dir: Path, nvtx: bool) -> None:
    """Start from the installed cufile.json, override only experiment keys."""
    base = next((p for p in BASE_CFG_CANDIDATES if p.exists()), None)
    if base is None:
        raise SystemExit("no base cufile.json found in /usr/local/cuda/gds or /etc")
    cfg = json.loads(_strip_line_comments(base.read_text()))
    cfg["properties"]["allow_compat_mode"] = bool(compat)
    cfg["properties"]["use_pci_p2pdma"] = bool(p2p)
    cfg["logging"]["dir"] = str(log_dir)
    cfg["logging"]["level"] = "INFO"
    cfg.setdefault("profile", {})["nvtx"] = bool(nvtx)
    path.write_text(json.dumps(cfg, indent=2) + "\n")


def drop_page_cache() -> dict:
    r = subprocess.run(["sudo", "sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches"],
                       capture_output=True, text=True)
    return {"rc": r.returncode, "stderr": r.stderr.strip()}


def run(run_dir: Path, binary: Path, storage: str, mode: str, size: int, iters: int,
        offset: int, compat: int, p2p: int, drop_caches: bool, keep: bool, nvtx: bool,
        workdir: Path = None, device: str = None) -> dict:
    scenario = scenario_name(storage, mode)
    out = run_dir / scenario
    out.mkdir(parents=True, exist_ok=True)

    if storage == "raw":
        if not device or not str(device).startswith("/dev/"):
            raise SystemExit("raw storage needs --raw-device /dev/<block device>")
        target = Path(device)
        keep = True   # never delete a block device
    else:
        if workdir is None:
            raise SystemExit("fs storage needs --workdir")
        workdir.mkdir(parents=True, exist_ok=True)
        target = workdir / f"bx_gds_{scenario}_{int(time.time())}.bin"

    env = dict(os.environ)
    if mode == "gds":
        cfg = out / "cufile.json"
        write_cufile_config(cfg, compat, p2p, out, nvtx)
        env["CUFILE_ENV_PATH_JSON"] = str(cfg)

    cmd = [str(binary), scenario, str(target), str(size), str(iters), str(offset)]
    (out / "command.txt").write_text(" ".join(cmd) + "\n")

    summary = {"scenario": scenario, "storage": storage, "mode": mode, "target": str(target),
               "offset": offset, "size": size, "iters": iters, "compat": compat,
               "p2p": p2p, "nvtx": nvtx}
    if drop_caches:
        summary["drop_caches"] = drop_page_cache()

    t0 = time.time()
    try:
        r = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=TIMEOUT_S)
        rc, stdout, stderr = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        rc, stdout, stderr = -999, _text(e.stdout), _text(e.stderr)

    (out / "trace.log").write_text(stderr)
    (out / "run.log").write_text(stdout)
    summary.update(rc=rc, wall_s=round(time.time() - t0, 3))

    for line in stdout.splitlines():
        if line.startswith("RESULT|"):
            for kv in line.split("|")[1:]:
                k, _, v = kv.partition("=")
                summary[f"result_{k}"] = v

    if storage == "fs" and keep:
        summary["kept_file"] = str(target)
    elif storage == "fs" and target.exists():
        target.unlink()

    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary
