# GPU Direct Storage (GDS): technical report (draft)

Task: task-261022-01. Status: DRAFT. Sections 1 to 4 contain stated design points that still need citations
(marked [CITE]). Sections 5 onward depend on experiment results not yet collected.

## 0. Conclusions first (provisional)
- GDS lets a storage DMA move data directly to or from GPU memory, avoiding a host bounce buffer.
- Whether native GDS is active on a node depends on platform support (PCIe topology, ACS/IOMMU, driver support).
  On the DGX Spark (GB10, unified memory), compat mode is expected; this must be confirmed from logs.
- For LLM KV cache offload/onboard, GDS is attractive when the offload tier is NVMe and transfers are large and
  batched. Whether it beats a tuned POSIX bounce path for the sizes used in KV cache is an open question for the DoE.

## 1. What GDS is [CITE: NVIDIA GPUDirect Storage design guide]
- cuFile API (user space, libcufile) plus the nvidia-fs kernel module.
- The application registers GPU buffers (cuFileBufRegister) and file handles (cuFileHandleRegister).
- Transfers use cuFileRead / cuFileWrite. Compat mode falls back to POSIX I/O when the native path is unavailable.

## 2. Design philosophy [CITE]
- Remove the host bounce buffer and the extra copy between host and GPU memory.
- Keep the file system and block layer in charge of I/O; GDS changes the data destination, not the storage stack.
- Fallback to POSIX is a correctness and portability feature, not a performance feature.

## 3. When GDS is used
- Large, aligned, mostly sequential I/O into GPU memory (dataset loading, checkpoint I/O, KV cache tiers).
- Not expected to help small random I/O or workloads where the CPU must inspect the data.

## 4. KV cache offload/onboard (analysis to do)
- Offload: GPU KV blocks -> NVMe file. Onboard: NVMe file -> GPU KV blocks.
- Relevant factors: block size (align to 4 KiB and to cuFile chunking), batch size (io_batchsize),
  whether blocks are contiguous in the file, and whether the transfer overlaps decode compute.
- Hypothesis to test in DoE: GDS benefit grows with block size and batching; small blocks favor POSIX + pinned staging.

## 5. Implementation (code state)
- src_pkg/src/bx_gds_basic.cu: gds and posix round trip with BXTRACE host events (core, tid),
  NVTX ranges, and an SM probe kernel that records SM, warp slot and GPU timer.
- src_pkg/trace2mermaid.py: converts trace.log to a mermaid sequence diagram.
- Scenario diagrams: docs/diagrams/ (GDS write/read are hypotheses; posix bounce matches the code).
- Known limits: copy engine, nvidia-fs, SSD DMA, PCIe, IOMMU are not observed by BXTRACE.

## 6. Observed results
- dgxspark, posix, 1 GiB, 1 iteration (cold start): write ~3.2 GiB/s, read ~10.9 GiB/s (single run, not representative).
  Cold-start effects dominate (65 ms first probe launch, first-touch page faults on the readback buffer).
- GDS results: pending.
- rtx6000 results: pending.

## 7. Open questions
1. Does RTX PRO 6000 have native GDS support in the installed driver? (check NVIDIA support matrix) [CITE]
2. On GB10 with unified memory, does cuFile use compat mode for all transfers? (check cuFile logs with INFO level)
3. How much of the GDS path can be observed without kernel instrumentation? Which tracepoints are available for nvidia-fs?
4. Is the GPU %globaltimer resolution sufficient for warp ordering on these GPUs?

## References
[CITE] entries are to be filled with verified sources before this report is circulated.
