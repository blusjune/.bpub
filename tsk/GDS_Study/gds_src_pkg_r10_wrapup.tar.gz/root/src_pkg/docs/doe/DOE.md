# DoE: GDS vs POSIX bounce on two nodes

Status: plan. No results yet. Run ids and results go to ../../exe_out/<host>/<ts>/.

## Nodes
| Node | Hardware | OS | Expected GDS path |
|---|---|---|---|
| dgxspark | NVIDIA GB10 (unified memory), Ubuntu 24.04.4, driver 580.126.09, CUDA 13.0 | Ubuntu 24.04 | compat mode expected (to be confirmed from cuFile logs) |
| rtx6000 | Intel CPU, NVIDIA RTX PRO 6000 (PCIe discrete GPU), Ubuntu 24.04 | Ubuntu 24.04 | native GDS not confirmed; support matrix to be verified |

## Factors
| Factor | Levels | Notes |
|---|---|---|
| mode | gds, posix | the comparison of interest |
| compat | 0 (strict), 1 (allow fallback) | compat=0 shows whether native GDS is possible at all |
| size | 256 MiB, 1 GiB, 4 GiB | must be a multiple of 4096 |
| drop_caches | off, on | O_DIRECT already bypasses page cache; keep as a control |

## Fixed
- iters per run: 10 (first iteration discarded from statistics as warm-up)
- O_DIRECT, 4 KiB aligned buffers, one device, same file path class (NVMe mount under test)
- nvtx on for one repetition per cell (for nsys), off for timing repetitions (probe overhead)
- Same binary build per node; build.log retained

## Responses
- write_us_avg, read_us_avg (from RESULT line)
- GPU probe elapsed time (gpu_elapsed_ms) for after_write and after_read
- cuFile fallback evidence: presence of compat-path lines in cuFile log (to be defined after first run)
- correctness: verify=ok

## Repetitions and analysis
- 5 repetitions per cell, interleaved (not all gds then all posix) to reduce drift
- report median and min/max; no claims from a single run
- record `nvidia-smi` clocks and temperature at start of each run

## Controls and checks before the main run
1. env stage on each node; confirm cufile.json allow_compat_mode and use_pci_p2pdma values
2. first launch warm-up: confirm the 65 ms lazy-load effect seen on dgxspark is excluded from timing
3. pinning CPU core with taskset to reduce core-migration variance (to be added to run command)
