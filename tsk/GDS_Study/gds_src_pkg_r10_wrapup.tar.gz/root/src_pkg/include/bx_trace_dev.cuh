/* bx_trace_dev.cuh - device-side probe. Call from __global__/__device__ code.
 * Use BX_DEV_PROBE(tag) so the record carries the call-site line automatically.
 * Reads %smid, %warpid, %laneid, %globaltimer via PTX (no printf).
 */
#ifndef BX_TRACE_DEV_CUH
#define BX_TRACE_DEV_CUH

#include "bx_trace.h"

__device__ __forceinline__ bx_dev_rec_t bx_dev_probe(int tag, unsigned int line) {
    bx_dev_rec_t r;
    unsigned long long t;
    unsigned int smid, warpid, laneid;
    asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t));
    asm volatile("mov.u32 %0, %%smid;" : "=r"(smid));
    asm volatile("mov.u32 %0, %%warpid;" : "=r"(warpid));
    asm volatile("mov.u32 %0, %%laneid;" : "=r"(laneid));
    r.gtimer_ns = t;
    r.smid = smid;
    r.warpid = warpid;
    r.laneid = laneid;
    r.line = line;
    r.tag = tag;
    return r;
}

#define BX_DEV_PROBE(tag) bx_dev_probe((tag), (unsigned int)__LINE__)

#endif /* BX_TRACE_DEV_CUH */
