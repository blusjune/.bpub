# Current command guide: r18

Run `./bx_ai_coding_setup.sh --help` for the full English sequence and examples.
[Command numbering and migration](docs/command_numbering.md) lists the new
normal and auxiliary command names. [Help preview](docs/cli_help.txt) is the
exact generated help output.

- Normal setup: 010 -> 020 -> 030 -> 040 -> 050 -> 060 -> 070 -> 080 -> 090
  -> 100 -> 110 -> 120 -> 130 in the same terminal.
- Terminal A: 140_serve_stack; wait for API READY and keep it running.
- Terminal B: 150_test_api; after success, 160_run_agent --project DIR.
- 140a_serve_baseline is an alternative diagnostic server. Never run it
  concurrently with 140 on the same ports. Use Ctrl-C to stop either server.
- Alphabet-suffixed commands are optional or recovery tasks.
- Existing successful installations need no reinstall solely for renumbering.
- Use the same --config for every stage and in both terminals.

Historical revision notes below may refer to bare stage numbers from their
time. Use the current help and migration table as the command authority.

# Source-preserving AI coding environment

Target: DGX Spark / Ubuntu 24.04 / Python 3.12 / CUDA 13.0 / SM 12.1.
One public entry point: `bx_ai_coding_setup.sh`. Without `--execute`, stages print plans only; `010a_validate_scripts` runs CPU/offline tests.

## Update an existing installation

Preserve your existing `configs/stack.json`, sources.lock.json, venv and source trees.
Update the top Bash file, the entire scripts/ and tests/ directories, and configs/stable_matrix_20261024.json. Do not overwrite the existing config with the new stable default.

Example selective extraction (set bx_package to the downloaded ZIP):

```bash
bx_package="$HOME/Downloads/ai_coding_source_package.zip"
unzip -o "$bx_package" 'ai_coding_source/bx_ai_coding_setup.sh' 'ai_coding_source/scripts/*' 'ai_coding_source/tests/*' 'ai_coding_source/configs/stable_matrix_20261024.json' -d /opt/work/ai_coding
```

The new lock guard rejects a config whose source refs differ from the recorded lock. It prevents accidentally relabeling an existing development checkout as a stable release.

## Preserve current sources before instrumentation

```bash
./bx_ai_coding_setup.sh 040a_preserve_sources --offline --execute
./bx_ai_coding_setup.sh 040a_preserve_sources --execute
# Optional independent Git-history copies:
./bx_ai_coding_setup.sh 040a_preserve_sources --bundle --execute
```

Stage 015 never checks out, resets, cleans, stashes, force-updates tags or prunes tags. It records the current commit under refs/bx/retained, snapshots staged/unstaged binary patches separately, archives nonignored untracked files, and records tag objects, git describe, submodule commits, .deps paths, and snapshot checksums. Full mode completes shallow history and re-fetches partial-clone objects, then verifies that no local referenced objects are missing. Offline mode only records what already exists.

Sources remain under /opt/work/ai_coding/root/src/. Their .git data remains available. Existing source-level instrumentation remains in place. Ignored files and .deps trees remain in place; ignored files are not copied into the untracked archive. A parent Git repository is never adopted by mistake.

Snapshots: ROOT/deliverables/ai_coding/source_snapshots/TIMESTAMP/.
New downloads in stage 020 use ordinary full Git clones with tags, without depth/blob filters. Model LFS payloads are still deferred to stage 080. Existing locked checkouts are retained; use stage 015 to complete their history.

Git bundles include the parent repository's Git objects and tags. They do not include LFS weight payloads, independent .deps repositories, or submodule object databases. Preserve the complete src tree for those dependencies; a portable all-dependency backup needs separate bundles/LFS copies. Linked worktrees depend on the original repositories' .git directories.

## Matched stable release candidate, as of 2026-10-24 KST

| Component | Selected source tag | Reason |
| --- | --- | --- |
| PyTorch | v2.13.0 | Shared upstream vLLM/LMCache build pin; individual latest is v2.14.1 |
| Transformers | v5.19.0 | Newest reviewed stable release within vLLM >=5.16.1,<5.20.0; individual latest v5.20.2 is excluded |
| vLLM | v0.32.0 | Latest reviewed stable release |
| LMCache | v0.5.6 | Latest reviewed stable release |
| OpenCode | v1.19.4 | Independent HTTP client; latest reviewed stable release, Bun 1.4.4 |

See configs/stable_matrix_20261024.json for immutable commit/tag object IDs, metadata edges, release URLs and validation status. This is a reviewed dependency-baseline candidate, not a claimed GPU/model/connector compatibility guarantee. Full transitive resolution, Spark native builds and Qwen cold/warm/cross-process KV transfer still require target validation.

Stable profiles also apply the reviewed NumPy 2.2.6 baseline and joint protobuf constraints before native builds. The full transitive solve is still unverified.

The source profile is frozen to this dated matrix. Future release updates require a reviewed matrix revision; the tool does not silently track new main/dev heads.

## Prepare stable source trees without changing the current installation

Run stage 015 first to preserve current sources and fetch history/tags, then:

```bash
./bx_ai_coding_setup.sh 040b_prepare_stable --profile-name stable_20261024 --execute
```

It validates tag commits against the dated matrix and checks the fetched vLLM/LMCache PyTorch/Transformers requirements. Sources are linked worktrees under ROOT/src/profiles/stable_20261024/. The original source HEADs and current venv remain unchanged. New config and venv root: ROOT/profiles/stable_20261024/. It reuses the existing model path and commit lock. Interrupted submodule preparation can be retried with the same unchanged profile plan. An already completed profile is never overwritten.

Continue with the same profile config on every stage:

```bash
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 030_conf_env --execute
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 050_build_pytorch --execute
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 060_build_transformers --execute
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 080_build_vllm --execute
```

The user has deferred the current LMCache stage-060 error. Source preparation does not diagnose that error or run stage 060.

## Source builds and provenance

Core Python packages use local editable source installs and source-origin checks. PyTorch is forced to build Python bindings and is import-tested before downstream builds. Triton is now cloned from source into PROFILE_SOURCE_ROOT/triton at the exact commit pinned by the selected PyTorch checkout; the previous make triton recipe installed a wheel and is no longer used. Triton's own compiler/toolchain dependencies may still be downloaded binaries. This is not an all-transitive-dependencies-from-source closure.

Builds snapshot source state before and after successful component builds. Failed builds leave the source and the pre-build snapshot in place. Third-party .deps source directories are retained. Git tag metadata does not replace runtime compatibility tests. Upstream source files are not rewritten with local BUILD_ID headers; their original contents and hashes are preserved. Maintained controller/test scripts have KST BUILD_ID comments after a required shebang, otherwise on the first line.

OpenCode V1 stable and the previous V2 development layout are detected separately. V1 uses packages/opencode and provider/npm/options configuration; V2 uses packages/cli and providers/package/settings. Bun must match the checked-out packageManager exactly. V1 compilation enables source maps.

System development package stages: 007 installs Python 3.12 headers; 008 installs ELF/DWARF headers. Stages 030/050 install missing headers automatically through sudo/apt. Run the top script as your regular user.

## Instrumentation and profiling

Make edits in the relevant retained worktree, then rebuild using that profile's --config. The commit lock allows working-tree edits while retaining the original commit identity. Use stage 015 offline to capture staged/unstaged instrumentation patches. vLLM's existing-torch helper modifies requirements files; these are recorded as local changes, not hidden as a new release.

Source maps and retained C++/CUDA files help tracing. Device line information, optimization/debug flags and Nsight collection must be configured and recorded for each experiment; this package does not claim a completed GPU profile. Model weight files are data, not compiled source; model implementations are in Transformers/vLLM and those exact trees are retained.

For a new clean installation use the numbered help sequence. Keep source folders, linked Git metadata, .deps and build/install artifacts together. The current service profile uses CPU L1 LMCache only; no SSD I/O is configured.

## Automatic build parallelism

Build jobs are calculated at runtime as `max(1, available logical CPUs - 4)`.
CPU affinity is respected. Set `reserve_cpu_cores` in the active configuration
to change the reserve. Legacy `max_jobs` values are superseded by this policy.
Both `MAX_JOBS` and `CMAKE_BUILD_PARALLEL_LEVEL` receive the calculated value;
`NVCC_THREADS=1` limits supported per-invocation NVCC threading. Components
remain sequential. OpenCode/Bun uses its own scheduling. This is a worker
budget, not CPU isolation or a guarantee of four idle CPUs. Memory usage can
increase with parallelism; cgroup CPU time quotas are not measured.

## Revision r13: dependency and addon build repair

The supplied failure log shows a completed LMCache native build followed by
a stale OpenTelemetry exporter dependency conflict, and a separate OpenCode
addon failure using distro node-gyp 9 with the stack Python 3.12 environment.
All pip installs now constrain the shared telemetry baseline to API/SDK/OTLP
1.40.0 and Prometheus 0.61b0, including when using older configuration files.
An incompatible orphan `opentelemetry-exporter-otlp-common` is removed only if
no installed distribution declares a dependency on it, including optional extras.
Other dependency conflicts remain fatal at pip check.
OpenCode builds install node-gyp 10.3.1 under the managed tools directory via
npm, without sudo; its bundled gyp avoids the distro Python metadata wrapper.
Node.js/npm and network access are required. This auxiliary build tool may
use packaged dependencies; primary project builds remain source based.
Retry 090_build_lmcache, then 100_build_opencode after replacing the controller
package. Existing source trees, tags, patches, and compiled outputs are retained.
Target addon compilation and GPU integration remain unverified.

## Revision r14: Bun lifecycle node-gyp selection

The r13 parent-shell node-gyp check was insufficient: Bun still launched the
distro CLI by its absolute path during tree-sitter-powershell installation.
A scoped Node CommonJS preloader now redirects only a node-gyp CLI main entry
to the managed node-gyp 10.3.1. It is enabled through NODE_OPTIONS only for
OpenCode build subprocesses and their children. It also covers an absolute
Node executable and an absolute legacy CLI path; ordinary Node programs are
unchanged. The preloader uses Node's internal Module._load interface, so an
actual trusted dependency lifecycle probe runs before installing OpenCode.
The probe must record v10.3.1 or the stage stops. JOBS is also set explicitly
to the computed worker budget. No system tool or upstream tracked source is
modified. Existing NODE_OPTIONS are preserved.

Validation: 64 CPU/offline tests passed, including real Node execution against
a failing absolute legacy CLI fixture. A separately executed Bun 1.4.4 local
file dependency lifecycle selected the redirected fixture CLI successfully.
This does not certify real native addon compilation on ARM64. Retry only
100_build_opencode after replacing the controller; the supplied new log shows
090_build_lmcache completed and pip check passed.

## Revision r15: correct V2 build artifact discovery

The supplied log shows Bun dependency installation and the CLI build command
completed. The controller then looked in the wrong output directory and for
the wrong executable name. The pinned V2 build script ignores --outdir and
writes packages/cli/dist/cli-linux-arm64/bin/lildax on the Spark host.
The controller now omits --outdir, enables source maps for both layouts,
extracts the reviewed V2 literal binary name, and selects the exact glibc
Linux host output path. V1 opencode-linux-ARCH/bin/opencode remains supported.
Before linking the result as the managed bin/opencode entry, it checks ELF64,
little endian, CPU machine type, and executable permission. Missing artifacts
report both the expected path and observed bin files. Other installed targets
are not silently replaced. Source snapshots and upstream files are preserved.

Validation: 69 tests passed, including the pinned upstream build-script output
contract, V1 and V2 paths, wrong architecture, permissions, missing artifacts,
and idempotent links. Actual target compilation and execution are not run here.
Replace the controller package and retry 100_build_opencode only.

## Revision r16: TorchVision source dependency and model import checks

The supplied vLLM startup log fails before weight loading because Qwen model
inspection imports qwen3_vl, Transformers Qwen2-VL image processing, and finally
torchvision.transforms.v2. TorchVision was absent. A generic vLLM import did
not cover this architecture-specific path. This failure is not evidence of
GPU memory exhaustion or an unsupported model architecture.

Run 070_build_torchvision --execute to clone the full pytorch/vision repository
under SOURCE_ROOT/torchvision, retain tags, and build v0.28.0 at commit
8fb87713a24951e639c494b0f2a8a81b5f8e33a6 against the existing torch 2.13.0.
The source commit is checked against the tag and saved in a separate source
lock. Existing unlocked directories or different torch versions are rejected.
Editable installation uses --no-build-isolation --no-deps, BUILD_VERSION=0.28.0,
PYTORCH_VERSION=2.13.0, FORCE_CUDA=1, and the existing parallel worker settings.
Setuptools, wheel, NumPy, and Pillow are prerequisite packages. Optional image
codec support depends on installed development libraries; this stage does not
claim video or image codec coverage. CPU L1 storage remains unchanged.

Source preservation stage 015 now includes TorchVision. Stage 100 and serving
stages validate its source origin, native extension, transforms.v2 import, and
the exact vLLM Qwen model import path before model serving. Server failures
print log paths and tails in addition to retaining the original logs.

Existing installation recovery:
  ./bx_ai_coding_setup.sh 070_build_torchvision --execute
  ./bx_ai_coding_setup.sh 130_verify_build --execute
  ./bx_ai_coding_setup.sh 140a_serve_baseline --execute

No PyTorch, vLLM, LMCache, OpenCode rebuild or weight download is required for
this missing dependency repair. Target TorchVision native compilation and
model loading are NOT_RUN here; 73 CPU/mock/Git tests passed.

## Revision r17: select the interactive coding agent, not the V2 preview CLI

The stable OpenCode repository contains both packages/opencode (V1 TUI) and
packages/cli (lildax V2 preview). The previous auto detection selected V2 when
both existed. That CLI does not accept the V1 project argument or --model.
Automatic selection now prefers packages/opencode, and the default profile
explicitly selects v1. An existing auto profile also selects V1 without a
source ref change. Explicit v2 profiles remain available for build inspection
but stage 140 rejects them with a migration instruction.

Stage 070 builds the V1 terminal agent with source maps and skips embedding
the optional web UI. For reviewed release tags it supplies the tag version
and latest channel to the build environment. Only the managed symlink that
points exactly to this source tree's legacy lildax host artifact may migrate
to V1; a backup symlink named opencode-v2-preview retains access to that
binary. Unknown symlinks and regular files remain protected.

Stages 070, 100, and 140 check actual CLI help for [project] and --model.
Help emitted on stderr is captured too. Stage 140 also rejects stale V2
provider JSON and asks for stage 090. Source trees, tags, and preview binaries
are retained. Validate the controller, run 100_build_opencode, then
120_conf_services, then 160_run_agent --project DIR. Leave an already ready
vLLM/LMCache service running. No other core rebuild or weight download is
required. If using a custom profile explicitly set to v2, change only its
opencode_layout field to v1 first.

Validation: 78 CPU/mock/Git tests passed. Pinned upstream V1 TUI source
confirms the default $0 [project] command and model option. Actual V1 native
TUI compilation and an end-to-end coding session on Spark remain NOT_RUN.
