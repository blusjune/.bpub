#!/usr/bin/env bash
# BUILD_ID="BMJ_20261025_124855"
# Single public dispatcher. Public stage numbers are independent of Python functions.
set -euo pipefail
bx_bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
bx_python="${BX_SETUP_PYTHON:-python3}"
bx_config="$bx_bundle_dir/configs/stack.json"

bx_help() {
    cat <<'HELP'
Usage: bx_ai_coding_setup.sh [--config FILE] SUBCOMMAND [OPTIONS]

Source-build OpenCode + vLLM + Qwen + LMCache on NVIDIA DGX Spark.
Default root: /opt/work/ai_coding/root/
Source root:  /opt/work/ai_coding/root/src/

NUMBERING POLICY
  Three digits: normal steps, run in ascending order when each step succeeds.
  Three digits + one lowercase letter: optional, recovery or diagnostic steps.
  Auxiliary steps are NOT required for a successful fresh installation.
  Internal Python function names are independent of these public numbers.

NORMAL INSTALLATION AND VERIFICATION: 010 -> 130 (same terminal)
  010_check_host            Inspect ARM64, GB10, CUDA and required tools
  020_prepare_system        Prepare Python development and ELF/DWARF headers
  030_conf_env              Create task directories and the isolated Python environment
  040_download_src          Clone complete source history/tags and lock commits
  050_build_pytorch         Build PyTorch and its matching Triton from source
  060_build_transformers    Install Transformers from retained source
  070_build_torchvision     Build matching TorchVision from retained source
  080_build_vllm            Build vLLM against the existing source PyTorch
  090_build_lmcache         Build LMCache against the same source PyTorch
  100_build_opencode        Build the interactive V1 agent and check CLI support
  110_download_weights      Download and check model weight shards with Git LFS
  120_conf_services         Generate local service and V1 agent configuration
  130_verify_build          Check source origins, CUDA, model imports and CLI tools

NORMAL SERVICE AND AGENT FLOW: 140 -> 150 -> 160 (two terminals)
  140_serve_stack           Start LMCache + vLLM; keep this terminal open
  150_test_api              Test inference/tool calling in a SECOND terminal
  160_run_agent             Run the interactive agent in a SECOND terminal

OPTIONAL / RECOVERY / DIAGNOSTIC COMMANDS
  010a_validate_scripts       Optional controller CPU/mock tests; no GPU/downloads
  020a_repair_python_dev      Repair Python development headers separately
  020b_repair_vllm_deps       Repair ELF/DWARF development headers separately
  040a_preserve_sources       Preserve source edits, history and tags before changes
  040b_prepare_stable         Create a separate reviewed stable source profile
  060a_align_transformers     Align a Transformers tag after a compatibility failure
  140a_serve_baseline         Alternative diagnostic server: vLLM without LMCache

OPTIONS
  --execute              Execute the selected step; otherwise print a plan only.
  --project DIR          Required for 160_run_agent; directory must already exist.
  --offline              040a: snapshot local state without fetching Git history.
  --bundle               040a: also create Git bundles; excludes LFS/submodule objects.
  --profile-name NAME    040b: name of the new isolated stable profile.
  --matrix FILE          040b: reviewed stable compatibility matrix JSON.
  --ref TAG              060a: explicit compatible Transformers tag.
  --config FILE          Select a profile; place BEFORE the subcommand.
  -h, --help             Show this help; never execute work or require Python.

FRESH INSTALLATION EXAMPLE (Terminal A)
  Run each command only after the previous command succeeds.
  Confirm host prerequisites reported by 010 before continuing.
  ./bx_ai_coding_setup.sh 010_check_host --execute
  ./bx_ai_coding_setup.sh 020_prepare_system --execute
  ./bx_ai_coding_setup.sh 030_conf_env --execute
  ./bx_ai_coding_setup.sh 040_download_src --execute
  ./bx_ai_coding_setup.sh 050_build_pytorch --execute
  ./bx_ai_coding_setup.sh 060_build_transformers --execute
  ./bx_ai_coding_setup.sh 070_build_torchvision --execute
  ./bx_ai_coding_setup.sh 080_build_vllm --execute
  ./bx_ai_coding_setup.sh 090_build_lmcache --execute
  ./bx_ai_coding_setup.sh 100_build_opencode --execute
  ./bx_ai_coding_setup.sh 110_download_weights --execute
  ./bx_ai_coding_setup.sh 120_conf_services --execute
  ./bx_ai_coding_setup.sh 130_verify_build --execute

START THE NORMAL SERVICE (Terminal A)
  ./bx_ai_coding_setup.sh 140_serve_stack --execute
  Wait for "API READY". Startup logs are written to:
    /opt/work/ai_coding/root/deliverables/ai_coding/lmcache.log
    /opt/work/ai_coding/root/deliverables/ai_coding/vllm.log
  Keep Terminal A open. The server stays in the foreground; it is not stuck.
  Ctrl-C in Terminal A stops the services started by this command.

TEST AND USE THE AGENT (Terminal B, while Terminal A remains running)
  cd /opt/work/ai_coding/ai_coding_source
  ./bx_ai_coding_setup.sh 150_test_api --execute
  Continue only after the API test succeeds.
  mkdir -p /opt/work/ai_coding/agent_sandbox
  ./bx_ai_coding_setup.sh 160_run_agent --project /opt/work/ai_coding/agent_sandbox --execute
  The agent is interactive and occupies Terminal B until you exit it.

BASELINE DIAGNOSTIC EXAMPLE (alternative to the normal stack)
  Stop 140 with Ctrl-C before starting the baseline on the same API port.
  Terminal A: ./bx_ai_coding_setup.sh 140a_serve_baseline --execute
  Wait for "API READY", then run 150_test_api in Terminal B.
  Stop 140a with Ctrl-C before starting 140 again.
  NEVER run 140 and 140a concurrently on the same ports.

AUXILIARY EXAMPLES (run only when applicable)
  ./bx_ai_coding_setup.sh 010a_validate_scripts
  ./bx_ai_coding_setup.sh 020a_repair_python_dev --execute
  ./bx_ai_coding_setup.sh 020b_repair_vllm_deps --execute
  ./bx_ai_coding_setup.sh 040a_preserve_sources --offline --execute
  ./bx_ai_coding_setup.sh 040a_preserve_sources --bundle --execute
  ./bx_ai_coding_setup.sh 040b_prepare_stable --profile-name stable_20261024 --execute
  ./bx_ai_coding_setup.sh 060a_align_transformers --ref v5.19.0 --execute
  After 060a, rebuild 060_build_transformers and any affected dependents.

SEPARATE PROFILE EXAMPLE
  ./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 030_conf_env --execute
  Use the SAME --config for every later step, including both terminals.
  Creating a profile does not install or validate its full stack automatically.

IMPORTANT BEHAVIOR
  010a_validate_scripts always runs tests, even without --execute; it writes
  bundle-local test results. Every other step defaults to a plan without --execute.
  020 and its repair commands use apt-get and may request sudo authentication.
  050/080 can also repair missing development headers when needed.
  010 checks prerequisites; it does not install CUDA, Bun, Git LFS or drivers.
  Build jobs = max(1, available logical CPUs - reserve_cpu_cores); default reserve=4.
  Replacing this controller does not require reinstalling successful stages.
  The service profile uses CPU L1 cache only; SSD/GDS I/O is not configured.
  API readiness does not prove cache hits, SSD I/O, or coding-agent quality.
  Core projects are built from source; toolchains and transitive dependencies
  may be supplied as binary packages. Native target integration needs validation.
  Legacy command names are rejected with their replacements; no legacy alias
  silently starts a differently numbered operation. See configs/command_migration_r18.json.
HELP
}

while (($#)); do
    case "$1" in
        --config)
            if (($# < 2)); then echo 'ERROR: --config requires a file' >&2; exit 2; fi
            bx_config="$2"; shift 2 ;;
        -h|--help) bx_help; exit 0 ;;
        --*) echo "ERROR: Unknown global option: $1" >&2; exit 2 ;;
        *) break ;;
    esac
done
if (($# == 0)); then bx_help; exit 0; fi
bx_command="$1"; shift
case "$bx_command" in
    010_check_host|020_prepare_system|030_conf_env|040_download_src|050_build_pytorch|060_build_transformers|070_build_torchvision|080_build_vllm|090_build_lmcache|100_build_opencode|110_download_weights|120_conf_services|130_verify_build|140_serve_stack|150_test_api|160_run_agent|010a_validate_scripts|020a_repair_python_dev|020b_repair_vllm_deps|040a_preserve_sources|040b_prepare_stable|060a_align_transformers|140a_serve_baseline) ;;
    005_check_host) echo "ERROR: Legacy command 005_check_host was renamed to 010_check_host. No work was performed." >&2; exit 2 ;;
    007_install_python_dev) echo "ERROR: Legacy command 007_install_python_dev was renamed to 020a_repair_python_dev. No work was performed." >&2; exit 2 ;;
    008_install_vllm_deps) echo "ERROR: Legacy command 008_install_vllm_deps was renamed to 020b_repair_vllm_deps. No work was performed." >&2; exit 2 ;;
    010_conf_env) echo "ERROR: Legacy command 010_conf_env was renamed to 030_conf_env. No work was performed." >&2; exit 2 ;;
    015_preserve_sources) echo "ERROR: Legacy command 015_preserve_sources was renamed to 040a_preserve_sources. No work was performed." >&2; exit 2 ;;
    017_prepare_stable) echo "ERROR: Legacy command 017_prepare_stable was renamed to 040b_prepare_stable. No work was performed." >&2; exit 2 ;;
    020_download_src) echo "ERROR: Legacy command 020_download_src was renamed to 040_download_src. No work was performed." >&2; exit 2 ;;
    025_align_transformers) echo "ERROR: Legacy command 025_align_transformers was renamed to 060a_align_transformers. No work was performed." >&2; exit 2 ;;
    030_build_pytorch) echo "ERROR: Legacy command 030_build_pytorch was renamed to 050_build_pytorch. No work was performed." >&2; exit 2 ;;
    040_build_transformers) echo "ERROR: Legacy command 040_build_transformers was renamed to 060_build_transformers. No work was performed." >&2; exit 2 ;;
    045_build_torchvision) echo "ERROR: Legacy command 045_build_torchvision was renamed to 070_build_torchvision. No work was performed." >&2; exit 2 ;;
    050_build_vllm) echo "ERROR: Legacy command 050_build_vllm was renamed to 080_build_vllm. No work was performed." >&2; exit 2 ;;
    060_build_lmcache) echo "ERROR: Legacy command 060_build_lmcache was renamed to 090_build_lmcache. No work was performed." >&2; exit 2 ;;
    070_build_opencode) echo "ERROR: Legacy command 070_build_opencode was renamed to 100_build_opencode. No work was performed." >&2; exit 2 ;;
    080_download_weights) echo "ERROR: Legacy command 080_download_weights was renamed to 110_download_weights. No work was performed." >&2; exit 2 ;;
    090_conf_services) echo "ERROR: Legacy command 090_conf_services was renamed to 120_conf_services. No work was performed." >&2; exit 2 ;;
    100_verify_build) echo "ERROR: Legacy command 100_verify_build was renamed to 130_verify_build. No work was performed." >&2; exit 2 ;;
    110_serve_baseline) echo "ERROR: Legacy command 110_serve_baseline was renamed to 140a_serve_baseline. No work was performed." >&2; exit 2 ;;
    120_serve_stack) echo "ERROR: Legacy command 120_serve_stack was renamed to 140_serve_stack. No work was performed." >&2; exit 2 ;;
    130_test_api) echo "ERROR: Legacy command 130_test_api was renamed to 150_test_api. No work was performed." >&2; exit 2 ;;
    140_run_agent) echo "ERROR: Legacy command 140_run_agent was renamed to 160_run_agent. No work was performed." >&2; exit 2 ;;
    900_validate) echo "ERROR: Legacy command 900_validate was renamed to 010a_validate_scripts. No work was performed." >&2; exit 2 ;;
    *) echo "ERROR: Unknown subcommand: $bx_command" >&2; exit 2 ;;
esac
for bx_argument in "$@"; do
    if [[ "$bx_argument" == --help || "$bx_argument" == -h ]]; then
        bx_help; exit 0
    fi
done
bx_call() { "$bx_python" "$bx_bundle_dir/scripts/bx_driver.py" --config "$bx_config" "$@"; }
case "$bx_command" in
    010_check_host) bx_call preflight "$@" ;;
    020_prepare_system) bx_call prepare_system "$@" ;;
    030_conf_env) bx_call init "$@"; bx_call env "$@" ;;
    040_download_src) bx_call fetch "$@" ;;
    050_build_pytorch) bx_call build --component pytorch "$@" ;;
    060_build_transformers) bx_call build --component transformers "$@" ;;
    070_build_torchvision) bx_call build_torchvision "$@" ;;
    080_build_vllm) bx_call build --component vllm "$@" ;;
    090_build_lmcache) bx_call build --component lmcache "$@" ;;
    100_build_opencode) bx_call build --component opencode "$@" ;;
    110_download_weights) bx_call weights "$@" ;;
    120_conf_services) bx_call configure "$@" ;;
    130_verify_build) bx_call verify "$@" ;;
    140_serve_stack) bx_call serve "$@" ;;
    150_test_api) bx_call smoke "$@" ;;
    160_run_agent) bx_call agent "$@" ;;
    010a_validate_scripts) bx_call validate "$@" ;;
    020a_repair_python_dev) bx_call install_python_dev "$@" ;;
    020b_repair_vllm_deps) bx_call install_vllm_deps "$@" ;;
    040a_preserve_sources) bx_call preserve_sources "$@" ;;
    040b_prepare_stable) bx_call prepare_stable "$@" ;;
    060a_align_transformers) bx_call align_transformers "$@" ;;
    140a_serve_baseline) bx_call serve --baseline "$@" ;;
esac
