"""subtest_roundtrip: one cuFile (gds) or POSIX bounce (posix) round trip.

Writes into run_dir/<mode>/: cufile.json, command.txt, trace.log (BXTRACE lines),
run.log (stdout incl. RESULT line), summary.json.
"""
import json
import os
import subprocess
import time
from pathlib import Path

TIMEOUT_S = 900


def _text(x) -> str:
    if x is None:
        return ""
    return x.decode(errors="replace") if isinstance(x, bytes) else x


BASE_CFG_CANDIDATES = [
    Path("/usr/local/cuda/gds/cufile.json"),
    Path("/etc/cufile.json"),
]


def _strip_line_comments(text: str) -> str:
    # cufile.json uses full-line // comments, which are not valid JSON.
    return "\n".join(l for l in text.splitlines() if not l.lstrip().startswith("//"))


def write_cufile_config(path: Path, compat: int, p2p: int, log_dir: Path, nvtx: bool) -> None:
    """Start from the installed cufile.json so every other key keeps its default,
    then override only what this experiment controls. cuFile logs go to log_dir
    at INFO so the compat fallback decision is recorded per run."""
    base = next((p for p in BASE_CFG_CANDIDATES if p.exists()), None)
    if base is None:
        raise SystemExit("no base cufile.json found in /usr/local/cuda/gds or /etc")
    cfg = json.loads(_strip_line_comments(base.read_text()))
    cfg["properties"]["allow_compat_mode"] = bool(compat)
    cfg["properties"]["use_pci_p2pdma"] = bool(p2p)
    cfg["logging"]["dir"] = str(log_dir)
    cfg["logging"]["level"] = "INFO"
    cfg.setdefault("profile", {})["nvtx"] = bool(nvtx)  # cuFile internal NVTX ranges
    path.write_text(json.dumps(cfg, indent=2) + "\n")


def drop_page_cache() -> dict:
    r = subprocess.run(["sudo", "sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches"],
                       capture_output=True, text=True)
    return {"rc": r.returncode, "stderr": r.stderr.strip()}


def run(run_dir: Path, binary: Path, mode: str, workdir: Path, size: int, iters: int,
        compat: int, p2p: int, drop_caches: bool, keep: bool, nvtx: bool = False) -> dict:
    out = run_dir / mode
    out.mkdir(parents=True, exist_ok=True)
    workdir.mkdir(parents=True, exist_ok=True)

    target = workdir / f"bx_gds_{mode}_{int(time.time())}.bin"
    cfg = out / "cufile.json"
    write_cufile_config(cfg, compat, p2p, out, nvtx)

    env = dict(os.environ)
    if mode == "gds":
        env["CUFILE_ENV_PATH_JSON"] = str(cfg)

    cmd = [str(binary), mode, str(target), str(size), str(iters)]
    (out / "command.txt").write_text(" ".join(cmd) + "\n")

    summary = {"mode": mode, "compat": compat, "p2p": p2p, "nvtx": nvtx, "size": size, "iters": iters}
    if drop_caches:
        summary["drop_caches"] = drop_page_cache()

    t0 = time.time()
    try:
        r = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=TIMEOUT_S)
        rc, stdout, stderr = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        rc, stdout, stderr = -999, _text(e.stdout), _text(e.stderr)

    (out / "trace.log").write_text(stderr)
    (out / "run.log").write_text(stdout)
    summary.update(rc=rc, wall_s=round(time.time() - t0, 3))

    for line in stdout.splitlines():
        if line.startswith("RESULT|"):
            for kv in line.split("|")[1:]:
                k, _, v = kv.partition("=")
                summary[f"result_{k}"] = v

    if keep:
        summary["kept_file"] = str(target)
    elif target.exists():
        target.unlink()

    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary
