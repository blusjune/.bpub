/*
 * bx_gds_basic.cu - write/read round trip, GDS (cuFile) vs POSIX bounce, with
 * execution-location tracing.
 *
 * Build:
 *   nvcc -O2 -std=c++14 -I../include bx_gds_basic.cu -o bx_gds_basic -lcufile -lcudart -ldl
 *
 * Usage:
 *   bx_gds_basic <gds|posix> <file> <size_bytes> <iters>
 *     size_bytes: non-zero multiple of 4096 (O_DIRECT alignment)
 *
 * Paths:
 *   gds   : cuFileWrite / cuFileRead directly on device buffers (DMA path inside cuFile/nvidia-fs)
 *   posix : cudaMemcpy D2H -> pwrite (write), pread -> cudaMemcpy H2D (read)
 *
 * Probes: after each write and read, a small kernel records SM / warp placement and
 * GPU time (both modes, so the probe cost is the same on both paths).
 *
 * Output: BXTRACE lines on stderr; one RESULT| line on stdout.
 */
#include <cuda_runtime.h>
#include <cufile.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "bx_trace.h"
#include "bx_trace_dev.cuh"

#define BX_ALIGN 4096
#define BX_PROBE_CAP 256
#define BX_PROBE_BLOCKS 4
#define BX_PROBE_THREADS 128
#define BX_TAG_AFTER_WRITE 1
#define BX_TAG_AFTER_READ 2

static void die(const char *msg) {
    fprintf(stderr, "fatal: %s\n", msg);
    exit(1);
}

/* Logs a cuFile status; returns 1 on success. Caller decides whether to die. */
static int trace_cufile(CUfileError_t st, const char *step) {
    BXTRACE("CUFILE_LIB", step, "err=%d cu_err=%d", (int)st.err, (int)st.cu_err);
    return st.err == CU_FILE_SUCCESS;
}

#define CHECK_CUDA(call, comp, step)                                                \
    do {                                                                            \
        cudaError_t _e = (call);                                                    \
        BXTRACE(comp, step, "cudaError=%d(%s)", (int)_e, cudaGetErrorString(_e));   \
        if (_e != cudaSuccess) die("CUDA call failed: " step);                      \
    } while (0)

/* One record per warp: lane 0 of each warp reserves a slot with atomicAdd. */
__global__ void bx_probe_kernel(bx_dev_rec_t *rec, unsigned int *cursor, int tag) {
    if ((threadIdx.x & 31) == 0) {
        unsigned int idx = atomicAdd(cursor, 1u);
        if (idx < BX_PROBE_CAP) rec[idx] = bx_dev_probe(tag);
    }
}

/* Host side of the probe: launch, time with CUDA events, copy back, emit trace lines.
 * Note: the CUDA event times are GPU-side kernel duration; the SM records are per warp. */
static void gpu_probe(const char *label, int tag, bx_dev_rec_t *d_rec, unsigned int *d_cursor) {
    static bx_dev_rec_t h_rec[BX_PROBE_CAP];
    cudaEvent_t e0, e1;

    CHECK_CUDA(cudaMemset(d_cursor, 0, sizeof(unsigned int)), "CUDA_RT", "Memset(probe cursor)");
    CHECK_CUDA(cudaEventCreate(&e0), "CUDA_RT", "EventCreate(start)");
    CHECK_CUDA(cudaEventCreate(&e1), "CUDA_RT", "EventCreate(stop)");

    BXTRACE("CUDA_RT", "LaunchProbe", "label=%s tag=%d grid=%d block=%d",
            label, tag, BX_PROBE_BLOCKS, BX_PROBE_THREADS);
    CHECK_CUDA(cudaEventRecord(e0, 0), "CUDA_RT", "EventRecord(start)");
    bx_probe_kernel<<<BX_PROBE_BLOCKS, BX_PROBE_THREADS>>>(d_rec, d_cursor, tag);
    CHECK_CUDA(cudaGetLastError(), "CUDA_RT", "LaunchCheck");
    CHECK_CUDA(cudaEventRecord(e1, 0), "CUDA_RT", "EventRecord(stop)");
    CHECK_CUDA(cudaEventSynchronize(e1), "CUDA_RT", "EventSynchronize");

    float ms = 0.0f;
    CHECK_CUDA(cudaEventElapsedTime(&ms, e0, e1), "CUDA_RT", "EventElapsedTime");

    unsigned int n = 0;
    CHECK_CUDA(cudaMemcpy(&n, d_cursor, sizeof(n), cudaMemcpyDeviceToHost),
               "CUDA_RT", "MemcpyD2H(probe cursor)");
    if (n > BX_PROBE_CAP) n = BX_PROBE_CAP;
    CHECK_CUDA(cudaMemcpy(h_rec, d_rec, n * sizeof(bx_dev_rec_t), cudaMemcpyDeviceToHost),
               "CUDA_RT", "MemcpyD2H(probe records)");

    BXTRACE("CUDA_RT", "ProbeKernelDone", "label=%s tag=%d gpu_elapsed_ms=%.4f warp_records=%u",
            label, tag, ms, n);
    for (unsigned int i = 0; i < n; i++) bx_trace_gpu_rec(&h_rec[i], label);

    CHECK_CUDA(cudaEventDestroy(e0), "CUDA_RT", "EventDestroy(start)");
    CHECK_CUDA(cudaEventDestroy(e1), "CUDA_RT", "EventDestroy(stop)");
}

int main(int argc, char **argv) {
    if (argc != 5) {
        fprintf(stderr, "usage: %s <gds|posix> <file> <size_bytes> <iters>\n", argv[0]);
        return 1;
    }
    const char *mode = argv[1];
    const char *path = argv[2];
    size_t size = (size_t)strtoull(argv[3], NULL, 10);
    int iters = atoi(argv[4]);

    int use_gds = (strcmp(mode, "gds") == 0);
    if (!use_gds && strcmp(mode, "posix") != 0) die("mode must be gds or posix");
    if (size == 0 || size % BX_ALIGN != 0) die("size must be a non-zero multiple of 4096");
    if (iters < 1) die("iters must be >= 1");

    BXTRACE("CPU_APP", "Main", "mode=%s file=%s size=%zu iters=%d", mode, path, size, iters);

    /* Host buffers, aligned for O_DIRECT. h_chk: posix bounce buffer and verify readback. */
    void *h_pat = NULL, *h_chk = NULL;
    if (posix_memalign(&h_pat, BX_ALIGN, size) || posix_memalign(&h_chk, BX_ALIGN, size))
        die("posix_memalign failed");
    for (size_t i = 0; i < size; i++)
        ((unsigned char *)h_pat)[i] = (unsigned char)(i * 131u + 7u);

    /* Device state (setup, not timed). */
    CHECK_CUDA(cudaSetDevice(0), "CUDA_RT", "SetDevice");
    void *d_w = NULL, *d_r = NULL;
    CHECK_CUDA(cudaMalloc(&d_w, size), "CUDA_RT", "Malloc(write)");
    CHECK_CUDA(cudaMalloc(&d_r, size), "CUDA_RT", "Malloc(read)");
    CHECK_CUDA(cudaMemcpy(d_w, h_pat, size, cudaMemcpyHostToDevice), "CUDA_RT", "MemcpyH2D(pattern)");
    bx_dev_rec_t *d_rec = NULL;
    unsigned int *d_cursor = NULL;
    CHECK_CUDA(cudaMalloc(&d_rec, BX_PROBE_CAP * sizeof(bx_dev_rec_t)), "CUDA_RT", "Malloc(probe rec)");
    CHECK_CUDA(cudaMalloc(&d_cursor, sizeof(unsigned int)), "CUDA_RT", "Malloc(probe cursor)");

    /* O_DIRECT bypasses the page cache for both modes, so timings reflect device I/O. */
    int fd = open(path, O_RDWR | O_CREAT | O_DIRECT, 0644);
    if (fd < 0) { perror("open"); return 1; }
    BXTRACE("POSIX_FS", "Open", "fd=%d flags=O_RDWR|O_CREAT|O_DIRECT", fd);

    CUfileHandle_t fh;
    if (use_gds) {
        if (!trace_cufile(cuFileDriverOpen(), "DriverOpen")) die("cuFileDriverOpen failed");

        /* Field names match /usr/local/cuda/include/cufile.h (CUfileDrvProps_t). */
        CUfileDrvProps_t props;
        memset(&props, 0, sizeof(props));
        CUfileError_t st = cuFileDriverGetProperties(&props);
        BXTRACE("CUFILE_LIB", "DriverGetProperties",
                "err=%d nvfs_version=%u.%u nvfs_dstatusflags=0x%x nvfs_dcontrolflags=0x%x "
                "nvfs_poll_thresh=%zu nvfs_max_direct_io=%zu fflags=0x%x "
                "max_device_cache_kb=%u per_buffer_cache_kb=%u max_device_pinned_kb=%u "
                "max_batch_io_size=%u max_batch_io_timeout_ms=%u",
                (int)st.err,
                props.nvfs.major_version, props.nvfs.minor_version,
                props.nvfs.dstatusflags, props.nvfs.dcontrolflags,
                props.nvfs.poll_thresh_size, props.nvfs.max_direct_io_size,
                props.fflags,
                props.max_device_cache_size, props.per_buffer_cache_size,
                props.max_device_pinned_mem_size,
                props.max_batch_io_size, props.max_batch_io_timeout_msecs);

        CUfileDescr_t descr;
        memset(&descr, 0, sizeof(descr));
        descr.handle.fd = fd;
        descr.type = CU_FILE_HANDLE_TYPE_OPAQUE_FD;
        if (!trace_cufile(cuFileHandleRegister(&fh, &descr), "HandleRegister")) die("handle register failed");
        if (!trace_cufile(cuFileBufRegister(d_w, size, 0), "BufRegister(write)")) die("buf register failed");
        if (!trace_cufile(cuFileBufRegister(d_r, size, 0), "BufRegister(read)")) die("buf register failed");
    }

    double wsum_us = 0.0, rsum_us = 0.0;
    int verify_ok = 1;

    for (int it = 0; it < iters; it++) {
        /* ---- WRITE: device -> storage (timed) ---- */
        long t0 = bx_now_us();
        ssize_t n;
        if (use_gds) {
            BXRANGE_PUSH("cuFileWrite");
            n = cuFileWrite(fh, d_w, size, 0, 0);
            BXRANGE_POP();
            BXTRACE("CUFILE_LIB", "Write", "iter=%d ret=%zd", it, n);
        } else {
            /* cudaMemcpy D2H is executed by a GPU copy engine; the host thread waits here.
             * Copy-engine activity is not visible to BXTRACE (use nsys). */
            CHECK_CUDA(cudaMemcpy(h_chk, d_w, size, cudaMemcpyDeviceToHost), "CUDA_RT", "MemcpyD2H(write)");
            BXRANGE_PUSH("pwrite");
            n = pwrite(fd, h_chk, size, 0);
            BXRANGE_POP();
            BXTRACE("POSIX_BOUNCE", "pwrite", "iter=%d ret=%zd", it, n);
        }
        long t1 = bx_now_us();
        if (n != (ssize_t)size) die("write failed or short");
        wsum_us += (double)(t1 - t0);

        gpu_probe("after_write", BX_TAG_AFTER_WRITE, d_rec, d_cursor);

        /* ---- READ: storage -> device (timed) ---- */
        t0 = bx_now_us();
        if (use_gds) {
            BXRANGE_PUSH("cuFileRead");
            n = cuFileRead(fh, d_r, size, 0, 0);
            BXRANGE_POP();
            BXTRACE("CUFILE_LIB", "Read", "iter=%d ret=%zd", it, n);
        } else {
            BXRANGE_PUSH("pread");
            n = pread(fd, h_chk, size, 0);
            BXRANGE_POP();
            BXTRACE("POSIX_BOUNCE", "pread", "iter=%d ret=%zd", it, n);
            if (n == (ssize_t)size)
                CHECK_CUDA(cudaMemcpy(d_r, h_chk, size, cudaMemcpyHostToDevice), "CUDA_RT", "MemcpyH2D(read)");
        }
        t1 = bx_now_us();
        if (n != (ssize_t)size) die("read failed or short");
        rsum_us += (double)(t1 - t0);

        gpu_probe("after_read", BX_TAG_AFTER_READ, d_rec, d_cursor);

        /* ---- VERIFY (outside timed region) ---- */
        CHECK_CUDA(cudaMemcpy(h_chk, d_r, size, cudaMemcpyDeviceToHost), "CUDA_RT", "MemcpyD2H(verify)");
        if (memcmp(h_chk, h_pat, size) != 0) verify_ok = 0;
        BXTRACE("CPU_APP", "Verify", "iter=%d ok=%d", it, verify_ok);
    }

    printf("RESULT|mode=%s|size=%zu|iters=%d|write_us_avg=%.1f|read_us_avg=%.1f|verify=%s\n",
           mode, size, iters, wsum_us / iters, rsum_us / iters, verify_ok ? "ok" : "FAIL");

    /* ---- Cleanup ---- */
    if (use_gds) {
        trace_cufile(cuFileBufDeregister(d_w), "BufDeregister(write)");
        trace_cufile(cuFileBufDeregister(d_r), "BufDeregister(read)");
        cuFileHandleDeregister(fh);
        BXTRACE("CUFILE_LIB", "HandleDeregister", "done");
        trace_cufile(cuFileDriverClose(), "DriverClose");
    }
    close(fd);
    BXTRACE("POSIX_FS", "Close", "fd=%d", fd);
    cudaFree(d_w);
    cudaFree(d_r);
    cudaFree(d_rec);
    cudaFree(d_cursor);
    free(h_pat);
    free(h_chk);

    return verify_ok ? 0 : 3;
}
