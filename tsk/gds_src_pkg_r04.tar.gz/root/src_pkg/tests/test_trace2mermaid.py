"""Unit tests for trace2mermaid. Run: python3 -m unittest discover -s tests -v"""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import trace2mermaid as t2m  # noqa: E402

SAMPLE = """\
BXTRACE|100|CPU:core=5:tid=1|CPU_APP|Main|mode=posix file=/tmp/x.bin size=1024 iters=1
BXTRACE|110|CPU:core=5:tid=1|POSIX_FS|Open|fd=3 flags=O_RDWR|O_CREAT|O_DIRECT
BXTRACE|120|CPU:core=5:tid=1|CUDA_RT|LaunchProbe|label=after_write tag=1 grid=4 block=128
BXTRACE|125|GPU:sm=2:warpslot=0:lane=0|SM|ProbeWarp|label=after_write tag=1 gtimer_ns=9
BXTRACE|125|GPU:sm=3:warpslot=0:lane=0|SM|ProbeWarp|label=after_write tag=1 gtimer_ns=9
BXTRACE|125|GPU:sm=3:warpslot=1:lane=0|SM|ProbeWarp|label=after_write tag=1 gtimer_ns=9
BXTRACE|130|CPU:core=5:tid=1|CUDA_RT|ProbeKernelDone|label=after_write tag=1 warp_records=3
BXTRACE|140|CPU:core=5:tid=1|CPU_APP|Verify|iter=0 ok=1
this line is not a trace line
"""


class Trace2MermaidTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.log = Path(self.tmp.name) / "trace.log"
        self.log.write_text(SAMPLE)

    def tearDown(self):
        self.tmp.cleanup()

    def test_parse_skips_non_trace_lines_and_keeps_pipes_in_message(self):
        events = t2m.parse(self.log)
        self.assertEqual(len(events), 8)
        self.assertEqual(events[1].msg, "fd=3 flags=O_RDWR|O_CREAT|O_DIRECT")

    def test_output_has_header_participants_and_calls(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertTrue(out.startswith("sequenceDiagram"))
        self.assertIn("participant CPU_APP as User app (CPU)", out)
        self.assertIn("participant SM as GPU SM (probe)", out)
        self.assertIn("CPU_APP->>POSIX_FS:", out)
        self.assertIn("flags=O_RDWR/O_CREAT/O_DIRECT", out)
        self.assertIn("Note over CPU_APP:", out)

    def test_sm_records_grouped_into_one_arrow(self):
        out = t2m.to_mermaid(t2m.parse(self.log))
        self.assertEqual(out.count("CUDA_RT->>SM:"), 1)
        self.assertIn("ProbeWarp x3 on SM 2,3", out)

    def test_expand_sm_draws_one_arrow_per_warp(self):
        out = t2m.to_mermaid(t2m.parse(self.log), expand_sm=True)
        self.assertEqual(out.count("CPU_APP->>SM:"), 3)

    def test_convert_writes_default_output_next_to_trace(self):
        n = t2m.convert(self.log)
        self.assertEqual(n, 8)
        self.assertTrue(self.log.with_name("trace_sequence.mmd").exists())

    def test_clean_removes_mermaid_breaking_characters(self):
        self.assertNotIn(";", t2m.clean("a;b#c<d>e\"f|g"))
        self.assertNotIn("|", t2m.clean("a|b"))


if __name__ == "__main__":
    unittest.main()
