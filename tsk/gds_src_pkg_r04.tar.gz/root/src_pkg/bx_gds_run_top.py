#!/usr/bin/env python3
"""bx_gds_run_top.py - top-level entry point for the GDS experiment package.

Stages:
  env        capture host, GPU, PCIe, storage and GDS state
  build      compile src/bx_gds_basic.cu with nvcc
  roundtrip  run one GDS (cuFile) or POSIX bounce round trip, collect BXTRACE log
  all        env -> build -> roundtrip gds -> roundtrip posix -> mermaid
  mermaid    convert every trace.log under a run directory to trace_sequence.mmd

Outputs: ../exe_out/<hostname>/<YYYYmmdd_HHMMSS>/   (never inside src_pkg)

Examples:
  # Full run on this node: 1 GiB file, 10 iterations, both paths, compat allowed
  ./bx_gds_run_top.py all --workdir /data/bx_gds --size 1073741824 --iters 10 --compat 1

  # Environment snapshot only
  ./bx_gds_run_top.py env

  # GDS path only, strict (no compat fallback), keep the test file
  ./bx_gds_run_top.py roundtrip --mode gds --workdir /data/bx_gds --size 1073741824 \
      --iters 5 --compat 0 --keep

  # Re-run POSIX path inside an existing run directory, dropping page cache first
  ./bx_gds_run_top.py roundtrip --mode posix --run-dir ../exe_out/spark-7121/20261022_120000 \
      --workdir /data/bx_gds --size 1073741824 --iters 5 --drop-caches
"""
import argparse
import datetime
import json
import shutil
import socket
import subprocess
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parent   # .../root/src_pkg
ROOT = PKG.parent                       # .../root
sys.path.insert(0, str(PKG / "subtests"))
import subtest_env_dump   # noqa: E402
import trace2mermaid      # noqa: E402
import subtest_roundtrip  # noqa: E402


def new_run_dir() -> Path:
    host = socket.gethostname()
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run = ROOT / "exe_out" / host / ts
    run.mkdir(parents=True, exist_ok=True)
    return run


def build(run_dir: Path) -> Path:
    if shutil.which("nvcc") is None:
        raise SystemExit("nvcc not found in PATH")
    out_dir = run_dir / "build"
    out_dir.mkdir(parents=True, exist_ok=True)
    binary = out_dir / "bx_gds_basic"
    cmd = ["nvcc", "-O2", "-std=c++14", f"-I{PKG / 'include'}",
           str(PKG / "src" / "bx_gds_basic.cu"), "-o", str(binary),
           "-lcufile", "-lcudart", "-ldl"]
    (out_dir / "build_command.txt").write_text(" ".join(cmd) + "\n")
    r = subprocess.run(cmd, capture_output=True, text=True)
    (out_dir / "build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0:
        raise SystemExit(f"build failed, see {out_dir / 'build.log'}")
    return binary


def ensure_binary(run_dir: Path) -> Path:
    binary = run_dir / "build" / "bx_gds_basic"
    return binary if binary.exists() else build(run_dir)


def add_roundtrip_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--workdir", type=Path, required=True,
                   help="directory for the test file (use the NVMe mount under test)")
    p.add_argument("--size", type=int, default=1 << 30,
                   help="file size in bytes, multiple of 4096 (default 1 GiB)")
    p.add_argument("--iters", type=int, default=10)
    p.add_argument("--compat", type=int, choices=[0, 1], default=1,
                   help="cufile allow_compat_mode (0 = strict GDS, no fallback)")
    p.add_argument("--p2p", type=int, choices=[0, 1], default=0,
                   help="cufile use_pci_p2pdma")
    p.add_argument("--drop-caches", action="store_true",
                   help="sudo drop_caches before the run (O_DIRECT already bypasses page cache)")
    p.add_argument("--keep", action="store_true", help="keep the test file")
    p.add_argument("--nvtx", action="store_true",
                   help="enable cuFile internal NVTX ranges (profile with nsys)")


def main() -> None:
    ap = argparse.ArgumentParser(
        description="GDS experiment top-level driver",
        epilog=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = ap.add_subparsers(dest="stage", required=True)
    sub.add_parser("env", help="capture environment state")
    sub.add_parser("build", help="compile bx_gds_basic")
    rt = sub.add_parser("roundtrip", help="run one round trip")
    rt.add_argument("--mode", choices=["gds", "posix"], required=True)
    rt.add_argument("--run-dir", type=Path, help="reuse an existing run directory")
    add_roundtrip_args(rt)
    mm = sub.add_parser("mermaid", help="convert trace.log files in a run dir to mermaid")
    mm.add_argument("--run-dir", type=Path, required=True)
    mm.add_argument("--expand-sm", action="store_true")
    al = sub.add_parser("all", help="env + build + roundtrip gds + roundtrip posix + mermaid")
    add_roundtrip_args(al)
    args = ap.parse_args()

    if args.stage == "env":
        run = new_run_dir()
        subtest_env_dump.run(run)
        print(run)

    elif args.stage == "build":
        run = new_run_dir()
        print(build(run))

    elif args.stage == "roundtrip":
        run = args.run_dir or new_run_dir()
        binary = ensure_binary(run)
        s = subtest_roundtrip.run(run, binary, args.mode, args.workdir, args.size,
                                  args.iters, args.compat, args.p2p,
                                  args.drop_caches, args.keep, args.nvtx)
        print(json.dumps(s, indent=2))

    elif args.stage == "all":
        run = new_run_dir()
        subtest_env_dump.run(run)
        binary = build(run)
        results = {}
        for mode in ("gds", "posix"):
            results[mode] = subtest_roundtrip.run(run, binary, mode, args.workdir, args.size,
                                                  args.iters, args.compat, args.p2p,
                                                  args.drop_caches, args.keep, args.nvtx)
        (run / "manifest.json").write_text(json.dumps(results, indent=2) + "\n")
        for mode in ("gds", "posix"):
            trace2mermaid.convert(run / mode / "trace.log", None, False, True)
        print(run)

    elif args.stage == "mermaid":
        logs = sorted(args.run_dir.glob("*/trace.log"))
        if not logs:
            raise SystemExit(f"no */trace.log under {args.run_dir}")
        for log in logs:
            n = trace2mermaid.convert(log, None, args.expand_sm, True)
            print(f"{n} events -> {log.with_name('trace_sequence.mmd')}")


if __name__ == "__main__":
    main()
