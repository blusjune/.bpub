#!/usr/bin/env python3
"""trace2mermaid.py - convert a BXTRACE log into a mermaid sequenceDiagram.

Input : trace.log written by bx_gds_basic (non-BXTRACE lines are ignored)
Output: trace_sequence.mmd next to the input, unless -o is given

Usage:
  python3 trace2mermaid.py trace.log
  python3 trace2mermaid.py trace.log -o out.mmd --expand-sm
  python3 trace2mermaid.py trace.log --no-time

Drawing rules:
  - Host API events (CPU:core=...) are drawn as CPU_APP->>component calls.
    Each label carries the delta from the previous event in microseconds.
  - CPU_APP events (Main, Verify) are drawn as notes on the app participant.
  - GPU SM records (GPU:sm=...) are grouped: consecutive records with the same
    label become one arrow CUDA_RT->>SM. --expand-sm draws one arrow per warp.
  - Delta times for SM records use the host emit time, not GPU time.
"""
import argparse
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List

PREFIX = "BXTRACE|"
SM_RE = re.compile(r"sm=(\d+):warpslot=(\d+):lane=(\d+)")
APP = "CPU_APP"
SM = "SM"
DISPLAY = {
    "CPU_APP": "User app (CPU)",
    "CUDA_RT": "CUDA runtime",
    "CUFILE_LIB": "cuFile library",
    "POSIX_FS": "POSIX file API",
    "POSIX_BOUNCE": "POSIX bounce I/O",
    "SM": "GPU SM (probe)",
}


@dataclass
class Event:
    ts: int
    where: str
    comp: str
    step: str
    msg: str

    @property
    def is_sm(self) -> bool:
        return self.where.startswith("GPU:")


def parse(path: Path) -> List[Event]:
    events = []
    for raw in path.read_text(errors="replace").splitlines():
        if not raw.startswith(PREFIX):
            continue
        # maxsplit keeps any '|' inside the message (e.g. O_RDWR|O_CREAT|O_DIRECT)
        parts = raw.split("|", 5)
        if len(parts) != 6:
            continue
        _, ts, where, comp, step, msg = parts
        try:
            ts_i = int(ts)
        except ValueError:
            continue
        events.append(Event(ts_i, where, comp, step, msg))
    return events


def clean(text: str, limit: int = 90) -> str:
    """Make text safe for mermaid sequence labels."""
    text = text.replace("|", "/")
    for ch in ';#<>"':
        text = text.replace(ch, " ")
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 3] + "..."


def sm_group_key(e: Event) -> str:
    # first two tokens of the message: label=<x> tag=<n>
    return " ".join(e.msg.split()[:2])


def sm_index(e: Event):
    m = SM_RE.search(e.where)
    return (int(m.group(1)), int(m.group(2))) if m else (-1, -1)


def to_mermaid(events: List[Event], expand_sm: bool = False, show_time: bool = True) -> str:
    # participants: app first, then in order of first appearance
    order = [APP]
    for e in events:
        target = SM if e.is_sm else e.comp
        if target not in order:
            order.append(target)

    lines = ["sequenceDiagram", "    autonumber"]
    for p in order:
        lines.append(f"    participant {p} as {DISPLAY.get(p, p)}")

    prev_ts = None
    i, n = 0, len(events)
    while i < n:
        e = events[i]
        delta = ""
        if show_time and prev_ts is not None:
            delta = f"+{e.ts - prev_ts}us "

        if e.is_sm:
            key = sm_group_key(e)
            group = []
            j = i
            while j < n and events[j].is_sm and sm_group_key(events[j]) == key:
                group.append(events[j])
                j += 1
            if expand_sm:
                for g in group:
                    sm, slot = sm_index(g)
                    lines.append(f"    {APP}->>{SM}: {delta}warp sm={sm} slot={slot} {clean(g.msg)}")
                    delta = ""
            else:
                sms = sorted({sm_index(g)[0] for g in group})
                sm_txt = ",".join(str(s) for s in sms)
                lines.append(f"    CUDA_RT->>{SM}: {delta}ProbeWarp x{len(group)} on SM {sm_txt} ({clean(key)})")
            prev_ts = group[-1].ts
            i = j
            continue

        if e.comp == APP:
            lines.append(f"    Note over {APP}: {delta}{clean(e.step)} {clean(e.msg)}")
        else:
            lines.append(f"    {APP}->>{e.comp}: {delta}{clean(e.step)} {clean(e.msg)}")
        prev_ts = e.ts
        i += 1

    return "\n".join(lines) + "\n"


def convert(trace: Path, out: Path = None, expand_sm: bool = False, show_time: bool = True) -> int:
    events = parse(trace)
    if not events:
        raise SystemExit(f"no BXTRACE events in {trace}")
    out = out or trace.with_name("trace_sequence.mmd")
    out.write_text(to_mermaid(events, expand_sm, show_time))
    return len(events)


def main() -> None:
    ap = argparse.ArgumentParser(description="BXTRACE log -> mermaid sequence diagram",
                                 epilog=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("trace", type=Path)
    ap.add_argument("-o", "--out", type=Path)
    ap.add_argument("--expand-sm", action="store_true", help="one arrow per warp record")
    ap.add_argument("--no-time", action="store_true", help="omit delta-time labels")
    args = ap.parse_args()
    count = convert(args.trace, args.out, args.expand_sm, not args.no_time)
    print(f"{count} events -> {args.out or args.trace.with_name('trace_sequence.mmd')}")


if __name__ == "__main__":
    main()
