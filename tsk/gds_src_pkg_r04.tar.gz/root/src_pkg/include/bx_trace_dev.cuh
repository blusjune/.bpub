/* bx_trace_dev.cuh - device-side probe. Call from __global__/__device__ code.
 *
 * Reads hardware special registers via PTX (no printf, so the probe does not
 * perturb timing much). The record is written to global memory by the kernel and
 * formatted on the host afterwards.
 *
 * Observable: which SM and warp slot ran the probe, and the GPU timestamp.
 * NOT observable here: copy engines, SSD DMA engine, PCIe root, MMU/IOMMU
 * (see README.md, section "Execution location and observability").
 */
#ifndef BX_TRACE_DEV_CUH
#define BX_TRACE_DEV_CUH

#include "bx_trace.h"

__device__ __forceinline__ bx_dev_rec_t bx_dev_probe(int tag) {
    bx_dev_rec_t r;
    unsigned long long t;
    unsigned int smid, warpid, laneid;
    asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t));
    asm volatile("mov.u32 %0, %%smid;" : "=r"(smid));
    asm volatile("mov.u32 %0, %%warpid;" : "=r"(warpid));
    asm volatile("mov.u32 %0, %%laneid;" : "=r"(laneid));
    r.gtimer_ns = t;
    r.smid = smid;
    r.warpid = warpid;
    r.laneid = laneid;
    r.tag = tag;
    return r;
}

#endif /* BX_TRACE_DEV_CUH */
