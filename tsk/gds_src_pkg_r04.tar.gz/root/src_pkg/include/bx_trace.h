/* bx_trace.h - BXTRACE(): structured trace events for GDS sequence reconstruction.
 *
 * Host event (stderr, one line):
 *   BXTRACE|<monotonic_us>|CPU:core=<n>:tid=<t>|<component>|<step>|<message>
 *   core/tid are captured automatically (sched_getcpu, gettid), so every host event
 *   says which CPU core and thread executed it.
 *
 * Device event (emitted on host from warp records, see bx_trace_gpu_rec):
 *   BXTRACE|<host_emit_us>|GPU:sm=<smid>:warpslot=<w>:lane=<l>|SM|ProbeWarp|label=... gtimer_ns=...
 *   gtimer_ns is the GPU %globaltimer value (GPU clock, not host clock).
 *   host_emit_us is when the host printed the record, not when the warp ran.
 *
 * component: participant name (becomes a mermaid actor).
 * step:      API-level operation name.
 */
#ifndef BX_TRACE_H
#define BX_TRACE_H

#include <stdio.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>
#include <sys/syscall.h>

#if defined(__has_include)
#if __has_include(<nvtx3/nvToolsExt.h>)
#include <nvtx3/nvToolsExt.h>
#define BX_HAVE_NVTX 1
#endif
#endif
#ifndef BX_HAVE_NVTX
#define BX_HAVE_NVTX 0
#endif

static inline long bx_now_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000L + ts.tv_nsec / 1000L;
}

static inline long bx_tid(void) {
    return (long)syscall(SYS_gettid);
}

#define BXTRACE(comp, step, ...)                                                   \
    do {                                                                           \
        fprintf(stderr, "BXTRACE|%ld|CPU:core=%d:tid=%ld|%s|%s|",                  \
                bx_now_us(), sched_getcpu(), bx_tid(), (comp), (step));            \
        fprintf(stderr, __VA_ARGS__);                                              \
        fprintf(stderr, "\n");                                                     \
    } while (0)

/* NVTX ranges: visible on the host timeline of nsys/Nsight Systems. They do not name
 * GPU subsystems by themselves; use them to align host calls with CUDA kernels/copies. */
#if BX_HAVE_NVTX
#define BXRANGE_PUSH(name) nvtxRangePushA(name)
#define BXRANGE_POP()      nvtxRangePop()
#else
#define BXRANGE_PUSH(name) ((void)0)
#define BXRANGE_POP()      ((void)0)
#endif

/* Device probe record. Filled inside kernels by bx_dev_probe() (bx_trace_dev.cuh). */
typedef struct bx_dev_rec {
    unsigned long long gtimer_ns;  /* %globaltimer: GPU clock in ns */
    unsigned int smid;             /* %smid: streaming multiprocessor index */
    unsigned int warpid;           /* %warpid: warp slot within the SM */
    unsigned int laneid;           /* %laneid: lane of the reporting thread (always 0 here) */
    int tag;                       /* caller-defined probe point id */
} bx_dev_rec_t;

static inline void bx_trace_gpu_rec(const bx_dev_rec_t *r, const char *label) {
    fprintf(stderr,
            "BXTRACE|%ld|GPU:sm=%u:warpslot=%u:lane=%u|SM|ProbeWarp|label=%s tag=%d gtimer_ns=%llu\n",
            bx_now_us(), r->smid, r->warpid, r->laneid, label, r->tag, r->gtimer_ns);
}

#endif /* BX_TRACE_H */
