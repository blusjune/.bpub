#!/usr/bin/env python3
# BUILD_ID="BMJ_20261024_010403"
"""Source-build controller for OpenCode V2, vLLM, Qwen and LMCache on DGX Spark."""
import argparse
import importlib.util
import json
import pathlib
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bx_stack', HERE/'scripts/bx_stack.py')
stack = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stack)

EXAMPLES = 'Internal implementation. Use bx_ai_coding_setup.sh --help for the public interface.'

def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, epilog=EXAMPLES,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--config', type=pathlib.Path, default=HERE/'configs/stack.json')
    sub = p.add_subparsers(dest='stage', required=True)
    for name in ('preflight','install_python_dev','align_transformers','init','fetch','env','build','weights','configure','verify','serve','smoke','agent'):
        q = sub.add_parser(name)
        q.add_argument('--execute', action='store_true', help='Perform the requested stage')
        if name == 'align_transformers':q.add_argument('--ref',default='v5.20.2',help='Explicit release tag, validated against local vLLM requirements')
        if name == 'build':
            q.add_argument('--component', choices=['all','pytorch','vllm','transformers','lmcache','opencode'], default='all')
        if name == 'serve': q.add_argument('--baseline', action='store_true', help='Run vLLM without LMCache')
        if name == 'agent': q.add_argument('--project', type=pathlib.Path, required=True)
    sub.add_parser('validate', help='Run local controller tests; no downloads or GPU operations')
    a = p.parse_args(argv)
    if a.stage == 'validate': return stack.validate(HERE)
    c = json.loads(a.config.read_text())
    runner = stack.Stack(c, execute=a.execute)
    getattr(runner, a.stage)(a)
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (RuntimeError, ValueError, OSError, subprocess.CalledProcessError) as exc:
        print('ERROR: '+str(exc), file=sys.stderr)
        raise SystemExit(1)
