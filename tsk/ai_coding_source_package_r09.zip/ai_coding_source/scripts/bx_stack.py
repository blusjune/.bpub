# BUILD_ID="BMJ_20261024_010403"
"""Source builds with explicit Ubuntu Python development package installation."""
import datetime
import hashlib
import json
import os
import pathlib
import platform
import re
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

CLICK_RUNTIME_PROBE = '''import importlib.metadata as m
import json
from packaging.requirements import Requirement
requirements = set()
for distribution in m.distributions():
    for raw in distribution.requires or []:
        requirement = Requirement(raw)
        if requirement.name.lower().replace("_", "-") == "click":
            if requirement.marker is None or requirement.marker.evaluate({"extra": ""}):
                requirements.add(str(requirement))
print(json.dumps(sorted(requirements)))
'''

class Stack:
    def __init__(self, config, execute=False):
        self.c = config
        self.root = pathlib.Path(config['root'])
        if not self.root.is_absolute() or self.root == pathlib.Path('/'):
            raise ValueError('root must be an absolute task directory')
        if config['model_id'] != 'Qwen/Qwen3.8-27B':
            raise ValueError('This profile uses Qwen3.8-27B hybrid geometry; create a reviewed profile for another model')
        if config['node'] != 'node3' or config['cuda_arch'] != '12.1':
            raise ValueError('This initial profile targets node3 DGX Spark / SM 12.1 only')
        if not 0 < config['gpu_memory_utilization'] < 0.8:
            raise ValueError('Keep unified-memory headroom for OS and LMCache')
        if config['max_batched_tokens'] < config['chunk_tokens']:
            raise ValueError('Batch token budget must cover one negotiated block')
        ports=[config[k] for k in ('port','cache_port','cache_http_port')]
        if len(set(ports)) != 3 or any(not 1024 <= p <= 65535 for p in ports):
            raise ValueError('Use three distinct nonprivileged ports')
        self.src = self.root/'src'
        self.out = self.root/'deliverables/ai_coding'
        self.py = self.root/'venvs/stack/bin/python'
        self.bin = self.out/'bin'
        self.model = self.src/'models'/config['model_id'].split('/')[-1]
        self.execute = execute

    def envvars(self):
        e = os.environ.copy()
        e.update(CUDA_HOME=self.c['cuda_home'], TORCH_CUDA_ARCH_LIST=self.c['cuda_arch'],
                 MAX_JOBS=str(self.c['max_jobs']), NVCC_THREADS='1',
                 VLLM_USE_PRECOMPILED='0', CMAKE_PREFIX_PATH=str(self.py.parents[1]),
                 HF_HOME=str(self.out/'cache/huggingface'),
                 TMPDIR=str(self.out/'tmp'), CCACHE_DIR=str(self.out/'cache/ccache'),
                 LMCACHE_CUDA_MAJOR='13', PIP_DISABLE_PIP_VERSION_CHECK='1',
                 PIP_CACHE_DIR=str(self.out/'cache/pip'), BUN_INSTALL_CACHE_DIR=str(self.out/'cache/bun'),
                 TORCH_EXTENSIONS_DIR=str(self.out/'cache/torch_extensions'),
                 TRITON_CACHE_DIR=str(self.out/'cache/triton'), XDG_CACHE_HOME=str(self.out/'cache/xdg'))
        e['PATH']=str(self.py.parent)+':'+str(pathlib.Path(e['CUDA_HOME'])/'bin')+':'+e.get('PATH','')
        return e

    def run(self, cmd, cwd=None, capture=False, extra=None):
        cmd = list(map(str, cmd))
        print(shlex.join(cmd), flush=True)
        if not self.execute: return ''
        e=self.envvars()
        if extra:e.update(extra)
        # Every executable stage can run before init, including captured probes.
        tmp=pathlib.Path(e['TMPDIR'])
        try:
            tmp.mkdir(parents=True,exist_ok=True)
            with tempfile.TemporaryFile(dir=tmp):
                pass
        except OSError as exc:
            raise RuntimeError('Cannot prepare writable TMPDIR '+str(tmp)+': '+str(exc)) from exc
        if capture:
            return subprocess.run(cmd,cwd=cwd,env=e,check=True,text=True,
                                  stdout=subprocess.PIPE).stdout.strip()
        self.out.mkdir(parents=True,exist_ok=True)
        log=self.out/'build_commands.log'
        with log.open('a') as f:
            f.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+' '+shlex.join(cmd)+'\n')
            f.flush()
            proc=subprocess.Popen(cmd,cwd=cwd,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            for line in proc.stdout:
                print(line,end='',flush=True);f.write(line);f.flush()
            if proc.wait():raise RuntimeError('Command failed; inspect '+str(log))
        return ''

    def write(self, path, data):
        if not self.execute:
            print('WRITE '+str(path));return
        path.parent.mkdir(parents=True,exist_ok=True)
        text=data if isinstance(data,str) else json.dumps(data,indent=2)+'\n'
        path.write_text(text)

    def init(self, args):
        for p in (self.src,self.py.parents[1],self.bin,self.out/'tmp',self.out/'cache',self.out/'reports'):
            print('MKDIR '+str(p))
            if self.execute:p.mkdir(parents=True,exist_ok=True)
        self.write(self.out/'requested_config.json',self.c)

    def preflight(self, args):
        commands=[['uname','-a'],['nvidia-smi'],[str(pathlib.Path(self.c['cuda_home'])/'bin/nvcc'),'--version'],
                  ['cmake','--version'],['ninja','--version'],['bun','--version'],['git','lfs','version'],
                  [self.c['python'],'--version']]
        if self.execute and platform.machine()!='aarch64':
            raise RuntimeError('node3 requires an aarch64 host; do not run a Spark build on x86_64')
        observations={}
        for cmd in commands:observations[' '.join(cmd)]=self.run(cmd,capture=True)
        if self.execute:
            if 'GB10' not in observations['nvidia-smi']:raise RuntimeError('Expected NVIDIA GB10')
            probe=self.run([str(pathlib.Path(self.c['cuda_home'])/'bin/nvcc'),'--list-gpu-code'],capture=True)
            if 'sm_121' not in probe:raise RuntimeError('Installed nvcc cannot target sm_121')
        self.write(self.out/'reports/preflight.json',observations)
        print('Also verify cuDNN development headers/libraries and free disk/RAM before building.')

    def git_identity(self, repo, expected=None):
        if not self.execute:return
        head=self.run(['git','rev-parse','HEAD'],cwd=repo,capture=True)
        if expected and head!=expected:raise RuntimeError('Checkout differs from sources.lock.json: '+str(repo))
        return head

    def fetch(self, args):
        lockfile=self.out/'sources.lock.json'
        lock=json.loads(lockfile.read_text()) if lockfile.exists() else {}
        entries={**self.c['repos'],'model':{'url':'https://huggingface.co/'+self.c['model_id'],'ref':self.c['model_ref']}}
        for name,entry in entries.items():
            dest=self.model if name=='model' else self.src/name
            saved=lock.get(name)
            if saved and (saved['url']!=entry['url'] or saved['requested_ref']!=entry['ref']):
                raise RuntimeError('Requested source differs from existing lock; use a new root/config')
            if not dest.exists():
                clone=['git','clone','--depth','1']
                # Model metadata uses ordinary shallow Git, avoiding lazy blob fetches.
                # LFS weights remain deferred until the explicit weights stage.
                if name!='model':clone.append('--filter=blob:none')
                self.run([*clone,'--no-checkout',entry['url'],dest],extra={'GIT_LFS_SKIP_SMUDGE':'1'})
            elif self.execute:
                origin=self.run(['git','remote','get-url','origin'],cwd=dest,capture=True)
                if origin.rstrip('/')!=entry['url'].rstrip('/'):raise RuntimeError('Unexpected Git origin: '+str(dest))
                if not saved:raise RuntimeError('Refuse to take over an existing unlocked checkout: '+str(dest))
            if saved:
                self.git_identity(dest,saved['commit']);continue
            self.run(['git','fetch','--depth','1','origin',entry['ref']],cwd=dest)
            self.run(['git','checkout','--detach','FETCH_HEAD'],cwd=dest,extra={'GIT_LFS_SKIP_SMUDGE':'1'})
            if name=='pytorch':self.run(['git','submodule','update','--init','--recursive','--jobs',str(self.c['max_jobs'])],cwd=dest)
            if self.execute:
                lock[name]={'url':entry['url'],'requested_ref':entry['ref'],'commit':self.git_identity(dest)}
                self.write(lockfile,lock)

    def locked(self):
        if not self.execute:return
        if platform.machine()!='aarch64':raise RuntimeError('Production Spark build/serve requires an aarch64 host')
        lock=json.loads((self.out/'sources.lock.json').read_text())
        for name in self.c['repos']:
            self.git_identity(self.src/name,lock[name]['commit'])

    def align_transformers(self, args):
        if not re.fullmatch(r'v[0-9]+\.[0-9]+\.[0-9]+',args.ref):
            raise ValueError('Use an explicit Transformers release tag such as v5.20.2')
        if not self.execute:
            print('ALIGN Transformers to '+args.ref+' after checking the locked vLLM requirement; back up and update config and source lock')
            return
        self.locked()
        repo=self.src/'transformers'
        if self.run(['git','status','--porcelain','--untracked-files=no'],cwd=repo,capture=True):
            raise RuntimeError('Refuse to change a Transformers checkout with tracked local modifications')
        lockfile=self.out/'sources.lock.json'
        oldlock=json.loads(lockfile.read_text());oldconfig=json.loads(args.config.read_text())
        if oldconfig!=self.c:raise RuntimeError('Config changed during execution; retry')
        self.run(['git','fetch','--depth','1','origin','refs/tags/'+args.ref],cwd=repo)
        commit=self.run(['git','rev-parse','FETCH_HEAD^{commit}'],cwd=repo,capture=True)
        setup=self.run(['git','show',commit+':setup.py'],cwd=repo,capture=True)
        version=re.search(r'\bversion\s*=\s*[\"\']([0-9][^\"\']*)[\"\']',setup)
        if not version or version.group(1)!=args.ref[1:]:
            raise RuntimeError('Cannot confirm the requested release version in Transformers setup.py')
        requirements=[]
        for line in (self.src/'vllm/requirements/common.txt').read_text().splitlines():
            line=line.split('#',1)[0].strip()
            if re.match(r'^transformers\s*(?:[<>=!~;\[]|$)',line):requirements.append(line)
        if len(requirements)!=1:raise RuntimeError('Expected one Transformers requirement in vLLM requirements/common.txt')
        self.run([self.py,'-c',
            'from packaging.requirements import Requirement; import sys; '
            'r=Requirement(sys.argv[1]); assert r.specifier.contains(sys.argv[2]), "Release does not satisfy "+str(r); '
            'print("Validated "+sys.argv[2]+" against "+str(r))',requirements[0],version.group(1)])
        backup=self.out/'state'/('transformers-ref-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')
        self.write(backup,{'config':oldconfig,'sources_lock':oldlock})
        newconfig=json.loads(json.dumps(oldconfig));newconfig['repos']['transformers']['ref']=args.ref
        newlock=json.loads(json.dumps(oldlock));newlock['transformers'].update(requested_ref=args.ref,commit=commit)
        try:
            self.run(['git','checkout','--detach',commit],cwd=repo)
            self.write(args.config,newconfig);self.write(lockfile,newlock)
        except Exception:
            self.run(['git','checkout','--detach',oldlock['transformers']['commit']],cwd=repo)
            self.write(args.config,oldconfig);self.write(lockfile,oldlock)
            raise
        self.c=newconfig
        print('Source ref aligned. Run stage 040, then stage 050. Backup: '+str(backup))

    def env(self, args):
        if not self.py.exists():self.run([self.c['python'],'-m','venv',self.py.parents[1]])
        self.run([self.py,'-m','pip','install','--upgrade','pip','setuptools','wheel','packaging','ninja','cmake','build','setuptools-scm'])
        self.write(self.out/'environment_scope.json',{'core':'local source','toolchain_and_third_party_dependencies':'may use binaries','all_transitive_source_build':False})

    def pip(self, *args, cwd=None):
        return self.run([self.py,'-m','pip',*args],cwd=cwd)

    def constraints(self):
        path=self.out/'core-constraints.txt'
        if self.execute:
            versions=self.run([self.py,'-c',"import importlib.metadata as m; print('torch=='+m.version('torch'))"],capture=True)
            self.write(path,versions+'\n')
        return path

    def missing_python_headers(self):
        interpreter=self.py if self.py.exists() else self.c['python']
        result=self.run([interpreter,'-c',
            'import json,pathlib,sysconfig; p=pathlib.Path(sysconfig.get_path("include")); '
            'print(json.dumps([str(p/n) for n in ("Python.h","patchlevel.h") if not (p/n).is_file()]))'],capture=True)
        return json.loads(result) if self.execute else []

    def install_python_dev(self, args):
        if self.execute:
            if platform.machine()!='aarch64':
                raise RuntimeError('Python development package installation requires the configured aarch64 host')
            distro=platform.freedesktop_os_release()
            if distro.get('ID')!='ubuntu' or distro.get('VERSION_ID')!='24.04' or self.c['python']!='python3.12':
                raise RuntimeError('Automatic apt installation supports Ubuntu 24.04 / python3.12 only')
        prefix=[] if self.execute and os.geteuid()==0 else ['sudo']
        if self.execute and prefix:
            # Keep the authentication prompt attached to the user's terminal.
            subprocess.run(['sudo','-v'],check=True)
        self.run([*prefix,'apt-get','update'])
        self.run([*prefix,'apt-get','install','-y','--reinstall','python3.12-dev','libpython3.12-dev'])
        if self.execute:
            missing=self.missing_python_headers()
            if missing:raise RuntimeError('Python development headers still missing after apt installation: '+', '.join(missing))

    def ensure_python_headers(self):
        if not self.execute:
            print('CHECK Python development headers; install Ubuntu python3.12-dev if missing (sudo may be required)')
        elif self.missing_python_headers():
            self.install_python_dev(None)

    def check_torch_import(self):
        self.run([self.py,'-I','-c',
            'import json,torch,torch._C,torch.version; '
            'assert torch.version.cuda is not None, "Expected a CUDA-enabled source PyTorch build"; '
            'assert torch.ones(2).sum().item()==2; '
            'print(json.dumps({"torch_file":torch.__file__,"torch_version":torch.__version__,"cuda":torch.version.cuda,"extension":torch._C.__file__}))'])

    def repair_runtime_click(self):
        if not self.execute:
            print('RESOLVE Click against installed runtime requirements after removing spin')
            return
        requirements=json.loads(self.run([self.py,'-c',CLICK_RUNTIME_PROBE],capture=True))
        if requirements:
            self.pip('install',*requirements)

    def build(self, args):
        self.locked()
        names=['pytorch','transformers','vllm','lmcache','opencode'] if args.component=='all' else [args.component]
        for name in names:
            repo=self.src/name
            if name=='pytorch':
                self.ensure_python_headers()
                self.run([self.py,'-c',
                    'import pathlib,sysconfig; p=pathlib.Path(sysconfig.get_path("include")); '
                    'missing=[str(p/n) for n in ("Python.h","patchlevel.h") if not (p/n).is_file()]; '
                    'assert not missing, "Missing Python development headers: "+", ".join(missing)+"; install python3.12-dev on Ubuntu 24.04"; '
                    'print("Python development headers: "+str(p))'])
                # This builds PyTorch itself, not a published torch wheel.
                self.pip('install','--group',str(repo/'pyproject.toml')+':dev')
                self.pip('install','numpy')
                self.run([self.py,'-c',
                    'import pathlib,numpy; p=pathlib.Path(numpy.get_include()); '
                    'assert (p/"numpy/arrayobject.h").is_file(), "Missing NumPy C headers"; '
                    'print("NumPy headers: "+str(p))'])
                self.pip('install','-v','--no-build-isolation','--no-deps',
                         '-Ccmake.define.BUILD_PYTHON=ON',
                         '-Ccmake.define.Python_EXECUTABLE='+str(self.py),'-e',repo)
                self.check_torch_import()
                self.run(['make','triton'],cwd=repo)
                # spin is a development CLI, not used by this pip/make build flow.
                self.pip('uninstall','-y','spin')
                self.repair_runtime_click()
            elif name=='opencode':
                if self.execute:
                    pkg=json.loads((repo/'package.json').read_text())
                    expected=pkg['packageManager'].removeprefix('bun@')
                    actual=self.run(['bun','--version'],capture=True)
                    if actual!=expected:raise RuntimeError('Install Bun '+expected+' for this locked checkout; actual '+actual)
                    if not (repo/'packages/cli/script/build.ts').exists():raise RuntimeError('Expected OpenCode V2 source layout')
                self.run(['bun','install','--frozen-lockfile'],cwd=repo)
                self.run(['bun','run','--cwd','packages/cli','script/build.ts','--single','--skip-install','--outdir='+str(self.out/'build/opencode')],cwd=repo)
                if self.execute:
                    candidates=list((self.out/'build/opencode').glob('*/bin/opencode'))
                    if len(candidates)!=1:raise RuntimeError('Expected exactly one host OpenCode artifact')
                    self.bin.mkdir(parents=True,exist_ok=True)
                    target=self.bin/'opencode'
                    if target.is_symlink() and target.resolve()==candidates[0].resolve():
                        pass
                    elif target.exists() or target.is_symlink():
                        raise RuntimeError('Refuse to replace existing '+str(target))
                    else:target.symlink_to(candidates[0])
                self.run([self.bin/'opencode','--version'])
            else:
                self.check_torch_import()
                constraint=self.constraints()
                # The PyTorch dev group brings spin's older Click requirement into
                # the shared environment. Remove that CLI before runtime resolution.
                self.pip('uninstall','-y','spin')
                if name=='vllm':
                    helper=repo/'tools/use_existing_torch.py'
                    if self.execute and not helper.exists():raise RuntimeError('vLLM source layout changed; review existing-torch helper')
                    self.run([self.py,helper],cwd=repo)
                    self.pip('install','-c',constraint,'-r',repo/'requirements/build/cuda.txt')
                if name=='lmcache':self.pip('install','-c',constraint,'-r',repo/'requirements/build.txt')
                # Dependency resolution cannot replace the source-built core packages.
                if self.execute:
                    versions=self.run([self.py,'-c',"import importlib.metadata as m; print('\\n'.join(n+'=='+m.version(n) for n in ('torch','transformers','vllm') if n != '"+name+"' and m.packages_distributions().get(n)))"],capture=True)
                    self.write(constraint,versions+'\n')
                self.pip('install','-v','-c',constraint,'--no-build-isolation','-e',repo)
        self.run([self.py,'-m','pip','check'])
        frozen=self.run([self.py,'-m','pip','freeze'],capture=True)
        self.write(self.out/'reports/pip-freeze.txt',frozen+'\n')
        self.write(self.out/'reports/build_status.json',{'status':'COMMANDS_COMPLETED_NOT_INTEGRATION_VERIFIED','components':names})

    def weights(self, args):
        if self.execute:
            lock=json.loads((self.out/'sources.lock.json').read_text())
            self.git_identity(self.model,lock['model']['commit'])
        self.run(['git','lfs','pull'],cwd=self.model)
        self.run(['git','lfs','fsck'],cwd=self.model)
        if self.execute:
            index=json.loads((self.model/'model.safetensors.index.json').read_text())
            for shard in set(index['weight_map'].values()):
                p=(self.model/shard).resolve()
                if not p.is_relative_to(self.model.resolve()):raise RuntimeError('Invalid shard path')
                with p.open('rb') as f:
                    if f.read(64).startswith(b'version https://git-lfs'):raise RuntimeError('Unmaterialized LFS pointer: '+str(p))
            self.write(self.out/'reports/weights.json',{'status':'LFS_FSCK_AND_SHARD_PRESENCE_PASS','model':str(self.model)})

    def configure(self, args):
        cfg={'$schema':'https://opencode.ai/config.json','model':'local/'+self.c['served_model'],
             'providers':{'local':{'name':'Local vLLM','package':'@opencode/ai/providers/openai-compatible',
                'settings':{'baseURL':'http://127.0.0.1:'+str(self.c['port'])+'/v1'},
                'models':{self.c['served_model']:{'name':self.c['model_id'],'modelID':self.c['served_model'],
                    'capabilities':{'tools':True,'input':['text'],'output':['text']},
                    'limit':{'context':self.c['max_model_len'],'output':8192}}}}}}
        self.write(self.out/'config/opencode.json',cfg)
        self.write(self.out/'reports/launch_plan.json',{'lmcache':self.cache_command(),'vllm':self.server_command(False),
            'status':'UNVALIDATED_ON_TARGET','cache_backend':'CPU_L1_ONLY','ssd_io_verified':False})

    def cache_command(self):
        return [str(self.py.parent/'lmcache'),'server','--host','127.0.0.1','--port',str(self.c['cache_port']),
                '--http-port',str(self.c['cache_http_port']),'--l1-size-gb',str(self.c['l1_gb']),
                '--chunk-size',str(self.c['chunk_tokens']),'--separate-object-groups','--eviction-policy','LRU']

    def server_command(self, baseline):
        c=self.c
        cmd=[str(self.py.parent/'vllm'),'serve',str(self.model),'--host','127.0.0.1','--port',str(c['port']),
             '--served-model-name',c['served_model'],'--tensor-parallel-size','1','--dtype','bfloat16',
             '--max-model-len',str(c['max_model_len']),'--max-num-seqs','1','--gpu-memory-utilization',str(c['gpu_memory_utilization']),
             '--enable-prefix-caching','--mamba-cache-mode','align','--max-num-batched-tokens',str(c['max_batched_tokens']),
             '--enable-auto-tool-choice','--tool-call-parser','qwen3_xml','--reasoning-parser','qwen3','--enforce-eager']
        if not baseline:
            cmd+=['--kv-transfer-config',json.dumps({'kv_connector':'LMCacheMPConnector','kv_connector_module_path':
                 'lmcache.integration.vllm.lmcache_mp_connector','kv_role':'kv_both','kv_connector_extra_config':{
                 'lmcache.mp.host':'127.0.0.1','lmcache.mp.port':c['cache_port']}})]
        return cmd

    def verify(self, args):
        code="""import torch, vllm, lmcache, transformers, importlib, json
from pathlib import Path
root=Path(__import__('sys').argv[1]).resolve()
for m in (torch,vllm,lmcache,transformers):
 assert Path(m.__file__).resolve().is_relative_to(root/'src'), (m.__name__,m.__file__)
assert torch.cuda.is_available()
assert torch.cuda.get_device_capability()==(12,1)
x=torch.arange(16,device='cuda'); assert int(x.sum())==120
torch.cuda.synchronize()
import lmcache.cuda_ops
importlib.import_module('lmcache.integration.vllm.lmcache_mp_connector')
print(json.dumps({'status':'IMPORT_SOURCE_ORIGIN_AND_CUDA_SMOKE_PASS','gpu':torch.cuda.get_device_name(),'torch_cuda':torch.version.cuda}))
"""
        self.run([self.py,'-c',code,self.root])
        self.run([self.py,'-m','pip','check'])
        self.run([self.py.parent/'vllm','serve','--help'])
        self.run([self.py.parent/'lmcache','server','--help'])
        self.run([self.bin/'opencode','--version'])

    def serve(self, args):
        cmds=[] if args.baseline else [self.cache_command()]
        cmds.append(self.server_command(args.baseline))
        if not self.execute:
            for cmd in cmds:self.run(cmd)
            return
        self.locked()
        ports=[self.c['port']] if args.baseline else [self.c[k] for k in ('port','cache_port','cache_http_port')]
        for p in ports:
            with socket.socket() as s:s.bind(('127.0.0.1',p))
        procs=[];files=[]
        self.out.mkdir(parents=True,exist_ok=True)
        try:
            for i,cmd in enumerate(cmds):
                f=(self.out/('vllm.log' if i==len(cmds)-1 else 'lmcache.log')).open('a')
                files.append(f)
                p=subprocess.Popen(cmd,env=self.envvars(),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
                procs.append(p)
                if i<len(cmds)-1:self.wait_url('http://127.0.0.1:'+str(self.c['cache_http_port'])+'/healthcheck',procs,180)
            self.wait_url(self.url('/models'),procs,1800)
            print('API READY; backend I/O and agent quality are not verified. Ctrl-C stops owned services.',flush=True)
            while True:
                if any(p.poll() is not None for p in procs):raise RuntimeError('A managed server exited; inspect logs')
                time.sleep(1)
        except KeyboardInterrupt:pass
        finally:
            for p in reversed(procs):
                if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
            for p in reversed(procs):
                try:p.wait(timeout=20)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            for f in files:f.close()

    def url(self,suffix):return 'http://127.0.0.1:'+str(self.c['port'])+'/v1'+suffix

    @staticmethod
    def wait_url(url,procs,seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            if any(p.poll() is not None for p in procs):raise RuntimeError('Server exited before readiness')
            try:
                with urllib.request.urlopen(url,timeout=2) as r:
                    if r.status==200:return
            except (OSError,ValueError):pass
            time.sleep(1)
        raise RuntimeError('Readiness timeout: '+url)

    def smoke(self, args):
        print('POST '+self.url('/chat/completions'))
        if not self.execute:return
        req={'model':self.c['served_model'],'messages':[{'role':'user','content':'Call inspect_project with path set to a single dot.'}],
             'tools':[{'type':'function','function':{'name':'inspect_project','description':'Inspect a project directory',
                'parameters':{'type':'object','properties':{'path':{'type':'string'}},'required':['path']}}}],
             'tool_choice':'auto','max_tokens':512,'temperature':0,
             'chat_template_kwargs':{'enable_thinking':False}}
        request=urllib.request.Request(self.url('/chat/completions'),json.dumps(req).encode(),{'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=300) as response:data=json.load(response)
        calls=data['choices'][0]['message'].get('tool_calls',[])
        if not calls:raise RuntimeError('Model did not emit a structured tool call; inspect parser/template')
        f=calls[0]['function']
        if f['name']!='inspect_project' or json.loads(f['arguments']).get('path')!='.':raise RuntimeError('Unexpected tool call')
        self.write(self.out/'reports/api_smoke.json',{'status':'STRUCTURED_TOOL_CALL_PASS','response':data,
            'agent_file_edit_test':'NOT_RUN','lmcache_hit':'NOT_VERIFIED','ssd_io':'NOT_CONFIGURED'})

    def agent(self, args):
        project=args.project.resolve()
        if self.execute and not project.is_dir():raise ValueError('Project directory does not exist')
        env=self.envvars();env['OPENCODE_CONFIG']=str(self.out/'config/opencode.json')
        env['XDG_DATA_HOME']=str(self.out/'state/data')
        env['XDG_CONFIG_HOME']=str(self.out/'state/config')
        cmd=[str(self.bin/'opencode'),str(project),'--model','local/'+self.c['served_model']]
        print(shlex.join(cmd))
        if self.execute:subprocess.run(cmd,cwd=project,env=env,check=True)

def validate(here):
    log=here/'tests/results/controller_tests.log'
    log.parent.mkdir(parents=True,exist_ok=True)
    r=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(here/'tests'),'-v'],capture_output=True,text=True)
    log.write_text(r.stdout+r.stderr)
    print(r.stdout+r.stderr,end='')
    return r.returncode
