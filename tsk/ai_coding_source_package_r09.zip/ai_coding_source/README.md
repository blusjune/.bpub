# Source-built local AI coding stack on DGX Spark

build: brianmjung_20261021_232535

The only public entry point is `bx_ai_coding_setup.sh`. Numbered subcommands
call the internal Python implementation in `scripts/`. No duplicate public
Python dispatcher is maintained.

## Scope and evidence

- Target: node3, Ubuntu 24.04, aarch64, NVIDIA GB10 / SM 12.1.
- Model: Qwen/Qwen3.8-27B, BF16, text-only agent integration, initial 32K context.
- Core source builds: PyTorch, matching Triton via PyTorch's build recipe,
  Transformers, vLLM, LMCache, and the OpenCode V2 host executable.
- Qwen weights are downloaded, not compiled or retrained. The Qwen GitHub repo
  contains documentation/reference material; executable model implementations
  are in vLLM and Transformers.
- OS, compilers, CUDA, cuDNN, Bun, and transitive Python/npm native dependencies
  can be binary prerequisites. This is NOT a fully source-built operating
  system or a source-only transitive dependency closure.
- The authoring environment passed controller CPU/mock checks. No target build,
  CUDA service, model download, agent editing session, or cache hit was run here.
- Source refs start as candidate branches, not a validated matrix. `fetch`
  records exact commits in `sources.lock.json` and reuses those commits.

## Prerequisites

Provide a writable `/opt/work/ai_coding/root/` owned by the intended user.
Use that user for builds; no root login or automatic sudo is required.
The bundle does not install or replace the driver/toolkit.

Required host tools: Python 3.12 with venv support, Git with Git LFS,
C/C++ compiler, make, CMake, Ninja, pkg-config, CUDA 13.0 development tools
including an nvcc supporting sm_121, cuDNN development headers/libraries,
and Bun matching the cloned OpenCode `packageManager` version. Current
reviewed OpenCode source declares Bun 1.4.2; the script checks the cloned value.
Additional development headers/Rust tooling may be required by the locked
upstream dependencies; preserve build errors rather than replacing core apps
with binary wheels.

Allow substantial disk space for PyTorch submodules/builds, native extension
builds, package caches, and approximately 54 GB plus auxiliary model files.
Several hundred GB of free SSD space is a reasonable planning allowance,
not a measured maximum. Start with four compiler jobs and no other GPU load.
`nvidia-smi` CUDA Version does not identify the installed nvcc toolkit.

## Installation layout

Copy the complete bundle to:

`/opt/work/ai_coding/root/deliverables/ai_coding_source/`

The root is configured in `configs/stack.json`, independently of bundle location.
At runtime the managed layout is:

| Path below root | Purpose |
| --- | --- |
| `src/pytorch`, `src/vllm`, `src/lmcache` | Editable Python/native source checkouts |
| `src/transformers`, `src/opencode`, `src/qwen` | Model library, agent source, Qwen reference source |
| `src/models/Qwen3.8-27B` | Hugging Face Git checkout and materialized weights |
| `venvs/stack` | Dedicated Python installation environment |
| `deliverables/ai_coding/config` | Generated OpenCode configuration |
| `deliverables/ai_coding/build`, `bin` | Built OpenCode artifact and symlink |
| `deliverables/ai_coding/cache`, `tmp`, `state` | Build/runtime caches and agent state |
| `deliverables/ai_coding/reports` | Host, build, weight, and API checks |
| `deliverables/ai_coding/sources.lock.json` | Exact resolved source commits |
| `deliverables/ai_coding/build_commands.log` | Timestamped commands and build output |

Upstream editable builds can also create their own build files inside `src/`.
Do not delete those while services use editable installations.

## Execution

```bash
cd /opt/work/ai_coding/root/deliverables/ai_coding_source
chmod +x bx_ai_coding_setup.sh
./bx_ai_coding_setup.sh --help
./bx_ai_coding_setup.sh 900_validate
./bx_ai_coding_setup.sh 005_check_host --execute
./bx_ai_coding_setup.sh 010_conf_env --execute
./bx_ai_coding_setup.sh 020_download_src --execute
./bx_ai_coding_setup.sh 030_build_pytorch --execute
./bx_ai_coding_setup.sh 040_build_transformers --execute
./bx_ai_coding_setup.sh 050_build_vllm --execute
./bx_ai_coding_setup.sh 060_build_lmcache --execute
./bx_ai_coding_setup.sh 070_build_opencode --execute
./bx_ai_coding_setup.sh 080_download_weights --execute
./bx_ai_coding_setup.sh 090_conf_services --execute
./bx_ai_coding_setup.sh 100_verify_build --execute
```

Use `--config FILE` before the subcommand to select another reviewed profile.
Without `--execute`, numbered operational stages print plans and do not launch
subprocesses or write files. `900_validate` always runs CPU/mock tests and saves
its bundle-local test log. Stage help performs no actions, even without Python.
Unknown commands/options fail before stage actions.

Stage 020 intentionally locks a candidate set at download time. For controlled
rebuilds, change branch refs in the JSON to reviewed commit SHAs before the
first download. Existing locks reject changed URLs/refs or checkout HEADs.
The script does not overwrite/adopt an unrelated existing checkout. If a clone
or initial fetch is interrupted before a lock is recorded, inspect that partial
checkout before retrying. It does not delete source automatically.

Stage 050 runs vLLM's existing-PyTorch helper, which changes upstream dependency
files intentionally. Core package version constraints prevent pip from silently
replacing the source-built torch/Transformers/vLLM with another version. A
resolver conflict is a compatibility failure to resolve, not a reason to remove
the constraint. `pip check` and recorded `pip-freeze.txt` supplement the source
lock; transitive dependency versions are not pre-locked before the first build.

## Baseline and integrated service

Terminal A, baseline first:

```bash
./bx_ai_coding_setup.sh 110_serve_baseline --execute
```

Terminal B:

```bash
./bx_ai_coding_setup.sh 130_test_api --execute
```

Stop the baseline with Ctrl-C. Then Terminal A:

```bash
./bx_ai_coding_setup.sh 120_serve_stack --execute
```

Terminal B:

```bash
./bx_ai_coding_setup.sh 130_test_api --execute
./bx_ai_coding_setup.sh 140_run_agent --project /opt/work/my-project --execute
```

The foreground controller starts LMCache before vLLM, waits for readiness,
rejects occupied ports, and stops only its own process groups on exit/Ctrl-C.
An API-ready message is not cache-hit proof. The API smoke test validates a
structured tool-call name and JSON arguments; it does not execute that tool or
certify an autonomous editing workflow. Project-specific OpenCode configuration
can merge with the generated configuration; inspect the selected model and
provider before real work. Other providers and MCP tools are not automatically
made offline by choosing a local main model.

The initial cache path is CPU L1 only. SSD/raw-block/GDS are deliberately separate
experiments and are not configured by this service bootstrap. On Spark all
allocations share physical system memory; the 4 GB CPU L1 is not extra physical
memory added to the GPU pool. Native GDS support is not claimed.

## Qwen hybrid configuration

The LMCache recipe lists Qwen3.8-27B with a unified block size of 784 tokens.
This profile requests chunk 784, `--separate-object-groups`, prefix caching,
`--mamba-cache-mode align`, and max batched tokens 1567. Verify the actual block
and negotiated chunk in your startup logs; update the reviewed profile if the
locked runtime chooses a different value. Do not force uniform-attention
assumptions onto this hybrid model. CacheBlend/CacheGen are not enabled.

The OpenCode V2 `providers` configuration declares text/tool support and the
same 32K context limit as vLLM; it does not inherit an incorrect 200K custom-model
default. Output is limited to 8192 tokens in the agent metadata. Increase context
only after measuring unified-memory headroom. Server parser flags are candidate
settings to verify with `130_test_api` and the installed CLI; do not assume a
successful text reply means tool-call parsing works.

## Troubleshooting and completion criteria

- Host check failure: inspect actual OS/toolchain/GPU; do not disable architecture checks.
- Build failure: inspect `build_commands.log`, source pins, cuDNN, RAM, and ABI.
- OpenCode build failure: check exact Bun version and upstream V2 source layout.
- Import failure: inspect source origin and ABI; rerun the relevant numbered build.
- Tool-call failure: verify template/parser/model and structured arguments.
- Apparent cache speedup: inspect LMCache store/retrieve counters separately from
  vLLM GPU prefix hits. This bootstrap does not quantify LMCache reuse.
- Accept the environment after a real multi-file edit/build/test cycle completes.
  Record modified files and independent test results. CUDA/Nsight and cache/SSD
  experiments need their own evidence after this bootstrap.

Technical rationale and remaining validation are in `reports/Technical_Report_KO.md`.

## TMPDIR initialization fix

Executable stages create and probe the managed TMPDIR before any subprocess, including captured preflight commands. Plan-only runs remain side-effect free. A directory creation or write failure stops before launching the command.

## Model metadata clone recovery

The model repository uses `--depth 1 --no-checkout` without a partial clone filter. `GIT_LFS_SKIP_SMUDGE=1` defers weights until stage 080. GitHub source repositories retain their partial clone filter. If model checkout failed with a promisor remote error, preserve the incomplete model directory by moving it into a unique backup directory, then rerun stage 020 with the updated controller. Completed source locks remain intact. Existing unlocked checkouts are still not adopted automatically. Remote/network behavior has not been reproduced on the target host.

## Python development prerequisites

On Ubuntu 24.04, stage 030 installs missing Python development packages automatically using apt-get; stage 007 can install or repair them explicitly. Stage 030 now checks Python.h and patchlevel.h using the stack interpreter, installs NumPy into that interpreter after the source development dependency group, and checks the NumPy C header. If an earlier CMake configuration disabled BUILD_PYTHON after failed dependency discovery, preserve the PyTorch build directory in a backup and rerun stage 030 to configure from scratch. Do not disable BUILD_PYTHON to bypass missing headers.

## Automatic Python development package installation

Run `./bx_ai_coding_setup.sh 007_install_python_dev --execute` to install or repair `python3.12-dev` and `libpython3.12-dev`. Stage 030 invokes the installer only when Python.h or patchlevel.h is missing. The installer supports the configured Ubuntu 24.04 aarch64 / Python 3.12 profile, authenticates with `sudo -v` in the terminal (unless already root), updates apt indexes, reinstalls the two development packages, and rechecks the interpreter headers. Failures stop the build. Run the top-level script as your regular user. Without --execute the command only prints a plan. This stage requires access to Ubuntu package repositories. Build IDs are KST timestamps in comments, after a required shebang or on the first line otherwise.

## Development tool and runtime dependency separation

The Click upper bound from the previous revision is removed: the observed spin 0.18 requires Click below 8.4, while huggingface-hub 1.31 through 2.2 requires Click at least 8.4.2. No shared version satisfies both ranges. Stage 030 removes spin after the pip/make PyTorch build. Transformers, vLLM and LMCache stages also remove spin before runtime resolution and regenerate core constraints without a Click cap. The source-built core packages remain constrained. This workflow does not invoke the spin CLI; developers who need that CLI should install it in a separate development environment.

Upgrade scripts/bx_stack.py before rerunning stage 040. The new script overwrites the old generated constraints; manually editing that generated file while keeping the old script is ineffective. An offline regression with synthetic package metadata reproduces the incompatible ranges, verifies the old cap fails, then verifies spin removal and runtime resolution pass pip check. This does not certify actual target packages or GPU integration.

## Incomplete PyTorch editable installation

An installed torch distribution/version does not prove that torch can be imported. Stage 030 now explicitly passes cmake.define.BUILD_PYTHON=ON and the stack Python executable to the scikit-build-core backend. Immediately after source installation it imports torch, torch.version and torch._C in isolated Python mode, verifies a CUDA-enabled build and a small CPU tensor operation, and prints the resolved paths. Transformers/vLLM/LMCache stages run this check before changing dependencies. If torch.version is missing in both normal and isolated Python, update the controller and rerun stage 030 before stage 050. Keep the existing build directory for incremental reuse; reconfiguration can require recompilation. Missing generated files versus a stale editable redirect cannot be distinguished without inspecting the target files. Do not fabricate torch/version.py or install a published torch wheel as a workaround.

## Runtime Click repair after rebuilding PyTorch

Installing the PyTorch dev group can downgrade Click again. Uninstalling spin alone leaves that older Click installed. After removing spin, stage 030 now reads active Click requirements from installed package metadata (excluding inactive extras) and asks pip to satisfy those requirements before pip check. It does not hard-code a Click version range. Existing users whose PyTorch import/tensor checks and Triton installation have succeeded can repair Click to the reported Hub requirement and run pip check, then resume stage 050 without repeating the PyTorch build.

## Align Transformers with the locked vLLM source

The reported vLLM checkout requires Transformers >=5.16.1,<5.21.0 and rejects the independently downloaded 5.21.0.dev0 main branch. New profiles use the official v5.20.2 source tag. Existing users should update the three controller files while preserving their config, then run `025_align_transformers --ref v5.20.2 --execute`, `040_build_transformers --execute`, and `050_build_vllm --execute`. Stage 025 checks source locks, refuses tracked Transformers modifications, fetches the explicit release tag, checks its setup.py version against local vLLM requirements/common.txt, and backs up config/source lock before changing checkout and recording the new ref/commit. On a write failure it attempts rollback. The backup path is printed. This operation does not install a published Transformers wheel. Stage 040 performs the local source installation. Do not manually edit only the checkout, since the source lock must match. If a different vLLM checkout rejects the tag, choose a release inside its declared range. This is dependency compatibility, not a full GPU/model validation.
