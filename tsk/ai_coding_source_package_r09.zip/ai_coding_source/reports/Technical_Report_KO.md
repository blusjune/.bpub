# DGX Spark 소스 기반 AI Coding 환경 구축

build: brianmjung_20261021_232535

## 1. 구성과 범위

상위 진입점은 `bx_ai_coding_setup.sh` 하나입니다. 실행 순서를 포함한 subcommand가 내부 Python 구현을 호출합니다. 기존 GDS 연구 패키지는 변경하지 않으며, 이번 bootstrap은 별도 `deliverables/ai_coding_source/`에 제공합니다.

설치 root는 `/opt/work/ai_coding/root/`, source root는 `/opt/work/ai_coding/root/src/`입니다. Python 환경은 `venvs/stack/`, 관리하는 build/log/config/report/cache/state는 `deliverables/ai_coding/`에 둡니다. upstream의 editable build 파일은 각 source tree에도 생성될 수 있습니다.

OpenCode는 파일·명령 도구와 agent loop를 관리하고, vLLM은 Qwen 추론을 수행하며, LMCache는 KV/state cache를 보관·조회합니다. Ollama는 이 구성에 필요하지 않습니다. OpenCode와 서비스는 같은 Spark에서 실행하되, 프로젝트는 `140_run_agent --project`로 별도 지정합니다.

## 2. Source build의 정확한 의미

| 대상 | 처리 방식 |
|---|---|
| OpenCode V2 | Git clone → frozen Bun dependency 설치 → host executable build |
| PyTorch | Git 및 recursive submodule clone → editable native/CUDA build |
| Triton | PyTorch의 matching `make triton` recipe 수행 |
| Transformers | Git clone → editable source install |
| vLLM | 기존 PyTorch 재사용 helper → native/CUDA editable build |
| LMCache | 동일 PyTorch 환경에서 native/CUDA editable build |
| Qwen 모델 | reference GitHub repo 및 Hugging Face weight repo clone; weight는 학습 결과를 다운로드 |

Qwen weight를 `git clone`한다고 모델을 source에서 재학습하거나 compile하는 것은 아닙니다. 실행 모델 구현은 Transformers/vLLM에 있습니다. CUDA driver/toolkit, cuDNN, Bun, compiler와 제3자 Python/npm native dependency는 binary prerequisite을 허용합니다. 모든 전이 의존성과 OS까지 source-only로 만드는 패키지는 아닙니다.

PyTorch까지 포함한 source build는 시간·디스크·ABI 조정 비용이 큽니다. CUDA 13.0 설치 여부는 실제 `nvcc`로 확인합니다. 기존 driver/toolkit를 자동 교체하지 않습니다. Bun은 checkout의 `packageManager`와 같은 버전을 요구합니다. OpenCode의 현재 검토 source는 V2이며 V1 설정을 혼용하지 않습니다.

## 3. 번호별 단계

| Subcommand | 작업 |
|---|---|
| `005_check_host` | ARM64, GB10, sm_121 nvcc 및 도구 확인 |
| `010_conf_env` | 작업 디렉터리와 Python venv 생성 |
| `020_download_src` | source/model metadata clone 및 commit lock |
| `030_build_pytorch` | PyTorch와 matching Triton build |
| `040_build_transformers` | Transformers source install |
| `050_build_vllm` | 기존 PyTorch에 맞춰 vLLM build |
| `060_build_lmcache` | 같은 ABI로 LMCache build |
| `070_build_opencode` | OpenCode V2 host executable build |
| `080_download_weights` | Git LFS pull/fsck 및 shard 확인 |
| `090_conf_services` | OpenCode provider 및 launch plan 생성 |
| `100_verify_build` | source origin, CUDA tensor 연산, import/CLI 확인 |
| `110_serve_baseline` | LMCache 없는 vLLM foreground 서비스 |
| `120_serve_stack` | LMCache MP + vLLM foreground 서비스 |
| `130_test_api` | 실제 API의 structured tool call 검사 |
| `140_run_agent` | 지정 프로젝트에서 OpenCode 실행 |
| `900_validate` | controller CPU/mock 회귀 검사 |

기본은 plan-only이며 `--execute`에서 실제 작업합니다. 예외인 `900_validate`는 실제 CPU/mock 테스트를 실행하고 bundle의 test log를 갱신합니다. `--help`는 동작·다운로드 없이 종료합니다. 실행 예제 전체는 English README와 top-level help에 있습니다.

## 4. 초기 모델과 LMCache 설정

초기 모델은 `Qwen/Qwen3.8-27B`, BF16, text-only agent 경로, context 32768입니다. CPU L1은 4 GB, vLLM GPU-memory fraction은 0.65, 동시 sequence는 1로 시작합니다. 이 값은 실측 최적값이 아니라 startup과 원인 분리를 위한 후보 설정입니다. 통합 128 GB에서 GPU·CPU cache·OS가 같은 물리 메모리를 공유합니다.

공식 LMCache hybrid recipe는 Qwen3.8-27B의 unified block을 784 tokens로 제시합니다. 이를 따라 chunk 784, `--separate-object-groups`, prefix caching, Mamba `align`, batched-token budget 1567을 사용합니다. 실제 startup 로그의 negotiated geometry가 다르면 재검토해야 합니다. hybrid recurrent state와 full-attention KV를 같은 일반 MHA 배열로 취급하지 않습니다. CacheBlend/CacheGen, 이미지·비디오 cache는 활성화하지 않습니다.

OpenCode V2는 `providers`와 OpenAI-compatible package로 `127.0.0.1:8000/v1`에 연결합니다. custom model의 자동 기본 context를 사용하지 않고 서버와 동일한 32K limit 및 text/tool capability를 명시합니다. `qwen3_xml`/`qwen3` parser 설정은 실제 source version과 API smoke로 확인해야 하는 후보입니다.

## 5. 재현성 및 검증 판정

첫 source download에서 branch/ref를 commit SHA로 고정하고 `sources.lock.json`으로 이후 재사용합니다. URL/ref 변경이나 HEAD 불일치는 거부합니다. 기본 branch 조합은 최신 후보이며 검증된 vLLM×LMCache×PyTorch 호환 matrix라는 뜻이 아닙니다. source lock은 Python/npm 전체 dependency closure lock과도 다릅니다. Python dependency는 첫 build 후 `pip-freeze.txt`로 기록합니다. core version constraint와 `pip check`로 binary core package의 조용한 대체를 방지합니다.

이번 작성 환경의 CPU/mock 테스트 20개가 통과했습니다. Bash syntax 및 Python compile도 확인했습니다. 주요 검증은 help 무동작, 잘못된 옵션, dry-run 무변경, architecture guard, lock drift, V2 설정, hybrid flag, baseline/integrated dispatch, readiness 실패 및 structured tool JSON 판정입니다.

**실제 DGX Spark에서 source build, model weight 다운로드, API 응답, agent의 파일 수정/테스트, LMCache store/retrieve는 아직 실행하지 않았습니다.** `100_verify_build` 통과도 전체 coding 품질을 인증하지 않습니다. `130_test_api`는 tool call 구조만 확인하며 명령을 실제 실행하거나 cache hit를 판정하지 않습니다.

서비스 최초 단계는 CPU L1이며 SSD/raw block/GDS는 아직 구성하지 않습니다. 기능 검증 후 기존 GDS 연구와 결합할 수 있지만 Spark native DMA를 주장하지 않습니다. 반복 요청의 속도 차이는 vLLM GPU prefix hit와 LMCache hit를 구분해 분석해야 합니다.

## 6. 공식 출처

- OpenCode source: https://github.com/anomalyco/opencode
- OpenCode source development: https://github.com/anomalyco/opencode/blob/dev/CONTRIBUTING.md
- OpenCode V2 providers: https://opencode.ai/v2/docs/providers
- OpenCode V2 model limits: https://opencode.ai/v2/docs/models
- PyTorch source build: https://github.com/pytorch/pytorch#from-source
- vLLM existing PyTorch source build: https://docs.vllm.ai/en/latest/getting_started/installation/gpu/
- LMCache source installation: https://docs.lmcache.ai/getting_started/installation.html
- LMCache compatibility: https://docs.lmcache.ai/getting_started/compatibility.html
- LMCache MP quickstart: https://docs.lmcache.ai/getting_started/quickstart.html
- LMCache Qwen hybrid recipe: https://docs.lmcache.ai/recipes/qwen3_5.html
- Qwen model card: https://huggingface.co/Qwen/Qwen3.8-27B

웹 문서는 이동하는 최신 자료입니다. 다운로드한 commit의 CLI/source와 실제 target 결과를 최종 근거로 사용합니다.

## TMPDIR 초기화 결함 수정

Build: brianmjung_20261022_000931

`005_check_host`가 `010_conf_env`보다 먼저 실행되면 `TMPDIR` 디렉터리가 없는 상태에서 `nvcc --list-gpu-code`가 실패할 수 있었습니다. 공통 실행 함수가 subprocess 실행 전에 임시 디렉터리를 생성하고 실제 임시 파일 생성으로 쓰기 가능 여부를 확인하도록 수정했습니다. Dry run은 디렉터리를 만들지 않습니다. 초기화 전 실행, preflight 독립 실행, 경로가 파일인 경우의 실패 처리를 추가 검증했으며 CPU/mock 테스트 23개가 통과했습니다. 실제 DGX Spark에서의 재검증은 사용자 환경에서 필요합니다.

## Hugging Face 모델 metadata checkout 실패 대응

Build: brianmjung_20261022_004428

사용자 로그에서 `--filter=blob:none` partial clone 이후 checkout의 lazy object fetch가 `expected packfile` 및 promisor remote 오류로 실패했습니다. 실패한 경로는 확인되지만 서버, 네트워크, 프록시 중 근본 원인은 확정하지 않았습니다. 모델 저장소에만 partial clone filter를 제거하고 shallow clone 및 `GIT_LFS_SKIP_SMUDGE=1`을 유지하여 가중치 다운로드를 080 단계로 분리했습니다. 중단된 unlocked 모델 디렉터리는 사용자가 백업 후 재실행하며, 기존 완료 source lock은 유지됩니다. 모델 clone 옵션, LFS 지연 및 checkout 실패 시 lock 보존을 포함한 CPU/mock 테스트 25개가 통과했습니다. 실제 Hugging Face 다운로드 재현 및 Spark 검증은 미수행입니다.

## Python 개발 헤더 누락으로 인한 CMake 실패 수정

Build: brianmjung_20261022_221031

사용자 로그의 최초 CMake Error는 `/usr/include/python3.12/patchlevel.h` 읽기 실패입니다. 이후 list GET 오류는 연쇄 오류이며 FindPython이 Development.Module과 NumPy를 찾지 못해 BUILD_PYTHON이 OFF로 변경되었습니다. Ubuntu의 python3.12-dev 및 stack 가상환경의 NumPy를 준비해야 합니다. 030 단계에 Python 개발 헤더 검사와 NumPy 설치 및 C 헤더 검사를 추가했습니다. 기존 실패한 CMake cache가 남지 않도록 build 디렉터리를 삭제 대신 백업한 후 재시도합니다. CPU/mock 테스트 26개가 통과했으며 실제 Spark PyTorch 빌드는 미검증입니다. NUMA 및 MPI 경고는 이 최초 오류와 별개입니다.

## Python 개발 패키지 자동 설치

BUILD_ID: BMJ_20261022_222543

007_install_python_dev 단계를 추가했습니다. Ubuntu 24.04 aarch64 및 설정의 Python 3.12를 확인한 후 sudo 인증, apt-get update, python3.12-dev/libpython3.12-dev 재설치를 수행하고 헤더를 다시 확인합니다. 030 단계도 헤더 누락 시 이 설치 함수를 호출합니다. sudo 및 apt 실패 시 빌드를 중단합니다. --execute 없는 dry run은 subprocess 및 파일 변경을 수행하지 않습니다. 기존 가상환경과 개발 패키지 설치를 구분하며, 전체 스크립트는 일반 사용자로 실행합니다. 수정된 모든 Python/Bash 파일에 KST 기준 BUILD_ID 주석을 반영했습니다. CPU/mock 테스트 32개 통과, 실제 Spark apt 설치 및 GPU 빌드 미검증입니다.

## Transformers 설치 후 Click 의존성 충돌 수정

BUILD_ID: BMJ_20261023_002014

첨부 로그에서 Transformers editable 설치는 완료됐으나 Click 8.5.0이 설치되어 spin 0.18의 click>=8,<8.4,!=8.3.0 요구와 충돌했고 마지막 pip check가 실패했습니다. 이 요구를 core constraints에 함께 유지하고 source editable 설치 전에 Click을 constraint 범위로 복구합니다. 고정된 요구 범위는 관측한 spin 0.18 환경에 근거하며 추후 도구 버전 변경 시 재검토가 필요합니다. CPU/mock 테스트 33개가 통과했고 Spark의 실제 dependency resolution 및 GPU 통합은 미검증입니다.

## Click 수정 정정: 개발 CLI와 runtime 의존성 분리

BUILD_ID: BMJ_20261023_002433

이 절은 앞선 Click 상한 고정 방식을 대체합니다. spin 0.18의 Click <8.4와 huggingface-hub의 Click >=8.4.2는 교집합이 없어 앞선 제약은 잘못됐습니다. Click cap을 제거하고 pip/make 방식의 PyTorch 빌드에서 사용하지 않는 spin 개발 CLI를 공유 runtime 환경에서 제거합니다. 030 빌드 완료 후 및 Transformers/vLLM/LMCache 의존성 설치 전에 spin을 제거하며 core source 패키지 pin은 유지합니다. 기존 생성 constraints는 새 스크립트가 재생성합니다. 테스트용 wheel metadata로 실제 pip resolver의 기존 실패 및 수정 후 설치/pip check 성공을 재현했습니다. 전체 CPU/mock 및 offline resolver 테스트 34개 통과. 실제 Spark 설치 및 GPU 통합은 미검증입니다.

## torch.version 누락 및 import 검증

BUILD_ID: BMJ_20261024_001818

사용자 환경에서 일반 및 isolated Python 모두 torch.version import에 실패했습니다. PYTHONPATH 및 현재 디렉터리만의 영향은 배제되지만 editable redirect 연결 문제와 생성 파일 누락은 타깃 파일 확인 없이 확정할 수 없습니다. 해당 checkout의 pyproject.toml은 scikit-build-core redirect editable 모드를 사용합니다. 030 단계에서 BUILD_PYTHON=ON 및 Python_EXECUTABLE을 config-settings로 명시하고 source editable 재설치를 수행한 직후 torch/version/native extension import와 CPU tensor 연산을 확인합니다. 이후 Transformers/vLLM/LMCache 단계도 의존성 변경 전에 검증합니다. 기존 build 디렉터리는 재사용하며 일부 재컴파일 가능성이 있습니다. CPU/mock 및 offline resolver 테스트 36개 통과, 실제 Spark 복구와 CUDA 연산은 미검증입니다.

## PyTorch 재빌드 후 runtime Click 복구

BUILD_ID: BMJ_20261024_003710

사용자 로그에서 PyTorch source editable 설치, torch.version/native extension import 및 CPU tensor 검사는 성공했습니다. CUDA 버전은 13.0으로 확인되지만 GPU tensor 연산 성공을 의미하지는 않습니다. 이후 Triton 설치도 성공했고 마지막 pip check에서 Hub와 Click의 충돌만 남았습니다. PyTorch dev group이 spin의 요구에 따라 Click을 낮춘 뒤 spin만 삭제해도 Click 버전은 복구되지 않는 것이 원인입니다. 030 단계에 spin 제거 후 현재 설치 metadata의 활성 Click 요구를 수집하여 pip로 복구하는 처리를 추가했습니다. 같은 상황을 offline synthetic wheel 테스트로 재현하여 복구 및 pip check 성공을 확인했고 전체 테스트 38개가 통과했습니다. 실제 Spark의 새 복구 명령은 사용자 재검증이 필요합니다.

## vLLM과 Transformers source ref 정합성

BUILD_ID: BMJ_20261024_010403

사용자 로그의 vLLM은 Transformers >=5.16.1,<5.21.0을 요구하지만 독립 main checkout의 5.21.0.dev0을 constraint로 고정하여 pip resolution이 실패했습니다. 공식 v5.20.2 release tag를 소스 설치 대상으로 선택했습니다 (https://github.com/huggingface/transformers/releases/tag/v5.20.2). 025_align_transformers는 로컬 vLLM 요구와 release setup.py 버전을 검증하고, tracked 수정이 없는 checkout만 전환하며 config와 source lock을 함께 갱신합니다. 변경 전 두 기록을 백업하고 write 실패 시 rollback을 시도합니다. 이후 040 source 설치 및 050 재시도가 필요합니다. 기존 사용자는 config를 기본값으로 덮어쓰지 않고 세 controller 파일만 갱신합니다. 호환성 거부, tracked 수정 거부, 기록 갱신 및 rollback을 포함한 테스트 42개 통과. 실제 Spark에서 source 전환, vLLM GPU 빌드 및 Qwen/LMCache 통합은 미검증입니다.
