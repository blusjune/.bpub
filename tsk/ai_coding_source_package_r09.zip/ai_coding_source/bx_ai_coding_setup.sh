#!/usr/bin/env bash
# BUILD_ID="BMJ_20261024_010403"
# Single public dispatcher. Build logic lives in scripts/bx_driver.py.
set -euo pipefail
bx_bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
bx_python="${BX_SETUP_PYTHON:-python3}"
bx_config="$bx_bundle_dir/configs/stack.json"

bx_help() {
    cat <<'HELP'
Usage: bx_ai_coding_setup.sh [--config FILE] SUBCOMMAND [OPTIONS]

Source-build OpenCode V2 + vLLM + Qwen + LMCache on DGX Spark.
Default root: /opt/work/ai_coding/root/
Source root:  /opt/work/ai_coding/root/src/

Numbered subcommands:
  005_check_host          Inspect ARM64, GB10, CUDA, build tools, Bun, Git LFS
  007_install_python_dev Install/repair Ubuntu 24.04 Python 3.12 development headers
  010_conf_env            Create task directories and isolated Python environment
  020_download_src        Clone sources/model metadata and lock exact Git commits
  025_align_transformers  Validate a release tag against vLLM; update source/config/lock
  030_build_pytorch       Build PyTorch and its matching Triton from source
  040_build_transformers  Install editable Transformers from source
  050_build_vllm          Build editable vLLM against the existing source PyTorch
  060_build_lmcache       Build editable LMCache against the same PyTorch
  070_build_opencode      Build the host OpenCode V2 executable from source
  080_download_weights    Materialize and check model weight shards with Git LFS
  090_conf_services       Generate local OpenCode and service configuration
  100_verify_build       Check source origins, imports, CUDA kernel, and CLI tools
  110_serve_baseline     Run vLLM alone in the foreground
  120_serve_stack        Run LMCache + vLLM; Ctrl-C stops owned process groups
  130_test_api           Verify a structured tool call against the running API
  140_run_agent          Run OpenCode against the local model for --project DIR
  900_validate           Run controller CPU/mock tests; no downloads or GPU work

Options:
  --execute              Perform work; omitted means print a plan only
  --project DIR          Required for 140_run_agent
  -h, --help             Show help without performing any stage actions
  --config FILE          Select the JSON profile; place before SUBCOMMAND

Typical sequence:
  ./bx_ai_coding_setup.sh 005_check_host --execute
  ./bx_ai_coding_setup.sh 007_install_python_dev --execute
  ./bx_ai_coding_setup.sh 010_conf_env --execute
  ./bx_ai_coding_setup.sh 020_download_src --execute
  ./bx_ai_coding_setup.sh 030_build_pytorch --execute
  ./bx_ai_coding_setup.sh 040_build_transformers --execute
  ./bx_ai_coding_setup.sh 050_build_vllm --execute
  ./bx_ai_coding_setup.sh 060_build_lmcache --execute
  ./bx_ai_coding_setup.sh 070_build_opencode --execute
  ./bx_ai_coding_setup.sh 080_download_weights --execute
  ./bx_ai_coding_setup.sh 090_conf_services --execute
  ./bx_ai_coding_setup.sh 100_verify_build --execute
  ./bx_ai_coding_setup.sh 110_serve_baseline --execute
  ./bx_ai_coding_setup.sh 130_test_api --execute
  ./bx_ai_coding_setup.sh 120_serve_stack --execute
  ./bx_ai_coding_setup.sh 140_run_agent --project /opt/work/my-project --execute
  ./bx_ai_coding_setup.sh 900_validate

Resolve a Transformers main-branch version conflict:
  ./bx_ai_coding_setup.sh 025_align_transformers --ref v5.20.2 --execute
  ./bx_ai_coding_setup.sh 040_build_transformers --execute
  ./bx_ai_coding_setup.sh 050_build_vllm --execute

Use a second terminal for API tests and the agent while a server is running.
Stop the baseline with Ctrl-C before starting the LMCache stack on the same port.
900_validate always runs tests; it writes only bundle-local validation results.
Latest source refs are candidates, not a hardware-validated compatibility matrix.
Core software is built from source; compilers/CUDA/cuDNN/Bun and transitive
package dependencies are prerequisites and may be supplied as binaries.
The initial service profile uses CPU L1 cache only; it does not perform SSD I/O.
Stage 007 uses apt-get and may request sudo authentication. Stage 030 also
installs Python development packages automatically if headers are missing.
Preview package installation: ./bx_ai_coding_setup.sh 007_install_python_dev
HELP
}

while (($#)); do
    case "$1" in
        --config)
            if (($# < 2)); then echo 'ERROR: --config requires a file' >&2; exit 2; fi
            bx_config="$2"; shift 2 ;;
        -h|--help) bx_help; exit 0 ;;
        --*) echo "ERROR: Unknown global option: $1" >&2; exit 2 ;;
        *) break ;;
    esac
done
if (($# == 0)); then bx_help; exit 0; fi
bx_command="$1"; shift
case "$bx_command" in
    005_check_host|007_install_python_dev|010_conf_env|020_download_src|025_align_transformers|030_build_pytorch|040_build_transformers|050_build_vllm|060_build_lmcache|070_build_opencode|080_download_weights|090_conf_services|100_verify_build|110_serve_baseline|120_serve_stack|130_test_api|140_run_agent|900_validate) ;;
    *) echo "ERROR: Unknown subcommand: $bx_command" >&2; exit 2 ;;
esac
for bx_argument in "$@"; do
    if [[ "$bx_argument" == --help || "$bx_argument" == -h ]]; then
        bx_help; exit 0
    fi
done
bx_call() { "$bx_python" "$bx_bundle_dir/scripts/bx_driver.py" --config "$bx_config" "$@"; }
case "$bx_command" in
    005_check_host) bx_call preflight "$@" ;;
    007_install_python_dev) bx_call install_python_dev "$@" ;;
    010_conf_env) bx_call init "$@"; bx_call env "$@" ;;
    020_download_src) bx_call fetch "$@" ;;
    025_align_transformers) bx_call align_transformers "$@" ;;
    030_build_pytorch) bx_call build --component pytorch "$@" ;;
    040_build_transformers) bx_call build --component transformers "$@" ;;
    050_build_vllm) bx_call build --component vllm "$@" ;;
    060_build_lmcache) bx_call build --component lmcache "$@" ;;
    070_build_opencode) bx_call build --component opencode "$@" ;;
    080_download_weights) bx_call weights "$@" ;;
    090_conf_services) bx_call configure "$@" ;;
    100_verify_build) bx_call verify "$@" ;;
    110_serve_baseline) bx_call serve --baseline "$@" ;;
    120_serve_stack) bx_call serve "$@" ;;
    130_test_api) bx_call smoke "$@" ;;
    140_run_agent) bx_call agent "$@" ;;
    900_validate) bx_call validate "$@" ;;
esac
