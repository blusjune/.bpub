# BUILD_ID="BMJ_20261024_010403"
"""CPU-only adversarial checks. These do not certify any target build."""
import contextlib
import importlib.util
import io
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest
import zipfile
from types import SimpleNamespace
from unittest import mock

HERE=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('controller',HERE/'scripts/bx_stack.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Controller(unittest.TestCase):
    def config(self,root):
        c=json.loads((HERE/'configs/stack.json').read_text());c['root']=str(root);return c

    def test_help_no_files(self):
        for stage in ('build','fetch','serve','agent','configure'):
            with tempfile.TemporaryDirectory() as t:
                r=subprocess.run([sys.executable,str(HERE/'scripts/bx_driver.py'),stage,'--help'],cwd=t,capture_output=True,text=True)
                self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(list(pathlib.Path(t).iterdir()),[])

    def test_unknown_option(self):
        r=subprocess.run([sys.executable,str(HERE/'scripts/bx_driver.py'),'fetch','--unexpected'],capture_output=True,text=True)
        self.assertEqual(r.returncode,2)

    def test_dry_run_has_no_mutations(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t)/'absent';s=m.Stack(self.config(root))
            a=SimpleNamespace(component='all',baseline=False,project=pathlib.Path(t),ref='v5.20.2')
            with contextlib.redirect_stdout(io.StringIO()),mock.patch.object(m.subprocess,'run',side_effect=AssertionError('subprocess')),mock.patch.object(m.subprocess,'Popen',side_effect=AssertionError('process')):
                for stage in ('init','preflight','install_python_dev','align_transformers','fetch','env','build','weights','configure','verify','serve','smoke','agent'):
                    getattr(s,stage)(a)
            self.assertFalse(root.exists())

    def test_architecture_guard(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(m.platform,'machine',return_value='x86_64'),mock.patch.object(s,'run') as run:
                with self.assertRaises(RuntimeError):s.preflight(None)
                run.assert_not_called()

    def test_bad_config(self):
        for key,value in [('root','/'),('node','node2'),('cuda_arch','12.0'),('model_id','Qwen/Other'),('gpu_memory_utilization',0.95),('max_batched_tokens',128),('cache_port',8000)]:
            c=self.config('/tmp/task');c[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):m.Stack(c)

    def alignment_fixture(self,root,requirement='transformers>=5.16.1,<5.21.0',dirty=False):
        c=self.config(root);c['repos']['transformers']['ref']='main';s=m.Stack(c,True)
        config=pathlib.Path(root)/'config.json';config.write_text(json.dumps(c))
        lock={'transformers':{'url':c['repos']['transformers']['url'],'requested_ref':'main','commit':'a'*40},'pytorch':{'commit':'preserved'}}
        s.out.mkdir(parents=True);(s.out/'sources.lock.json').write_text(json.dumps(lock))
        requirements=s.src/'vllm/requirements/common.txt';requirements.parent.mkdir(parents=True);requirements.write_text(requirement+'\n')
        def run(cmd,**kwargs):
            if cmd[:2]==['git','status']:return ' M setup.py' if dirty else ''
            if cmd[:2]==['git','rev-parse']:return 'b'*40
            if cmd[:2]==['git','show']:return 'setup(version="5.20.2")'
            if str(cmd[0])==str(s.py):
                subprocess.run([sys.executable,*cmd[1:]],check=True,capture_output=True,text=True)
            return ''
        return s,SimpleNamespace(ref='v5.20.2',config=config),lock,run

    def test_alignment_updates_ref_and_lock_with_backup(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run):s.align_transformers(a)
            new=json.loads((s.out/'sources.lock.json').read_text())
            self.assertEqual(new['transformers']['commit'],'b'*40)
            self.assertEqual(new['pytorch'],old['pytorch'])
            self.assertEqual(json.loads(a.config.read_text())['repos']['transformers']['ref'],'v5.20.2')
            backup=json.loads(next((s.out/'state').glob('*.json')).read_text())
            self.assertEqual(backup['sources_lock'],old)

    def test_alignment_rejects_incompatible_release_before_checkout(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t,'transformers>=5.16.1,<5.20.0')
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run) as calls:
                with self.assertRaises(subprocess.CalledProcessError):s.align_transformers(a)
            self.assertFalse(any(x.args[0][:2]==['git','checkout'] for x in calls.call_args_list))
            self.assertEqual(json.loads((s.out/'sources.lock.json').read_text()),old)

    def test_alignment_rejects_dirty_checkout(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t,dirty=True)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run) as calls:
                with self.assertRaisesRegex(RuntimeError,'tracked local modifications'):s.align_transformers(a)
            self.assertEqual(calls.call_count,1)

    def test_alignment_rolls_back_config_write_failure(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t);write=s.write;failed=False
            def fail_once(path,data):
                nonlocal failed
                if path==a.config and not failed:
                    failed=True;raise OSError('simulated write failure')
                write(path,data)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run) as calls,mock.patch.object(s,'write',side_effect=fail_once):
                with self.assertRaisesRegex(OSError,'simulated write failure'):s.align_transformers(a)
            self.assertEqual(json.loads((s.out/'sources.lock.json').read_text()),old)
            self.assertEqual(json.loads(a.config.read_text())['repos']['transformers']['ref'],'main')
            checkouts=[x.args[0] for x in calls.call_args_list if x.args[0][:2]==['git','checkout']]
            self.assertEqual(checkouts[-1][-1],'a'*40)

    def test_python_header_probe_rejects_missing_headers(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'ensure_python_headers'),mock.patch.object(s,'repair_runtime_click'),mock.patch.object(s,'pip'),mock.patch.object(s,'run',return_value='') as run:
                s.build(SimpleNamespace(component='pytorch'))
            probe=run.call_args_list[0].args[0][2]
            code='import sysconfig; sysconfig.get_path=lambda name: '+repr(t)+'; '+probe
            result=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
            self.assertIn('install python3.12-dev',result.stderr)
            for name in ('Python.h','patchlevel.h'):(pathlib.Path(t)/name).touch()
            result=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)

    def test_python_headers_auto_install_only_when_missing(self):
        s=m.Stack(self.config('/tmp/test'),True)
        for missing in ([],['/missing/Python.h']):
            with self.subTest(missing=missing),mock.patch.object(s,'missing_python_headers',return_value=missing),mock.patch.object(s,'install_python_dev') as install:
                s.ensure_python_headers()
                self.assertEqual(install.call_count,bool(missing))

    def test_apt_installer_authenticates_and_rechecks_headers(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.platform,'freedesktop_os_release',return_value={'ID':'ubuntu','VERSION_ID':'24.04'}),mock.patch.object(m.os,'geteuid',return_value=1000),mock.patch.object(m.subprocess,'run') as auth,mock.patch.object(s,'run') as run,mock.patch.object(s,'missing_python_headers',return_value=[]):
            s.install_python_dev(None)
            auth.assert_called_once_with(['sudo','-v'],check=True)
            self.assertEqual(run.call_args_list[0].args[0],['sudo','apt-get','update'])
            self.assertEqual(run.call_args_list[1].args[0],['sudo','apt-get','install','-y','--reinstall','python3.12-dev','libpython3.12-dev'])

    def test_apt_installer_rejects_other_os(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.platform,'freedesktop_os_release',return_value={'ID':'debian','VERSION_ID':'12'}),mock.patch.object(s,'run') as run:
            with self.assertRaisesRegex(RuntimeError,'Ubuntu 24.04'):s.install_python_dev(None)
            run.assert_not_called()

    def test_sudo_failure_does_not_run_apt(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.platform,'freedesktop_os_release',return_value={'ID':'ubuntu','VERSION_ID':'24.04'}),mock.patch.object(m.os,'geteuid',return_value=1000),mock.patch.object(m.subprocess,'run',side_effect=subprocess.CalledProcessError(1,['sudo','-v'])),mock.patch.object(s,'run') as run:
            with self.assertRaises(subprocess.CalledProcessError):s.install_python_dev(None)
            run.assert_not_called()

    def test_header_install_failure_stops_build(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'locked'),mock.patch.object(s,'missing_python_headers',return_value=['missing']),mock.patch.object(s,'install_python_dev',side_effect=RuntimeError('apt failed')),mock.patch.object(s,'pip') as pip:
            with self.assertRaisesRegex(RuntimeError,'apt failed'):s.build(SimpleNamespace(component='pytorch'))
            pip.assert_not_called()

    def test_captured_command_creates_writable_tmp_before_init(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(pathlib.Path(t)/'absent'),True)
            result=s.run([sys.executable,'-c',
                'import os,tempfile; f=tempfile.TemporaryFile(dir=os.environ["TMPDIR"]); print("ready"); f.close()'],capture=True)
            self.assertEqual(result,'ready')
            self.assertTrue((s.out/'tmp').is_dir())
            self.assertEqual(list((s.out/'tmp').iterdir()),[])

    def test_preflight_without_init(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(pathlib.Path(t)/'absent'),True)
            def probe(cmd,**kwargs):
                self.assertTrue(pathlib.Path(kwargs['env']['TMPDIR']).is_dir())
                return SimpleNamespace(stdout='GB10 sm_121')
            with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.subprocess,'run',side_effect=probe):
                s.preflight(None)
            self.assertTrue((s.out/'reports/preflight.json').is_file())

    def test_invalid_tmp_fails_before_subprocess(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            s.out.mkdir(parents=True);(s.out/'tmp').write_text('not a directory')
            with mock.patch.object(m.subprocess,'run') as run:
                with self.assertRaisesRegex(RuntimeError,'Cannot prepare writable TMPDIR'):
                    s.run([sys.executable,'--version'],capture=True)
                run.assert_not_called()

    def test_connector_and_hybrid_settings(self):
        s=m.Stack(self.config('/tmp/task'))
        cmd=s.server_command(False)
        connector=json.loads(cmd[cmd.index('--kv-transfer-config')+1])
        self.assertEqual(connector['kv_connector_module_path'],'lmcache.integration.vllm.lmcache_mp_connector')
        self.assertEqual(cmd[cmd.index('--mamba-cache-mode')+1],'align')
        self.assertIn('--separate-object-groups',s.cache_command())
        self.assertNotIn('--kv-transfer-config',s.server_command(True))

    def test_config_v2_and_no_project_write(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True);s.configure(None)
            c=json.loads((s.out/'config/opencode.json').read_text())
            self.assertIn('providers',c);self.assertNotIn('provider',c)
            self.assertEqual(c['model'],'local/qwen-local')
            self.assertFalse((pathlib.Path(t)/'opencode.json').exists())

    def test_source_lock_mismatch(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(s,'run',return_value='different'):
                with self.assertRaises(RuntimeError):s.git_identity(pathlib.Path(t),'expected')

    def test_broken_torch_stops_vllm_before_dependency_changes(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'locked'),mock.patch.object(s,'check_torch_import',side_effect=RuntimeError('missing torch.version')),mock.patch.object(s,'pip') as pip,mock.patch.object(s,'run') as run:
            with self.assertRaisesRegex(RuntimeError,'missing torch.version'):
                s.build(SimpleNamespace(component='vllm'))
            pip.assert_not_called();run.assert_not_called()

    def test_pytorch_forces_python_build_and_requires_import_before_triton(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'locked'),mock.patch.object(s,'ensure_python_headers'),mock.patch.object(s,'run',return_value='') as run,mock.patch.object(s,'pip') as pip,mock.patch.object(s,'check_torch_import',side_effect=RuntimeError('broken editable')):
            with self.assertRaisesRegex(RuntimeError,'broken editable'):
                s.build(SimpleNamespace(component='pytorch'))
            editable=next(call for call in pip.call_args_list if '-e' in call.args)
            self.assertIn('-Ccmake.define.BUILD_PYTHON=ON',editable.args)
            self.assertIn('-Ccmake.define.Python_EXECUTABLE='+str(s.py),editable.args)
            self.assertFalse(any(call.args[0]==['make','triton'] for call in run.call_args_list))

    def test_spin_removed_without_click_cap_and_core_pins_retained(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',return_value='torch==2.16.0'),mock.patch.object(s,'pip') as pip:
                s.build(SimpleNamespace(component='transformers'))
            constraints=(s.out/'core-constraints.txt').read_text()
            self.assertIn('torch==2.16.0',constraints)
            self.assertNotIn('click',constraints)
            self.assertEqual(pip.call_args_list[0].args,('uninstall','-y','spin'))
            self.assertIn(s.out/'core-constraints.txt',pip.call_args_list[1].args)

    def test_click_probe_uses_installed_requirements_and_active_markers(self):
        namespace={}
        distributions=[SimpleNamespace(requires=['click>=8.4.2,<9', 'click<8; extra == "docs"', 'packaging>=20']),SimpleNamespace(requires=None)]
        import importlib.metadata
        with mock.patch.object(importlib.metadata,'distributions',return_value=distributions),contextlib.redirect_stdout(io.StringIO()) as out:
            exec(m.CLICK_RUNTIME_PROBE,namespace)
        self.assertEqual(json.loads(out.getvalue()),['click<9,>=8.4.2'])

    def test_click_repair_installs_observed_runtime_requirement(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'run',return_value='["click<9,>=8.4.2"]'),mock.patch.object(s,'pip') as pip:
            s.repair_runtime_click()
            pip.assert_called_once_with('install','click<9,>=8.4.2')

    def test_offline_pip_resolves_hub_after_spin_removal(self):
        # Synthetic metadata reproduces the reported ranges, without network/GPU.
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);wheels=root/'wheels';wheels.mkdir()
            def wheel(name,version,requirements=()):
                dist=name+'-'+version+'.dist-info'
                files={dist+'/METADATA':'Metadata-Version: 2.1\nName: '+name+'\nVersion: '+version+'\n'+''.join('Requires-Dist: '+r+'\n' for r in requirements),
                       dist+'/WHEEL':'Wheel-Version: 1.0\nGenerator: regression-fixture\nRoot-Is-Purelib: true\nTag: py3-none-any\n'}
                files[dist+'/RECORD']=''.join(n+',,\n' for n in [*files,dist+'/RECORD'])
                with zipfile.ZipFile(wheels/(name+'-'+version+'-py3-none-any.whl'),'w') as z:
                    for n,data in files.items():z.writestr(n,data)
            wheel('click','8.3.3');wheel('click','8.5.0')
            wheel('spin','0.18',('click>=8,<8.4,!=8.3.0',))
            wheel('huggingface_hub','2.2.0',('click>=8.4.2,<9',))
            wheel('transformers','5.21.0',('huggingface_hub>=1.31,<3',))
            wheel('torch','2.16.0')
            subprocess.run([sys.executable,'-m','venv','--without-pip',str(root/'venv')],check=True,capture_output=True)
            pip=[sys.executable,'-m','pip','--isolated','--python',str(root/'venv/bin/python'),'--disable-pip-version-check','--no-cache-dir']
            def invoke(*args):return subprocess.run([*pip,*args],capture_output=True,text=True)
            options=['--no-index','--find-links',str(wheels)]
            result=invoke('install',*options,'spin==0.18','torch==2.16.0')
            self.assertEqual(result.returncode,0,result.stderr)
            constraint=root/'constraints.txt';constraint.write_text('torch==2.16.0\nclick>=8,<8.4,!=8.3.0\n')
            result=invoke('install',*options,'-c',str(constraint),'transformers')
            self.assertNotEqual(result.returncode,0)
            self.assertIn('ResolutionImpossible',result.stderr)
            self.assertEqual(invoke('uninstall','-y','spin').returncode,0)
            constraint.write_text('torch==2.16.0\n')
            result=invoke('install',*options,'-c',str(constraint),'transformers')
            self.assertEqual(result.returncode,0,result.stderr)
            result=invoke('check');self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            # Re-running the PyTorch dev group can reintroduce the old Click.
            result=invoke('install',*options,'spin==0.18')
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(invoke('uninstall','-y','spin').returncode,0)
            self.assertNotEqual(invoke('check').returncode,0)
            import importlib.metadata
            site=next((root/'venv/lib').glob('python*/site-packages'))
            installed=list(importlib.metadata.distributions(path=[str(site)]))
            with mock.patch.object(importlib.metadata,'distributions',return_value=installed),contextlib.redirect_stdout(io.StringIO()) as out:
                exec(m.CLICK_RUNTIME_PROBE,{})
            requirements=json.loads(out.getvalue())
            result=invoke('install',*options,*requirements)
            self.assertEqual(result.returncode,0,result.stderr)
            result=invoke('check');self.assertEqual(result.returncode,0,result.stdout+result.stderr)

    def test_fetch_ref_drift(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            s.out.mkdir(parents=True)
            (s.out/'sources.lock.json').write_text(json.dumps({'pytorch':{'url':'https://wrong','requested_ref':'main','commit':'x'}}))
            with self.assertRaises(RuntimeError):s.fetch(None)

    def test_readiness_process_exit(self):
        with self.assertRaises(RuntimeError):m.Stack.wait_url('http://127.0.0.1:1',[SimpleNamespace(poll=lambda:1)],10)

    def test_model_clone_without_partial_filter_and_deferred_weights(self):
        with tempfile.TemporaryDirectory() as t:
            c=self.config(t);c['repos']={}
            s=m.Stack(c,True)
            with mock.patch.object(s,'run',return_value='a'*40) as run:
                s.fetch(None)
            calls=run.call_args_list
            clone=calls[0]
            self.assertEqual(clone.args[0][:4],['git','clone','--depth','1'])
            self.assertFalse(any(str(x).startswith('--filter') for x in clone.args[0]))
            self.assertEqual(clone.kwargs['extra']['GIT_LFS_SKIP_SMUDGE'],'1')
            checkout=next(x for x in calls if x.args[0][:2]==['git','checkout'])
            self.assertEqual(checkout.kwargs['extra']['GIT_LFS_SKIP_SMUDGE'],'1')
            self.assertFalse(any(x.args[0][:3]==['git','lfs','pull'] for x in calls))
            lock=json.loads((s.out/'sources.lock.json').read_text())
            self.assertEqual(lock['model']['commit'],'a'*40)

    def test_model_checkout_failure_preserves_completed_locks(self):
        with tempfile.TemporaryDirectory() as t:
            c=self.config(t);c['repos']={};s=m.Stack(c,True)
            previous={'pytorch':{'commit':'completed'}}
            s.out.mkdir(parents=True)
            lockfile=s.out/'sources.lock.json';lockfile.write_text(json.dumps(previous))
            def command(cmd,**kwargs):
                if cmd[:2]==['git','checkout']:raise RuntimeError('simulated checkout failure')
                return ''
            with mock.patch.object(s,'run',side_effect=command),self.assertRaisesRegex(RuntimeError,'simulated checkout failure'):
                s.fetch(None)
            self.assertEqual(json.loads(lockfile.read_text()),previous)

    def test_readiness_http_success(self):
        response=mock.MagicMock();response.__enter__.return_value.status=200
        with mock.patch.object(m.urllib.request,'urlopen',return_value=response):
            m.Stack.wait_url('http://127.0.0.1:1',[],1)

    def test_smoke_rejects_plain_text(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            response=mock.MagicMock();response.__enter__.return_value=io.StringIO(json.dumps({'choices':[{'message':{'content':'I will inspect it'}}]}))
            with mock.patch.object(m.urllib.request,'urlopen',return_value=response),self.assertRaises(RuntimeError):s.smoke(None)

    def test_smoke_structured_arguments(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            data={'choices':[{'message':{'tool_calls':[{'function':{'name':'inspect_project','arguments':'{"path":"."}'}}]}}]}
            response=mock.MagicMock();response.__enter__.return_value=io.StringIO(json.dumps(data))
            with mock.patch.object(m.urllib.request,'urlopen',return_value=response):s.smoke(None)
            self.assertEqual(json.loads((s.out/'reports/api_smoke.json').read_text())['lmcache_hit'],'NOT_VERIFIED')

    def test_english_scripts(self):
        for p in HERE.rglob('*'):
            if p.suffix in ('.py','.json','.mmd') and '__pycache__' not in p.parts:
                self.assertFalse(any('\u3400'<=ch<='\u9fff' or '\uac00'<=ch<='\ud7af' for ch in p.read_text()),str(p))


class ShellDispatch(unittest.TestCase):
    def invoke(self,*args,env=None):
        return subprocess.run(['bash',str(HERE/'bx_ai_coding_setup.sh'),*args],capture_output=True,text=True,env=env)

    def test_shell_help_without_python(self):
        import os
        env=dict(os.environ,BX_SETUP_PYTHON='/not/a/python')
        for args in [('--help',),('010_conf_env','--help'),('120_serve_stack','-h')]:
            r=self.invoke(*args,env=env);self.assertEqual(r.returncode,0,r.stderr)
            self.assertIn('020_download_src',r.stdout)

    def test_shell_unknown_command(self):
        self.assertEqual(self.invoke('020_typo').returncode,2)

    def test_shell_python_dev_plan_and_help(self):
        r=self.invoke('007_install_python_dev')
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('apt-get install',r.stdout)
        self.assertIn('python3.12-dev',r.stdout)
        r=self.invoke('007_install_python_dev','--help','--execute')
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('Usage:',r.stdout)

    def test_shell_missing_config(self):
        self.assertEqual(self.invoke('--config').returncode,2)

    def test_shell_source_build_dispatch(self):
        r=self.invoke('050_build_vllm');self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('tools/use_existing_torch.py',r.stdout)
        self.assertIn('--no-build-isolation',r.stdout)
        self.assertNotIn('pip install vllm',r.stdout)

    def test_shell_init_invalid_option_no_side_effect(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t)/'untouched';cfg=json.loads((HERE/'configs/stack.json').read_text());cfg['root']=str(root)
            p=pathlib.Path(t)/'config.json';p.write_text(json.dumps(cfg))
            r=self.invoke('--config',str(p),'010_conf_env','--unexpected','--execute')
            self.assertEqual(r.returncode,2);self.assertFalse(root.exists())

    def test_shell_foreground_and_agent_dispatch(self):
        r=self.invoke('110_serve_baseline');self.assertEqual(r.returncode,0,r.stderr)
        self.assertNotIn('--kv-transfer-config',r.stdout)
        r=self.invoke('120_serve_stack');self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('LMCacheMPConnector',r.stdout)
        self.assertIn('lmcache server',r.stdout)
        r=self.invoke('140_run_agent','--project','/tmp/example project');self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('/tmp/example project',r.stdout)

if __name__=='__main__':unittest.main()
