# Local inference profiling (r19)

The public entry point is `bx_ai_coding_setup.sh 150a_profile`.
Nothing runs without --execute. Do not profile the serving system while an
uncontrolled OpenCode session or another client is generating requests.
The current Spark profile uses shared LPDDR5X, BF16, one sequence, eager
execution, and CPU-L1 LMCache. SSD/GDS cache traffic is not configured.

## Prerequisites and scope

Run `010a_validate_scripts` after updating the controller. No core rebuild is
required. Optional system tools: vmstat (procps), mpstat/pidstat/iostat
(sysstat), and nvidia-smi. `sudo apt install sysstat` supplies the sysstat tools
on Ubuntu. The harness does not install packages, change clocks, disable swap,
drop page caches, reset LMCache, or kill unrelated processes. Missing or failed
collectors are explicitly recorded. Nsight tools must support GB10/CUDA 13;
check `nsys --version`, `ncu --version`, and tool help on the target. GPU metric
availability varies. GPU utilization is not memory-bandwidth utilization.

Default outputs: ROOT/deliverables/ai_coding/perf/TIMESTAMP/.
Explicit --output must stay under ROOT/deliverables/ai_coding/.
An existing output directory is never overwritten by a new measurement.
Prompts, responses, machine name and software config are retained locally;
review artifacts before sharing them. Host processes may appear in pidstat logs.

## Direct API baseline: two terminals

Finish/exit the agent. Stop the current server with Ctrl-C in its own terminal.
Terminal A:

```bash
./bx_ai_coding_setup.sh 140a_serve_baseline --execute
```

Wait for API READY. Terminal B:

```bash
./bx_ai_coding_setup.sh 150a_profile --action benchmark --mode baseline --output /opt/work/ai_coding/root/deliverables/ai_coding/perf/baseline --execute
```

Defaults: one warmup, three measured requests, max_tokens=256, temperature=0,
seed=42, thinking off, concurrency one. A request may stop before max_tokens.
Completion usage is required; no token count is inferred from words or SSE
chunks. TTFT is time to the first nonempty generated stream event, including
reasoning/tool deltas if present. Decode TPS is explicitly an event-boundary
estimate because a stream event can contain multiple tokens. E2E request TPS
and event-gap observations are not pure GPU-kernel throughput.

`--timeout` is the socket timeout and checked stream deadline in seconds;
a blocked read can delay deadline detection until the socket returns/times out.
Counters are sampled around all measured requests, so their window includes
inter-request/client and scrape overhead. Other traffic invalidates isolation.

## LMCache comparison

Stop baseline in Terminal A, then run:

```bash
./bx_ai_coding_setup.sh 140_serve_stack --execute
```

Wait for API READY. Terminal B:

```bash
./bx_ai_coding_setup.sh 150a_profile --action benchmark --mode lmcache --output /opt/work/ai_coding/root/deliverables/ai_coding/perf/lmcache --execute
./bx_ai_coding_setup.sh 150a_profile --action compare --inputs /opt/work/ai_coding/root/deliverables/ai_coding/perf/baseline /opt/work/ai_coding/root/deliverables/ai_coding/perf/lmcache --execute
```

--mode is a declared label, NOT proof of the live server configuration. Inspect
server-info.json if available, process launch arguments and server logs. Both
experiments must use the same actual model/checkpoint, dtype, launch arguments
except connector enablement, thermal conditions, prompt/output budget and
software commits. Comparison rejects mismatched recorded configs and profiler
runs, but cannot prove matching hardware state or cache residency.

Repeated identical prompts may hit vLLM's internal prefix cache and avoid
external restore. These default runs do NOT establish LMCache cold/warm benefit.
Do not add internal and external cache hit percentages. Absent metrics are
UNAVAILABLE, not zero. Counter resets are reported and excluded from deltas.

## Workload matrix (staged DoE)

| Stage | Controlled change | Required observations |
| --- | --- | --- |
| 1 | Direct API, short prompt, baseline vs stack | Decode estimate, TTFT, logs, counter deltas |
| 2 | Short vs long prompt, same output budget | Actual prompt_tokens from usage; prefill vs decode |
| 3 | Thinking off vs on | Reasoning usage if supplied; quality and task time |
| 4 | Cache residency protocols | Explicit internal-prefix and external-cache states |
| 5 | OpenCode versus direct API | Per-request timings versus tool/test/search intervals |
| 6 | Eager versus CUDA graphs | Same inputs; graph compatibility, memory and gaps |

Use --prompt-file FILE, --max-tokens N, --warmup N, --repeats N, --thinking on|off.
Record actual prompt and completion usage rather than assuming a byte count is
a token count. Warm up compilation separately from cache experiments. For a
cold prompt, warm the engine with unrelated text, then measure a fresh prompt
with --warmup 0 --repeats 1; inspect residual prefix hits. Reuse experiments
need a separately verified external-cache residency/engine-cache protocol;
the harness deliberately does not issue cache reset/clear commands.
Start with 3 repeats for a pilot, then 10+ for medians; use more samples for
credible tail latency. One factor at a time comes before larger DoE designs.

## Nsight Systems capture

Stop the existing server first. Terminal A:

```bash
./bx_ai_coding_setup.sh 150a_profile --action serve-nsys --mode baseline --output /opt/work/ai_coding/root/deliverables/ai_coding/perf/nsys --execute
```

Wait for API READY. Terminal B:

```bash
./bx_ai_coding_setup.sh 150a_profile --action benchmark --mode baseline --capture-profile --warmup 1 --repeats 1 --output /opt/work/ai_coding/root/deliverables/ai_coding/perf/nsys_client --execute
```

The client calls /start_profile and /stop_profile around measured requests.
Stop Terminal A with Ctrl-C after capture completes; wait for report flush.
Then export summary tables:

```bash
./bx_ai_coding_setup.sh 150a_profile --action analyze --output /opt/work/ai_coding/root/deliverables/ai_coding/perf/nsys --execute
```

Open capture*.nsys-rep in Nsight Systems. Confirm CUDA engine worker processes
are present, not only the API frontend. Inspect GPU gaps, launch costs,
synchronization and overlap. The wrapper profiles vLLM and its subprocesses;
LMCache is a separate process observed by system collectors and its metrics,
not a guaranteed separately traced Nsight process. Sum of kernel durations is
not union-of-busy-intervals or critical-path time. Inspect the timeline before
calling anything CPU-, memory-, or compute-bound. Report extraction fails
explicitly for missing reports or unsupported tool report names.

## Nsight Compute: selected kernels only

Identify a hot kernel regex from Systems first. Stop the Systems server.
Terminal A (replace the example regex with the observed kernel name):

```bash
./bx_ai_coding_setup.sh 150a_profile --action serve-ncu --mode baseline --kernel-regex 'YOUR_OBSERVED_KERNEL_REGEX' --output /opt/work/ai_coding/root/deliverables/ai_coding/perf/ncu --execute
```

Terminal B: benchmark with --capture-profile as above, in a new client output
directory. NCU uses target-processes all, profile-from-start off, set basic and
launch-count 5. This is an initial targeted capture; collect additional memory
and roofline sections only after checking GB10 metric support in ncu --help and
ncu --query-metrics. Stop the server and use --action analyze on the NCU directory.
NCU replay, cache control and launch serialization alter execution. Never use
these client TPS values as production throughput. Check clock/cache behavior
before comparing kernel numbers with Systems.

## Optional instrumentation, after timeline triage

No upstream files are patched by this release. Existing NVTX/CUDA activity is
collected; logical request-to-cache attribution may need additional ranges.
If needed, add low-overhead NVTX ranges at scheduler/worker, connector lookup,
store/load submission and completion, and LMCache IPC/L1 operations. Add client
request/tool timing in OpenCode. Preserve patches with 040a_preserve_sources.
Log monotonic clock type, pid/tid, request/span ID, token/chunk/byte counts,
cache outcome and begin/end phase. CPU function return is not GPU completion.
Do not add synchronization per token or dump full tensors. Measure overhead
against an uninstrumented run. No kernel surgery is justified before profiling.

## Artifacts and interpretation

manifest.json, request.json, request-N.json, warmup-N.json, summary.json,
analysis.md, *-before/after.prom, metrics-before/after.json, procfs.jsonl,
collectors.json and optional system logs are generated per run. Comparison
writes comparison.json in the second run directory. Nsight directories contain
profile_manifest.json, native reports and checked summary exports.

A rough dense BF16 check is 27B*2 bytes / token versus 273 GB/s nominal memory
bandwidth, about 5.1 tokens/s if all those bytes are read each token. This is
an assumption, not a measured bound. Embedding access, cache reuse, GDN state,
CPU competition and kernel efficiency change real traffic. A 4.3 TPS log alone
cannot establish memory saturation. Nsight counter/timeline evidence is needed.

References:
- https://docs.vllm.ai/en/v0.32.0/contributing/profiling/
- https://docs.nvidia.com/nsight-compute/ProfilingGuide/
- https://docs.nvidia.com/dgx/dgx-spark/hardware.html
