# Public command numbering (r18)

Normal steps use three digits. Auxiliary steps use the related three digits
plus one lowercase letter. Normal installation and verification run from
010 through 130 in one terminal. Run each step only after its predecessor
succeeds. Start 140 in Terminal A and keep it open until API READY. Run 150
and then 160 in Terminal B. Stop 140 before using diagnostic alternative
140a on the same ports, and stop 140a before returning to 140.

See [the complete English help](cli_help.txt) for commands, flags and examples.
The default reserve is four available logical CPUs. The current service
backend remains CPU L1; readiness does not certify cache hits or SSD I/O.

## Migration from r17 and earlier

Existing installations do not need to repeat successful builds. Public command
names changed; the source tree, source lock, model weights and venv did not.
Legacy names fail with an explicit replacement message before any work runs.
Internal Python stage names remain independent of the public numbers.

| Previous command | Current command |
| --- | --- |
| `005_check_host` | `010_check_host` |
| `007_install_python_dev` | `020a_repair_python_dev` |
| `008_install_vllm_deps` | `020b_repair_vllm_deps` |
| `010_conf_env` | `030_conf_env` |
| `015_preserve_sources` | `040a_preserve_sources` |
| `017_prepare_stable` | `040b_prepare_stable` |
| `020_download_src` | `040_download_src` |
| `025_align_transformers` | `060a_align_transformers` |
| `030_build_pytorch` | `050_build_pytorch` |
| `040_build_transformers` | `060_build_transformers` |
| `045_build_torchvision` | `070_build_torchvision` |
| `050_build_vllm` | `080_build_vllm` |
| `060_build_lmcache` | `090_build_lmcache` |
| `070_build_opencode` | `100_build_opencode` |
| `080_download_weights` | `110_download_weights` |
| `090_conf_services` | `120_conf_services` |
| `100_verify_build` | `130_verify_build` |
| `110_serve_baseline` | `140a_serve_baseline` |
| `120_serve_stack` | `140_serve_stack` |
| `130_test_api` | `150_test_api` |
| `140_run_agent` | `160_run_agent` |
| `900_validate` | `010a_validate_scripts` |

The new normal `020_prepare_system` combines the development-header preparation
previously available through two separate commands. Individual repair commands
remain available as 020a and 020b. The optional 010a controller validation
always runs tests without --execute; other commands default to a plan.

## r19 extension

`150a_profile` is an optional measurement/profiling command related to API
validation. It supports benchmark, analyze, compare, serve-nsys and serve-ncu.
Normal stage numbers remain unchanged. See performance/Profiling_Guide.md.
