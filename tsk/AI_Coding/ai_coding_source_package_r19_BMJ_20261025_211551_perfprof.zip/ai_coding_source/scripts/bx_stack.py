# BUILD_ID="BMJ_20261025_211551"
"""Source builds with explicit Ubuntu Python development package installation."""
import datetime
import hashlib
import importlib.util
import json
import os
import pathlib
import platform
import re
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

BUILD_ID = "BMJ_20261025_211551"

CLICK_RUNTIME_PROBE = '''import importlib.metadata as m
import json
from packaging.requirements import Requirement
requirements = set()
for distribution in m.distributions():
    for raw in distribution.requires or []:
        requirement = Requirement(raw)
        if requirement.name.lower().replace("_", "-") == "click":
            if requirement.marker is None or requirement.marker.evaluate({"extra": ""}):
                requirements.add(str(requirement))
print(json.dumps(sorted(requirements)))
'''

def available_build_cpus():
    """Count logical CPUs available to this process, respecting CPU affinity."""
    counts = [os.cpu_count() or 1]
    process_count = getattr(os, 'process_cpu_count', lambda: None)()
    if process_count:
        counts.append(process_count)
    try:
        counts.append(len(os.sched_getaffinity(0)))
    except (AttributeError, OSError):
        pass
    return max(1, min(counts))

TELEMETRY_CONSTRAINTS = [
    'opentelemetry-api==1.40.0',
    'opentelemetry-sdk==1.40.0',
    'opentelemetry-exporter-otlp==1.40.0',
    'opentelemetry-exporter-prometheus==0.61b0',
]

ORPHAN_OTEL_PROBE = r'''import importlib.metadata as m
import json
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name
name = 'opentelemetry-exporter-otlp-common'
try:
    dist = m.distribution(name)
except m.PackageNotFoundError:
    print(json.dumps({'remove': False, 'required_by': []}))
else:
    broken = False
    for raw in dist.requires or []:
        req = Requirement(raw)
        if canonicalize_name(req.name) == 'opentelemetry-sdk' and (req.marker is None or req.marker.evaluate({'extra': ''})):
            try:
                broken = m.version('opentelemetry-sdk') not in req.specifier
            except m.PackageNotFoundError:
                broken = True
    parents = []
    for other in m.distributions():
        for raw in other.requires or []:
            req = Requirement(raw)
            if canonicalize_name(req.name) == name:
                # Also retain optional dependencies: do not guess which extras are used.
                parents.append(other.metadata['Name'])
    print(json.dumps({'remove': broken and not parents, 'required_by': sorted(set(parents))}))
'''

class Stack:
    def __init__(self, config, execute=False):
        self.c = dict(config)
        reserve = config.get('reserve_cpu_cores', 4)
        if type(reserve) is not int or reserve < 0:
            raise ValueError('reserve_cpu_cores must be a nonnegative integer')
        self.available_cpus = available_build_cpus()
        self.max_jobs = max(1, self.available_cpus - reserve)
        self.root = pathlib.Path(config['root'])
        if not self.root.is_absolute() or self.root == pathlib.Path('/'):
            raise ValueError('root must be an absolute task directory')
        if config['model_id'] != 'Qwen/Qwen3.8-27B':
            raise ValueError('This profile uses Qwen3.8-27B hybrid geometry; create a reviewed profile for another model')
        if config['node'] != 'node3' or config['cuda_arch'] != '12.1':
            raise ValueError('This initial profile targets node3 DGX Spark / SM 12.1 only')
        if not 0 < config['gpu_memory_utilization'] < 0.8:
            raise ValueError('Keep unified-memory headroom for OS and LMCache')
        if config['max_batched_tokens'] < config['chunk_tokens']:
            raise ValueError('Batch token budget must cover one negotiated block')
        ports=[config[k] for k in ('port','cache_port','cache_http_port')]
        if len(set(ports)) != 3 or any(not 1024 <= p <= 65535 for p in ports):
            raise ValueError('Use three distinct nonprivileged ports')
        self.src = pathlib.Path(config.get('source_root',self.root/'src'))
        if not self.src.is_absolute():raise ValueError('source_root must be absolute')
        self.out = self.root/'deliverables/ai_coding'
        self.py = self.root/'venvs/stack/bin/python'
        self.bin = self.out/'bin'
        self.model = pathlib.Path(config.get('model_path',self.src/'models'/config['model_id'].split('/')[-1]))
        self.execute = execute

    def envvars(self):
        e = os.environ.copy()
        e.update(CUDA_HOME=self.c['cuda_home'], TORCH_CUDA_ARCH_LIST=self.c['cuda_arch'],
                 MAX_JOBS=str(self.max_jobs), NVCC_THREADS='1',
                 CMAKE_BUILD_PARALLEL_LEVEL=str(self.max_jobs),
                 VLLM_USE_PRECOMPILED='0', CMAKE_PREFIX_PATH=str(self.py.parents[1]),
                 HF_HOME=str(self.out/'cache/huggingface'),
                 TMPDIR=str(self.out/'tmp'), CCACHE_DIR=str(self.out/'cache/ccache'),
                 LMCACHE_CUDA_MAJOR='13', PIP_DISABLE_PIP_VERSION_CHECK='1',
                 PIP_CACHE_DIR=str(self.out/'cache/pip'), BUN_INSTALL_CACHE_DIR=str(self.out/'cache/bun'),
                 TORCH_EXTENSIONS_DIR=str(self.out/'cache/torch_extensions'),
                 TRITON_CACHE_DIR=str(self.out/'cache/triton'), XDG_CACHE_HOME=str(self.out/'cache/xdg'))
        e['PATH']=str(self.py.parent)+':'+str(pathlib.Path(e['CUDA_HOME'])/'bin')+':'+e.get('PATH','')
        if 'pytorch' in self.c.get('package_versions',{}):
            e['PYTORCH_BUILD_VERSION']=self.c['package_versions']['pytorch']
            e['PYTORCH_BUILD_NUMBER']='1'
        return e

    def run(self, cmd, cwd=None, capture=False, extra=None, merge_stderr=False):
        cmd = list(map(str, cmd))
        print(shlex.join(cmd), flush=True)
        if not self.execute: return ''
        e=self.envvars()
        if extra:e.update(extra)
        # Every executable stage can run before init, including captured probes.
        tmp=pathlib.Path(e['TMPDIR'])
        try:
            tmp.mkdir(parents=True,exist_ok=True)
            with tempfile.TemporaryFile(dir=tmp):
                pass
        except OSError as exc:
            raise RuntimeError('Cannot prepare writable TMPDIR '+str(tmp)+': '+str(exc)) from exc
        if capture:
            return subprocess.run(cmd,cwd=cwd,env=e,check=True,text=True,
                                  stdout=subprocess.PIPE,stderr=subprocess.STDOUT if merge_stderr else None).stdout.strip()
        self.out.mkdir(parents=True,exist_ok=True)
        log=self.out/'build_commands.log'
        with log.open('a') as f:
            f.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+' '+shlex.join(cmd)+'\n')
            f.flush()
            with subprocess.Popen(cmd,cwd=cwd,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True) as proc:
                for line in proc.stdout:
                    print(line,end='',flush=True);f.write(line);f.flush()
                if proc.wait():raise RuntimeError('Command failed; inspect '+str(log))
        return ''

    def write(self, path, data):
        if not self.execute:
            print('WRITE '+str(path));return
        path.parent.mkdir(parents=True,exist_ok=True)
        text=data if isinstance(data,str) else json.dumps(data,indent=2)+'\n'
        path.write_text(text)

    def init(self, args):
        for p in (self.src,self.py.parents[1],self.bin,self.out/'tmp',self.out/'cache',self.out/'reports'):
            print('MKDIR '+str(p))
            if self.execute:p.mkdir(parents=True,exist_ok=True)
        self.write(self.out/'requested_config.json',self.c)

    def profile(self, args):
        spec=importlib.util.spec_from_file_location('bx_perf',pathlib.Path(__file__).with_name('bx_perf.py'))
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        module.dispatch(self,args)

    def preflight(self, args):
        commands=[['uname','-a'],['nvidia-smi'],[str(pathlib.Path(self.c['cuda_home'])/'bin/nvcc'),'--version'],
                  ['cmake','--version'],['ninja','--version'],['bun','--version'],['git','lfs','version'],
                  [self.c['python'],'--version']]
        if self.execute and platform.machine()!='aarch64':
            raise RuntimeError('node3 requires an aarch64 host; do not run a Spark build on x86_64')
        observations={}
        for cmd in commands:observations[' '.join(cmd)]=self.run(cmd,capture=True)
        if self.execute:
            if 'GB10' not in observations['nvidia-smi']:raise RuntimeError('Expected NVIDIA GB10')
            probe=self.run([str(pathlib.Path(self.c['cuda_home'])/'bin/nvcc'),'--list-gpu-code'],capture=True)
            if 'sm_121' not in probe:raise RuntimeError('Installed nvcc cannot target sm_121')
        self.write(self.out/'reports/preflight.json',observations)
        print('Also verify cuDNN development headers/libraries and free disk/RAM before building.')

    def git_identity(self, repo, expected=None):
        if not self.execute:return
        head=self.run(['git','rev-parse','HEAD'],cwd=repo,capture=True)
        if expected and head!=expected:raise RuntimeError('Checkout differs from sources.lock.json: '+str(repo))
        return head

    def fetch(self, args):
        lockfile=self.out/'sources.lock.json'
        lock=json.loads(lockfile.read_text()) if lockfile.exists() else {}
        entries={**self.c['repos'],'model':{'url':'https://huggingface.co/'+self.c['model_id'],'ref':self.c['model_ref']}}
        for name,entry in entries.items():
            dest=self.model if name=='model' else self.src/name
            saved=lock.get(name)
            if saved and (saved['url']!=entry['url'] or saved['requested_ref']!=entry['ref']):
                raise RuntimeError('Requested source differs from existing lock; use a new root/config')
            if not dest.exists():
                clone=['git','clone','--tags']
                # Retain full ordinary Git objects and tags for profiling and git describe.
                # LFS weights remain deferred until the explicit weights stage.
                self.run([*clone,'--no-checkout',entry['url'],dest],extra={'GIT_LFS_SKIP_SMUDGE':'1'})
            elif self.execute:
                origin=self.run(['git','remote','get-url','origin'],cwd=dest,capture=True)
                if origin.rstrip('/')!=entry['url'].rstrip('/'):raise RuntimeError('Unexpected Git origin: '+str(dest))
                if not saved:raise RuntimeError('Refuse to take over an existing unlocked checkout: '+str(dest))
            if saved:
                self.git_identity(dest,saved['commit']);continue
            self.run(['git','fetch','--tags','--no-prune','--no-prune-tags','--no-auto-maintenance','--no-recurse-submodules','origin',entry['ref']],cwd=dest)
            self.run(['git','checkout','--detach','FETCH_HEAD'],cwd=dest,extra={'GIT_LFS_SKIP_SMUDGE':'1'})
            if name=='pytorch':self.run(['git','submodule','update','--init','--recursive','--jobs',str(self.max_jobs)],cwd=dest)
            if self.execute:
                lock[name]={'url':entry['url'],'requested_ref':entry['ref'],'commit':self.git_identity(dest)}
                self.write(lockfile,lock)
                self.source_snapshot(name,'download')

    def source_manager(self):
        spec=importlib.util.spec_from_file_location('bx_sources',pathlib.Path(__file__).with_name('bx_sources.py'))
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        return module.Sources(self)

    def preserve_sources(self, args):self.source_manager().preserve(args)

    def prepare_stable(self, args):self.source_manager().stable(args)

    def source_snapshot(self, name, phase):
        repo=self.model if name=='model' else self.src/name
        if self.execute and (repo/'.git').exists():
            manager=self.source_manager()
            module_time=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            manager.snapshot(name,repo,self.out/'source_snapshots'/('build-'+module_time)/name/phase)

    def locked(self):
        if not self.execute:return
        if platform.machine()!='aarch64':raise RuntimeError('Production Spark build/serve requires an aarch64 host')
        lock=json.loads((self.out/'sources.lock.json').read_text())
        for name in self.c['repos']:
            if lock[name]['url']!=self.c['repos'][name]['url'] or lock[name]['requested_ref']!=self.c['repos'][name]['ref']:
                raise RuntimeError('Config differs from the source lock for '+name+'; preserve the original config or use an isolated profile')
            self.git_identity(self.src/name,lock[name]['commit'])

    def align_transformers(self, args):
        if not re.fullmatch(r'v[0-9]+\.[0-9]+\.[0-9]+',args.ref):
            raise ValueError('Use an explicit Transformers release tag such as v5.20.2')
        if not self.execute:
            print('ALIGN Transformers to '+args.ref+' after checking the locked vLLM requirement; back up and update config and source lock')
            return
        self.locked()
        repo=self.src/'transformers'
        if self.run(['git','status','--porcelain','--untracked-files=no'],cwd=repo,capture=True):
            raise RuntimeError('Refuse to change a Transformers checkout with tracked local modifications')
        lockfile=self.out/'sources.lock.json'
        oldlock=json.loads(lockfile.read_text());oldconfig=json.loads(args.config.read_text())
        if oldconfig!=self.c:raise RuntimeError('Config changed during execution; retry')
        self.run(['git','fetch','--tags','--no-prune','--no-prune-tags','--no-auto-maintenance','origin','refs/tags/'+args.ref],cwd=repo)
        commit=self.run(['git','rev-parse','FETCH_HEAD^{commit}'],cwd=repo,capture=True)
        setup=self.run(['git','show',commit+':setup.py'],cwd=repo,capture=True)
        version=re.search(r'\bversion\s*=\s*[\"\']([0-9][^\"\']*)[\"\']',setup)
        if not version or version.group(1)!=args.ref[1:]:
            raise RuntimeError('Cannot confirm the requested release version in Transformers setup.py')
        requirements=[]
        for line in (self.src/'vllm/requirements/common.txt').read_text().splitlines():
            line=line.split('#',1)[0].strip()
            if re.match(r'^transformers\s*(?:[<>=!~;\[]|$)',line):requirements.append(line)
        if len(requirements)!=1:raise RuntimeError('Expected one Transformers requirement in vLLM requirements/common.txt')
        self.run([self.py,'-c',
            'from packaging.requirements import Requirement; import sys; '
            'r=Requirement(sys.argv[1]); assert r.specifier.contains(sys.argv[2]), "Release does not satisfy "+str(r); '
            'print("Validated "+sys.argv[2]+" against "+str(r))',requirements[0],version.group(1)])
        backup=self.out/'state'/('transformers-ref-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')
        self.write(backup,{'config':oldconfig,'sources_lock':oldlock})
        newconfig=json.loads(json.dumps(oldconfig));newconfig['repos']['transformers']['ref']=args.ref
        newlock=json.loads(json.dumps(oldlock));newlock['transformers'].update(requested_ref=args.ref,commit=commit)
        try:
            self.run(['git','checkout','--detach',commit],cwd=repo)
            self.write(args.config,newconfig);self.write(lockfile,newlock)
        except Exception:
            self.run(['git','checkout','--detach',oldlock['transformers']['commit']],cwd=repo)
            self.write(args.config,oldconfig);self.write(lockfile,oldlock)
            raise
        self.c=newconfig
        print('Source ref aligned. Run 060_build_transformers, then 080_build_vllm. Backup: '+str(backup))

    def env(self, args):
        if not self.py.exists():self.run([self.c['python'],'-m','venv',self.py.parents[1]])
        self.run([self.py,'-m','pip','install','--upgrade','pip','setuptools','wheel','packaging','ninja','cmake','build','setuptools-scm'])
        self.write(self.out/'environment_scope.json',{'core':'local source','toolchain_and_third_party_dependencies':'may use binaries','all_transitive_source_build':False})

    def pip(self, *args, cwd=None, extra=None):
        if args and args[0]=='install':
            path=self.out/'config/dependency-constraints.txt'
            self.write(path,'\n'.join(self.c.get('dependency_constraints',[])+TELEMETRY_CONSTRAINTS)+'\n')
            args=(args[0],'-c',path,*args[1:])
        return self.run([self.py,'-m','pip',*args],cwd=cwd,extra=extra)

    def constraints(self):
        path=self.out/'core-constraints.txt'
        if self.execute:
            versions=self.run([self.py,'-c',"import importlib.metadata as m; print('torch=='+m.version('torch'))"],capture=True)
            self.write(path,versions+'\n')
        return path

    def missing_python_headers(self):
        interpreter=self.py if self.py.exists() else self.c['python']
        result=self.run([interpreter,'-c',
            'import json,pathlib,sysconfig; p=pathlib.Path(sysconfig.get_path("include")); '
            'print(json.dumps([str(p/n) for n in ("Python.h","patchlevel.h") if not (p/n).is_file()]))'],capture=True)
        return json.loads(result) if self.execute else []

    def apt_dev_packages(self, packages):
        if self.execute:
            if platform.machine()!='aarch64':
                raise RuntimeError('Development package installation requires the configured aarch64 host')
            distro=platform.freedesktop_os_release()
            if distro.get('ID')!='ubuntu' or distro.get('VERSION_ID')!='24.04' or self.c['python']!='python3.12':
                raise RuntimeError('Automatic apt installation supports Ubuntu 24.04 / python3.12 only')
        prefix=[] if self.execute and os.geteuid()==0 else ['sudo']
        if self.execute and prefix:
            # Keep the authentication prompt attached to the user's terminal.
            subprocess.run(['sudo','-v'],check=True)
        self.run([*prefix,'apt-get','update'])
        self.run([*prefix,'apt-get','install','-y','--reinstall',*packages])

    def prepare_system(self, args):
        self.apt_dev_packages(['python3.12-dev','libpython3.12-dev','libdw-dev','libelf-dev'])
        if self.execute:
            missing=self.missing_python_headers()+self.missing_elf_headers()
            if missing:raise RuntimeError('Development headers still missing: '+', '.join(missing))

    def install_python_dev(self, args):
        self.apt_dev_packages(['python3.12-dev','libpython3.12-dev'])
        if self.execute:
            missing=self.missing_python_headers()
            if missing:raise RuntimeError('Python development headers still missing after apt installation: '+', '.join(missing))

    def missing_elf_headers(self):
        return [p for p in ('/usr/include/elfutils/libdwfl.h','/usr/include/libelf.h','/usr/include/gelf.h')
                if not pathlib.Path(p).is_file()]

    def install_vllm_deps(self, args):
        self.apt_dev_packages(['libdw-dev','libelf-dev'])
        if self.execute:
            missing=self.missing_elf_headers()
            if missing:raise RuntimeError('ELF/DWARF development headers still missing: '+', '.join(missing))

    def ensure_vllm_headers(self):
        if not self.execute:
            print('CHECK ELF/DWARF headers; install libdw-dev and libelf-dev if missing')
        elif self.missing_elf_headers():
            self.install_vllm_deps(None)

    def ensure_python_headers(self):
        if not self.execute:
            print('CHECK Python development headers; install Ubuntu python3.12-dev if missing (sudo may be required)')
        elif self.missing_python_headers():
            self.install_python_dev(None)

    def check_torch_import(self):
        self.run([self.py,'-I','-c',
            'import json,torch,torch._C,torch.version; '
            'assert torch.version.cuda is not None, "Expected a CUDA-enabled source PyTorch build"; '
            'assert torch.ones(2).sum().item()==2; '
            'print(json.dumps({"torch_file":torch.__file__,"torch_version":torch.__version__,"cuda":torch.version.cuda,"extension":torch._C.__file__}))'])

    def repair_runtime_click(self):
        if not self.execute:
            print('RESOLVE Click against installed runtime requirements after removing spin')
            return
        requirements=json.loads(self.run([self.py,'-c',CLICK_RUNTIME_PROBE],capture=True))
        if requirements:
            self.pip('install',*requirements)

    def build_triton_source(self):
        pinfile=self.src/'pytorch/.ci/docker/ci_commit_pins/triton.txt'
        if not self.execute:
            print('BUILD matching Triton from source; pin read from '+str(pinfile))
            return
        pin=pinfile.read_text().strip()
        if not re.fullmatch(r'[0-9a-f]{40}',pin):raise RuntimeError('Expected a full Triton commit pin in PyTorch')
        repo=self.src/'triton';url='https://github.com/triton-lang/triton.git'
        if not repo.exists():self.run(['git','clone','--tags',url,repo])
        manager=self.source_manager();manager.assert_repo(repo,url)
        state=self.out/'triton.source.lock.json'
        if state.exists():
            if json.loads(state.read_text())['commit']!=pin:
                raise RuntimeError('Triton source pin changed; use a separate profile')
            self.git_identity(repo,pin)
        else:
            if self.run(['git','status','--porcelain','--untracked-files=no'],cwd=repo,capture=True):
                raise RuntimeError('Preserve Triton local modifications before initial checkout')
            self.run(['git','fetch','--tags','--no-prune','--no-prune-tags','--no-auto-maintenance','origin',pin],cwd=repo)
            self.run(['git','checkout','--detach',pin],cwd=repo)
            self.write(state,{'url':url,'commit':pin,'derived_from':str(pinfile)})
        self.source_snapshot('triton','before')
        import tomllib
        requirements=tomllib.loads((repo/'pyproject.toml').read_text()).get('build-system',{}).get('requires',[])
        if requirements:self.pip('install','-c',self.constraints(),*requirements)
        self.pip('install','-v','--no-build-isolation','--no-deps','-e',repo)
        self.source_snapshot('triton','after')

    def repair_orphan_telemetry(self):
        if not self.execute:
            print('CHECK obsolete orphan OpenTelemetry exporter before pip check')
            return
        result=json.loads(self.run([self.py,'-c',ORPHAN_OTEL_PROBE],capture=True))
        if result['remove']:
            self.pip('uninstall','-y','opentelemetry-exporter-otlp-common')

    def opencode_build_env(self):
        # Use an isolated modern node-gyp with bundled gyp, not the distro wrapper.
        tools=self.out/'tools/node-gyp'
        self.run(['npm','install','--prefix',tools,'--ignore-scripts','--no-audit',
                  '--no-fund','node-gyp@10.3.1'])
        executable=tools/'node_modules/.bin/node-gyp'
        extra={'PATH':str(executable.parent)+':'+self.envvars()['PATH'],
               'npm_config_node_gyp':str(tools/'node_modules/node-gyp/bin/node-gyp.js'),
               'BX_NODE_GYP_MAIN':str(tools/'node_modules/node-gyp/bin/node-gyp.js'),
               'NODE_OPTIONS':(self.envvars().get('NODE_OPTIONS','')+' --require='+
                               json.dumps(str(pathlib.Path(__file__).with_name('bx_node_gyp_redirect.cjs')))).strip(),
               'JOBS':str(self.max_jobs),
               'PYTHON':str(self.py),'npm_config_python':str(self.py),
               'npm_config_jobs':str(self.max_jobs)}
        self.run([executable,'--version'],extra=extra)
        self.probe_opencode_lifecycle(extra)
        return extra

    def probe_opencode_lifecycle(self, extra):
        # Check inside a dependency lifecycle, not merely the parent shell PATH.
        if not self.execute:
            print('VERIFY managed node-gyp inside a Bun dependency lifecycle')
            return
        with tempfile.TemporaryDirectory(prefix='bx-gyp-probe-',dir=self.out/'tmp') as directory:
            root=pathlib.Path(directory)
            package=root/'dependency';package.mkdir()
            marker=root/'selected.json'
            code=('const cp=require("node:child_process"),fs=require("node:fs");'
                  'const v=cp.execFileSync("node-gyp",["--version"],{encoding:"utf8"}).trim();'
                  'if(v!=="v10.3.1")throw new Error("Unexpected lifecycle node-gyp: "+v);'
                  'fs.writeFileSync('+json.dumps(str(marker))+',JSON.stringify({version:v}));')
            (package/'probe.cjs').write_text('// BUILD_ID="'+BUILD_ID+'"\n'+code+'\n')
            (package/'package.json').write_text(json.dumps({'name':'bx-node-gyp-probe',
                'version':'1.0.0','scripts':{'install':'node probe.cjs'}}))
            (root/'package.json').write_text(json.dumps({'name':'bx-lifecycle-check','private':True,
                'dependencies':{'bx-node-gyp-probe':'file:./dependency'},
                'trustedDependencies':['bx-node-gyp-probe']}))
            self.run(['bun','install'],cwd=root,extra=extra)
            if not marker.exists() or json.loads(marker.read_text())['version']!='v10.3.1':
                raise RuntimeError('Bun dependency lifecycle did not select managed node-gyp')
            self.write(self.out/'reports/opencode_node_gyp_probe.json',
                       {'status':'PASS','version':'v10.3.1','scope':'Bun dependency install lifecycle'})


    def check_model_imports(self, include_model=True):
        code="""import pathlib,json,sys,torch,torchvision,importlib
from torchvision.transforms.v2 import functional
root=pathlib.Path(sys.argv[1]).resolve()
assert pathlib.Path(torchvision.__file__).resolve().is_relative_to(root), 'TorchVision must come from its retained source tree'
assert torchvision.extension._has_ops(), 'TorchVision native extension failed to load'
if sys.argv[2]=='1':importlib.import_module('vllm.model_executor.models.qwen3_5')
print(json.dumps({'status':'QWEN_MODEL_IMPORT_PASS' if sys.argv[2]=='1' else 'TORCHVISION_IMPORT_PASS','torch':torch.__version__,'torchvision':torchvision.__version__,'vision_source':torchvision.__file__}))
"""
        self.run([self.py,'-I','-c',code,self.src/'torchvision','1' if include_model else '0'])

    def build_torchvision(self, args):
        self.locked()
        self.check_torch_import()
        version=self.run([self.py,'-c','import torch; print(torch.__version__.split("+")[0])'],capture=True)
        if self.execute and version!='2.13.0':
            raise RuntimeError('This TorchVision v0.28.0 source profile requires torch 2.13.0; actual '+version+'; preserve the installed source torch and review a matching vision tag')
        repo=self.src/'torchvision'
        url='https://github.com/pytorch/vision.git'
        tag='v0.28.0';pin='8fb87713a24951e639c494b0f2a8a81b5f8e33a6'
        state=self.out/'torchvision.source.lock.json'
        exists=repo.exists()
        if not exists:
            self.run(['git','clone','--tags','--no-checkout',url,repo])
        elif self.execute and not state.exists():
            raise RuntimeError('Refuse to adopt an unlocked TorchVision directory; preserve it before using this stage: '+str(repo))
        if self.execute:self.source_manager().assert_repo(repo,url)
        if state.exists():
            lock=json.loads(state.read_text())
            if lock.get('commit')!=pin or lock.get('url')!=url or lock.get('requested_ref')!=tag:
                raise RuntimeError('TorchVision source lock differs; use a separate profile')
            self.git_identity(repo,pin)
        else:
            self.run(['git','fetch','--tags','--no-prune','--no-prune-tags','--no-auto-maintenance','origin','refs/tags/'+tag],cwd=repo)
            actual=self.run(['git','rev-parse','FETCH_HEAD^{commit}'],cwd=repo,capture=True)
            if self.execute and actual!=pin:raise RuntimeError('TorchVision release tag changed; refuse unreviewed source')
            self.run(['git','checkout','--detach',pin],cwd=repo)
            self.write(state,{'url':url,'requested_ref':tag,'commit':pin,'torch':'2.13.0'})
        self.source_snapshot('torchvision','before')
        constraint=self.constraints()
        self.pip('install','-c',constraint,'setuptools','wheel','numpy','pillow')
        self.pip('install','-v','-c',constraint,'--no-build-isolation','--no-deps','-e',repo,
                 extra={'BUILD_VERSION':'0.28.0','PYTORCH_VERSION':version or '2.13.0','FORCE_CUDA':'1'})
        self.check_model_imports(include_model=False)
        self.source_snapshot('torchvision','after')
        self.run([self.py,'-m','pip','check'])

    def opencode_layout(self):
        configured=self.c.get('opencode_layout','auto')
        if configured in ('v1','v2'):return configured
        repo=self.src/'opencode'
        # A stable checkout can contain both the interactive V1 and preview V2 CLI.
        if (repo/'packages/opencode/script/build.ts').exists():return 'v1'
        if (repo/'packages/cli/script/build.ts').exists():return 'v2'
        return 'v1' if self.c['repos']['opencode']['ref'].startswith('v1.') else 'v2'

    def opencode_host_artifact(self, repo):
        layout=self.opencode_layout()
        package='packages/cli' if layout=='v2' else 'packages/opencode'
        script=repo/package/'script/build.ts'
        text=script.read_text()
        binary='opencode'
        if layout=='v2':
            match=re.search(r"const\s+binary\s*=\s*['\"]([A-Za-z0-9_-]+)['\"]",text)
            if not match or './dist/${name}/bin/${binary}' not in text:
                raise RuntimeError('Unsupported OpenCode V2 artifact layout; inspect '+str(script))
            binary=match.group(1)
        arch={'aarch64':'arm64','arm64':'arm64','x86_64':'x64','AMD64':'x64'}.get(platform.machine())
        if platform.system()!='Linux' or arch is None:
            raise RuntimeError('Unsupported OpenCode build host architecture')
        name=('cli' if layout=='v2' else 'opencode')+'-linux-'+arch
        return repo/package/'dist'/name/'bin'/binary

    def link_opencode_artifact(self, repo):
        artifact=self.opencode_host_artifact(repo)
        if not artifact.is_file():
            root=artifact.parents[2]
            observed=sorted(str(p.relative_to(root)) for p in root.glob('*/bin/*') if p.is_file())
            raise RuntimeError('Expected OpenCode host artifact '+str(artifact)+
                               '; observed bin files: '+json.dumps(observed))
        with artifact.open('rb') as stream:
            header=stream.read(20)
        expected=183 if platform.machine() in ('aarch64','arm64') else 62
        if (len(header)<20 or header[:6]!=b'\x7fELF\x02\x01' or
                int.from_bytes(header[18:20],'little')!=expected or not os.access(artifact,os.X_OK)):
            raise RuntimeError('Expected executable ELF64 for the host architecture: '+str(artifact))
        self.bin.mkdir(parents=True,exist_ok=True)
        target=self.bin/'opencode'
        if target.is_symlink() and target.resolve()==artifact.resolve():
            return
        if target.is_symlink() and self.opencode_layout()=='v1':
            arch={'aarch64':'arm64','arm64':'arm64','x86_64':'x64','AMD64':'x64'}[platform.machine()]
            legacy=repo/'packages/cli/dist'/('cli-linux-'+arch)/'bin/lildax'
            if target.resolve()==legacy.resolve():
                backup=self.bin/'opencode-v2-preview'
                if backup.exists() or backup.is_symlink():
                    if not backup.is_symlink() or backup.resolve()!=legacy.resolve():
                        raise RuntimeError('Refuse to replace existing preview backup '+str(backup))
                else:backup.symlink_to(target.readlink())
                with tempfile.TemporaryDirectory(prefix='bx-agent-link-',dir=self.bin) as directory:
                    new=pathlib.Path(directory)/'opencode';new.symlink_to(artifact)
                    os.replace(new,target)
                return
        if target.exists() or target.is_symlink():
            raise RuntimeError('Refuse to replace existing '+str(target))
        target.symlink_to(artifact)

    def check_agent_cli(self):
        if self.opencode_layout()!='v1':
            raise RuntimeError('Interactive agent requires OpenCode V1; set opencode_layout to v1 and rerun 100_build_opencode and 120_conf_services')
        help_text=self.run([self.bin/'opencode','--help'],capture=True,merge_stderr=True)
        if self.execute and ('--model' not in help_text or '[project]' not in help_text):
            raise RuntimeError('Installed CLI lacks interactive project/--model support; rerun 100_build_opencode and 120_conf_services')
        if self.execute:
            self.write(self.out/'reports/opencode_agent_cli.json',
                       {'status':'INTERACTIVE_CLI_CONTRACT_PASS','layout':'v1','project_argument':True,'model_flag':True})

    def build(self, args):
        print('Build parallelism: available logical CPUs='+str(self.available_cpus)+
              ', reserved='+str(self.c.get('reserve_cpu_cores',4))+
              ', jobs='+str(self.max_jobs), flush=True)
        self.locked()
        names=['pytorch','transformers','vllm','lmcache','opencode'] if args.component=='all' else [args.component]
        for name in names:
            repo=self.src/name
            self.source_snapshot(name,'before')
            if name=='pytorch':
                self.ensure_python_headers()
                self.run([self.py,'-c',
                    'import pathlib,sysconfig; p=pathlib.Path(sysconfig.get_path("include")); '
                    'missing=[str(p/n) for n in ("Python.h","patchlevel.h") if not (p/n).is_file()]; '
                    'assert not missing, "Missing Python development headers: "+", ".join(missing)+"; install python3.12-dev on Ubuntu 24.04"; '
                    'print("Python development headers: "+str(p))'])
                # This builds PyTorch itself, not a published torch wheel.
                self.pip('install','--group',str(repo/'pyproject.toml')+':dev')
                self.pip('install','numpy')
                self.run([self.py,'-c',
                    'import pathlib,numpy; p=pathlib.Path(numpy.get_include()); '
                    'assert (p/"numpy/arrayobject.h").is_file(), "Missing NumPy C headers"; '
                    'print("NumPy headers: "+str(p))'])
                self.pip('install','-v','--no-build-isolation','--no-deps',
                         '-Ccmake.define.BUILD_PYTHON=ON',
                         '-Ccmake.define.Python_EXECUTABLE='+str(self.py),'-e',repo)
                self.check_torch_import()
                self.build_triton_source()
                # spin is a development CLI, not used by this pip/make build flow.
                self.pip('uninstall','-y','spin')
                self.repair_runtime_click()
            elif name=='opencode':
                if self.execute:
                    pkg=json.loads((repo/'package.json').read_text())
                    expected=pkg['packageManager'].removeprefix('bun@')
                    actual=self.run(['bun','--version'],capture=True)
                    if actual!=expected:raise RuntimeError('Install Bun '+expected+' for this locked checkout; actual '+actual)
                    package='packages/cli' if self.opencode_layout()=='v2' else 'packages/opencode'
                    if not (repo/package/'script/build.ts').exists():raise RuntimeError('Unsupported OpenCode source layout')
                build_env=self.opencode_build_env()
                self.run(['bun','install','--frozen-lockfile'],cwd=repo,extra=build_env)
                package='packages/cli' if self.opencode_layout()=='v2' else 'packages/opencode'
                if self.opencode_layout()=='v1':
                    ref=self.c['repos']['opencode']['ref']
                    if re.fullmatch(r'v\d+\.\d+\.\d+',ref):
                        build_env.update(OPENCODE_VERSION=ref[1:],OPENCODE_CHANNEL='latest')
                cmd=['bun','run','--cwd',package,'script/build.ts','--single','--skip-install']
                cmd+=['--sourcemaps']
                if self.opencode_layout()=='v1':cmd+=['--skip-embed-web-ui']
                self.run(cmd,cwd=repo,extra=build_env)
                if self.execute:
                    self.link_opencode_artifact(repo)
                self.run([self.bin/'opencode','--version'])
                if self.opencode_layout()=='v1':self.check_agent_cli()
            else:
                self.check_torch_import()
                constraint=self.constraints()
                # The PyTorch dev group brings spin's older Click requirement into
                # the shared environment. Remove that CLI before runtime resolution.
                self.pip('uninstall','-y','spin')
                if name=='vllm':
                    self.ensure_vllm_headers()
                    helper=repo/'tools/use_existing_torch.py'
                    if self.execute and not helper.exists():raise RuntimeError('vLLM source layout changed; review existing-torch helper')
                    self.run([self.py,helper],cwd=repo)
                    self.pip('install','-c',constraint,'-r',repo/'requirements/build/cuda.txt')
                if name=='lmcache':self.pip('install','-c',constraint,'-r',repo/'requirements/build.txt')
                # Dependency resolution cannot replace the source-built core packages.
                if self.execute:
                    versions=self.run([self.py,'-c',"import importlib.metadata as m; print('\\n'.join(n+'=='+m.version(n) for n in ('torch','transformers','vllm') if n != '"+name+"' and m.packages_distributions().get(n)))"],capture=True)
                    self.write(constraint,versions+'\n')
                self.pip('install','-v','-c',constraint,'--no-build-isolation','-e',repo)
            self.source_snapshot(name,'after')
        self.repair_orphan_telemetry()
        self.run([self.py,'-m','pip','check'])
        frozen=self.run([self.py,'-m','pip','freeze'],capture=True)
        self.write(self.out/'reports/pip-freeze.txt',frozen+'\n')
        self.write(self.out/'reports/build_status.json',{'status':'COMMANDS_COMPLETED_NOT_INTEGRATION_VERIFIED','components':names})

    def weights(self, args):
        if self.execute:
            lock=json.loads((self.out/'sources.lock.json').read_text())
            self.git_identity(self.model,lock['model']['commit'])
        self.run(['git','lfs','pull'],cwd=self.model)
        self.run(['git','lfs','fsck'],cwd=self.model)
        if self.execute:
            index=json.loads((self.model/'model.safetensors.index.json').read_text())
            for shard in set(index['weight_map'].values()):
                p=(self.model/shard).resolve()
                if not p.is_relative_to(self.model.resolve()):raise RuntimeError('Invalid shard path')
                with p.open('rb') as f:
                    if f.read(64).startswith(b'version https://git-lfs'):raise RuntimeError('Unmaterialized LFS pointer: '+str(p))
            self.write(self.out/'reports/weights.json',{'status':'LFS_FSCK_AND_SHARD_PRESENCE_PASS','model':str(self.model)})

    def configure(self, args):
        cfg={'$schema':'https://opencode.ai/config.json','model':'local/'+self.c['served_model'],
             'providers':{'local':{'name':'Local vLLM','package':'@opencode/ai/providers/openai-compatible',
                'settings':{'baseURL':'http://127.0.0.1:'+str(self.c['port'])+'/v1'},
                'models':{self.c['served_model']:{'name':self.c['model_id'],'modelID':self.c['served_model'],
                    'capabilities':{'tools':True,'input':['text'],'output':['text']},
                    'limit':{'context':self.c['max_model_len'],'output':8192}}}}}}
        if self.opencode_layout()=='v1':
            cfg={'$schema':'https://opencode.ai/config.json','model':'local/'+self.c['served_model'],
                 'provider':{'local':{'name':'Local vLLM','npm':'@ai-sdk/openai-compatible',
                    'options':{'baseURL':'http://127.0.0.1:'+str(self.c['port'])+'/v1'},
                    'models':{self.c['served_model']:{'name':self.c['model_id'],'tool_call':True,
                        'limit':{'context':self.c['max_model_len'],'output':8192}}}}}}
        self.write(self.out/'config/opencode.json',cfg)
        self.write(self.out/'reports/launch_plan.json',{'lmcache':self.cache_command(),'vllm':self.server_command(False),
            'status':'UNVALIDATED_ON_TARGET','cache_backend':'CPU_L1_ONLY','ssd_io_verified':False})

    def cache_command(self):
        return [str(self.py.parent/'lmcache'),'server','--host','127.0.0.1','--port',str(self.c['cache_port']),
                '--http-port',str(self.c['cache_http_port']),'--l1-size-gb',str(self.c['l1_gb']),
                '--chunk-size',str(self.c['chunk_tokens']),'--separate-object-groups','--eviction-policy','LRU']

    def server_command(self, baseline):
        c=self.c
        cmd=[str(self.py.parent/'vllm'),'serve',str(self.model),'--host','127.0.0.1','--port',str(c['port']),
             '--served-model-name',c['served_model'],'--tensor-parallel-size','1','--dtype','bfloat16',
             '--max-model-len',str(c['max_model_len']),'--max-num-seqs','1','--gpu-memory-utilization',str(c['gpu_memory_utilization']),
             '--enable-prefix-caching','--mamba-cache-mode','align','--max-num-batched-tokens',str(c['max_batched_tokens']),
             '--enable-auto-tool-choice','--tool-call-parser','qwen3_xml','--reasoning-parser','qwen3','--enforce-eager']
        if not baseline:
            cmd+=['--kv-transfer-config',json.dumps({'kv_connector':'LMCacheMPConnector','kv_connector_module_path':
                 'lmcache.integration.vllm.lmcache_mp_connector','kv_role':'kv_both','kv_connector_extra_config':{
                 'lmcache.mp.host':'127.0.0.1','lmcache.mp.port':c['cache_port']}})]
        return cmd

    def verify(self, args):
        code="""import torch, vllm, lmcache, transformers, importlib, json
from pathlib import Path
root=Path(__import__('sys').argv[1]).resolve()
for m in (torch,vllm,lmcache,transformers):
 assert Path(m.__file__).resolve().is_relative_to(root), (m.__name__,m.__file__)
assert torch.cuda.is_available()
assert torch.cuda.get_device_capability()==(12,1)
x=torch.arange(16,device='cuda'); assert int(x.sum())==120
torch.cuda.synchronize()
import lmcache.cuda_ops
importlib.import_module('lmcache.integration.vllm.lmcache_mp_connector')
print(json.dumps({'status':'IMPORT_SOURCE_ORIGIN_AND_CUDA_SMOKE_PASS','gpu':torch.cuda.get_device_name(),'torch_cuda':torch.version.cuda}))
"""
        self.run([self.py,'-c',code,self.src])
        self.check_model_imports()
        self.run([self.py,'-m','pip','check'])
        self.run([self.py.parent/'vllm','serve','--help'])
        self.run([self.py.parent/'lmcache','server','--help'])
        self.run([self.bin/'opencode','--version'])
        self.check_agent_cli()

    def serve(self, args):
        cmds=[] if args.baseline else [self.cache_command()]
        server=self.server_command(args.baseline)
        if getattr(args,'profiler_prefix',None):
            server=list(args.profiler_prefix)+server+['--profiler-config','{"profiler":"cuda"}']
        cmds.append(server)
        if not self.execute:
            for cmd in cmds:self.run(cmd)
            return
        self.locked()
        self.check_model_imports()
        ports=[self.c['port']] if args.baseline else [self.c[k] for k in ('port','cache_port','cache_http_port')]
        for p in ports:
            with socket.socket() as s:s.bind(('127.0.0.1',p))
        procs=[];files=[]
        self.out.mkdir(parents=True,exist_ok=True)
        try:
            for i,cmd in enumerate(cmds):
                f=(self.out/('vllm.log' if i==len(cmds)-1 else 'lmcache.log')).open('a')
                files.append(f)
                p=subprocess.Popen(cmd,env=self.envvars(),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
                procs.append(p)
                if i<len(cmds)-1:self.wait_url('http://127.0.0.1:'+str(self.c['cache_http_port'])+'/healthcheck',procs,180)
            self.wait_url(self.url('/models'),procs,1800)
            print('API READY; backend I/O and agent quality are not verified. Ctrl-C stops owned services.',flush=True)
            while True:
                if any(p.poll() is not None for p in procs):raise RuntimeError('A managed server exited; inspect logs')
                time.sleep(1)
        except KeyboardInterrupt:pass
        except RuntimeError:
            for name in ('vllm.log','lmcache.log'):
                log=self.out/name
                if log.exists():
                    print('SERVER LOG: '+str(log),file=sys.stderr)
                    print(''.join(log.read_text(errors='replace').splitlines(keepends=True)[-45:]),file=sys.stderr)
            raise
        finally:
            for p in reversed(procs):
                if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
            for p in reversed(procs):
                try:p.wait(timeout=20)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            for f in files:f.close()

    def url(self,suffix):return 'http://127.0.0.1:'+str(self.c['port'])+'/v1'+suffix

    @staticmethod
    def wait_url(url,procs,seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            if any(p.poll() is not None for p in procs):raise RuntimeError('Server exited before readiness')
            try:
                with urllib.request.urlopen(url,timeout=2) as r:
                    if r.status==200:return
            except (OSError,ValueError):pass
            time.sleep(1)
        raise RuntimeError('Readiness timeout: '+url)

    def smoke(self, args):
        print('POST '+self.url('/chat/completions'))
        if not self.execute:return
        req={'model':self.c['served_model'],'messages':[{'role':'user','content':'Call inspect_project with path set to a single dot.'}],
             'tools':[{'type':'function','function':{'name':'inspect_project','description':'Inspect a project directory',
                'parameters':{'type':'object','properties':{'path':{'type':'string'}},'required':['path']}}}],
             'tool_choice':'auto','max_tokens':512,'temperature':0,
             'chat_template_kwargs':{'enable_thinking':False}}
        request=urllib.request.Request(self.url('/chat/completions'),json.dumps(req).encode(),{'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=300) as response:data=json.load(response)
        calls=data['choices'][0]['message'].get('tool_calls',[])
        if not calls:raise RuntimeError('Model did not emit a structured tool call; inspect parser/template')
        f=calls[0]['function']
        if f['name']!='inspect_project' or json.loads(f['arguments']).get('path')!='.':raise RuntimeError('Unexpected tool call')
        self.write(self.out/'reports/api_smoke.json',{'status':'STRUCTURED_TOOL_CALL_PASS','response':data,
            'agent_file_edit_test':'NOT_RUN','lmcache_hit':'NOT_VERIFIED','ssd_io':'NOT_CONFIGURED'})

    def agent(self, args):
        project=args.project.resolve()
        if self.execute and not project.is_dir():raise ValueError('Project directory does not exist')
        if self.execute:
            self.check_agent_cli()
            config_path=self.out/'config/opencode.json'
            configured=json.loads(config_path.read_text())
            if 'local' not in configured.get('provider',{}):
                raise RuntimeError('V1 local provider configuration missing; rerun 120_conf_services')
        env=self.envvars();env['OPENCODE_CONFIG']=str(self.out/'config/opencode.json')
        env['XDG_DATA_HOME']=str(self.out/'state/data')
        env['XDG_CONFIG_HOME']=str(self.out/'state/config')
        cmd=[str(self.bin/'opencode'),str(project),'--model','local/'+self.c['served_model']]
        print(shlex.join(cmd))
        if self.execute:subprocess.run(cmd,cwd=project,env=env,check=True)

def validate(here):
    log=here/'tests/results/controller_tests.log'
    log.parent.mkdir(parents=True,exist_ok=True)
    r=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(here/'tests'),'-v'],capture_output=True,text=True)
    log.write_text(r.stdout+r.stderr)
    print(r.stdout+r.stderr,end='')
    return r.returncode
