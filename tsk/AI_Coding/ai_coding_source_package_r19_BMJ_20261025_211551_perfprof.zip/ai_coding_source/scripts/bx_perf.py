# BUILD_ID="BMJ_20261025_211551"
"""Local inference measurements; no third-party Python dependencies required."""
import contextlib
import datetime
import hashlib
import json
import os
import pathlib
import platform
import re
import math
import shutil
import signal
import statistics
import subprocess
import threading
import time
import urllib.request
from types import SimpleNamespace

DEFAULT_PROMPT = 'Write a detailed explanation of a Python bounded queue implementation, including cancellation and tests. Do not use tools.'

def save(path, value):
    path.write_text(json.dumps(value,indent=2)+'\n')

def fetch(url, timeout=5):
    with urllib.request.urlopen(url,timeout=timeout) as response:
        return response.read().decode()

def control(base, action, timeout):
    request=urllib.request.Request(base+'/'+action, data=b'',method='POST')
    with urllib.request.urlopen(request,timeout=timeout) as response:
        return response.status

def request_stream(url, payload, timeout):
    start=time.monotonic_ns(); first=None; last=None; chunks=[]; usage=None; finish=None; done=False
    body=json.dumps(payload).encode()
    req=urllib.request.Request(url,data=body,headers={'Content-Type':'application/json'})
    # HTTP response chunks are not tokenizer tokens. Record their timing separately.
    with urllib.request.urlopen(req,timeout=timeout) as response:
        for raw in response:
            if (time.monotonic_ns()-start)/1e9>timeout:raise TimeoutError('Streaming request exceeded the measurement deadline')
            line=raw.decode().strip()
            if not line.startswith('data:'):continue
            data=line[5:].strip()
            if data=='[DONE]':done=True;break
            event=json.loads(data)
            if event.get('error'):raise RuntimeError('API stream error: '+json.dumps(event['error']))
            if event.get('usage'):usage=event['usage']
            for choice in event.get('choices',[]):
                if choice.get('finish_reason'):finish=choice['finish_reason']
                delta=choice.get('delta',{})
                if any(delta.get(key) for key in ('content','reasoning','reasoning_content','tool_calls')):
                    now=time.monotonic_ns()
                    if first is None:first=now
                    last=now;chunks.append({'time_ns':now,'delta':delta})
    end=time.monotonic_ns()
    if not done or first is None or not usage or type(usage.get('completion_tokens')) is not int or usage['completion_tokens']<=0:
        raise RuntimeError('Incomplete stream, no generated content, or missing positive completion token usage')
    tokens=usage['completion_tokens']; elapsed=(end-start)/1e9
    span=(last-first)/1e9 if last>first else None
    return {'status':'PASS','clock':'monotonic_ns','start_ns':start,'first_delta_ns':first,'last_delta_ns':last,'end_ns':end,
            'e2e_seconds':elapsed,'ttft_stream_event_seconds':(first-start)/1e9,
            'completion_tokens':tokens,'usage':usage,'finish_reason':finish,
            'request_tps':tokens/elapsed,
            'decode_tps_event_estimate':(tokens-1)/span if span and tokens>1 else None,
            'decode_estimate_warning':'SSE events may contain multiple tokens; this is not exact engine TPS or token ITL.',
            'delta_events':chunks}

class Collectors:
    def __init__(self, output):
        self.output=output;self.processes=[];self.files=[];self.stop=threading.Event();self.thread=None
    def __enter__(self):
        tools={'vmstat':['vmstat','-y','-t','1'], 'mpstat':['mpstat','-P','ALL','1'],
               'pidstat':['pidstat','-u','-r','-d','-w','-t','1'], 'iostat':['iostat','-x','-z','-y','1'],
               'gpu':['nvidia-smi','--query-gpu=timestamp,name,utilization.gpu,utilization.memory,power.draw,temperature.gpu,clocks.sm,clocks.mem','--format=csv','-l','1']}
        status={}
        for name,cmd in tools.items():
            if not shutil.which(cmd[0]):status[name]={'status':'MISSING','command':cmd};continue
            f=(self.output/(name+'.log')).open('w');self.files.append(f)
            try:
                proc=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
                self.processes.append((name,proc));status[name]={'status':'STARTED','pid':proc.pid,'command':cmd}
            except OSError as exc:status[name]={'status':'FAILED','error':str(exc)}
        self.status=status
        def sample():
            with (self.output/'procfs.jsonl').open('w') as out:
                while not self.stop.is_set():
                    row={'monotonic_ns':time.monotonic_ns(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
                    for key,path in [('meminfo','/proc/meminfo'),('memory_psi','/proc/pressure/memory'),('cpu_psi','/proc/pressure/cpu'),('io_psi','/proc/pressure/io')]:
                        try:row[key]=pathlib.Path(path).read_text()
                        except OSError as exc:row[key]={'error':str(exc)}
                    out.write(json.dumps(row)+'\n');out.flush();self.stop.wait(1)
        self.thread=threading.Thread(target=sample,daemon=True);self.thread.start();return self
    def __exit__(self,*unused):
        self.stop.set()
        if self.thread:self.thread.join(timeout=3)
        for name,p in self.processes:
            before=p.poll()
            if before is None:
                with contextlib.suppress(ProcessLookupError):os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    with contextlib.suppress(ProcessLookupError):os.killpg(p.pid,signal.SIGKILL)
                    p.wait()
            self.status[name].update(status='COLLECTED' if before is None else 'EXITED_EARLY',returncode=p.returncode)
        for f in self.files:f.close()
        save(self.output/'collectors.json',self.status)

def snapshot(output, name, s):
    stamps={}
    for target,url in [('vllm',s.url('/metrics').replace('/v1/metrics','/metrics')),
                       ('lmcache','http://127.0.0.1:'+str(s.c['cache_http_port'])+'/metrics')]:
        try:
            begin=time.monotonic_ns()
            (output/(target+'-'+name+'.prom')).write_text(fetch(url))
            stamps[target]={'begin_ns':begin,'end_ns':time.monotonic_ns()}
        except Exception as exc:save(output/(target+'-'+name+'-error.json'),{'error':str(exc)})
    save(output/('metrics-'+name+'.json'),stamps)

def counters(text):
    result={}
    for line in text.splitlines():
        match=re.fullmatch(r'([a-zA-Z_:][a-zA-Z0-9_:]*_total)(\{.*\})?\s+([-+0-9.eE]+)(?:\s+\d+)?',line)
        if match:
            value=float(match[3])
            if math.isfinite(value):result[match[1]+(match[2] or '')]=value
    return result

def counter_deltas(output):
    result={}
    for target in ('vllm','lmcache'):
        try:
            before=counters((output/(target+'-before.prom')).read_text())
            after=counters((output/(target+'-after.prom')).read_text())
            start=json.loads((output/'metrics-before.json').read_text())[target]
            end=json.loads((output/'metrics-after.json').read_text())[target]
            seconds=((end['begin_ns']+end['end_ns'])-(start['begin_ns']+start['end_ns']))/2e9
            result[target]={'window_seconds':seconds,'series':{key:{'delta':value-before[key], 'per_second':(value-before[key])/seconds if seconds>0 else None}
                for key,value in after.items() if key in before and value>=before[key]},
                'reset_series':[key for key,value in after.items() if key in before and value<before[key]]}
        except (OSError,KeyError,ValueError) as exc:result[target]={'status':'UNAVAILABLE','error':str(exc)}
    return result

def benchmark(s,a,output):
    prompt=a.prompt_file.read_text() if a.prompt_file else DEFAULT_PROMPT
    payload={'model':s.c['served_model'],'messages':[{'role':'user','content':prompt}],
             'stream':True,'stream_options':{'include_usage':True},'max_tokens':a.max_tokens,
             'temperature':0,'seed':42,'chat_template_kwargs':{'enable_thinking':a.thinking=='on'}}
    manifest={'status':'RUNNING','mode_declared':a.mode,'mode_verified':False,'host':platform.node(),'machine':platform.machine(),
              'model':s.c['model_id'],'served_model':s.c['served_model'],'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),
              'max_tokens':a.max_tokens,'thinking':a.thinking,'repeats':a.repeats,'warmup':a.warmup,
              'profiler_enabled':a.capture_profile,'config':s.c,'cache_regime':'UNCONTROLLED_NO_RESET',
              'notes':['No cache reset is performed. Repeated prompts may hit vLLM prefix cache.',
                       'Match actual server launch arguments before attributing baseline/LMCache differences.',
                       'Prompt and model outputs are retained locally; review before sharing.']}
    for name in ('sources.lock.json','torchvision.source.lock.json','triton.source.lock.json'):
        path=s.out/name
        if path.exists():manifest[name]=json.loads(path.read_text())
    save(output/'manifest.json',manifest);save(output/'request.json',payload)
    # A local server can expose its live config; absence is explicit, not guessed.
    try:(output/'server-info.json').write_text(fetch(s.url('/server_info').replace('/v1/server_info','/server_info')))
    except Exception as exc:save(output/'server-info-error.json',{'error':str(exc)})
    started=False
    try:
        with Collectors(output):
            for i in range(a.warmup):
                save(output/('warmup-'+str(i)+'.json'),request_stream(s.url('/chat/completions'),payload,a.timeout))
            snapshot(output,'before',s)
            if a.capture_profile:
                control(s.url('').removesuffix('/v1'),'start_profile',a.timeout);started=True
            try:
                for i in range(a.repeats):
                    result=request_stream(s.url('/chat/completions'),payload,a.timeout)
                    save(output/('request-'+str(i)+'.json'),result)
                    print('Request '+str(i)+': '+json.dumps({k:result[k] for k in ('completion_tokens','ttft_stream_event_seconds','request_tps','decode_tps_event_estimate')}),flush=True)
            finally:
                if started:control(s.url('').removesuffix('/v1'),'stop_profile',a.timeout)
            snapshot(output,'after',s)
        manifest['status']='PASS'
    except BaseException as exc:
        manifest['status']='FAILED';manifest['error']=str(exc);raise
    finally:save(output/'manifest.json',manifest)
    analyze(output)

def analyze_profile(output):
    manifest=json.loads((output/'profile_manifest.json').read_text())
    if manifest['action']=='serve-nsys':
        reports=sorted(output.glob('capture*.nsys-rep'))
        tool='nsys'
    else:
        reports=sorted(output.glob('capture*.ncu-rep'))
        tool='ncu'
    if not reports:raise RuntimeError('No completed profiler report; stop the profiled server and wait for report flush')
    if not shutil.which(tool):raise RuntimeError('Analysis tool missing: '+tool)
    for report in reports:
        cmd=([tool,'stats','--format','csv','--report','cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum',str(report)] if tool=='nsys' else
             [tool,'--import',str(report),'--page','details','--csv'])
        result=subprocess.run(cmd,capture_output=True,text=True)
        (output/(report.name+'.stats.csv')).write_text(result.stdout)
        (output/(report.name+'.stats.stderr')).write_text(result.stderr)
        if result.returncode:raise RuntimeError('Profiler stats failed; inspect saved stderr and installed tool report support')
    (output/'profile_analysis.md').write_text('# Profiler summary exports\n\nReview the exported kernel and API tables, then open the original timeline.\nSummed kernel time is not GPU busy time when kernels overlap.\nNCU replay durations are not end-to-end service TPS.\nBottleneck remains UNDETERMINED until timeline and counter evidence are correlated.\n')

def analyze(output):
    if (output/'profile_manifest.json').exists():
        analyze_profile(output);return
    manifest=json.loads((output/'manifest.json').read_text())
    rows=[json.loads(p.read_text()) for p in sorted(output.glob('request-*.json'))]
    summary={'status':manifest['status'],'requests':len(rows),'mode_declared':manifest['mode_declared'],
             'mode_verified':manifest['mode_verified'],'profiler_enabled':manifest['profiler_enabled'],
             'bottleneck':'UNDETERMINED_REQUIRES_TIMELINE_OR_COUNTER_EVIDENCE','counter_deltas':counter_deltas(output)}
    for key in ('request_tps','decode_tps_event_estimate','ttft_stream_event_seconds','e2e_seconds'):
        values=[row[key] for row in rows if row.get(key) is not None]
        summary[key]={'median':statistics.median(values),'min':min(values),'max':max(values)} if values else None
    save(output/'summary.json',summary)
    report=['# Measurement summary','',json.dumps(summary,indent=2),'',
            'The decode estimate uses streamed event boundaries, not individual token timestamps.',
            'Counter deltas and logs must be correlated with these intervals; other traffic invalidates isolation.',
            'A mode label is user-declared until live server arguments are checked.',
            'Profiler-enabled TPS must not replace unprofiled baseline measurements.',
            'Inspect procfs and system logs for swap activity, per-thread CPU pressure and device I/O.',
            'Use Nsight Systems for GPU gaps and critical-path attribution, then NCU for selected hot kernels.',
            'No automatic bandwidth/compute/SSD bottleneck diagnosis is asserted.']
    (output/'analysis.md').write_text('\n'.join(report)+'\n');print(json.dumps(summary,indent=2))

def compare(inputs):
    if not inputs or len(inputs)!=2:raise ValueError('Compare requires exactly two --inputs directories')
    manifests=[json.loads((p/'manifest.json').read_text()) for p in inputs]
    for key in ('host','machine','model','served_model','prompt_sha256','max_tokens','thinking','cache_regime','repeats','warmup','config'):
        if manifests[0][key]!=manifests[1][key]:raise ValueError('Comparison mismatch: '+key)
    if any(m['status']!='PASS' or m['profiler_enabled'] for m in manifests):raise ValueError('Compare only successful unprofiled runs')
    if {m['mode_declared'] for m in manifests}!={'baseline','lmcache'}:raise ValueError('Compare baseline against lmcache')
    if manifests[0].get('sources.lock.json')!=manifests[1].get('sources.lock.json'):raise ValueError('Source lock mismatch')
    for p in inputs:analyze(p)
    rows=[json.loads((p/'summary.json').read_text()) for p in inputs]
    result={'status':'DESCRIPTIVE_COMPARISON_NOT_CAUSAL_PROOF','runs':[str(p) for p in inputs],'summaries':rows,
            'warning':'Actual live server mode, cache residency and competing traffic require independent verification.'}
    save(inputs[1]/'comparison.json',result);print(json.dumps(result,indent=2))

def dispatch(s,a):
    if a.max_tokens<2 or a.repeats<1 or a.warmup<0 or a.timeout<1:raise ValueError('Invalid measurement counts or timeout')
    if a.action=='compare':
        if not s.execute:print('PLAN compare successful unprofiled baseline/LMCache measurements');return
        compare(a.inputs);return
    output=a.output or s.out/'perf'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    if not output.resolve().is_relative_to(s.out.resolve()):raise ValueError('Profiling output must stay under the task deliverables directory: '+str(s.out))
    if a.action=='analyze':
        if not a.output:raise ValueError('Analyze requires --output with an existing measurement directory')
        if not s.execute:print('PLAN analyze '+str(output));return
        analyze(output);return
    if a.action in ('serve-nsys','serve-ncu'):
        if a.action=='serve-ncu' and not a.kernel_regex:raise ValueError('NCU requires --kernel-regex selected from a Systems trace')
        prefix=(['nsys','profile','--trace=cuda,nvtx,osrt','--trace-fork-before-exec=true',
                 '--cuda-graph-trace=node','--capture-range=cudaProfilerApi','--capture-range-end=repeat',
                 '--output='+str(output/'capture')] if a.action=='serve-nsys' else
                ['ncu','--target-processes','all','--profile-from-start','off','--set','basic',
                 '--kernel-name','regex:'+a.kernel_regex,'--launch-count','5','--export',str(output/'capture')])
        if s.execute:
            if not shutil.which(prefix[0]):raise RuntimeError('Profiler executable missing: '+prefix[0])
            output.mkdir(parents=True,exist_ok=False)
            save(output/'profile_manifest.json',{'action':a.action,'prefix':prefix,'mode_declared':a.mode,
                 'note':'Terminal B must benchmark with --capture-profile. Stop server after capture. NCU changes execution through replay.'})
        s.serve(SimpleNamespace(baseline=a.mode=='baseline',profiler_prefix=prefix));return
    if not s.execute:
        print('PLAN streaming benchmark + optional system collectors -> '+str(output));return
    output.mkdir(parents=True,exist_ok=False)
    benchmark(s,a,output)
