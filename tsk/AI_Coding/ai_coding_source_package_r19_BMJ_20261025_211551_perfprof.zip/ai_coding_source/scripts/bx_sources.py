# BUILD_ID="BMJ_20261025_211551"
"""Preserve Git history, tags and instrumentation; prepare isolated stable sources."""
import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess
import tarfile


def timestamp():
    return datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')


def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):result.update(chunk)
    return result.hexdigest()


class Sources:
    def __init__(self, stack):
        self.s=stack

    def git(self, repo, *args):
        if args and args[0]=='fetch':
            args=list(args)
            for flag in ('--no-prune','--no-prune-tags','--no-auto-maintenance'):
                if flag not in args:args.insert(1,flag)
        return self.s.run(['git',*args],cwd=repo,capture=True,extra={'GIT_LFS_SKIP_SMUDGE':'1'})

    def raw(self, repo, *args):
        return subprocess.run(['git',*args],cwd=repo,env=self.s.envvars(),check=True,
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout

    def assert_repo(self, repo, url):
        top=pathlib.Path(self.git(repo,'rev-parse','--show-toplevel')).resolve()
        if top!=repo.resolve():raise RuntimeError('Refuse a directory inside another Git repository: '+str(repo))
        if self.git(repo,'remote','get-url','origin').rstrip('/')!=url.rstrip('/'):
            raise RuntimeError('Unexpected Git origin: '+str(repo))

    def snapshot(self, name, repo, destination):
        """Save staged/unstaged binary patches separately, plus nonignored untracked files."""
        destination.mkdir(parents=True,exist_ok=True)
        for filename,args in [('unstaged.patch',('diff','--binary')),
                              ('staged.patch',('diff','--cached','--binary'))]:
            (destination/filename).write_bytes(self.raw(repo,*args))
        untracked=[os.fsdecode(p) for p in self.raw(repo,'ls-files','--others','--exclude-standard','-z').split(b'\0') if p]
        with tarfile.open(destination/'untracked.tar','w',dereference=False) as archive:
            for rel in untracked:
                path=pathlib.PurePosixPath(rel)
                if path.is_absolute() or '..' in path.parts:raise RuntimeError('Unsafe untracked path')
                archive.add(repo/rel,arcname=rel,recursive=False)
        head=self.git(repo,'rev-parse','HEAD')
        self.git(repo,'update-ref','refs/bx/retained/'+head,head)
        tags=self.git(repo,'for-each-ref','--format=%(refname:strip=2) %(objectname) %(objecttype) %(*objectname)','refs/tags')
        (destination/'tags.txt').write_text(tags+'\n')
        dependencies=[]
        if (repo/'.deps').is_dir():
            for child in sorted((repo/'.deps').iterdir()):
                entry={'path':str(child),'preserved':'IN_PLACE'}
                if (child/'.git').exists():entry['commit']=self.git(child,'rev-parse','HEAD')
                dependencies.append(entry)
        info={'name':name,'path':str(repo),'resolved_path':str(repo.resolve()),'head':head,
              'git_dir':self.git(repo,'rev-parse','--absolute-git-dir'),
              'describe':self.git(repo,'describe','--tags','--always','--dirty'),
              'tags_at_head':self.git(repo,'tag','--points-at','HEAD').splitlines(),
              'shallow':self.git(repo,'rev-parse','--is-shallow-repository')=='true',
              'submodules':self.git(repo,'submodule','status','--recursive').splitlines(),
              'status':self.git(repo,'status','--porcelain=v1'),
              'ignored_untracked_files':'not archived; retained in the source directory',
              'untracked_count':len(untracked),'gpu_validation':'NOT_RUN'}
        info['dependency_sources']=dependencies
        if name=='model':
            info['lfs_files']=self.git(repo,'lfs','ls-files','-l').splitlines()
        info['snapshot_sha256']={f.name:digest(f)
                                 for f in destination.iterdir() if f.is_file() and f.name!='manifest.json'}
        self.s.write(destination/'manifest.json',info)
        return info

    def complete(self, repo):
        """Fetch all branch/tag history without checkout, reset, clean or tag pruning."""
        shallow=self.git(repo,'rev-parse','--is-shallow-repository')=='true'
        config=self.git(repo,'config','--local','--list')
        partial='remote.origin.partialclonefilter=' in config or 'remote.origin.promisor=true' in config
        args=['fetch','--no-auto-maintenance','--tags','--no-recurse-submodules']
        if shallow:args.append('--unshallow')
        if partial:args+=['--refetch','--no-filter']
        self.git(repo,*args,'origin','+refs/heads/*:refs/remotes/origin/*')
        missing=self.git(repo,'rev-list','--objects','--all','--missing=print')
        if any(line.startswith('?') for line in missing.splitlines()):
            raise RuntimeError('Missing Git objects remain; partial clone state retained: '+str(repo))
        if self.git(repo,'rev-parse','--is-shallow-repository')!='false':
            raise RuntimeError('Repository is still shallow: '+str(repo))
        # A successful full fetch already makes the retained checkout self-contained.
        # Keep Git's promisor metadata: deleting it can hide future object errors.
        return {'history':'FULL_FOR_FETCHED_REFS','objects':'COMPLETE_FOR_LOCAL_REFS','partial_origin':partial}

    def entries(self):
        entries=[(name,self.s.src/name,entry['url']) for name,entry in self.s.c['repos'].items()]
        entries.append(('model',self.s.model,'https://huggingface.co/'+self.s.c['model_id']))
        triton=self.s.src/'triton'
        if triton.exists():entries.append(('triton',triton,'https://github.com/triton-lang/triton.git'))
        vision=self.s.src/'torchvision'
        if vision.exists():entries.append(('torchvision',vision,'https://github.com/pytorch/vision.git'))
        return entries

    def preserve(self, args):
        if not self.s.execute:
            print('PRESERVE source HEAD/worktree; snapshot instrumentation; fetch complete Git history/tags unless --offline; optional --bundle')
            return
        dest=self.s.out/'source_snapshots'/timestamp()
        manifests=[]
        for name,repo,url in self.entries():
            if not repo.exists():continue
            self.assert_repo(repo,url)
            before=self.snapshot(name,repo,dest/name/'before')
            result={'fetch':'OFFLINE_SKIPPED'} if args.offline else self.complete(repo)
            after=self.snapshot(name,repo,dest/name/'after')
            if before['head']!=after['head'] or before['status']!=after['status']:
                raise RuntimeError('Worktree changed while preserving '+name+'; inspect snapshots')
            for filename in ('staged.patch','unstaged.patch','untracked.tar'):
                if before['snapshot_sha256'][filename]!=after['snapshot_sha256'][filename]:
                    raise RuntimeError('Source edits changed while preserving '+name+'; inspect snapshots')
            if args.bundle:
                self.git(repo,'bundle','create',str(dest/name/(name+'.bundle')),'--all')
                self.git(repo,'bundle','verify',str(dest/name/(name+'.bundle')))
            manifests.append({**after,**result})
        if not manifests:raise RuntimeError('No source repositories found; run stage 020 first')
        self.s.write(dest/'manifest.json',{'repositories':manifests,'lfs_payloads':'not included in Git bundles',
                    'submodule_objects':'kept in original repositories; each submodule needs its own bundle for portability'})
        print('Source snapshot: '+str(dest))

    def stable(self, args):
        """Add separate linked worktrees and venv root; never switch installed sources."""
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*',args.profile_name):raise ValueError('Invalid profile name')
        if not self.s.execute:
            print('PREPARE isolated stable source worktrees and config for '+args.profile_name+'; existing environment retained')
            return
        manifest=json.loads(args.matrix.read_text())
        profile_root=self.s.root/'profiles'/args.profile_name
        source_root=self.s.src/'profiles'/args.profile_name
        statefile=profile_root/'deliverables/ai_coding/stable_prepare_state.json'
        if (profile_root/'stack.json').exists() or ((profile_root.exists() or source_root.exists()) and not statefile.exists()):
            raise RuntimeError('Profile already exists; use a new profile name')
        lockfile=self.s.out/'sources.lock.json'
        current=json.loads(lockfile.read_text())
        commits={};newconfig=json.loads(json.dumps(self.s.c))
        # Validate every tag first. No existing worktree changes are needed.
        for name,entry in self.s.c['repos'].items():
            repo=self.s.src/name;self.assert_repo(repo,entry['url'])
            requested=manifest['selected'][name]['tag'] if name in manifest['selected'] else current[name]['commit']
            if name in manifest['selected']:
                self.git(repo,'fetch','--tags','--no-recurse-submodules','origin')
                commit=self.git(repo,'rev-parse','refs/tags/'+requested+'^{commit}')
                expected=manifest['selected'][name].get('commit')
                if expected and commit!=expected:raise RuntimeError('Release tag moved or matrix commit differs: '+name)
            else:commit=self.git(repo,'rev-parse',requested+'^{commit}')
            commits[name]=(requested,commit)
        # Assert critical dependency edges against the fetched tag contents.
        vllm=self.s.src/'vllm'
        common=self.git(vllm,'show',commits['vllm'][1]+':requirements/common.txt')
        cuda=self.git(vllm,'show',commits['vllm'][1]+':requirements/cuda.txt')
        lmproject=self.git(self.s.src/'lmcache','show',commits['lmcache'][1]+':pyproject.toml')
        lmcommon=self.git(self.s.src/'lmcache','show',commits['lmcache'][1]+':requirements/common.txt')
        torch_version=commits['pytorch'][0].removeprefix('v')
        tf_version=commits['transformers'][0].removeprefix('v')
        requirement=next((line.split('#')[0].strip() for line in common.splitlines() if re.match(r'^transformers\s*[<>=]',line)),None)
        if not requirement or not re.search(r'^torch\s*==\s*'+re.escape(torch_version)+r'\s*$',cuda,re.M):
            raise RuntimeError('Stable matrix disagrees with vLLM torch/Transformers metadata')
        if not re.search(r'"torch\s*==\s*'+re.escape(torch_version)+r'"',lmproject):
            raise RuntimeError('Stable matrix disagrees with LMCache build-time torch')
        lmrequirement=next((line.split('#')[0].strip() for line in lmcommon.splitlines() if re.match(r'^transformers\s*[<>=]',line)),None)
        if not lmrequirement:raise RuntimeError('Cannot read LMCache Transformers requirement')
        interpreter=self.s.py if self.s.py.exists() else self.s.c['python']
        self.s.run([interpreter,'-c','from packaging.requirements import Requirement; import sys; assert Requirement(sys.argv[1]).specifier.contains(sys.argv[2])',requirement,tf_version])
        self.s.run([interpreter,'-c','from packaging.requirements import Requirement; import sys; assert Requirement(sys.argv[1]).specifier.contains(sys.argv[2])',lmrequirement,tf_version])
        plan={'commits':{name:list(value) for name,value in commits.items()},'source_root':str(source_root),
              'matrix_sha256':hashlib.sha256(args.matrix.read_bytes()).hexdigest()}
        if statefile.exists():
            if json.loads(statefile.read_text())!=plan:raise RuntimeError('Incomplete profile plan changed; use a new profile name')
        else:self.s.write(statefile,plan)
        newlock={}
        for name,(requested,commit) in commits.items():
            dest=source_root/name;dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():
                self.assert_repo(dest,self.s.c['repos'][name]['url'])
                if self.git(dest,'rev-parse','HEAD')!=commit or self.git(dest,'status','--porcelain','--untracked-files=no'):
                    raise RuntimeError('Incomplete worktree changed; preserve it and use a new profile name')
            else:self.git(self.s.src/name,'worktree','add','--detach',str(dest),commit)
            self.git(dest,'submodule','update','--init','--recursive','--jobs',str(self.s.max_jobs))
            newconfig['repos'][name]['ref']=requested
            newlock[name]={'url':self.s.c['repos'][name]['url'],'requested_ref':requested,'commit':commit}
        newconfig.update(root=str(profile_root),source_root=str(source_root),model_path=str(self.s.model),
                         source_policy='full_history_and_tags',stable_matrix=manifest,
                         package_versions={name:entry['version'] for name,entry in manifest['selected'].items()},
                         dependency_constraints=manifest.get('dependency_constraints',[]))
        if 'model' in current:newlock['model']=current['model']
        out=profile_root/'deliverables/ai_coding'
        self.s.write(out/'sources.lock.json',newlock)
        self.s.write(profile_root/'stack.json',newconfig)
        self.s.write(out/'stable_validation.json',{'status':'DEPENDENCY_EDGES_CHECKED','runtime':'NOT_RUN','model_cache_transfer':'NOT_RUN','commits':commits})
        print('Stable profile config: '+str(profile_root/'stack.json'))
