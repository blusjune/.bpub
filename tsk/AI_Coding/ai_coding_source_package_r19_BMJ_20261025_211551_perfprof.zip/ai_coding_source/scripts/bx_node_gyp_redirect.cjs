// BUILD_ID="BMJ_20261025_211551"
"use strict";
// Redirect only a node-gyp CLI entry point; ordinary Node programs are unchanged.
const Module = require("node:module");
const path = require("node:path");
const fs = require("node:fs");
const target = process.env.BX_NODE_GYP_MAIN;
if (!target || !path.isAbsolute(target) || !fs.existsSync(target)) {
  throw new Error("BX_NODE_GYP_MAIN must name the installed managed node-gyp CLI");
}
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (isMain && typeof request === "string") {
    const absolute = path.resolve(request);
    const isGyp = path.basename(absolute) === "node-gyp.js" &&
      path.basename(path.dirname(absolute)) === "bin" &&
      path.basename(path.dirname(path.dirname(absolute))) === "node-gyp";
    if (isGyp && fs.realpathSync(absolute) !== fs.realpathSync(target)) {
      process.stderr.write("BX_NODE_GYP_REDIRECT " + absolute + " -> " + target + "\n");
      process.argv[1] = target;
      return originalLoad.call(this, target, parent, true);
    }
  }
  return originalLoad.call(this, request, parent, isMain);
};
