# BUILD_ID="BMJ_20261025_211551"
"""Offline performance harness checks, including a real HTTP SSE endpoint."""
import importlib.util
import json
import pathlib
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from types import SimpleNamespace
from unittest import mock

ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('perf',ROOT/'scripts/bx_perf.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Perf(unittest.TestCase):
    def test_real_http_sse_usage_not_chunk_count(self):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(self):
                self.rfile.read(int(self.headers['Content-Length']))
                self.send_response(200);self.end_headers()
                for event in [{'choices':[{'delta':{'content':'several tokens here'}}]},
                              {'choices':[{'delta':{'reasoning_content':'more tokens'}}]},
                              {'choices':[{'finish_reason':'length','delta':{}}]},
                              {'choices':[],'usage':{'completion_tokens':17,'prompt_tokens':9}}]:
                    self.wfile.write(('data: '+json.dumps(event)+'\n\n').encode())
                self.wfile.write(b'data: [DONE]\n\n')
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever);thread.start()
        try:
            row=m.request_stream('http://127.0.0.1:'+str(server.server_port),{},2)
            self.assertEqual(row['completion_tokens'],17);self.assertEqual(len(row['delta_events']),2)
            self.assertEqual(row['finish_reason'],'length');self.assertGreater(row['request_tps'],0)
        finally:server.shutdown();server.server_close();thread.join()

    def test_missing_usage_is_failure(self):
        with mock.patch.object(m.urllib.request,'urlopen',return_value=SimpleContext([b'data: {"choices":[{"delta":{"content":"x"}}]}\n',b'data: [DONE]\n'])):
            with self.assertRaisesRegex(RuntimeError,'missing positive'):m.request_stream('http://127.0.0.1',{},1)

    def test_profile_analysis_requires_a_completed_report(self):
        with tempfile.TemporaryDirectory() as directory:
            p=pathlib.Path(directory);m.save(p/'profile_manifest.json',{'action':'serve-nsys'})
            with self.assertRaisesRegex(RuntimeError,'completed profiler report'):m.analyze(p)

    def test_profile_summary_export_is_checked(self):
        with tempfile.TemporaryDirectory() as directory:
            p=pathlib.Path(directory);m.save(p/'profile_manifest.json',{'action':'serve-nsys'});(p/'capture.nsys-rep').write_bytes(b'fixture')
            with mock.patch.object(m.shutil,'which',return_value='/usr/bin/nsys'),mock.patch.object(m.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='kernel,time',stderr='')) as run:
                m.analyze(p)
            self.assertIn('cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum',run.call_args.args[0])
            self.assertTrue((p/'capture.nsys-rep.stats.csv').exists())

    def test_incomplete_stream_is_not_success(self):
        events=[b'data: {"choices":[{"delta":{"content":"x"}}],"usage":{"completion_tokens":1}}\n']
        with mock.patch.object(m.urllib.request,'urlopen',return_value=SimpleContext(events)):
            with self.assertRaisesRegex(RuntimeError,'Incomplete stream'):m.request_stream('http://127.0.0.1',{},1)

    def test_output_cannot_escape_deliverables(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError,'must stay under'):
                m.dispatch(SimpleNamespace(execute=False,out=pathlib.Path(directory)/'deliverables'),self.args(output=pathlib.Path(directory)/'outside'))

    def test_counter_parser_and_reset(self):
        text='# HELP x\nvllm:generation_tokens_total{model_name="qwen local"} 100\nfoo_bucket 9\nlmcache_mp_read_total 4\n'
        self.assertEqual(m.counters(text),{'vllm:generation_tokens_total{model_name="qwen local"}':100.,'lmcache_mp_read_total':4.})
        with tempfile.TemporaryDirectory() as directory:
            p=pathlib.Path(directory)
            (p/'vllm-before.prom').write_text('x_total 10\ny_total 10\n')
            (p/'vllm-after.prom').write_text('x_total 30\ny_total 1\n')
            for name,stamp in [('before',0),('after',2_000_000_000)]:m.save(p/('metrics-'+name+'.json'),{'vllm':{'begin_ns':stamp,'end_ns':stamp}})
            row=m.counter_deltas(p)
            self.assertEqual(row['vllm']['series']['x_total']['per_second'],10)
            self.assertEqual(row['vllm']['reset_series'],['y_total'])
            self.assertEqual(row['lmcache']['status'],'UNAVAILABLE')

    def args(self,**kwargs):
        values=dict(action='benchmark',mode='baseline',max_tokens=8,repeats=1,warmup=0,timeout=1,output=None,inputs=None,thinking='off',kernel_regex=None,capture_profile=False)
        values.update(kwargs);return SimpleNamespace(**values)

    def test_dry_runs_do_not_launch_or_write(self):
        with tempfile.TemporaryDirectory() as directory:
            p=pathlib.Path(directory)/'absent'
            stack=SimpleNamespace(execute=False,out=p,serve=lambda args:None)
            with mock.patch.object(m.subprocess,'Popen',side_effect=AssertionError('launch')):
                for action in ('benchmark','serve-nsys','serve-ncu','compare','analyze'):
                    m.dispatch(stack,self.args(action=action,output=p,kernel_regex='gemm'))
            self.assertFalse(p.exists())

    def test_ncu_requires_selected_kernel(self):
        with self.assertRaisesRegex(ValueError,'kernel-regex'):
            m.dispatch(SimpleNamespace(execute=False,out=pathlib.Path('/tmp')),self.args(action='serve-ncu'))

    def test_existing_output_not_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileExistsError):m.dispatch(SimpleNamespace(execute=True,out=pathlib.Path(directory)),self.args(output=pathlib.Path(directory)))

    def test_compare_rejects_profiler_and_mismatched_conditions(self):
        with tempfile.TemporaryDirectory() as directory:
            inputs=[pathlib.Path(directory)/name for name in ('a','b')]
            base=dict(host='h',machine='aarch64',model='m',served_model='m',prompt_sha256='p',max_tokens=8,thinking='off',cache_regime='UNCONTROLLED_NO_RESET',repeats=1,warmup=0,config={},status='PASS',profiler_enabled=False,mode_declared='baseline')
            for p in inputs:p.mkdir();m.save(p/'manifest.json',base)
            changed=dict(base,profiler_enabled=True,mode_declared='lmcache');m.save(inputs[1]/'manifest.json',changed)
            with self.assertRaisesRegex(ValueError,'unprofiled'):m.compare(inputs)
            changed.update(profiler_enabled=False,prompt_sha256='other');m.save(inputs[1]/'manifest.json',changed)
            with self.assertRaisesRegex(ValueError,'prompt_sha256'):m.compare(inputs)

class SimpleContext:
    def __init__(self,value):self.value=value
    def __enter__(self):return self.value
    def __exit__(self,*args):pass
