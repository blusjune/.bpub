# BUILD_ID="BMJ_20261025_211551"
"""Offline Git integration tests: real history, tags, patches, bundles and worktrees."""
import contextlib
import importlib.util
import io
import json
import os
import pathlib
import subprocess
import sys
import tarfile
import tempfile
import unittest
from types import SimpleNamespace
from unittest import mock

HERE=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('source_stack',HERE/'scripts/bx_stack.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def git(repo,*args):
    return subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,check=True,stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,text=True).stdout.strip()


class SourcePreservation(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=pathlib.Path(self.tmp.name)
        self.c=json.loads((HERE/'configs/stack.json').read_text())
        self.c.update(root=str(self.base/'root'),python=sys.executable)

    def tearDown(self):self.tmp.cleanup()

    def upstream(self,name,files=None,tag='v1.0.0'):
        repo=self.base/('remote-'+name);repo.mkdir()
        git(repo,'init','-b','main');git(repo,'config','user.email','test@example.invalid');git(repo,'config','user.name','Test')
        for rel,text in (files or {'code.py':'print("first")\n'}).items():
            f=repo/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text)
        git(repo,'add','.');git(repo,'commit','-m','initial');git(repo,'tag','-a',tag,'-m','release')
        (repo/'later.txt').write_text('second\n');git(repo,'add','.');git(repo,'commit','-m','later')
        git(repo,'config','uploadpack.allowFilter','true')
        return repo

    def stack_with_repo(self,partial=False,shallow=False):
        remote=self.upstream('sample');self.c['repos']={'sample':{'url':remote.as_uri(),'ref':'main'}}
        s=m.Stack(self.c,True);s.src.mkdir(parents=True);repo=s.src/'sample'
        args=['clone']
        if shallow:args+=['--depth','1']
        if partial:args+=['--filter=blob:none','--no-checkout']
        git(self.base,*args,remote.as_uri(),str(repo))
        if partial:git(repo,'checkout','main')
        git(repo,'config','user.email','test@example.invalid');git(repo,'config','user.name','Test')
        return s,repo

    def test_unshallow_fetch_retains_dirty_worktree_and_annotated_tags(self):
        s,repo=self.stack_with_repo(shallow=True)
        head=git(repo,'rev-parse','HEAD');(repo/'code.py').write_text('print("instrumented")\n')
        git(repo,'tag','local-instrumentation-baseline')
        git(repo,'config','fetch.prune','true');git(repo,'config','fetch.pruneTags','true')
        git(repo,'add','code.py');(repo/'code.py').write_text('print("second edit")\n')
        (repo/'new instrumentation.py').write_text('trace = True\n')
        status=git(repo,'status','--porcelain=v1')
        with contextlib.redirect_stdout(io.StringIO()):s.preserve_sources(SimpleNamespace(offline=False,bundle=True))
        self.assertEqual(git(repo,'rev-parse','HEAD'),head)
        self.assertEqual(git(repo,'status','--porcelain=v1'),status)
        self.assertEqual(git(repo,'rev-parse','--is-shallow-repository'),'false')
        self.assertEqual(git(repo,'cat-file','-t','refs/tags/v1.0.0'),'tag')
        self.assertEqual(git(repo,'rev-parse','refs/tags/local-instrumentation-baseline'),head)
        snapshot=next((s.out/'source_snapshots').iterdir())
        for phase in ('before','after'):
            folder=snapshot/'sample'/phase
            self.assertIn(b'instrumented',(folder/'staged.patch').read_bytes())
            self.assertIn(b'second edit',(folder/'unstaged.patch').read_bytes())
            with tarfile.open(folder/'untracked.tar') as archive:
                self.assertEqual(archive.extractfile('new instrumentation.py').read(),b'trace = True\n')
        restored=self.base/'bundle-restored'
        git(self.base,'clone',str(snapshot/'sample/sample.bundle'),str(restored))
        self.assertEqual(git(restored,'rev-parse','HEAD'),head)
        self.assertEqual(git(restored,'cat-file','-t','refs/tags/v1.0.0'),'tag')

    def test_partial_objects_are_hydrated_without_switching_head(self):
        s,repo=self.stack_with_repo(partial=True)
        # Add a history-only blob that checkout did not need.
        remote=self.base/'remote-sample'
        (remote/'historical.txt').write_text('history payload\n');git(remote,'add','.');git(remote,'commit','-m','history blob')
        git(remote,'rm','historical.txt');git(remote,'commit','-m','remove history blob')
        git(repo,'fetch','origin')
        head=git(repo,'rev-parse','HEAD')
        with contextlib.redirect_stdout(io.StringIO()):result=s.source_manager().complete(repo)
        self.assertEqual(result['objects'],'COMPLETE_FOR_LOCAL_REFS')
        self.assertEqual(git(repo,'rev-parse','HEAD'),head)
        self.assertFalse(any(x.startswith('?') for x in git(repo,'rev-list','--objects','--all','--missing=print').splitlines()))

    def test_offline_snapshot_never_fetches(self):
        s,repo=self.stack_with_repo()
        manager=s.source_manager();original=manager.git
        def guarded(repo,*args):
            if args[0]=='fetch':raise AssertionError('network fetch')
            return original(repo,*args)
        with mock.patch.object(manager,'git',side_effect=guarded),contextlib.redirect_stdout(io.StringIO()):
            manager.preserve(SimpleNamespace(offline=True,bundle=False))
        self.assertTrue(list((s.out/'source_snapshots').glob('*/manifest.json')))

    def test_parent_repository_is_not_adopted(self):
        s,repo=self.stack_with_repo();child=repo/'nested';child.mkdir()
        with contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(RuntimeError,'inside another'):
            s.source_manager().assert_repo(child,self.c['repos']['sample']['url'])

    def test_stable_profile_uses_separate_worktrees_and_preserves_current_config(self):
        matrix=json.loads((HERE/'configs/stable_matrix_20261024.json').read_text())
        self.c['repos']={}
        files={'vllm':{'requirements/common.txt':'transformers>=5.16.1,<5.20.0\n','requirements/cuda.txt':'torch==2.13.0\n'},
               'lmcache':{'pyproject.toml':'[build-system]\nrequires=["torch==2.13.0"]\n','requirements/common.txt':'transformers>=5.4\n'}}
        for name,entry in matrix['selected'].items():
            remote=self.upstream(name,files.get(name),entry['tag'])
            entry['commit']=git(remote,'rev-parse',entry['tag']+'^{commit}')
            self.c['repos'][name]={'url':remote.as_uri(),'ref':'main'}
        s=m.Stack(self.c,True);s.src.mkdir(parents=True)
        oldlock={};heads={}
        for name,entry in self.c['repos'].items():
            git(self.base,'clone',entry['url'],str(s.src/name))
            heads[name]=git(s.src/name,'rev-parse','HEAD')
            oldlock[name]={'url':entry['url'],'requested_ref':'main','commit':heads[name]}
        s.out.mkdir(parents=True);(s.out/'sources.lock.json').write_text(json.dumps(oldlock))
        original_config=json.dumps(self.c);configfile=self.base/'original.json';configfile.write_text(original_config)
        matrixfile=self.base/'matrix.json';matrixfile.write_text(json.dumps(matrix))
        args=SimpleNamespace(profile_name='stable-test',matrix=matrixfile)
        manager=s.source_manager();original_git=manager.git;failed=False
        def fail_once(repo,*cmd):
            nonlocal failed
            if cmd[0]=='submodule' and not failed:
                failed=True;raise RuntimeError('simulated interrupted submodule download')
            return original_git(repo,*cmd)
        with mock.patch.object(manager,'git',side_effect=fail_once),contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError,'interrupted'):manager.stable(args)
        with contextlib.redirect_stdout(io.StringIO()):s.prepare_stable(args)
        profile=s.root/'profiles/stable-test';new=json.loads((profile/'stack.json').read_text())
        self.assertEqual(configfile.read_text(),original_config)
        self.assertEqual(json.loads((s.out/'sources.lock.json').read_text()),oldlock)
        for name,entry in matrix['selected'].items():
            self.assertEqual(git(s.src/name,'rev-parse','HEAD'),heads[name])
            tree=pathlib.Path(new['source_root'])/name
            self.assertTrue((tree/'.git').is_file())
            self.assertEqual(git(tree,'describe','--tags','--exact-match'),entry['tag'])
        self.assertNotEqual(new['root'],self.c['root'])
        self.assertEqual(new['package_versions']['pytorch'],'2.13.0')
        with self.assertRaisesRegex(RuntimeError,'already exists'):s.prepare_stable(args)
        matrix['selected']['pytorch']['commit']='0'*40;matrixfile.write_text(json.dumps(matrix))
        args.profile_name='moved-tag'
        with contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(RuntimeError,'tag moved'):
            s.prepare_stable(args)
        self.assertFalse((s.src/'profiles/moved-tag').exists())

    def test_stable_profile_rejects_unsafe_name_without_writes(self):
        s=m.Stack(self.c,True)
        with self.assertRaises(ValueError):s.prepare_stable(SimpleNamespace(profile_name='../escape'))
        self.assertFalse(s.root.exists())


if __name__=='__main__':unittest.main()
