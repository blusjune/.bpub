# BUILD_ID="BMJ_20261025_211551"
"""CPU-only adversarial checks. These do not certify any target build."""
import contextlib
import importlib.util
import io
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest
import zipfile
from types import SimpleNamespace
from unittest import mock

HERE=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('controller',HERE/'scripts/bx_stack.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Controller(unittest.TestCase):
    def config(self,root):
        c=json.loads((HERE/'configs/stack.json').read_text());c['root']=str(root);return c

    def test_automatic_build_parallelism(self):
        for available, expected in ((20,16),(8,4),(4,1),(2,1),(1,1)):
            with self.subTest(available=available), mock.patch.object(m,'available_build_cpus',return_value=available):
                c=self.config('/tmp/bx-parallel-test');c['max_jobs']=4
                stack=m.Stack(c)
                self.assertEqual(stack.max_jobs,expected)
                self.assertEqual(stack.envvars()['MAX_JOBS'],str(expected))
                self.assertEqual(stack.envvars()['CMAKE_BUILD_PARALLEL_LEVEL'],str(expected))
                self.assertEqual(stack.envvars()['NVCC_THREADS'],'1')

    def test_build_cpu_affinity(self):
        with mock.patch.object(m.os,'cpu_count',return_value=32), mock.patch.object(m.os,'sched_getaffinity',return_value={0,1,2,3,4,5}):
            self.assertLessEqual(m.available_build_cpus(),6)

    def test_orphan_telemetry_removal_guard(self):
        for remove in (False,True):
            stack=m.Stack(self.config('/tmp/bx-otel-test'),execute=True)
            with mock.patch.object(stack,'run',return_value=json.dumps({'remove':remove,'required_by':[]})), mock.patch.object(stack,'pip') as pip:
                stack.repair_orphan_telemetry()
                self.assertEqual(pip.call_count,int(remove))

    def test_orphan_telemetry_probe_retains_required_exporter(self):
        import importlib.metadata as metadata
        orphan=SimpleNamespace(requires=['opentelemetry-sdk~=1.45.1'],metadata={'Name':'opentelemetry-exporter-otlp-common'})
        for required in (False,True):
            parent=SimpleNamespace(requires=['opentelemetry-exporter-otlp-common; extra == "metrics"'] if required else [],metadata={'Name':'consumer'})
            with mock.patch.object(metadata,'distribution',return_value=orphan), mock.patch.object(metadata,'distributions',return_value=[orphan,parent]), mock.patch.object(metadata,'version',return_value='1.40.0'), contextlib.redirect_stdout(io.StringIO()) as out:
                exec(m.ORPHAN_OTEL_PROBE,{})
            result=json.loads(out.getvalue())
            self.assertEqual(result['remove'],not required)
            self.assertEqual(result['required_by'],['consumer'] if required else [])

    def test_absolute_distro_node_gyp_redirect(self):
        node=m.shutil.which('node')
        if not node:self.skipTest('Node.js is required for the redirect regression')
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory)
            old=root/'distro/node-gyp/bin/node-gyp.js';old.parent.mkdir(parents=True)
            old.write_text('throw new Error("Distro node-gyp must not run");')
            target=root/'managed/node-gyp/bin/node-gyp.js';target.parent.mkdir(parents=True)
            target.write_text('console.log(JSON.stringify({argv:process.argv.slice(2),main:process.argv[1]}));')
            extra=dict(m.os.environ,BX_NODE_GYP_MAIN=str(target),NODE_OPTIONS='--require='+json.dumps(str(HERE/'scripts/bx_node_gyp_redirect.cjs')))
            result=subprocess.run([node,str(old),'rebuild','--jobs=16','argument with spaces'],env=extra,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            data=json.loads(result.stdout)
            self.assertEqual(data['main'],str(target))
            self.assertEqual(data['argv'],['rebuild','--jobs=16','argument with spaces'])
            self.assertIn('BX_NODE_GYP_REDIRECT',result.stderr)
            normal=root/'ordinary.cjs';normal.write_text('console.log("ordinary-ok");')
            result=subprocess.run([node,str(normal)],env=extra,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(result.stdout.strip(),'ordinary-ok')
            self.assertNotIn('BX_NODE_GYP_REDIRECT',result.stderr)

    def test_lifecycle_probe_rejects_missing_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            stack=m.Stack(self.config(directory),execute=True)
            (stack.out/'tmp').mkdir(parents=True)
            with mock.patch.object(stack,'run'):
                with self.assertRaisesRegex(RuntimeError,'lifecycle did not select'):
                    stack.probe_opencode_lifecycle({})

    def test_opencode_managed_node_gyp(self):
        stack=m.Stack(self.config('/tmp/bx-gyp-test'))
        with mock.patch.object(stack,'run') as run:
            extra=stack.opencode_build_env()
        self.assertTrue(extra['PATH'].startswith(str(stack.out/'tools/node-gyp/node_modules/.bin')))
        self.assertEqual(extra['PYTHON'],str(stack.py))
        self.assertIn('node-gyp@10.3.1',run.call_args_list[0].args[0])
        self.assertEqual(extra['npm_config_jobs'],str(stack.max_jobs))

    def artifact_fixture(self, directory, machine='aarch64', layout='v2', elf_machine=183):
        config=self.config(directory);config['opencode_layout']=layout
        stack=m.Stack(config,True);repo=stack.src/'opencode'
        package='packages/cli' if layout=='v2' else 'packages/opencode'
        script=repo/package/'script/build.ts';script.parent.mkdir(parents=True)
        script.write_text('const binary = "lildax"; const outfile = `./dist/${name}/bin/${binary}`;' if layout=='v2' else '// V1 build fixture')
        with mock.patch.object(m.platform,'machine',return_value=machine), mock.patch.object(m.platform,'system',return_value='Linux'):
            artifact=stack.opencode_host_artifact(repo)
        artifact.parent.mkdir(parents=True)
        header=bytearray(20);header[:6]=b'\x7fELF\x02\x01';header[18:20]=elf_machine.to_bytes(2,'little')
        artifact.write_bytes(header);artifact.chmod(0o755)
        return stack,repo,artifact

    def test_v2_lildax_host_artifact_and_idempotent_link(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(m.platform,'machine',return_value='aarch64'), mock.patch.object(m.platform,'system',return_value='Linux'):
            stack,repo,artifact=self.artifact_fixture(directory)
            self.assertTrue(str(artifact).endswith('packages/cli/dist/cli-linux-arm64/bin/lildax'))
            stack.link_opencode_artifact(repo);stack.link_opencode_artifact(repo)
            self.assertEqual((stack.bin/'opencode').resolve(),artifact.resolve())

    def test_v1_host_artifact_is_retained(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(m.platform,'machine',return_value='aarch64'), mock.patch.object(m.platform,'system',return_value='Linux'):
            stack,repo,artifact=self.artifact_fixture(directory,layout='v1')
            self.assertTrue(str(artifact).endswith('packages/opencode/dist/opencode-linux-arm64/bin/opencode'))
            stack.link_opencode_artifact(repo)

    def test_artifact_rejects_wrong_arch_and_non_executable(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(m.platform,'machine',return_value='aarch64'), mock.patch.object(m.platform,'system',return_value='Linux'):
            stack,repo,artifact=self.artifact_fixture(directory,elf_machine=62)
            with self.assertRaisesRegex(RuntimeError,'ELF64'):stack.link_opencode_artifact(repo)
            header=bytearray(artifact.read_bytes());header[18:20]=(183).to_bytes(2,'little');artifact.write_bytes(header);artifact.chmod(0o644)
            with self.assertRaisesRegex(RuntimeError,'ELF64'):stack.link_opencode_artifact(repo)

    def test_artifact_missing_has_expected_path_and_preserves_existing(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(m.platform,'machine',return_value='aarch64'), mock.patch.object(m.platform,'system',return_value='Linux'):
            stack,repo,artifact=self.artifact_fixture(directory)
            artifact.unlink()
            with self.assertRaisesRegex(RuntimeError,'cli-linux-arm64/bin/lildax'):stack.link_opencode_artifact(repo)
            artifact.write_bytes(b'\x7fELF\x02\x01'+bytes(12)+(183).to_bytes(2,'little'));artifact.chmod(0o755)
            stack.bin.mkdir(parents=True);(stack.bin/'opencode').write_text('preserve me')
            with self.assertRaisesRegex(RuntimeError,'Refuse to replace'):stack.link_opencode_artifact(repo)
            self.assertEqual((stack.bin/'opencode').read_text(),'preserve me')

    def test_pinned_v2_build_source_output_contract(self):
        source=(HERE/'source_evidence/20261024/opencode_v2_build.txt').read_text()
        self.assertIn('const binary = "lildax"',source)
        self.assertIn('outfile: `./dist/${name}/bin/${binary}`',source)
        self.assertNotIn('--outdir',source)
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(m.platform,'machine',return_value='aarch64'), mock.patch.object(m.platform,'system',return_value='Linux'):
            stack,repo,artifact=self.artifact_fixture(directory)
            (repo/'packages/cli/script/build.ts').write_text(source)
            self.assertEqual(stack.opencode_host_artifact(repo),artifact)

    def test_torchvision_wrong_torch_stops_before_changes(self):
        stack=m.Stack(self.config('/tmp/bx-vision-version'),True)
        with mock.patch.object(stack,'locked'),mock.patch.object(stack,'check_torch_import'),mock.patch.object(stack,'run',return_value='2.16.0a0') as run,mock.patch.object(stack,'pip') as pip:
            with self.assertRaisesRegex(RuntimeError,'requires torch 2.13.0'):stack.build_torchvision(SimpleNamespace())
            self.assertEqual(run.call_count,1);pip.assert_not_called()

    def test_torchvision_source_build_preserves_core_and_pin(self):
        with tempfile.TemporaryDirectory() as directory:
            stack=m.Stack(self.config(directory),True)
            pin='8fb87713a24951e639c494b0f2a8a81b5f8e33a6'
            def run(command,**kwargs):
                if command[:3]==['git','rev-parse','FETCH_HEAD^{commit}']:return pin
                if '-c' in command and 'torch.__version__' in command[command.index('-c')+1]:return '2.13.0'
                return 'torch==2.13.0'
            with mock.patch.object(stack,'locked'),mock.patch.object(stack,'check_torch_import'),mock.patch.object(stack,'run',side_effect=run) as commands,mock.patch.object(stack,'pip') as pip,mock.patch.object(stack,'source_snapshot'),mock.patch.object(stack,'source_manager',return_value=SimpleNamespace(assert_repo=lambda *a:None)),mock.patch.object(stack,'check_model_imports') as check:
                stack.build_torchvision(SimpleNamespace())
            editable=pip.call_args_list[-1]
            self.assertIn('--no-deps',editable.args);self.assertIn('--no-build-isolation',editable.args)
            self.assertEqual(editable.kwargs['extra']['FORCE_CUDA'],'1')
            self.assertEqual(editable.args[-1],stack.src/'torchvision')
            self.assertEqual(json.loads((stack.out/'torchvision.source.lock.json').read_text())['commit'],pin)
            check.assert_called_once_with(include_model=False)
            self.assertTrue(any(c.args[0][:3]==['git','clone','--tags'] for c in commands.call_args_list))

    def test_torchvision_unlocked_checkout_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            stack=m.Stack(self.config(directory),True);repo=stack.src/'torchvision';repo.mkdir(parents=True);marker=repo/'instrumentation.txt';marker.write_text('retained')
            with mock.patch.object(stack,'locked'),mock.patch.object(stack,'check_torch_import'),mock.patch.object(stack,'run',return_value='2.13.0'),mock.patch.object(stack,'pip') as pip:
                with self.assertRaisesRegex(RuntimeError,'unlocked TorchVision'):stack.build_torchvision(SimpleNamespace())
                pip.assert_not_called()
            self.assertEqual(marker.read_text(),'retained')

    def test_model_preflight_checks_exact_failed_import_path(self):
        stack=m.Stack(self.config('/tmp/bx-model-probe'))
        with mock.patch.object(stack,'run') as run:stack.check_model_imports()
        command=run.call_args.args[0]
        self.assertIn('torchvision.transforms.v2',command[command.index('-c')+1])
        self.assertIn('vllm.model_executor.models.qwen3_5',command[command.index('-c')+1])
        self.assertEqual(command[-1],'1')

    def test_auto_layout_prefers_interactive_v1_when_both_exist(self):
        with tempfile.TemporaryDirectory() as directory:
            config=self.config(directory);config['opencode_layout']='auto';stack=m.Stack(config)
            for package in ('opencode','cli'):
                script=stack.src/'opencode/packages'/package/'script/build.ts';script.parent.mkdir(parents=True);script.write_text('// fixture')
            self.assertEqual(stack.opencode_layout(),'v1')
            stack.c['opencode_layout']='v2';self.assertEqual(stack.opencode_layout(),'v2')

    def test_preview_link_migration_preserves_preview_executable(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(m.platform,'machine',return_value='aarch64'), mock.patch.object(m.platform,'system',return_value='Linux'):
            stack,repo,artifact=self.artifact_fixture(directory,layout='v1')
            legacy=repo/'packages/cli/dist/cli-linux-arm64/bin/lildax';legacy.parent.mkdir(parents=True);legacy.write_text('keep preview')
            stack.bin.mkdir(parents=True);(stack.bin/'opencode').symlink_to(legacy)
            stack.link_opencode_artifact(repo)
            self.assertEqual((stack.bin/'opencode').resolve(),artifact.resolve())
            self.assertEqual((stack.bin/'opencode-v2-preview').resolve(),legacy.resolve())
            self.assertEqual(legacy.read_text(),'keep preview')
            stack.link_opencode_artifact(repo)

    def test_agent_cli_contract_rejects_preview_help(self):
        stack=m.Stack(self.config('/tmp/bx-cli-contract'),True)
        for help_text,accepted in (('lildax <subcommand> --help',False),('opencode [project] --model',True)):
            with mock.patch.object(stack,'run',return_value=help_text),mock.patch.object(stack,'write'):
                if accepted:stack.check_agent_cli()
                else:
                    with self.assertRaisesRegex(RuntimeError,'lacks interactive'):stack.check_agent_cli()
        stack.c['opencode_layout']='v2'
        with mock.patch.object(stack,'run') as run:
            with self.assertRaisesRegex(RuntimeError,'requires OpenCode V1'):stack.check_agent_cli()
            run.assert_not_called()

    def test_agent_rejects_stale_v2_provider_configuration(self):
        with tempfile.TemporaryDirectory() as directory:
            stack=m.Stack(self.config(directory),True);stack.out.mkdir(parents=True);(stack.out/'config').mkdir();(stack.out/'config/opencode.json').write_text('{"providers":{"local":{}}}')
            with mock.patch.object(stack,'check_agent_cli'),mock.patch.object(m.subprocess,'run') as run:
                with self.assertRaisesRegex(RuntimeError,'120_conf_services'):stack.agent(SimpleNamespace(project=pathlib.Path(directory)))
                run.assert_not_called()

    def test_capture_help_includes_stderr(self):
        with tempfile.TemporaryDirectory() as directory:
            stack=m.Stack(self.config(directory),True)
            output=stack.run([sys.executable,'-c','import sys; print("opencode [project] --model",file=sys.stderr)'],capture=True,merge_stderr=True)
            self.assertIn('[project]',output);self.assertIn('--model',output)

    def test_help_no_files(self):
        for stage in ('build','fetch','serve','agent','configure'):
            with tempfile.TemporaryDirectory() as t:
                r=subprocess.run([sys.executable,str(HERE/'scripts/bx_driver.py'),stage,'--help'],cwd=t,capture_output=True,text=True)
                self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(list(pathlib.Path(t).iterdir()),[])

    def test_unknown_option(self):
        r=subprocess.run([sys.executable,str(HERE/'scripts/bx_driver.py'),'fetch','--unexpected'],capture_output=True,text=True)
        self.assertEqual(r.returncode,2)

    def test_dry_run_has_no_mutations(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t)/'absent';s=m.Stack(self.config(root))
            a=SimpleNamespace(component='all',baseline=False,project=pathlib.Path(t),ref='v5.20.2')
            with contextlib.redirect_stdout(io.StringIO()),mock.patch.object(m.subprocess,'run',side_effect=AssertionError('subprocess')),mock.patch.object(m.subprocess,'Popen',side_effect=AssertionError('process')):
                for stage in ('init','preflight','install_python_dev','install_vllm_deps','align_transformers','fetch','env','build','weights','configure','verify','serve','smoke','agent'):
                    getattr(s,stage)(a)
            self.assertFalse(root.exists())

    def test_architecture_guard(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(m.platform,'machine',return_value='x86_64'),mock.patch.object(s,'run') as run:
                with self.assertRaises(RuntimeError):s.preflight(None)
                run.assert_not_called()

    def test_bad_config(self):
        for key,value in [('root','/'),('node','node2'),('cuda_arch','12.0'),('model_id','Qwen/Other'),('gpu_memory_utilization',0.95),('max_batched_tokens',128),('cache_port',8000)]:
            c=self.config('/tmp/task');c[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):m.Stack(c)

    def alignment_fixture(self,root,requirement='transformers>=5.16.1,<5.21.0',dirty=False):
        c=self.config(root);c['repos']['transformers']['ref']='main';s=m.Stack(c,True)
        config=pathlib.Path(root)/'config.json';config.write_text(json.dumps(c))
        lock={'transformers':{'url':c['repos']['transformers']['url'],'requested_ref':'main','commit':'a'*40},'pytorch':{'commit':'preserved'}}
        s.out.mkdir(parents=True);(s.out/'sources.lock.json').write_text(json.dumps(lock))
        requirements=s.src/'vllm/requirements/common.txt';requirements.parent.mkdir(parents=True);requirements.write_text(requirement+'\n')
        def run(cmd,**kwargs):
            if cmd[:2]==['git','status']:return ' M setup.py' if dirty else ''
            if cmd[:2]==['git','rev-parse']:return 'b'*40
            if cmd[:2]==['git','show']:return 'setup(version="5.20.2")'
            if str(cmd[0])==str(s.py):
                subprocess.run([sys.executable,*cmd[1:]],check=True,capture_output=True,text=True)
            return ''
        return s,SimpleNamespace(ref='v5.20.2',config=config),lock,run

    def test_alignment_updates_ref_and_lock_with_backup(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run):s.align_transformers(a)
            new=json.loads((s.out/'sources.lock.json').read_text())
            self.assertEqual(new['transformers']['commit'],'b'*40)
            self.assertEqual(new['pytorch'],old['pytorch'])
            self.assertEqual(json.loads(a.config.read_text())['repos']['transformers']['ref'],'v5.20.2')
            backup=json.loads(next((s.out/'state').glob('*.json')).read_text())
            self.assertEqual(backup['sources_lock'],old)

    def test_alignment_rejects_incompatible_release_before_checkout(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t,'transformers>=5.16.1,<5.20.0')
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run) as calls:
                with self.assertRaises(subprocess.CalledProcessError):s.align_transformers(a)
            self.assertFalse(any(x.args[0][:2]==['git','checkout'] for x in calls.call_args_list))
            self.assertEqual(json.loads((s.out/'sources.lock.json').read_text()),old)

    def test_alignment_rejects_dirty_checkout(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t,dirty=True)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run) as calls:
                with self.assertRaisesRegex(RuntimeError,'tracked local modifications'):s.align_transformers(a)
            self.assertEqual(calls.call_count,1)

    def test_alignment_rolls_back_config_write_failure(self):
        with tempfile.TemporaryDirectory() as t:
            s,a,old,run=self.alignment_fixture(t);write=s.write;failed=False
            def fail_once(path,data):
                nonlocal failed
                if path==a.config and not failed:
                    failed=True;raise OSError('simulated write failure')
                write(path,data)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',side_effect=run) as calls,mock.patch.object(s,'write',side_effect=fail_once):
                with self.assertRaisesRegex(OSError,'simulated write failure'):s.align_transformers(a)
            self.assertEqual(json.loads((s.out/'sources.lock.json').read_text()),old)
            self.assertEqual(json.loads(a.config.read_text())['repos']['transformers']['ref'],'main')
            checkouts=[x.args[0] for x in calls.call_args_list if x.args[0][:2]==['git','checkout']]
            self.assertEqual(checkouts[-1][-1],'a'*40)

    def test_python_header_probe_rejects_missing_headers(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'ensure_python_headers'),mock.patch.object(s,'build_triton_source'),mock.patch.object(s,'repair_runtime_click'),mock.patch.object(s,'repair_orphan_telemetry'),mock.patch.object(s,'pip'),mock.patch.object(s,'run',return_value='') as run:
                s.build(SimpleNamespace(component='pytorch'))
            probe=run.call_args_list[0].args[0][2]
            code='import sysconfig; sysconfig.get_path=lambda name: '+repr(t)+'; '+probe
            result=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
            self.assertIn('install python3.12-dev',result.stderr)
            for name in ('Python.h','patchlevel.h'):(pathlib.Path(t)/name).touch()
            result=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)

    def test_python_headers_auto_install_only_when_missing(self):
        s=m.Stack(self.config('/tmp/test'),True)
        for missing in ([],['/missing/Python.h']):
            with self.subTest(missing=missing),mock.patch.object(s,'missing_python_headers',return_value=missing),mock.patch.object(s,'install_python_dev') as install:
                s.ensure_python_headers()
                self.assertEqual(install.call_count,bool(missing))

    def test_apt_installer_authenticates_and_rechecks_headers(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.platform,'freedesktop_os_release',return_value={'ID':'ubuntu','VERSION_ID':'24.04'}),mock.patch.object(m.os,'geteuid',return_value=1000),mock.patch.object(m.subprocess,'run') as auth,mock.patch.object(s,'run') as run,mock.patch.object(s,'missing_python_headers',return_value=[]):
            s.install_python_dev(None)
            auth.assert_called_once_with(['sudo','-v'],check=True)
            self.assertEqual(run.call_args_list[0].args[0],['sudo','apt-get','update'])
            self.assertEqual(run.call_args_list[1].args[0],['sudo','apt-get','install','-y','--reinstall','python3.12-dev','libpython3.12-dev'])

    def test_apt_installer_rejects_other_os(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.platform,'freedesktop_os_release',return_value={'ID':'debian','VERSION_ID':'12'}),mock.patch.object(s,'run') as run:
            with self.assertRaisesRegex(RuntimeError,'Ubuntu 24.04'):s.install_python_dev(None)
            run.assert_not_called()

    def test_elf_header_install_checks_result(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'apt_dev_packages') as apt,mock.patch.object(s,'missing_elf_headers',return_value=[]):
            s.install_vllm_deps(None)
            apt.assert_called_once_with(['libdw-dev','libelf-dev'])
        with mock.patch.object(s,'apt_dev_packages'),mock.patch.object(s,'missing_elf_headers',return_value=['/usr/include/elfutils/libdwfl.h']):
            with self.assertRaisesRegex(RuntimeError,'still missing'):s.install_vllm_deps(None)

    def test_vllm_headers_only_install_if_missing(self):
        s=m.Stack(self.config('/tmp/test'),True)
        for missing in ([],['/usr/include/elfutils/libdwfl.h']):
            with self.subTest(missing=missing),mock.patch.object(s,'missing_elf_headers',return_value=missing),mock.patch.object(s,'install_vllm_deps') as install:
                s.ensure_vllm_headers()
                self.assertEqual(install.call_count,bool(missing))

    def test_vllm_header_failure_stops_before_build_helper(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'locked'),mock.patch.object(s,'check_torch_import'),mock.patch.object(s,'constraints',return_value=pathlib.Path('/tmp/constraints')),mock.patch.object(s,'pip'),mock.patch.object(s,'run') as run,mock.patch.object(s,'ensure_vllm_headers',side_effect=RuntimeError('apt failed')):
            with self.assertRaisesRegex(RuntimeError,'apt failed'):s.build(SimpleNamespace(component='vllm'))
            run.assert_not_called()

    def test_sudo_failure_does_not_run_apt(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.platform,'freedesktop_os_release',return_value={'ID':'ubuntu','VERSION_ID':'24.04'}),mock.patch.object(m.os,'geteuid',return_value=1000),mock.patch.object(m.subprocess,'run',side_effect=subprocess.CalledProcessError(1,['sudo','-v'])),mock.patch.object(s,'run') as run:
            with self.assertRaises(subprocess.CalledProcessError):s.install_python_dev(None)
            run.assert_not_called()

    def test_header_install_failure_stops_build(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'locked'),mock.patch.object(s,'missing_python_headers',return_value=['missing']),mock.patch.object(s,'install_python_dev',side_effect=RuntimeError('apt failed')),mock.patch.object(s,'pip') as pip:
            with self.assertRaisesRegex(RuntimeError,'apt failed'):s.build(SimpleNamespace(component='pytorch'))
            pip.assert_not_called()

    def test_captured_command_creates_writable_tmp_before_init(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(pathlib.Path(t)/'absent'),True)
            result=s.run([sys.executable,'-c',
                'import os,tempfile; f=tempfile.TemporaryFile(dir=os.environ["TMPDIR"]); print("ready"); f.close()'],capture=True)
            self.assertEqual(result,'ready')
            self.assertTrue((s.out/'tmp').is_dir())
            self.assertEqual(list((s.out/'tmp').iterdir()),[])

    def test_preflight_without_init(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(pathlib.Path(t)/'absent'),True)
            def probe(cmd,**kwargs):
                self.assertTrue(pathlib.Path(kwargs['env']['TMPDIR']).is_dir())
                return SimpleNamespace(stdout='GB10 sm_121')
            with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(m.subprocess,'run',side_effect=probe):
                s.preflight(None)
            self.assertTrue((s.out/'reports/preflight.json').is_file())

    def test_invalid_tmp_fails_before_subprocess(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            s.out.mkdir(parents=True);(s.out/'tmp').write_text('not a directory')
            with mock.patch.object(m.subprocess,'run') as run:
                with self.assertRaisesRegex(RuntimeError,'Cannot prepare writable TMPDIR'):
                    s.run([sys.executable,'--version'],capture=True)
                run.assert_not_called()

    def test_connector_and_hybrid_settings(self):
        s=m.Stack(self.config('/tmp/task'))
        cmd=s.server_command(False)
        connector=json.loads(cmd[cmd.index('--kv-transfer-config')+1])
        self.assertEqual(connector['kv_connector_module_path'],'lmcache.integration.vllm.lmcache_mp_connector')
        self.assertEqual(cmd[cmd.index('--mamba-cache-mode')+1],'align')
        self.assertIn('--separate-object-groups',s.cache_command())
        self.assertNotIn('--kv-transfer-config',s.server_command(True))

    def test_config_v2_and_no_project_write(self):
        with tempfile.TemporaryDirectory() as t:
            config=self.config(t);config['opencode_layout']='v2'
            s=m.Stack(config,True);s.configure(None)
            c=json.loads((s.out/'config/opencode.json').read_text())
            self.assertIn('providers',c);self.assertNotIn('provider',c)
            self.assertEqual(c['model'],'local/qwen-local')
            self.assertFalse((pathlib.Path(t)/'opencode.json').exists())

    def test_stable_opencode_uses_v1_provider_schema(self):
        with tempfile.TemporaryDirectory() as t:
            c=self.config(t);c['opencode_layout']='v1'
            s=m.Stack(c,True);s.configure(None)
            config=json.loads((s.out/'config/opencode.json').read_text())
            self.assertNotIn('providers',config)
            self.assertEqual(config['provider']['local']['npm'],'@ai-sdk/openai-compatible')
            self.assertTrue(config['provider']['local']['models']['qwen-local']['tool_call'])

    def test_source_fetch_plan_has_full_history_tags_and_no_partial_clone(self):
        s=m.Stack(self.config('/tmp/test'))
        with contextlib.redirect_stdout(io.StringIO()) as out:s.fetch(None)
        self.assertIn('git clone --tags',out.getvalue())
        self.assertNotIn('--depth',out.getvalue());self.assertNotIn('--filter',out.getvalue())

    def test_pytorch_plan_uses_triton_source_instead_of_make_wheel_recipe(self):
        s=m.Stack(self.config('/tmp/test'))
        with contextlib.redirect_stdout(io.StringIO()) as out:s.build(SimpleNamespace(component='pytorch'))
        self.assertIn('BUILD matching Triton from source',out.getvalue())
        self.assertNotIn('make triton',out.getvalue())

    def test_locked_triton_source_build_keeps_instrumentation(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True);pin='a'*40
            pinfile=s.src/'pytorch/.ci/docker/ci_commit_pins/triton.txt'
            pinfile.parent.mkdir(parents=True);pinfile.write_text(pin+'\n')
            repo=s.src/'triton';repo.mkdir();(repo/'pyproject.toml').write_text('[build-system]\nrequires=["setuptools"]\n')
            instrument=repo/'trace.cpp';instrument.write_text('instrumentation retained\n')
            s.out.mkdir(parents=True);(s.out/'triton.source.lock.json').write_text(json.dumps({'commit':pin}))
            with mock.patch.object(s,'source_manager',return_value=SimpleNamespace(assert_repo=lambda *args:None)),mock.patch.object(s,'source_snapshot'),mock.patch.object(s,'git_identity') as identity,mock.patch.object(s,'run',return_value='torch==2.13.0') as run,mock.patch.object(s,'pip') as pip:
                s.build_triton_source()
                identity.assert_called_once_with(repo,pin)
                self.assertFalse(any(call.args[0][:2]==['git','checkout'] for call in run.call_args_list))
                self.assertEqual(pip.call_args_list[-1].args[-2:],('-e',repo))
            self.assertEqual(instrument.read_text(),'instrumentation retained\n')

    def test_source_lock_mismatch(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(s,'run',return_value='different'):
                with self.assertRaises(RuntimeError):s.git_identity(pathlib.Path(t),'expected')

    def test_changed_default_config_cannot_relabel_existing_sources(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True);s.out.mkdir(parents=True)
            lock={name:{'url':entry['url'],'requested_ref':entry['ref'],'commit':'a'*40} for name,entry in s.c['repos'].items()}
            lock['pytorch']['requested_ref']='main'
            (s.out/'sources.lock.json').write_text(json.dumps(lock))
            with mock.patch.object(m.platform,'machine',return_value='aarch64'),mock.patch.object(s,'git_identity') as identity:
                with self.assertRaisesRegex(RuntimeError,'Config differs'):s.locked()
                identity.assert_not_called()

    def test_broken_torch_stops_vllm_before_dependency_changes(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'locked'),mock.patch.object(s,'check_torch_import',side_effect=RuntimeError('missing torch.version')),mock.patch.object(s,'pip') as pip,mock.patch.object(s,'run') as run:
            with self.assertRaisesRegex(RuntimeError,'missing torch.version'):
                s.build(SimpleNamespace(component='vllm'))
            pip.assert_not_called();run.assert_not_called()

    def test_pytorch_forces_python_build_and_requires_import_before_triton(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'locked'),mock.patch.object(s,'ensure_python_headers'),mock.patch.object(s,'run',return_value='') as run,mock.patch.object(s,'pip') as pip,mock.patch.object(s,'check_torch_import',side_effect=RuntimeError('broken editable')):
            with self.assertRaisesRegex(RuntimeError,'broken editable'):
                s.build(SimpleNamespace(component='pytorch'))
            editable=next(call for call in pip.call_args_list if '-e' in call.args)
            self.assertIn('-Ccmake.define.BUILD_PYTHON=ON',editable.args)
            self.assertIn('-Ccmake.define.Python_EXECUTABLE='+str(s.py),editable.args)
            self.assertFalse(any(call.args[0]==['make','triton'] for call in run.call_args_list))

    def test_spin_removed_without_click_cap_and_core_pins_retained(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            with mock.patch.object(s,'locked'),mock.patch.object(s,'run',return_value='torch==2.16.0'),mock.patch.object(s,'repair_orphan_telemetry'),mock.patch.object(s,'pip') as pip:
                s.build(SimpleNamespace(component='transformers'))
            constraints=(s.out/'core-constraints.txt').read_text()
            self.assertIn('torch==2.16.0',constraints)
            self.assertNotIn('click',constraints)
            self.assertEqual(pip.call_args_list[0].args,('uninstall','-y','spin'))
            self.assertIn(s.out/'core-constraints.txt',pip.call_args_list[1].args)

    def test_click_probe_uses_installed_requirements_and_active_markers(self):
        namespace={}
        distributions=[SimpleNamespace(requires=['click>=8.4.2,<9', 'click<8; extra == "docs"', 'packaging>=20']),SimpleNamespace(requires=None)]
        import importlib.metadata
        with mock.patch.object(importlib.metadata,'distributions',return_value=distributions),contextlib.redirect_stdout(io.StringIO()) as out:
            exec(m.CLICK_RUNTIME_PROBE,namespace)
        self.assertEqual(json.loads(out.getvalue()),['click<9,>=8.4.2'])

    def test_click_repair_installs_observed_runtime_requirement(self):
        s=m.Stack(self.config('/tmp/test'),True)
        with mock.patch.object(s,'run',return_value='["click<9,>=8.4.2"]'),mock.patch.object(s,'pip') as pip:
            s.repair_runtime_click()
            pip.assert_called_once_with('install','click<9,>=8.4.2')

    def test_offline_pip_resolves_hub_after_spin_removal(self):
        # Synthetic metadata reproduces the reported ranges, without network/GPU.
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);wheels=root/'wheels';wheels.mkdir()
            def wheel(name,version,requirements=()):
                dist=name+'-'+version+'.dist-info'
                files={dist+'/METADATA':'Metadata-Version: 2.1\nName: '+name+'\nVersion: '+version+'\n'+''.join('Requires-Dist: '+r+'\n' for r in requirements),
                       dist+'/WHEEL':'Wheel-Version: 1.0\nGenerator: regression-fixture\nRoot-Is-Purelib: true\nTag: py3-none-any\n'}
                files[dist+'/RECORD']=''.join(n+',,\n' for n in [*files,dist+'/RECORD'])
                with zipfile.ZipFile(wheels/(name+'-'+version+'-py3-none-any.whl'),'w') as z:
                    for n,data in files.items():z.writestr(n,data)
            wheel('click','8.3.3');wheel('click','8.5.0')
            wheel('spin','0.18',('click>=8,<8.4,!=8.3.0',))
            wheel('huggingface_hub','2.2.0',('click>=8.4.2,<9',))
            wheel('transformers','5.21.0',('huggingface_hub>=1.31,<3',))
            wheel('torch','2.16.0')
            subprocess.run([sys.executable,'-m','venv','--without-pip',str(root/'venv')],check=True,capture_output=True)
            pip=[sys.executable,'-m','pip','--isolated','--python',str(root/'venv/bin/python'),'--disable-pip-version-check','--no-cache-dir']
            def invoke(*args):return subprocess.run([*pip,*args],capture_output=True,text=True)
            options=['--no-index','--find-links',str(wheels)]
            result=invoke('install',*options,'spin==0.18','torch==2.16.0')
            self.assertEqual(result.returncode,0,result.stderr)
            constraint=root/'constraints.txt';constraint.write_text('torch==2.16.0\nclick>=8,<8.4,!=8.3.0\n')
            result=invoke('install',*options,'-c',str(constraint),'transformers')
            self.assertNotEqual(result.returncode,0)
            self.assertIn('ResolutionImpossible',result.stderr)
            self.assertEqual(invoke('uninstall','-y','spin').returncode,0)
            constraint.write_text('torch==2.16.0\n')
            result=invoke('install',*options,'-c',str(constraint),'transformers')
            self.assertEqual(result.returncode,0,result.stderr)
            result=invoke('check');self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            # Re-running the PyTorch dev group can reintroduce the old Click.
            result=invoke('install',*options,'spin==0.18')
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(invoke('uninstall','-y','spin').returncode,0)
            self.assertNotEqual(invoke('check').returncode,0)
            import importlib.metadata
            site=next((root/'venv/lib').glob('python*/site-packages'))
            installed=list(importlib.metadata.distributions(path=[str(site)]))
            with mock.patch.object(importlib.metadata,'distributions',return_value=installed),contextlib.redirect_stdout(io.StringIO()) as out:
                exec(m.CLICK_RUNTIME_PROBE,{})
            requirements=json.loads(out.getvalue())
            result=invoke('install',*options,*requirements)
            self.assertEqual(result.returncode,0,result.stderr)
            result=invoke('check');self.assertEqual(result.returncode,0,result.stdout+result.stderr)

    def test_fetch_ref_drift(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            s.out.mkdir(parents=True)
            (s.out/'sources.lock.json').write_text(json.dumps({'pytorch':{'url':'https://wrong','requested_ref':'main','commit':'x'}}))
            with self.assertRaises(RuntimeError):s.fetch(None)

    def test_readiness_process_exit(self):
        with self.assertRaises(RuntimeError):m.Stack.wait_url('http://127.0.0.1:1',[SimpleNamespace(poll=lambda:1)],10)

    def test_model_clone_without_partial_filter_and_deferred_weights(self):
        with tempfile.TemporaryDirectory() as t:
            c=self.config(t);c['repos']={}
            s=m.Stack(c,True)
            with mock.patch.object(s,'run',return_value='a'*40) as run:
                s.fetch(None)
            calls=run.call_args_list
            clone=calls[0]
            self.assertEqual(clone.args[0][:3],['git','clone','--tags'])
            self.assertNotIn('--depth',clone.args[0])
            self.assertFalse(any(str(x).startswith('--filter') for x in clone.args[0]))
            self.assertEqual(clone.kwargs['extra']['GIT_LFS_SKIP_SMUDGE'],'1')
            checkout=next(x for x in calls if x.args[0][:2]==['git','checkout'])
            self.assertEqual(checkout.kwargs['extra']['GIT_LFS_SKIP_SMUDGE'],'1')
            self.assertFalse(any(x.args[0][:3]==['git','lfs','pull'] for x in calls))
            lock=json.loads((s.out/'sources.lock.json').read_text())
            self.assertEqual(lock['model']['commit'],'a'*40)

    def test_model_checkout_failure_preserves_completed_locks(self):
        with tempfile.TemporaryDirectory() as t:
            c=self.config(t);c['repos']={};s=m.Stack(c,True)
            previous={'pytorch':{'commit':'completed'}}
            s.out.mkdir(parents=True)
            lockfile=s.out/'sources.lock.json';lockfile.write_text(json.dumps(previous))
            def command(cmd,**kwargs):
                if cmd[:2]==['git','checkout']:raise RuntimeError('simulated checkout failure')
                return ''
            with mock.patch.object(s,'run',side_effect=command),self.assertRaisesRegex(RuntimeError,'simulated checkout failure'):
                s.fetch(None)
            self.assertEqual(json.loads(lockfile.read_text()),previous)

    def test_readiness_http_success(self):
        response=mock.MagicMock();response.__enter__.return_value.status=200
        with mock.patch.object(m.urllib.request,'urlopen',return_value=response):
            m.Stack.wait_url('http://127.0.0.1:1',[],1)

    def test_smoke_rejects_plain_text(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            response=mock.MagicMock();response.__enter__.return_value=io.StringIO(json.dumps({'choices':[{'message':{'content':'I will inspect it'}}]}))
            with mock.patch.object(m.urllib.request,'urlopen',return_value=response),self.assertRaises(RuntimeError):s.smoke(None)

    def test_smoke_structured_arguments(self):
        with tempfile.TemporaryDirectory() as t:
            s=m.Stack(self.config(t),True)
            data={'choices':[{'message':{'tool_calls':[{'function':{'name':'inspect_project','arguments':'{"path":"."}'}}]}}]}
            response=mock.MagicMock();response.__enter__.return_value=io.StringIO(json.dumps(data))
            with mock.patch.object(m.urllib.request,'urlopen',return_value=response):s.smoke(None)
            self.assertEqual(json.loads((s.out/'reports/api_smoke.json').read_text())['lmcache_hit'],'NOT_VERIFIED')

    def test_english_scripts(self):
        for p in HERE.rglob('*'):
            if p.suffix in ('.py','.json','.mmd') and '__pycache__' not in p.parts:
                self.assertFalse(any('\u3400'<=ch<='\u9fff' or '\uac00'<=ch<='\ud7af' for ch in p.read_text()),str(p))


class ShellDispatch(unittest.TestCase):
    def invoke(self,*args,env=None):
        return subprocess.run(['bash',str(HERE/'bx_ai_coding_setup.sh'),*args],capture_output=True,text=True,env=env)

    def test_shell_help_without_python(self):
        import os
        env=dict(os.environ,BX_SETUP_PYTHON='/not/a/python')
        for args in [('--help',),('030_conf_env','--help'),('140_serve_stack','-h')]:
            r=self.invoke(*args,env=env);self.assertEqual(r.returncode,0,r.stderr)
            self.assertIn('040_download_src',r.stdout)

    def test_help_numbering_and_terminal_guidance_without_python(self):
        import os,re
        env=dict(os.environ,BX_SETUP_PYTHON='/not/a/python')
        result=self.invoke('--help',env=env)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertTrue(result.stdout.isascii())
        listed=re.findall(r'^  ([0-9]{3}[a-z]?_[a-z_]+)\s',result.stdout.split('\nOPTIONS\n')[0],re.M)
        normal=[name for name in listed if re.match(r'^[0-9]{3}_',name)]
        self.assertEqual([int(name[:3]) for name in normal],list(range(10,170,10)))
        self.assertEqual(len(listed),24)
        for name in listed:
            help_result=self.invoke(name,'--help','--execute',env=env)
            self.assertEqual(help_result.returncode,0,help_result.stderr)
            self.assertEqual(help_result.stdout,result.stdout)
        for phrase in ('Terminal A','Terminal B','API READY','NEVER run 140 and 140a concurrently','Ctrl-C','same terminal','SAME --config','always runs tests'):
            self.assertIn(phrase,result.stdout)

    def test_all_numbered_commands_dispatch_to_expected_internal_functions(self):
        import os
        expected={
            '150a_profile':['profile'],'010_check_host':['preflight'],'020_prepare_system':['prepare_system'],
            '030_conf_env':['init','env'],'040_download_src':['fetch'],
            '050_build_pytorch':['build --component pytorch'],
            '060_build_transformers':['build --component transformers'],
            '070_build_torchvision':['build_torchvision'],
            '080_build_vllm':['build --component vllm'],
            '090_build_lmcache':['build --component lmcache'],
            '100_build_opencode':['build --component opencode'],
            '110_download_weights':['weights'],'120_conf_services':['configure'],
            '130_verify_build':['verify'],'140_serve_stack':['serve'],
            '150_test_api':['smoke'],'160_run_agent':['agent'],
            '010a_validate_scripts':['validate'],'020a_repair_python_dev':['install_python_dev'],
            '020b_repair_vllm_deps':['install_vllm_deps'],'040a_preserve_sources':['preserve_sources'],
            '040b_prepare_stable':['prepare_stable'],'060a_align_transformers':['align_transformers'],
            '140a_serve_baseline':['serve --baseline']}
        with tempfile.TemporaryDirectory() as directory:
            fake=pathlib.Path(directory)/'fake-python'
            fake.write_text('#!'+sys.executable+'\n# BUILD_ID="'+m.BUILD_ID+'"\nimport sys,json; print(json.dumps(sys.argv[1:]))\n');fake.chmod(0o755)
            env=dict(os.environ,BX_SETUP_PYTHON=str(fake))
            for name,calls in expected.items():
                with self.subTest(name=name):
                    result=self.invoke('--config','/tmp/bx-profile.json',name,env=env)
                    self.assertEqual(result.returncode,0,result.stderr)
                    observed=[json.loads(line) for line in result.stdout.splitlines()]
                    self.assertEqual([row[3:] for row in observed],[call.split() for call in calls])
                    self.assertTrue(all(row[1:3]==['--config','/tmp/bx-profile.json'] for row in observed))

    def test_legacy_commands_are_rejected_with_replacements(self):
        import os
        mapping=json.loads((HERE/'configs/command_migration_r18.json').read_text())['old_to_new']
        env=dict(os.environ,BX_SETUP_PYTHON='/not/a/python')
        for old,new in mapping.items():
            with self.subTest(old=old):
                result=self.invoke(old,'--execute',env=env)
                self.assertEqual(result.returncode,2)
                self.assertIn(new,result.stderr)
                self.assertIn('No work was performed',result.stderr)
                self.assertEqual(result.stdout,'')

    def test_prepare_system_plan_includes_both_dependency_groups(self):
        result=self.invoke('020_prepare_system')
        self.assertEqual(result.returncode,0,result.stderr)
        for package in ('python3.12-dev','libpython3.12-dev','libdw-dev','libelf-dev'):
            self.assertIn(package,result.stdout)

    def test_shell_unknown_command(self):
        self.assertEqual(self.invoke('020_typo').returncode,2)

    def test_shell_python_dev_plan_and_help(self):
        r=self.invoke('020a_repair_python_dev')
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('apt-get install',r.stdout)
        self.assertIn('python3.12-dev',r.stdout)
        r=self.invoke('020a_repair_python_dev','--help','--execute')
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('Usage:',r.stdout)

    def test_shell_vllm_deps_plan(self):
        r=self.invoke('020b_repair_vllm_deps')
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('libdw-dev',r.stdout);self.assertIn('libelf-dev',r.stdout)

    def test_shell_missing_config(self):
        self.assertEqual(self.invoke('--config').returncode,2)

    def test_shell_source_build_dispatch(self):
        r=self.invoke('080_build_vllm');self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('tools/use_existing_torch.py',r.stdout)
        self.assertIn('--no-build-isolation',r.stdout)
        self.assertNotIn('pip install vllm',r.stdout)

    def test_shell_init_invalid_option_no_side_effect(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t)/'untouched';cfg=json.loads((HERE/'configs/stack.json').read_text());cfg['root']=str(root)
            p=pathlib.Path(t)/'config.json';p.write_text(json.dumps(cfg))
            r=self.invoke('--config',str(p),'030_conf_env','--unexpected','--execute')
            self.assertEqual(r.returncode,2);self.assertFalse(root.exists())

    def test_shell_foreground_and_agent_dispatch(self):
        r=self.invoke('140a_serve_baseline');self.assertEqual(r.returncode,0,r.stderr)
        self.assertNotIn('--kv-transfer-config',r.stdout)
        r=self.invoke('140_serve_stack');self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('LMCacheMPConnector',r.stdout)
        self.assertIn('lmcache server',r.stdout)
        r=self.invoke('160_run_agent','--project','/tmp/example project');self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('/tmp/example project',r.stdout)

if __name__=='__main__':unittest.main()
