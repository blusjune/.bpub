# BUILD_ID="BMJ_20261025_230849"
"""CPU-only Docker command, path and ownership regression tests."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bx_docker', HERE / 'scripts/bx_docker.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class DockerTests(unittest.TestCase):
    def instance(self, directory, command='040_serve_stack', execute=False):
        root = Path(directory) / 'real root'
        root.mkdir(exist_ok=True)
        alias = Path(directory) / 'alias root'
        if not alias.exists():
            alias.symlink_to(root, target_is_directory=True)
        config = json.loads((HERE / 'configs/stack.json').read_text())
        config['root'] = str(alias)
        path = Path(directory) / 'stack.json'
        path.write_text(json.dumps(config))
        args = m.parser().parse_args([command, '--config', str(path), '--project', str(root / 'project')])
        args.execute = execute
        return m.Docker(args)

    def test_real_and_alias_paths_are_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp)
            mounts = d.mounts(True)
            text = '\n'.join(mounts)
            self.assertIn('dst=' + str(d.root), text)
            self.assertIn('dst=' + str(d.root.resolve()), text)
            self.assertIn('src=' + str(d.root.resolve()), text)
            self.assertIn(',readonly', text)

    def test_runtime_gpu_uid_network_and_signal(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp)
            with mock.patch.object(d, 'run') as run:
                d.launch('stack')
            cmd = run.call_args.args[0]
            self.assertEqual(cmd[cmd.index('--gpus') + 1], 'all')
            self.assertEqual(cmd[cmd.index('--user') + 1], f'{os.getuid()}:{os.getgid()}')
            self.assertEqual(cmd[cmd.index('--stop-signal') + 1], 'SIGINT')
            self.assertIn('--init', cmd)
            self.assertNotIn('--privileged', cmd)
            self.assertNotIn('--pid', cmd)
            self.assertNotIn('/var/run/docker.sock', ' '.join(cmd))
            self.assertIn('--network', cmd)

    def test_dry_run_never_calls_docker(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp)
            with mock.patch.object(m.subprocess, 'run', side_effect=AssertionError('executed')), contextlib.redirect_stdout(io.StringIO()) as output:
                d.dispatch([])
            self.assertIn('docker run', output.getvalue())
            self.assertFalse((d.root / 'deliverables').exists())

    def test_profile_server_actions_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, '050a_profile')
            with mock.patch.object(d, 'execute_in') as run, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    d.dispatch(['--action', 'serve-nsys'])
                run.assert_not_called()

    def test_foreign_container_cannot_be_stopped(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, '070_stop', True)
            fake = [{'Config': {'Labels': {}}, 'State': {'Running': True}}]
            with mock.patch.object(d, 'local_daemon'), mock.patch.object(d, 'run', return_value=json.dumps(fake)) as run:
                with self.assertRaisesRegex(RuntimeError, 'ownership'):
                    d.dispatch([])
                self.assertEqual(run.call_count, 1)
                self.assertEqual(run.call_args.args[0][:2], ['docker', 'inspect'])

    def test_changed_config_cannot_exec(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, '050_test_api', True)
            fake = [{'Config': {'Labels': {m.OWNER: 'bx-ai-coding-r20', m.IDENTITY: 'wrong'}}, 'State': {'Running': True}}]
            with mock.patch.object(d, 'run', return_value=json.dumps(fake)):
                with self.assertRaisesRegex(RuntimeError, 'mismatch'):
                    d.owned()

    def test_owned_container_stop(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, '070_stop', True)
            fake = [{'Config': {'Labels': {m.OWNER: 'bx-ai-coding-r20', m.IDENTITY: d.key}}, 'State': {'Running': True}}]
            with mock.patch.object(d, 'local_daemon'), mock.patch.object(d, 'run', return_value=json.dumps(fake)) as run:
                d.dispatch([])
                self.assertEqual(run.call_args.args[0], ['docker', 'stop', '--time', '60', 'bx-ai-coding'])

    def test_remote_daemon_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, execute=True)
            with mock.patch.object(m.platform, 'machine', return_value='aarch64'), mock.patch.dict(os.environ, {'DOCKER_HOST': 'ssh://other-host'}), mock.patch.object(d, 'run') as run:
                with self.assertRaisesRegex(RuntimeError, 'local Unix'):
                    d.local_daemon()
                run.assert_not_called()

    def test_architecture_guard(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, execute=True)
            with mock.patch.object(m.platform, 'machine', return_value='x86_64'):
                with self.assertRaisesRegex(RuntimeError, 'aarch64'):
                    d.local_daemon()

    def test_missing_runtime_prevents_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, execute=True)
            with mock.patch.object(d, 'run') as run:
                with self.assertRaisesRegex(RuntimeError, 'source installation'):
                    d.launch('stack')
                run.assert_not_called()

    def test_missing_project_prevents_docker_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, execute=True)
            with self.assertRaisesRegex(RuntimeError, 'missing'):
                d.mounts(True)

    def test_dangerous_mount_paths_refused(self):
        for path in ('/', 'relative', '/tmp/a,b', '/tmp/a\nb'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                m.absolute(path)

    def test_command_arguments_not_shell_interpolated(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, execute=True)
            cmd = ['docker', 'exec', 'container', 'literal;$(touch /tmp/not-created)']
            with mock.patch.object(m.subprocess, 'run', return_value=subprocess.CompletedProcess(cmd, 0)) as run:
                d.run(cmd)
                self.assertEqual(run.call_args.args[0][-1], cmd[-1])
                self.assertNotIn('shell', run.call_args.kwargs)

    def test_help_in_english_and_no_docker(self):
        p = subprocess.run(['/bin/bash', str(HERE / 'bx_ai_coding_docker.sh'), '--help'], capture_output=True, text=True)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertTrue(p.stdout.isascii())
        for phrase in ('Terminal A', 'Terminal B', '040a_serve_baseline', '050a_profile', '--execute'):
            self.assertIn(phrase, p.stdout)

    def test_entrypoint_verifies_before_exec(self):
        text = (HERE / 'docker/bx_container_entry.sh').read_text()
        self.assertLess(text.rindex('130_verify_build'), text.index('exec "$bx_root/venvs'))
        self.assertIn('serve --execute', text)

    def test_agent_refuses_unmounted_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, '060_run_agent', True)
            fake = [{'Config': {'Labels': {m.OWNER: 'bx-ai-coding-r20', m.IDENTITY: d.key}},
                     'State': {'Running': True}, 'Mounts': []}]
            with mock.patch.object(d, 'local_daemon'), mock.patch.object(d, 'run', return_value=json.dumps(fake)) as run:
                with self.assertRaisesRegex(RuntimeError, 'Project was not mounted'):
                    d.dispatch([])
                self.assertEqual(run.call_count, 1)


    def test_alias_to_host_root_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp)
            alias = Path(tmp) / 'danger'
            alias.symlink_to('/', target_is_directory=True)
            d.a.extra_mount = [alias]
            with self.assertRaisesRegex(ValueError, 'root filesystem'):
                d.mounts(False)

    def test_context_override_takes_precedence_over_docker_host(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = self.instance(tmp, execute=True)
            with mock.patch.object(m.platform, 'machine', return_value='aarch64'), mock.patch.dict(os.environ, {'DOCKER_HOST': 'unix:///local.sock', 'DOCKER_CONTEXT': 'remote'}), mock.patch.object(d, 'run', return_value='ssh://remote') as run:
                with self.assertRaisesRegex(RuntimeError, 'local Unix'):
                    d.local_daemon()
                self.assertIn('remote', run.call_args.args[0])
