# AI Coding 환경: Source 보존 및 Stable Version 정합성

BUILD_ID: BMJ_20261024_095412  
검토 기준: 2026-10-24 KST

## 결론과 검증 수준

이 revision은 tracing/profiling instrumentation에 필요한 원본 source tree, Git metadata, tag, commit, 로컬 수정 내용을 보존합니다. 기존 환경의 source HEAD와 가상환경을 전환하지 않고, 안정 릴리스 조합을 별도 worktree 및 venv profile에 준비할 수 있습니다.

개별 프로젝트의 latest stable을 모두 선택하는 것과 호환되는 stable 조합을 선택하는 것은 다릅니다. vLLM 및 LMCache의 실제 source metadata를 우선해 PyTorch와 Transformers 버전을 맞췄습니다. 이 조합은 dependency baseline 후보입니다. 전체 transitive dependency resolver, DGX Spark native build/ABI, Qwen3.8-27B의 cold/warm/cross-process KV transfer는 아직 검증하지 않았습니다. LMCache 공식 문서도 모든 model/connector/device/backend에 통용되는 단일 version pair가 없다고 명시합니다.

## 검토한 안정 조합

| 구성요소 | 선택한 source tag | 개별 latest stable | 선택 이유 |
| --- | --- | --- | --- |
| PyTorch | v2.13.0 | v2.14.1 | vLLM/LMCache의 공통 build-time torch==2.13.0 기준 |
| Transformers | v5.19.0 | v5.20.2 | stable vLLM의 >=5.16.1,<5.20.0 범위 안에서 확인한 최신 stable release |
| vLLM | v0.32.0 | v0.32.0 | 검토 시점 latest stable |
| LMCache | v0.5.6 | v0.5.6 | 검토 시점 latest stable, 동일 PyTorch 기준 source build |
| OpenCode | v1.19.4 | v1.19.4 | HTTP API로 연결하는 독립 client; 해당 tag의 Bun 1.4.4 요구 |
| Triton | PyTorch pin commit | 별도 latest를 선택하지 않음 | v2.13.0의 pin 5d6048aa0a324e090ada215b609ea76620133845, version baseline 3.7.1 |

`configs/stable_matrix_20261024.json`에 각 release의 full commit SHA와 tag object ID, 근거 URL 및 검증 상태를 저장했습니다. `017` 단계는 실제 fetch한 tag commit이 이 기록과 다르면 중단합니다. branch main/dev 및 release name만 기록하는 방식으로는 source 재현성을 확보할 수 없습니다.

Qwen 문서 저장소 및 Hugging Face 모델에는 없는 stable tag를 만들어 붙이지 않습니다. 실제 commit SHA 및 Git LFS object 기록을 보존합니다. 모델 weight는 data이며, 실제 추론 구현 source는 해당 버전의 Transformers/vLLM tree에 있습니다.

LMCache의 NumPy cap과 vLLM/LMCache의 protobuf 범위도 안정 profile의 공통 constraints에 반영했습니다. NumPy 2.2.6을 native build 전에 선택해 뒤늦은 header/runtime 버전 변경을 줄입니다. 이 직접 요구사항의 교집합 확인이 전체 dependency solve 성공을 의미하지는 않습니다.

## Source와 Git metadata 보존

새 `040_download_src`는 `--depth 1`과 `--filter=blob:none`을 사용하지 않습니다. 일반 full clone과 tag fetch를 사용합니다. HF 모델은 `GIT_LFS_SKIP_SMUDGE=1`로 metadata를 받으며 weight materialization은 `080`에 남겨둡니다.

기존 환경에는 `040a_preserve_sources`를 사용합니다. offline 모드는 현재 상태만 기록하며, full 모드는 shallow 이력을 보완하고 partial clone의 Git objects를 다시 fetch합니다. 원래 HEAD, branch/worktree, staged/unstaged 변경은 전환하지 않습니다. reset/clean/stash 및 tag 강제 갱신이나 tag pruning을 수행하지 않습니다.

보존 정보:

- source의 논리/실제 경로 및 Git directory;
- HEAD commit, git describe, HEAD를 가리키는 tag;
- tag object SHA/type 및 annotated tag의 peeled object;
- staged/unstaged binary patch를 각각 별도 파일로 저장;
- Git이 ignore하지 않는 untracked 파일 archive;
- recursive submodule commit과 `.deps` 경로/가능한 Git commit;
- snapshot 파일 SHA-256;
- model Git LFS 파일/object 목록;
- `refs/bx/retained/<HEAD>` ref로 기존 commit의 도달 가능성 보존.

snapshot 경로는 `ROOT/deliverables/ai_coding/source_snapshots/<timestamp>/`입니다. 빌드 전후에도 해당 component의 source 상태를 기록합니다. 실패한 빌드는 원본 source와 pre-build snapshot을 남깁니다. 전체 `.deps` source는 source directory 안에 유지됩니다. ignore된 파일은 원위치에 남지만 untracked archive에 복사하지 않습니다.

`--bundle`은 Git 객체와 tag의 검증된 bundle을 추가합니다. LFS 실제 weight, 독립 `.deps` Git database, submodule object database까지 하나의 parent bundle에 포함되는 것은 아닙니다. 완전한 이동형 백업에는 각 저장소 bundle 및 LFS data가 별도로 필요합니다. worktree는 원래 저장소의 `.git` database를 참조하므로 base repository를 유지해야 합니다.

GitHub에서 받은 upstream source 자체에는 BUILD_ID를 삽입하지 않습니다. 원본 내용을 변경하면 tag/commit hash와의 관계를 흐리기 때문입니다. 이 패키지가 관리하는 controller/test script에만 KST 기준 BUILD_ID 주석을 넣습니다.

## 기존 설치본에 적용

기존 `configs/stack.json`, source tree 및 source lock을 보존합니다. ZIP 전체를 덮어쓰면 새 stable 기본 config가 기존 개발 checkout을 가리키게 될 수 있으므로 controller/scripts/tests와 stable matrix만 선택적으로 갱신합니다. source lock과 config ref가 다르면 빌드를 중단하도록 guard도 추가했습니다.

```bash
bx_package="$HOME/Downloads/ai_coding_source_package.zip"
unzip -o "$bx_package" 'ai_coding_source/bx_ai_coding_setup.sh' 'ai_coding_source/scripts/*' 'ai_coding_source/tests/*' 'ai_coding_source/configs/stable_matrix_20261024.json' -d /opt/work/ai_coding

cd /opt/work/ai_coding/ai_coding_source
./bx_ai_coding_setup.sh 040a_preserve_sources --offline --execute
./bx_ai_coding_setup.sh 040a_preserve_sources --execute
```

full history/tag 복구는 기존 shallow clone보다 전송량과 저장량이 커집니다. metadata만 보존하면 되는 시점에는 offline snapshot을 먼저 만들 수 있습니다. 이 코드 작성 환경에서 사용자의 Spark에 직접 명령을 실행한 것은 아닙니다.

## 별도 Stable Profile 생성

```bash
./bx_ai_coding_setup.sh 040b_prepare_stable --profile-name stable_20261024 --execute
```

생성 위치:

| 항목 | 경로 |
| --- | --- |
| 기존 source | /opt/work/ai_coding/root/src/<component> |
| stable source worktree | /opt/work/ai_coding/root/src/profiles/stable_20261024/<component> |
| stable config | /opt/work/ai_coding/root/profiles/stable_20261024/stack.json |
| stable venv | /opt/work/ai_coding/root/profiles/stable_20261024/venvs/stack |
| stable build/report | /opt/work/ai_coding/root/profiles/stable_20261024/deliverables/ai_coding |
| 기존 model data | 기존 model_path 재사용, 기존 model commit lock 유지 |

`017`은 기존 source의 HEAD와 로컬 수정을 바꾸지 않습니다. exact tag/commit 및 critical dependency edge를 검증한 다음 별도 worktree를 만듭니다. submodule 준비가 중단되면 동일한 plan으로 재시도할 수 있습니다. 이미 완료된 profile이나 변경된 부분 작업을 자동으로 덮어쓰지 않습니다.

stable profile을 사용할 때에는 이후 모든 단계에 같은 `--config`를 지정해야 합니다.

```bash
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 030_conf_env --execute
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 050_build_pytorch --execute
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 060_build_transformers --execute
./bx_ai_coding_setup.sh --config /opt/work/ai_coding/root/profiles/stable_20261024/stack.json 080_build_vllm --execute
```

이 요청에서는 현재 `090_build_lmcache` 오류를 조사하거나 수정하지 않았습니다. 기존 오류는 다음 요청에서 별도 분석합니다.

## Build와 instrumentation의 관계

PyTorch/Transformers/vLLM/LMCache는 로컬 source editable 설치를 유지합니다. 컴파일된 `_C` 등은 build/install 경로에 있고 Python 파일은 source tree에 있을 수 있으므로 manifest의 실제 경로를 함께 확인합니다. `100`은 선택한 source_root에서 import되는지도 검사합니다.

이전 `make triton`은 PyTorch wheel index에서 바이너리 Triton을 설치했습니다. 새 코드에서는 해당 PyTorch가 지정한 commit의 Triton 저장소를 `source_root/triton`에 남기고 source build합니다. 동일 pin의 로컬 instrumentation 수정은 유지합니다. LLVM 등 하위 toolchain dependency에는 binary가 포함될 수 있으며, 모든 transitive dependency를 source build했다는 의미는 아닙니다.

OpenCode latest stable은 V1 source layout이므로 `packages/opencode`와 V1 provider schema를 사용합니다. 이전 V2 development checkout은 별도로 감지해 기존 layout을 지원합니다. V1 build에는 source map 옵션을 사용합니다. 해당 tag의 packageManager가 요구하는 Bun 버전은 별도 prerequisite입니다.

instrumentation은 선택한 profile의 worktree에 적용합니다. HEAD commit lock은 그대로 두고 로컬 patch를 snapshot으로 남길 수 있습니다. source file이 보존됐다는 사실과 Nsight device line mapping/debug symbol이 준비됐다는 사실은 다릅니다. CUDA line-info, compiler optimization/debug flag, NVTX 및 profiler 옵션은 각 실험별로 명시적으로 설정·기록해야 합니다. 이번 revision은 GPU profile 결과를 생성하지 않았습니다.

## 동작 관계

```mermaid
sequenceDiagram
    participant CLI as Setup CLI
    participant Src as Existing sources
    participant Archive as Snapshot archive
    participant Git as Git object database
    participant Stable as Stable worktrees
    CLI->>Src: Read HEAD, staged and unstaged edits
    Src-->>CLI: Patches and nonignored untracked files
    CLI->>Archive: Save original state and checksums
    CLI->>Git: Retain HEAD ref and fetch history and tags
    Git-->>CLI: Complete referenced objects and tag IDs
    CLI->>Src: Confirm HEAD and edits unchanged
    CLI->>Archive: Save tag, commit and submodule inventory
    CLI->>Git: Validate stable tags and dependency edges
    Git->>Stable: Add separate detached worktrees
    CLI->>Archive: Write separate profile config and source lock
    Note over Src,Stable: Original editable sources and venv remain available
```

## 검증 결과

실제 작은 로컬 Git 저장소를 만들어 네트워크/GPU 없이 검증했습니다. shallow 이력 복구, partial object hydration, dirty worktree 보존, staged/unstaged patch, untracked archive, annotated tag, bundle clone, parent repository 오인 방지, stable worktree 분리, 중단된 submodule 준비 재시도, tag commit 변경 거부를 포함합니다. 기존 CPU/mock 및 offline pip resolver regression도 유지했습니다. 최종 test log와 status JSON은 tests/results/에 있습니다.

Spark에서 수행해야 하는 검증은 native build, C++/CUDA ABI, source-origin import, parser/tool calling, cold store/warm hit/cross-process retrieve, hybrid KV geometry 및 실제 Nsight profiling입니다. 성공하지 않은 항목을 검증 완료로 표시하지 않습니다.

## 주요 근거

- vLLM stable release: https://github.com/vllm-project/vllm/releases/tag/v0.32.0
- vLLM CUDA requirements: https://github.com/vllm-project/vllm/blob/v0.32.0/requirements/cuda.txt
- vLLM common requirements: https://github.com/vllm-project/vllm/blob/v0.32.0/requirements/common.txt
- LMCache stable release: https://github.com/LMCache/LMCache/releases/tag/v0.5.6
- LMCache build metadata: https://github.com/LMCache/LMCache/blob/v0.5.6/pyproject.toml
- LMCache compatibility policy: https://docs.lmcache.ai/getting_started/compatibility.html
- Transformers selected release: https://github.com/huggingface/transformers/releases/tag/v5.19.0
- PyTorch selected release: https://github.com/pytorch/pytorch/releases/tag/v2.13.0
- OpenCode stable release: https://github.com/anomalyco/opencode/releases/tag/v1.19.4
- Git fetch documentation: https://git-scm.com/docs/git-fetch

검토한 upstream metadata 원문과 SHA-256은 source_evidence/20261024/index.json 및 대응 파일에 보존했습니다. 과거 technical report는 reports/history/에 유지했습니다.

## 자동 병렬 컴파일 변경

실행 시 CPU affinity를 반영한 사용 가능한 logical CPU 수를 확인하고,
`max(1, CPU 수 - 4)`로 build jobs를 계산합니다. `reserve_cpu_cores`의 기본값은
4이며 기존 `max_jobs` 설정보다 우선합니다. `MAX_JOBS`와
`CMAKE_BUILD_PARALLEL_LEVEL`에 같은 값을 전달하고 `NVCC_THREADS=1`은 유지합니다.
예를 들어 사용 가능한 logical CPU가 20개이면 16 jobs입니다. 이는 CPU core
격리나 4개 CPU의 유휴 상태 보장이 아닙니다. Cgroup CPU time quota는 별도로
측정하지 않으며 OpenCode/Bun은 자체 scheduling을 사용합니다. 병렬도 증가에
따른 메모리 사용량 증가는 target machine에서 확인해야 합니다.

## r13: 첨부 로그의 두 가지 오류 수정

첨부 로그는 LMCache 0.5.6 native extension의 컴파일·설치 성공 후
`pip check`에서 OpenTelemetry dependency conflict가 발생한 사례입니다.
API/SDK/OTLP 1.40.0과 Prometheus 0.61b0을 공통 baseline으로 제한하여
LMCache API 상한과 vLLM 요구 조건을 맞춥니다. 이전 exporter-common이
설치된 SDK와 호환되지 않고 다른 distribution의 dependency 선언이 없을
때만 제거합니다. Optional dependency 선언도 있으면 자동 제거하지 않습니다.

별도 OpenCode 실패는 distro node-gyp 9.3.0이 stack Python 3.12를 선택하여
`gyp` distribution metadata를 찾지 못한 것입니다. Managed tools directory에
node-gyp 10.3.1을 설치하고 PATH 및 npm_config_node_gyp를 명시합니다.
System node-gyp는 변경하지 않습니다. Python 3.12는 upstream 기준으로
node-gyp 10 이상이 필요합니다. npm/Node.js 및 network가 필요합니다.

Controller package를 교체한 뒤 090_build_lmcache, 100_build_opencode 순으로
재실행합니다. 기존 source/tag/instrumentation은 유지합니다. 실제 target
GPU build와 Bun lifecycle의 node-gyp 선택 여부는 target 재실행으로 확인해야
하며, 첨부 로그에 없는 vLLM build 성공 여부는 판단하지 않습니다.

Reference: https://github.com/nodejs/node-gyp
Reference: https://github.com/open-telemetry/opentelemetry-python/blob/main/CHANGELOG.md

## r14: Bun lifecycle에서 실제 node-gyp 호출 경로 고정

사용자 재실행 로그에서 LMCache 0.5.6 설치 및 `pip check` 성공을 확인했습니다.
OpenCode는 managed node-gyp 10.3.1 설치·버전 검사 성공 후에도 lifecycle에서
`/usr/share/nodejs/node-gyp/bin/node-gyp.js` 9.3.0을 실행했습니다. 따라서 r13의
parent shell PATH 및 npm_config_node_gyp 설정만으로는 충분하지 않았습니다.

OpenCode build subprocess에 한정하여 NODE_OPTIONS CommonJS preloader를
적용합니다. node-gyp CLI가 main module로 실행될 때만 managed CLI로 전환하고
일반 Node program은 유지합니다. 절대 경로의 Node 및 legacy CLI 실행도
대상이며 argv를 보존합니다. System executable 및 upstream source는 변경하지
않습니다. 기존 NODE_OPTIONS도 유지합니다. Node internal Module._load 사용의
호환성 한계를 보완하기 위해 실제 Bun trusted dependency install lifecycle에서
버전 v10.3.1을 검증하고 marker가 없거나 다르면 즉시 중단합니다.

검증: CPU/offline tests 64개 통과. 별도로 Bun 1.4.4 실제 lifecycle에서 legacy
absolute CLI fixture를 managed version fixture로 전환하는 검사를 통과했습니다.
실제 node-gyp native addon compilation 및 Spark ARM64 검증은 아직 수행하지
않았습니다. 사용자 환경에서는 100_build_opencode만 재실행하면 됩니다.
Npm deprecation warning은 이번 `gyp` metadata 예외의 직접 원인이 아닙니다.

## r15: OpenCode V2 artifact 경로 및 실행 파일명 수정

사용자 로그에서 Bun lifecycle 검사와 1167개 dependency 설치 후
`building cli-linux-arm64`까지 진행됐고 build subprocess의 nonzero exit 없이
controller artifact 검사에서 실패했습니다. 확인한 commit
`148842ef7cb1bc34192b3fff57d0f9721ab9c801`의 V2 build script는
`const binary = "lildax"`를 선언하고
`./dist/${name}/bin/${binary}`에 출력합니다. `--outdir`는 처리하지 않습니다.
따라서 예상 실제 경로는
`root/src/opencode/packages/cli/dist/cli-linux-arm64/bin/lildax`입니다.
기존 controller는 managed build directory의 `*/bin/opencode`를 찾아 실패했습니다.

V2의 지원하지 않는 outdir 인수를 제거하고 source map을 활성화했습니다.
Host 전용 경로를 선택하여 ELF64/little-endian/CPU machine type 및 executable
permission을 확인한 뒤 managed `bin/opencode`에 symlink를 만듭니다. V1
layout은 유지하며 다른 기존 파일은 덮어쓰지 않습니다. Missing artifact
오류에는 expected path와 observed bin files를 기록합니다. Upstream source와
tag 및 instrumentation은 유지합니다.

검증: 69 tests 통과. 저장한 pinned upstream source contract 및 V1/V2
layout, wrong architecture, permission, missing file, idempotent symlink를
확인했습니다. 실제 Spark native build 및 실행은 미검증입니다. Controller를
교체하고 100_build_opencode만 다시 실행하며 LMCache 재빌드는 필요 없습니다.

Reference: https://github.com/anomalyco/opencode/blob/148842ef7cb1bc34192b3fff57d0f9721ab9c801/packages/cli/script/build.ts

## r16: Qwen architecture 검사 중 TorchVision 누락 해결

사용자 vLLM log의 직접 원인은 `ModuleNotFoundError: No module named
'torchvision'`입니다. Import chain은 Qwen3_5ForConditionalGeneration 검사 →
vLLM qwen3_5 → qwen3_vl → Transformers Qwen2-VL image processor →
torchvision.transforms.v2 입니다. 뒤의 ModelConfig ValidationError는 이
import 실패의 결과이며 모델 미지원 또는 GPU OOM을 입증하지 않습니다.
텍스트 요청만 사용할 예정이어도 현재 구현의 module import에는 필요합니다.

기존 130_verify_build는 generic package import, CUDA smoke 및 CLI help를
검사했으므로 이 architecture-specific import를 놓쳤습니다. r16에서는
100 및 110/120 시작 전 TorchVision source origin, native extension, v2
transforms와 정확한 vLLM Qwen module import를 검사합니다. Server readiness
실패 시 보관 로그의 경로와 마지막 45줄도 출력합니다.

070_build_torchvision을 추가했습니다. 기존 PyTorch 2.13.0과 공식 대응되는
TorchVision 0.28.0을 source build합니다. URL은 pytorch/vision이며 tag
v0.28.0 및 확인한 commit 8fb87713a24951e639c494b0f2a8a81b5f8e33a6을
고정합니다. Full Git history/tags를 보존하고 source root의 torchvision에
checkout합니다. 별도 torchvision.source.lock.json 및 전후 source snapshot을
기록하고 015 preservation 대상에도 포함합니다. 기존 instrumentation을
checkout/reset하지 않으며 unlocked directory와 다른 Torch version은
자동 변경하지 않고 중단합니다.

Editable install은 no-build-isolation/no-deps로 기존 source PyTorch 교체를
방지하며 CUDA build와 parallel jobs를 사용합니다. Codec development library는
환경에 따라 선택 기능에 영향을 주므로 image/video codec 전체 지원을
보장하지 않습니다. 새 설치에서는 040 → 045 → 050 순서, 현재 환경에서는
045 → 100 → 110만 실행하면 됩니다. 045에서는 vLLM 설치 전에도 가능한
TorchVision 자체 검사만 수행하고 Qwen 전체 import 검사는 100/serve에서
수행합니다. 다른 core rebuild 및 weights 재다운로드는 필요하지 않습니다.

검증: 73 tests 통과. Version mismatch 차단, full clone/pin 검사, no-deps
source install, unlocked source 보존 및 모델 import probe를 확인했습니다.
실제 Spark native TorchVision compile 및 Qwen 가중치 로딩은 미검증입니다.

Reference: https://github.com/pytorch/vision#installation
Reference: https://github.com/pytorch/vision/tree/v0.28.0

## r17: interactive agent와 V2 preview CLI 선택 오류 수정

사용자 실행 결과의 lildax는 OpenCode 2.0 preview CLI이며 api/debug/migrate/
service/serve 명령을 제공합니다. `160_run_agent`가 사용하는 positional project
및 --model CLI contract와 맞지 않습니다. CLI가 argument parsing 중 실패했으므로
이 로그는 vLLM/LMCache inference 실패를 의미하지 않습니다. r15의 artifact
탐색 수정은 V2 binary를 찾게 했지만 실제 agent CLI contract 검사가 부족했습니다.

고정된 commit에는 packages/opencode의 V1 interactive TUI와 packages/cli의
V2 preview가 공존합니다. Upstream V1 TUI의 `$0 [project]` 및 model option을
확인했습니다. Auto detection은 V1을 먼저 선택하며 기본 profile도 v1로
명시합니다. 기존 auto profile은 그대로 사용 가능합니다. V2를 명시한 custom
profile은 opencode_layout을 v1로 바꾸어야 합니다. 소스 ref/tag/commit은
변경하지 않습니다. V1은 source map을 유지하고 선택적인 embedded web UI는
빌드하지 않습니다. Stable release tag의 version/channel도 build env에 전달합니다.

기존 managed opencode symlink가 정확히 현재 repo의 lildax host artifact를
가리킬 때만 opencode-v2-preview backup symlink를 보존하고 V1으로 atomic
전환합니다. Unknown symlink나 regular file은 덮어쓰지 않습니다. 기존 preview
binary와 instrumentation은 유지합니다.

070/100/140은 actual CLI help의 [project] 및 --model 지원을 확인합니다.
V1 help가 stderr로 출력되는 경우도 수집합니다. 140은 V1 provider config도
검사하여 stale V2 config를 실행 전에 차단합니다. Controller 교체 후
900 → 070 → 090 → 140 순서로 실행합니다. 이미 준비된 vLLM/LMCache server는
유지할 수 있으며 다른 core rebuild나 weights 재다운로드는 불필요합니다.

검증: 78 tests 통과. Both-layout selection, preview link migration/preservation,
CLI contract, stderr capture 및 stale provider config 차단을 확인했습니다.
실제 Spark V1 native TUI compile 및 end-to-end agent session은 미검증입니다.

Reference: https://github.com/anomalyco/opencode/blob/148842ef7cb1bc34192b3fff57d0f9721ab9c801/packages/opencode/src/cli/cmd/tui.ts

## r18: 정상 경로와 예외 경로의 명령 번호 체계

정상 단계는 010부터 160까지 10 간격의 3자리 번호를 사용하고, 선택·복구·
진단 단계는 관련 번호 뒤에 소문자 a/b를 붙입니다. --help 전체는 English로
작성하며 정상 설치/검증 010→130은 같은 terminal, 140은 Terminal A에서
server를 유지, 150/160은 Terminal B에서 실행하는 예시를 제공합니다. 140과
140a baseline은 같은 port에서 동시 실행하지 않으며 Ctrl-C로 종료합니다.

020_prepare_system은 Python 및 ELF/DWARF development headers 준비를
통합합니다. 기존 내부 Python 함수명은 유지하고 public Bash dispatcher
번호와 분리합니다. 기존 명령은 silent alias로 실행하지 않고 새 명령을
안내하며 exit code 2로 종료합니다. 기존 source/commit lock/venv/model
weights는 변경하지 않으며 번호 변경만으로 재설치할 필요가 없습니다.

Current command authority: docs/cli_help.txt 및 docs/command_numbering.md.
이전 revision 경과 설명의 bare stage number는 당시 번호일 수 있으므로
현재 help를 우선합니다. Migration table은 configs/command_migration_r18.json
에도 저장합니다. --config는 global option으로 subcommand 앞에 지정하고
모든 단계 및 두 terminal에서 동일한 profile을 사용합니다.

검증은 전체 23개 명령의 dispatcher target, 16개 normal 단계의 번호순서,
모든 valid subcommand --help의 무실행/Python 불필요 동작, English ASCII,
legacy 명령 차단 및 terminal guidance를 포함합니다. Native target build와
LLM inference를 재실행했다는 의미는 아닙니다.

## r19: end-to-end 성능 계측 및 profiler 실행 도구

150a_profile 보조 명령을 추가했습니다. 현재 4.3 TPS는 vLLM의 logging interval
동안 생성한 token 수를 wall time으로 나눈 engine generation throughput입니다.
직접 API, vLLM 단독, LMCache 연동, OpenCode의 순서로 비용을 분리합니다.
기본 benchmark는 concurrency 1, thinking off, seed 42, temperature 0,
max_tokens 256, warmup 1 및 측정 3회를 사용합니다. 출력이 EOS로 일찍 끝날 수
있으므로 실제 usage 및 finish_reason을 기록합니다. SSE chunk를 token으로
세지 않습니다. TTFT는 첫 generated event 기준이고 decode TPS는 event boundary
기준 추정치이며 exact token ITL 또는 GPU kernel throughput이 아닙니다.

Warmup 뒤 측정 구간의 vLLM/LMCache Prometheus counter snapshot과 monotonic
time을 저장하고 증가량/초를 계산합니다. Missing series는 unavailable이며
counter reset은 제외합니다. 별도 서버 request가 섞이면 attribution이 깨집니다.
System collectors는 vmstat/mpstat/pidstat/iostat/nvidia-smi와 procfs memory/
PSI를 수집합니다. 누락/조기 종료는 collectors.json에 명시합니다. 설치나
clock 변경, swap 해제, cache clear, 임의 process kill은 수행하지 않습니다.

Mode는 사용자가 선언하는 label입니다. Live server config를 /server_info에서
가능하면 보관하지만 unavailable일 수 있으며 process args 및 log와 대조해야
합니다. Baseline/LMCache 비교는 동일 host/model/prompt/budget/thinking/config/
source lock 조건과 unprofiled PASS run을 요구합니다. 이것만으로 cache residency
또는 실행 중인 server identity를 보증하지 않습니다. Default 반복 prompt는
vLLM 내부 prefix cache를 탈 수 있어 external LMCache 효과를 입증하지 않습니다.
Cold/warm protocol 및 서로 다른 prompt 길이, thinking, agent/tool 시간을
분리하는 DoE는 docs/performance/Profiling_Guide.md에 정리했습니다.

Nsight Systems server launch는 실제 vLLM serve를 감싸고 worker subprocess
trace와 CUDA profiler API capture를 설정합니다. 별도 terminal benchmark가
/start_profile 및 /stop_profile을 호출합니다. LMCache는 별도 process로,
system logs 및 metrics 대상이지 이 wrapper에서 별도 Nsight trace가 보장되는
것은 아닙니다. NCU는 Systems에서 고른 kernel regex가 필수이며 basic set,
5 launches로 범위를 제한합니다. Replay로 왜곡된 client TPS는 baseline 비교에서
거부합니다. Completed native report가 없으면 분석 성공으로 처리하지 않습니다.

Analyze는 client measurement summary 또는 native profiler report summary를
생성합니다. Kernel/API 합산값은 overlap을 반영한 GPU busy union이나 critical
path가 아니므로 timeline에서 gap/overlap/synchronization을 검토해야 합니다.
Bottleneck은 근거 없이 자동 확정하지 않습니다.

초기 단계에서는 upstream source를 patch하지 않습니다. Existing CUDA/NVTX
activity로 triage하고 attribution이 모자라면 scheduler/worker/connector/LMCache
IPC에 request/span ID, chunk/bytes, cache outcome을 포함한 NVTX 및 제한 로그를
추가합니다. CUDA async 제출/완료를 구분하고 token마다 synchronize하거나
과도한 printf를 넣지 않습니다. 계측 overhead는 uninstrumented run과 비교합니다.

현재 GB10은 shared LPDDR5X 구조이며 CPU DRAM과 별도 GPU HBM 구조가 아닙니다.
BF16 weight traffic의 거친 roofline으로 4.3 TPS가 설명될 가능성이 있지만
실제 DRAM traffic과 GPU gap을 측정하기 전에는 bandwidth-bound로 확정하지
않습니다. 현재 SSD KV backend는 미설정이며 SSD 활동이 보이면 weight loading,
page fault/swap, agent file/test I/O와 구분합니다.

검증: 93개 CPU/offline/Git/mock tests 통과. 실제 HTTP SSE fixture, missing usage,
incomplete stream, counter reset, output protection, comparison mismatch 및
missing profiler report를 검사했습니다. 실제 Spark/GPU profiler 결과와 병목
분석 결과는 NOT_RUN입니다. 사용자가 target에서 생성한 결과로 다음 분석을
수행해야 합니다.

References:
- https://docs.vllm.ai/en/v0.32.0/contributing/profiling/
- https://docs.nvidia.com/nsight-compute/ProfilingGuide/
- https://docs.nvidia.com/dgx/dgx-spark/hardware.html

## r20: 기존 source build의 Docker runtime 실행

사용자의 요청에 따라 `bx_ai_coding_docker.sh` 및 internal `scripts/bx_docker.py`,
`docker/Dockerfile`, container entry script, English guide와 regression tests를 추가했다.
기존 source-build controller의 normal numbering은 바꾸지 않았다. Docker wrapper는
이미지/컨테이너 lifecycle, 기존 controller는 source build와 검증을 담당한다.

이번 구현은 **기존 host source/venv/weights를 동일 절대 경로로 bind mount하여 실행**한다.
사용자 환경의 `/opt/work/...` alias와 긴 `/home/...` canonical path를 모두 보존한다.
PyTorch editable loader, build/install 경로, venv entry point, Git metadata가 원래 path에
의존하기 때문이다. 독립된 relocation 가능한 image나 container-native 재build를
완료한 것으로 취급하지 않는다. core에 binary replacement를 설치하지 않는다.

Runtime image는 Ubuntu24.04 / CUDA13 / cuDNN / Python3.12 및 native OS libraries를
제공하며 host UID/GID에 대한 NSS identity를 준비한다. 기본 base는
`nvidia/cuda:13.0.0-cudnn-devel-ubuntu24.04`이고 ARM64로 build한다. image tag의
mutable 특성과 host venv native ABI를 고려해 필요하면 matching digest/OS dependencies를
고정한다. host library ABI가 다르면 container import 검증이 실패할 수 있으며, 이를
wheel 재설치로 숨기지 않는다.

Docker normal sequence는010 host/runtime check,020 image build,030 in-container verify,
040 foreground stack,050 API test,060 interactive agent,070 owned-container stop이다.
040a baseline은040의 대안이다. Terminal A는 service, Terminal B는 readiness 이후
API와 agent를 수행한다. **host와 container server를 동일 port에서 동시 실행하지 않는다.**
모든 Docker command는 --execute가 없으면 plan만 출력한다.

`--gpus all`, local host networking, private shared memory8g capacity,
current UID/GID/supplementary groups를 사용한다. host localhost config를 보존하므로
network namespace isolation을 제공하는 배포는 아니다. privileged, host PID namespace,
Docker socket 또는 전체 host root mount를 추가하지 않는다. managed-container labels와
config identity를 확인한 후에만 exec/stop한다. source/root/project는 writable mount이며
변경 내용은 host에도 남는다. controller/config/extra dependencies는 read-only다.

서비스 시작 전에130_verify_build를 container 내부에서 실행하여 native CUDA/source
origin, TorchVision/Qwen imports, pip check, 실제 V1 CLI contract를 확인한다. verify를
통과하면 serving controller를 init의 direct child로 exec한다. SIGINT와60초 stop timeout으로
기존 owned-process cleanup을 유도한다. 삭제되는 것은 --rm container layer이며
bind-mounted host logs/cache/agent state는 유지된다.

API benchmark/analyze/compare를050a_profile로 전달한다. profiler server launch 및
Nsight counter 권한 설정은 이번 wrapper에 포함하지 않는다. initial Nsight 분석은
Docker server를 정지하고 기존 host profiling workflow로 진행한다. CPU L1 LMCache4GB,
BF16/eager 설정을 유지하며 SSD/GDS backend는 여전히 NOT_CONFIGURED다.

검증: 기존93개 + 신규 Docker18개 =111개 CPU/offline/mock tests가 통과했다.
이 작업 환경에는 Docker Engine/GB10이 없어 image registry pull/build, 실제 container
CUDA import, model serving, OpenCode task 및 성능 비교는 **NOT_RUN**이다. Spark에서
030→040→050→060 순서의 실증이 필요하다. 가이드는 `docker/README.md`에 있다.

공식 근거:
- https://docs.nvidia.com/dgx/dgx-spark/nvidia-container-runtime-for-docker.html
- https://docs.nvidia.com/dgx/dgx-spark-porting-guide/latest/porting/compilation.html
- https://docs.docker.com/engine/storage/bind-mounts/
- https://docs.docker.com/engine/containers/run/
