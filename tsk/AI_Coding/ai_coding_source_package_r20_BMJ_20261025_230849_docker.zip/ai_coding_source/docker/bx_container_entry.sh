#!/usr/bin/env bash
# BUILD_ID="BMJ_20261025_230849"
# Keep the serving controller as the direct child of Docker's init process.
set -euo pipefail
bx_bundle="$1"
bx_config="$2"
bx_root="$3"
bx_action="$4"
mkdir -p -- "$HOME"
if [[ "$bx_action" == verify ]]; then
    exec /bin/bash "$bx_bundle/bx_ai_coding_setup.sh" --config "$bx_config" 130_verify_build --execute
fi
/bin/bash "$bx_bundle/bx_ai_coding_setup.sh" --config "$bx_config" 130_verify_build --execute
bx_args=(serve --execute)
if [[ "$bx_action" == baseline ]]; then bx_args+=(--baseline); fi
exec "$bx_root/venvs/stack/bin/python" "$bx_bundle/scripts/bx_driver.py" \
    --config "$bx_config" "${bx_args[@]}"
