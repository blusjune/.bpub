#!/usr/bin/env python3
# BUILD_ID="BMJ_20261025_230849"
"""Run the retained source-built Spark stack in a path-preserving Docker runtime."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import subprocess
import sys

HERE = Path(__file__).resolve().parents[1]
OWNER = 'io.bmj.ai-coding.owner'
IDENTITY = 'io.bmj.ai-coding.config'
HELP = '''
Normal sequence (all commands default to a printed plan):
  010_check_host       Check local Docker, ARM64, NVIDIA runtime and GPU access
  020_build_image      Build the Ubuntu 24.04 / CUDA 13 / cuDNN runtime image
  030_verify_runtime   Check retained source imports, CUDA, Qwen and agent CLI
  040_serve_stack      Foreground LMCache + vLLM; keep Terminal A open
  050_test_api         Test the running container in Terminal B after API READY
  060_run_agent        Run interactive OpenCode in Terminal B
  070_stop             Stop only a running container with matching ownership labels
Auxiliary commands:
  040a_serve_baseline   Alternative to 040; never run both on the same ports
  050a_profile         Direct API benchmark/analyze/compare in the running container
  050b_logs            Follow Docker output; service logs also remain on the host
  060a_shell           Interactive shell in the running container

Typical use (finish the host source build and stop host servers first):
  ./bx_ai_coding_docker.sh 010_check_host --execute
  ./bx_ai_coding_docker.sh 020_build_image --execute
  ./bx_ai_coding_docker.sh 030_verify_runtime --execute
  mkdir -p /opt/work/ai_coding/agent_sandbox
  Terminal A:
  ./bx_ai_coding_docker.sh 040_serve_stack --project /opt/work/ai_coding/agent_sandbox --execute
  Wait for API READY. Terminal B:
  ./bx_ai_coding_docker.sh 050_test_api --execute
  ./bx_ai_coding_docker.sh 060_run_agent --project /opt/work/ai_coding/agent_sandbox --execute
  ./bx_ai_coding_docker.sh 050a_profile --execute -- --action benchmark --mode lmcache --output /opt/work/ai_coding/root/deliverables/ai_coding/perf/docker_run1
  Stop from Terminal A with Ctrl-C, or run 070_stop in Terminal B.

Options may follow the command. Use the SAME --config, --name and --image
for all terminals. This wrapper uses an already built host source tree/venv,
not an independently portable image. Original real paths and aliases are
mounted; project selection must be supplied when starting the server.
Host networking preserves the existing localhost API configuration. Stop
host baseline/stack processes first. Default private shared memory is 8g;
--shm-size controls a capacity ceiling, not an up-front RAM reservation.
--extra-mount adds an existing READ-ONLY dependency or Git metadata directory.
Nsight launch is not enabled here; 050a supports client actions only.
No Docker socket, privileged mode, host PID namespace or host root mount is used.
'''
COMMANDS = ['010_check_host', '020_build_image', '030_verify_runtime',
            '040_serve_stack', '050_test_api', '060_run_agent', '070_stop',
            '040a_serve_baseline', '050a_profile', '050b_logs', '060a_shell']


def absolute(value):
    p = Path(value).expanduser()
    if not p.is_absolute() or p == Path('/') or any(x in str(p) for x in [',', '\n', '\r', '\x00']):
        raise ValueError('Use a non-root absolute path without comma or control characters: ' + str(p))
    return p


def parser():
    p = argparse.ArgumentParser(description=__doc__, epilog=HELP,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', choices=COMMANDS)
    p.add_argument('--config', type=absolute, default=HERE / 'configs/stack.json')
    p.add_argument('--image', default='bx-ai-coding:source-r20')
    p.add_argument('--base-image', default='nvidia/cuda:13.0.0-cudnn-devel-ubuntu24.04')
    p.add_argument('--name', default='bx-ai-coding')
    p.add_argument('--project', type=absolute, default=Path('/opt/work/ai_coding/agent_sandbox'))
    p.add_argument('--extra-mount', type=absolute, action='append', default=[])
    p.add_argument('--shm-size', default='8g')
    p.add_argument('--execute', action='store_true')
    return p


class Docker:
    def __init__(self, args):
        self.a = args
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]*', args.name):
            raise ValueError('Invalid container name')
        if not re.fullmatch(r'[1-9][0-9]*[bBkKmMgG]?', args.shm_size):
            raise ValueError('Invalid shared-memory capacity')
        for value in (args.image, args.base_image):
            if not value or value.startswith('-') or any(c.isspace() for c in value):
                raise ValueError('Invalid image reference')
        self.config = json.loads(args.config.read_text())
        self.root = absolute(self.config['root'])
        if self.config.get('node') != 'node3' or self.config.get('cuda_arch') != '12.1':
            raise ValueError('Docker runtime currently supports the reviewed Spark node3 profile only')
        self.key = hashlib.sha256((str(args.config.resolve()) + '\n' +
                                   json.dumps(self.config, sort_keys=True)).encode()).hexdigest()

    def run(self, cmd, capture=False):
        print(shlex.join(map(str, cmd)), flush=True)
        if not self.a.execute:
            return ''
        result = subprocess.run(list(map(str, cmd)), check=True, text=True,
                                stdout=subprocess.PIPE if capture else None)
        return result.stdout.strip() if capture else ''

    def local_daemon(self):
        if not self.a.execute:
            return
        if platform.machine() != 'aarch64':
            raise RuntimeError('Execute on the DGX Spark aarch64 host')
        override = os.environ.get('DOCKER_HOST')
        context = os.environ.get('DOCKER_CONTEXT')
        if context:
            endpoint = self.run(['docker', 'context', 'inspect', context, '--format',
                                 '{{.Endpoints.docker.Host}}'], capture=True)
        elif override:
            endpoint = override
        else:
            endpoint = self.run(['docker', 'context', 'inspect', '--format',
                                 '{{.Endpoints.docker.Host}}'], capture=True)
        if not endpoint.startswith('unix://'):
            raise RuntimeError('Only a local Unix-socket Docker daemon is supported for host bind mounts')
        self.run(['docker', 'info', '--format', '{{.Architecture}}'])

    def owned(self):
        if not self.a.execute:
            return
        data = json.loads(self.run(['docker', 'inspect', self.a.name], capture=True))[0]
        labels = data['Config'].get('Labels') or {}
        if labels.get(OWNER) != 'bx-ai-coding-r20' or labels.get(IDENTITY) != self.key:
            raise RuntimeError('Container ownership/config mismatch; no exec or stop performed')
        if not data['State']['Running']:
            raise RuntimeError('Managed container is not running')
        self.live = data

    def mounts(self, project):
        requested = [(self.root, False), (HERE, True), (self.a.config.parent, True)]
        for key, default in [('source_root', self.root / 'src'),
                             ('model_path', self.root / 'src/models/Qwen3.8-27B')]:
            requested.append((absolute(self.config.get(key, str(default))), False))
        if project:
            requested.append((self.a.project, False))
        requested += [(p, True) for p in self.a.extra_mount]
        targets = {}
        for lexical, readonly in requested:
            real = lexical.resolve()
            if real == Path('/'):
                raise ValueError('Refuse a mount resolving to the host root filesystem')
            if self.a.execute and not real.is_dir():
                raise RuntimeError('Required mount directory is missing: ' + str(lexical))
            # Bind real paths first, then aliases. Editable files contain both.
            for dest in (real, lexical):
                if str(dest) in targets:
                    if targets[str(dest)][1] != readonly:
                        raise RuntimeError('Conflicting mount access for ' + str(dest))
                    continue
                targets[str(dest)] = (str(real), readonly)
        result = []
        for dest, (src, readonly) in sorted(targets.items(), key=lambda kv: (len(Path(kv[0]).parts), kv[0])):
            result += ['--mount', 'type=bind,src=' + src + ',dst=' + dest + (',readonly' if readonly else '')]
        return result

    def launch(self, action):
        a = self.a
        if a.execute:
            for path in [self.root / 'venvs/stack/bin/python',
                         self.root / 'deliverables/ai_coding/sources.lock.json']:
                if not path.exists():
                    raise RuntimeError('Complete the host source installation first: ' + str(path))
            output = self.root / 'deliverables/ai_coding'
            if not os.access(output, os.W_OK):
                raise RuntimeError('Runtime output is not writable by the current host UID')
        cmd = ['docker', 'run', '--rm', '--init', '--gpus', 'all', '--network', 'host',
               '--shm-size', a.shm_size, '--ulimit', 'memlock=-1:-1',
               '--stop-signal', 'SIGINT', '--stop-timeout', '60',
               '--user', str(os.getuid()) + ':' + str(os.getgid()),
               '--env', 'HOME=/tmp/bx-home', '--env', 'NVIDIA_DRIVER_CAPABILITIES=compute,utility',
               '--env', 'PYTHONDONTWRITEBYTECODE=1', '--name', a.name if action != 'verify' else a.name + '-verify',
               '--label', OWNER + '=bx-ai-coding-r20', '--label', IDENTITY + '=' + self.key]
        # Supplementary groups may be needed for shared storage permissions.
        for group in sorted(set(os.getgroups()) - {os.getgid()}):
            cmd += ['--group-add', str(group)]
        cmd += self.mounts(action != 'verify')
        cmd += ['--workdir', str(HERE), '--entrypoint', '/bin/bash', a.image,
                str(HERE / 'docker/bx_container_entry.sh'), str(HERE), str(a.config), str(self.root), action]
        self.run(cmd)

    def execute_in(self, args, interactive=False):
        self.owned()
        cmd = ['docker', 'exec']
        if interactive:
            if self.a.execute and not (sys.stdin.isatty() and sys.stdout.isatty()):
                raise RuntimeError('An interactive terminal is required for agent/shell')
            cmd += ['-it']
        cmd += ['--env', 'HOME=/tmp/bx-home']
        for name in ('OPENCODE_ENABLE_EXA', 'OPENCODE_WEBSEARCH_PROVIDER'):
            if name in os.environ:
                cmd += ['--env', name + '=' + os.environ[name]]
        cmd += [self.a.name] + args
        self.run(cmd)

    def dispatch(self, extra):
        a = self.a
        self.local_daemon()
        top = ['/bin/bash', str(HERE / 'bx_ai_coding_setup.sh'), '--config', str(a.config)]
        if a.command == '010_check_host':
            self.run(['docker', 'version'])
            self.run(['docker', 'run', '--rm', '--gpus', 'all', '--entrypoint', 'nvidia-smi', a.base_image])
        elif a.command == '020_build_image':
            self.run(['docker', 'build', '--platform', 'linux/arm64', '--build-arg',
                      'BASE_IMAGE=' + a.base_image, '--build-arg', 'APP_UID=' + str(os.getuid()),
                      '--build-arg', 'APP_GID=' + str(os.getgid()), '--tag', a.image, '--file',
                      str(HERE / 'docker/Dockerfile'), str(HERE / 'docker')])
        elif a.command in ('030_verify_runtime', '040_serve_stack', '040a_serve_baseline'):
            self.launch({'030_verify_runtime': 'verify', '040_serve_stack': 'stack',
                         '040a_serve_baseline': 'baseline'}[a.command])
        elif a.command == '050_test_api':
            self.execute_in(top + ['150_test_api', '--execute'])
        elif a.command == '060_run_agent':
            if a.execute:
                # A project must have been explicitly mounted when serving started.
                self.owned()
                real = str(a.project.resolve())
                if not any(m.get('Destination') == str(a.project) and
                           m.get('Source') == real and m.get('RW') for m in self.live.get('Mounts', [])):
                    raise RuntimeError('Project was not mounted writable at server start; stop and restart with --project')
            self.execute_in(top + ['160_run_agent', '--project', str(a.project), '--execute'], True)
        elif a.command == '050a_profile':
            q = argparse.ArgumentParser(add_help=False)
            q.add_argument('--action', choices=['benchmark', 'analyze', 'compare'], default='benchmark')
            q.add_argument('--execute', action='store_true')
            q.parse_known_args(extra)
            self.execute_in(top + ['150a_profile', '--execute'] + extra)
        elif a.command == '060a_shell':
            self.execute_in(['/bin/bash'], True)
        elif a.command == '050b_logs':
            self.owned()
            self.run(['docker', 'logs', '--follow', '--tail', '100', a.name])
        elif a.command == '070_stop':
            self.owned()
            self.run(['docker', 'stop', '--time', '60', a.name])


def main(argv=None):
    tokens = list(sys.argv[1:] if argv is None else argv)
    extra = []
    if '--' in tokens:
        index = tokens.index('--')
        tokens, extra = tokens[:index], tokens[index + 1:]
    p = parser()
    if not tokens:
        p.print_help()
        return 0
    a = p.parse_args(tokens)
    if extra and a.command != '050a_profile':
        p.error('Arguments after -- are allowed only for 050a_profile')
    Docker(a).dispatch(extra)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
