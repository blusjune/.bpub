#!/usr/bin/env bash
# BUILD_ID="BMJ_20261025_230849"
# Docker lifecycle entry point; source build stages remain in bx_ai_coding_setup.sh.
set -euo pipefail
bx_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec "${BX_DOCKER_PYTHON:-python3}" "$bx_dir/scripts/bx_docker.py" "$@"
