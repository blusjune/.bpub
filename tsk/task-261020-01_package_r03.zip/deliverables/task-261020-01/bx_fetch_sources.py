#!/usr/bin/env python3
"""Fetch exact inspected commits. No packages/drivers installed; no disk writes outside output."""
import argparse, json, pathlib, subprocess
p=argparse.ArgumentParser();p.add_argument('--dest',type=pathlib.Path,default=pathlib.Path('sources'));a=p.parse_args()
manifest=json.loads(pathlib.Path(__file__).with_name('source_manifest.json').read_text())
a.dest.mkdir(parents=True,exist_ok=True)
for r in manifest['repositories']:
    d=a.dest/r['name']
    if d.exists(): raise SystemExit(f'Refusing existing path {d}')
    subprocess.run(['git','init',str(d)],check=True)
    subprocess.run(['git','-C',str(d),'remote','add','origin',r['url']],check=True)
    subprocess.run(['git','-C',str(d),'fetch','--depth','1','origin',r['commit']],check=True)
    subprocess.run(['git','-C',str(d),'checkout','--detach','FETCH_HEAD'],check=True)
print('Exact snapshots downloaded; independent HEAD pins are NOT a validated dependency matrix.')
