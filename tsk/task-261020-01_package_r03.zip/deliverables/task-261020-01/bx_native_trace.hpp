#pragma once
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <mutex>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
// Local scope, fixed literal names only. Data pointer is opaque; never dereferenced.
namespace bx {
inline uint64_t now(){timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return uint64_t(t.tv_sec)*1000000000ULL+t.tv_nsec;}
inline std::atomic<unsigned long> counter{0};
inline std::mutex lock;
inline void label(char* dst,size_t n,const char* src){if(!src)src="unknown";size_t i=0;for(;src[i]&&i+1<n;++i){char c=src[i];dst[i]=(c=='"'||c=='\\'||c<32)?'_':c;}dst[i]=0;}
inline void emit(const char* fn,const char* phase,unsigned long span, long long off,size_t bytes){
 const char* dir=getenv("BX_TRACE_DIR"); if(!dir)return;
 char node[128],run[256],host[256];label(node,sizeof(node),getenv("BX_NODE_ID"));label(run,sizeof(run),getenv("BX_RUN_ID"));char rawhost[256]={0};gethostname(rawhost,sizeof(rawhost)-1);label(host,sizeof(host),rawhost);
 char path[4096],line[2048];snprintf(path,sizeof(path),"%s/native-%d.jsonl",dir,getpid());
 int n=snprintf(line,sizeof(line),"{\"schema\":1,\"node_id\":\"%s\",\"run_id\":\"%s\",\"host\":\"%s\",\"clock\":\"monotonic_ns\",\"ts_ns\":%llu,\"pid\":%d,\"tid\":%ld,\"component\":\"Native\",\"fn\":\"%s\",\"span\":\"native-%d-%lu\",\"parent\":null,\"phase\":\"%s\",\"evidence\":\"observed_native\",\"args\":{\"offset\":%lld,\"bytes\":%zu}}\n",node,run,host,(unsigned long long)now(),getpid(),syscall(SYS_gettid),fn,getpid(),span,phase,off,bytes);
 if(n<=0||size_t(n)>=sizeof(line))return;
 std::lock_guard<std::mutex> g(lock);int fd=open(path,O_CREAT|O_WRONLY|O_APPEND,0600);
 if(fd<0){perror("BX_TRACE_FAILURE open");return;}
 size_t pos=0;while(pos<size_t(n)){ssize_t w=write(fd,line+pos,n-pos);if(w<=0){perror("BX_TRACE_FAILURE write");break;}pos+=w;}close(fd);
}
struct Scope{const char* fn;unsigned long id;long long off;size_t bytes;Scope(const char*f,long long o=0,size_t b=0):fn(f),id(++counter),off(o),bytes(b){emit(fn,"B",id,off,bytes);}~Scope(){emit(fn,"E",id,off,bytes);}};
inline void mark(const char*f,long long o=0,size_t b=0){emit(f,"I",++counter,o,b);}
}
