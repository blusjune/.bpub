"""Test-only simulated host identities. Production architecture checks remain active."""
import pathlib,sys
MOCK_HOSTS=(('node2','x86_64','NVIDIA RTX PRO 6000 Blackwell'),('node3','aarch64','NVIDIA GB10'))

def simulated_command(script,arch,*arguments):
    """Patch platform.machine only inside an isolated mock-test subprocess.

    The caller must provide fake hardware/profiler executables. This helper does
    not expose a production flag or environment variable to bypass validation.
    """
    runner='''import pathlib,platform,runpy,sys
from unittest.mock import patch
arch=sys.argv[1]
script=pathlib.Path(sys.argv[2]).resolve()
sys.argv=[str(script),*sys.argv[3:]]
sys.path.insert(0,str(script.parent))
import bx_platform
node=sys.argv[sys.argv.index('--node')+1]
observation={'node_id':node,'host':'mock-host','cpu_arch':arch,'kernel':'mock-kernel','gpu_matches_profile':True,'architecture_matches_profile':arch==bx_platform.profile(node)['cpu_arch'],'native_dma_verified':False,'evidence':'MOCK_TEST_FIXTURE'}
with patch.object(platform,'machine',return_value=arch),patch.object(bx_platform,'observe',return_value=observation):
    runpy.run_path(str(script),run_name='__main__')
'''
    return [sys.executable,'-c',runner,arch,str(pathlib.Path(script).resolve()),*arguments]
