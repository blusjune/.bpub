import csv,importlib.util,json,os,pathlib,sqlite3,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'tests'))
from mock_host import MOCK_HOSTS,simulated_command
import bx_analyze as qa
from bx_platform import mode_for,run_environment
from bx_profile import profiler_command

def fixture_db(path,copy=True):
    db=sqlite3.connect(path);db.executescript('create table StringIds(id integer,value text);insert into StringIds values(1,"gather_kernel");create table CUPTI_ACTIVITY_KIND_KERNEL(start integer,end integer,deviceId integer,demangledName integer);insert into CUPTI_ACTIVITY_KIND_KERNEL values(0,10,0,1),(5,20,0,1);')
    if copy:db.executescript('create table CUPTI_ACTIVITY_KIND_MEMCPY(start integer,end integer,deviceId integer,bytes integer);insert into CUPTI_ACTIVITY_KIND_MEMCPY values(8,12,0,4096);')
    db.commit();db.close()

class MultiNode(unittest.TestCase):
    def test_single_entry(self):
        self.assertFalse((ROOT/'bx_gds_test_top.sh').exists())
        r=subprocess.run([sys.executable,str(ROOT/'bx_gds_test_top.py'),'--help'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0);self.assertIn('Typical examples',r.stdout);self.assertIn('--node node2',r.stdout);self.assertIn('--tool ncu',r.stdout)
    def test_mode_policy(self):
        self.assertEqual(mode_for('node2','cufile_fs','auto'),'compat')
        self.assertEqual(mode_for('node2','cufile_fs','native'),'native')
        for backend,mode in [('cufile_fs','native'),('ugds_raw','auto')]:
            with self.assertRaises(ValueError):mode_for('node3',backend,mode)
    def test_cufile_overlay(self):
        with tempfile.TemporaryDirectory() as d:
            d=pathlib.Path(d);env=run_environment('node3',d,'cufile_fs','compat')
            config=json.loads(pathlib.Path(env['CUFILE_ENV_PATH_JSON']).read_text());self.assertTrue(config['properties']['force_compat_mode']);self.assertEqual(env['BX_TRACE'],'0')
    def test_inherited_compat_conflict(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'CUFILE_FORCE_COMPAT_MODE':'true'}):
            with self.assertRaises(ValueError):run_environment('node2',pathlib.Path(d),'cufile_fs','native')
    def test_doe_both_nodes(self):
        for node,n in [('node2',255),('node3',153)]:
            subprocess.run([sys.executable,str(ROOT/'bx_make_doe.py'),'--node',node],check=True,capture_output=True)
            with (ROOT/'doe'/f'{node}_cases.csv').open() as f:rows=list(csv.DictReader(f))
            self.assertEqual(len(rows),n);self.assertTrue(all(r['node_id']==node and r['status']=='UNMEASURED' for r in rows))
            if node=='node3':self.assertFalse(any(r['requested_mode']=='native' for r in rows))
    def test_profiler_commands(self):
        cmd=profiler_command('nsys',pathlib.Path('r'),['python','pilot'])
        self.assertIn('--wait=all',cmd);self.assertIn('--trace=cuda,nvtx,osrt',cmd)
        with self.assertRaises(ValueError):profiler_command('ncu',pathlib.Path('r'),['python'])
        cmd=profiler_command('ncu',pathlib.Path('r'),['python'],'kv.*',3)
        self.assertIn('MemoryWorkloadAnalysis',cmd);self.assertIn('regex:kv.*',cmd);self.assertIn('all',cmd)
    def test_profile_plan_no_write(self):
        r=subprocess.run([sys.executable,str(ROOT/'bx_gds_test_top.py'),'--node','node2','profile','--tool','nsys','--path','raw_cpu','--storage','/dev/never'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr);self.assertIn('PLAN ONLY',r.stdout)
    def test_profile_wrong_node_rejects(self):
        r=subprocess.run([sys.executable,str(ROOT/'bx_gds_test_top.py'),'--node','node3','profile','--tool','nsys','--path','cufile_fs','--gds-mode','native','--storage','/mnt/never'],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0)
    def test_interval_union_not_sum(self):
        self.assertEqual(qa.duration([(0,10),(5,20)]),20);self.assertEqual(qa.overlap([(0,10),(5,20)],[(8,12)]),4)
    def test_nsys_sqlite_known_quantities(self):
        with tempfile.TemporaryDirectory() as d:
            f=pathlib.Path(d)/'nsys.sqlite';fixture_db(f)
            result=qa.sqlite_summary(f);gpu=result['devices']['0']
            self.assertAlmostEqual(gpu['gpu_activity_union_pct'],100);self.assertAlmostEqual(gpu['kernel_copy_overlap_ms'],4/1e6)
            self.assertEqual(result['hot_kernels_by_summed_gpu_time'][0]['sum_ms'],25/1e6)
    def test_nsys_missing_table_is_null(self):
        with tempfile.TemporaryDirectory() as d:
            f=pathlib.Path(d)/'nsys.sqlite';fixture_db(f,False);gpu=qa.sqlite_summary(f)['devices']['0']
            self.assertIsNone(gpu['copy_union_ms']);self.assertIsNone(gpu['kernel_copy_overlap_ms'])
    def test_sqlite_window_clipped_bytes(self):
        with tempfile.TemporaryDirectory() as d:
            f=pathlib.Path(d)/'n.sqlite';fixture_db(f);gpu=qa.sqlite_summary(f,9,11)['devices']['0']
            self.assertAlmostEqual(gpu['kernel_copy_overlap_ms'],2/1e6);self.assertEqual(gpu['cuda_copy_bytes_unclipped'],0)
    def test_ncu_csv(self):
        with tempfile.TemporaryDirectory() as d:
            f=pathlib.Path(d)/'ncu.csv';f.write_text('==PROF== preamble\n"Kernel Name","Metric Name","Metric Unit","Metric Value"\n"kv","dram__throughput.avg.pct_of_peak_sustained_elapsed","%","76.5"\n')
            r=qa.ncu_csv(f);self.assertEqual(r['metrics'][0]['value'],76.5)
    def test_cross_node_trace_rejected(self):
        import bx_gen_seqdiag_from_tracelog as seq
        base=dict(schema=1,clock='monotonic_ns',ts_ns=1,pid=1,tid=1,component='Native',fn='f',span='a',phase='I',evidence='synthetic')
        with tempfile.TemporaryDirectory() as d:
            f=pathlib.Path(d)/'x';f.write_text('\n'.join(json.dumps(dict(base,node_id=node,span=node)) for node in ('node2','node3')))
            with self.assertRaisesRegex(ValueError,'node_id'):seq.load([f])
    def test_streaming_ttft(self):
        import http.server,threading,time
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(self):
                self.rfile.read(int(self.headers['Content-Length']));self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
                for data in ({'choices':[{'text':'hello'}]},{'choices':[{'text':' world'}]},{'choices':[],'usage':{'completion_tokens':2}}):
                    self.wfile.write(('data: '+json.dumps(data)+'\n\n').encode());self.wfile.flush();time.sleep(.002)
                self.wfile.write(b'data: [DONE]\n\n')
        server=http.server.HTTPServer(('127.0.0.1',0),H);thread=threading.Thread(target=server.serve_forever);thread.start()
        try:
            with tempfile.TemporaryDirectory() as d:
                output=pathlib.Path(d)/'workload.jsonl'
                r=subprocess.run([sys.executable,str(ROOT/'bx_workload.py'),'--model','facebook/opt-125m','--tokens','16','--requests','1','--rounds','1','--stream','--url',f'http://127.0.0.1:{server.server_port}/v1/completions','--output',str(output)],capture_output=True,text=True)
                self.assertEqual(r.returncode,0,r.stderr);row=json.loads(output.read_text());self.assertGreater(row['ttft_ms'],0);self.assertEqual(len(row['content_chunk_gaps_ms']),1)
        finally:server.shutdown();thread.join();server.server_close()
    def _mock_nsys_export_analysis(self,node,arch):
        tempbase=ROOT/'tests/results/tmp';tempbase.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=tempbase) as d:
            d=pathlib.Path(d);tools=d/'bin';tools.mkdir();fake=tools/'nsys'
            fake.write_text('#!'+sys.executable+'\n'+"""import sys,pathlib,sqlite3,json
args=sys.argv[1:]
if args[0]=='profile':
 node=args[args.index('--node')+1]
 p=pathlib.Path(args[args.index('--output')+1]);p.with_suffix('.nsys-rep').write_text('MOCK REPORT');pilot=pathlib.Path(args[args.index('--run-dir')+1]);pilot.mkdir();(pilot/'run_manifest.json').write_text(json.dumps({'node_id':node,'status':'WORKLOAD_COMPLETED_IO_UNVERIFIED'}))
elif args[0]=='stats': print('Name,Time\\nmock,1')
elif args[0]=='export':
 p=pathlib.Path(args[args.index('--output')+1]);c=sqlite3.connect(p);c.executescript('create table StringIds(id integer,value text);insert into StringIds values(1,"mock_kv");create table CUPTI_ACTIVITY_KIND_KERNEL(start integer,end integer,deviceId integer,demangledName integer);insert into CUPTI_ACTIVITY_KIND_KERNEL values(0,100,0,1);');c.commit();c.close()
""")
            fake.chmod(0o700)
            env=dict(os.environ,PATH=str(tools)+os.pathsep+os.environ['PATH'])
            r=subprocess.run(simulated_command(ROOT/'bx_profile.py',arch,'--node',node,'--tool','nsys','--path','raw_cpu','--storage','/dev/never','--output-dir',str(d/'capture'),'--execute'),env=env,capture_output=True,text=True,timeout=20)
            self.assertEqual(r.returncode,0,r.stderr);m=json.loads((d/'capture/profile_manifest.json').read_text());self.assertEqual(len(m['exports']),6)
            q=json.loads((d/'capture/quantitative_summary.json').read_text());self.assertEqual(len(q['nsys']),1);self.assertFalse(q['native_dma_verified'])
    def _missing_profiler_report_is_failure(self,node,arch):
        tempbase=ROOT/'tests/results/tmp';tempbase.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=tempbase) as d:
            d=pathlib.Path(d);f=d/'ncu';f.write_text('#!'+sys.executable+'\npass\n');f.chmod(0o700)
            env=dict(os.environ,PATH=str(d)+os.pathsep+os.environ['PATH'])
            r=subprocess.run(simulated_command(ROOT/'bx_profile.py',arch,'--node',node,'--tool','ncu','--kernel-regex','kv.*','--path','raw_cpu','--storage','/dev/never','--output-dir',str(d/'capture'),'--execute'),env=env,capture_output=True,text=True,timeout=20)
            self.assertNotEqual(r.returncode,0)
    def test_mock_nsys_export_analysis(self):
        for node,arch,gpu in MOCK_HOSTS:
            with self.subTest(node=node,arch=arch):self._mock_nsys_export_analysis(node,arch)
    def test_missing_profiler_report_is_failure(self):
        for node,arch,gpu in MOCK_HOSTS:
            with self.subTest(node=node,arch=arch):self._missing_profiler_report_is_failure(node,arch)
if __name__=='__main__':unittest.main(verbosity=2)
