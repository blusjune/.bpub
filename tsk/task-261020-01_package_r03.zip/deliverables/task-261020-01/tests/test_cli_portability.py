"""Regression tests for side-effect-free help and simulated host validation."""
import contextlib,importlib.util,io,pathlib,sys,unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import bx_gds_test_top as top
import bx_platform

class HelpAndPortability(unittest.TestCase):
    def test_local_stage_help_has_no_actions(self):
        for node in ('node2','node3'):
            for stage in ('suite','validate','preflight'):
                for flag in ('--help','-h'):
                    with self.subTest(node=node,stage=stage,flag=flag):
                        text=io.StringIO()
                        with patch.object(top.subprocess,'run') as run,patch.object(top,'observe') as observe,contextlib.redirect_stdout(text):
                            with self.assertRaises(SystemExit) as ex:top.main(['--node',node,stage,flag])
                            self.assertEqual(ex.exception.code,0);run.assert_not_called();observe.assert_not_called()
                        self.assertIn('usage:',text.getvalue());self.assertNotIn('test_duplicate',text.getvalue())

    def test_invalid_suite_option_has_no_actions(self):
        with patch.object(top.subprocess,'run') as run,patch.object(top,'observe') as observe,contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as ex:top.main(['--node','node3','suite','--unknown-option'])
            self.assertEqual(ex.exception.code,2);run.assert_not_called();observe.assert_not_called()

    def test_production_arch_checks_remain_strict(self):
        for arch,valid,invalid in [('x86_64','node2','node3'),('aarch64','node3','node2')]:
            with self.subTest(arch=arch),patch.object(bx_platform.platform,'machine',return_value=arch):
                bx_platform.check_arch(valid)
                with self.assertRaisesRegex(RuntimeError,'actual host is '+arch):bx_platform.check_arch(invalid)

    def test_delegated_help_forwarding(self):
        for stage in ('plan','pilot','profile','analyze','diagram','workload','fetch','doe','instrument'):
            with self.subTest(stage=stage),patch.object(top.subprocess,'run') as run:
                run.return_value.returncode=0
                self.assertEqual(top.main(['--node','node3',stage,'--help']),0)
                self.assertIn('--help',run.call_args.args[0])

if __name__=='__main__':unittest.main(verbosity=2)
