#!/usr/bin/env python3
import importlib.util,json,os,pathlib,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from mock_host import MOCK_HOSTS,simulated_command
spec=importlib.util.spec_from_file_location('seq',ROOT/'bx_gen_seqdiag_from_tracelog.py');seq=importlib.util.module_from_spec(spec);spec.loader.exec_module(seq)
def event(phase,ts=1,span='s',**kw):
 e=dict(schema=1,clock='monotonic_ns',ts_ns=ts,pid=1,tid=2,component='LMCache',fn='f',span=span,parent=None,phase=phase,evidence='synthetic');e.update(kw);return e
class Adversarial(unittest.TestCase):
 def test_timestamp_reordering(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'a';p.write_text('\n'.join(map(json.dumps,[event('E',2),event('B',1)])))
   self.assertIn('segment end',seq.render(seq.load([p])));self.assertIn('SYNTHETIC',seq.render(seq.load([p])))
 def test_missing_end(self):
  with self.assertRaisesRegex(ValueError,'incomplete'):seq.render([event('B')])
  self.assertIn('incomplete spans: 1',seq.render([event('B')],allow_incomplete=True))
 def test_orphan_end(self):
  with self.assertRaises(ValueError):seq.render([event('E')])
 def test_duplicate_span(self):
  with self.assertRaises(ValueError):seq.render([event('B'),event('B',2)])
 def test_mismatched_thread(self):
  with self.assertRaises(ValueError):seq.render([event('B'),event('E',2,tid=3)])
 def test_unknown_clock_and_bad_json(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'a'
   for data in ['{bad',json.dumps(event('I',clock='wall')),json.dumps(event('I',ts_ns=-1)),json.dumps(event('I',component='Alien'))]:
    p.write_text(data)
    with self.assertRaises(ValueError):seq.load([p])
 def test_duplicate_input(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'a';p.write_text(json.dumps(event('I')))
   with self.assertRaises(ValueError):seq.load([p,p])
 def test_mermaid_injection(self):
  s=seq.render([event('I',fn='bad\n```\nparticipant P; <script>%%{init}')])
  self.assertEqual(s.count('```'),2);self.assertNotIn('<script>',s);self.assertNotIn('%%{',s)
 def test_process_span_collision(self):
  self.assertIn('Events: 4',seq.render([event('B'),event('B',pid=3),event('E',2),event('E',2,pid=3)]))
 def test_native_header(self):
  with tempfile.TemporaryDirectory() as d:
   d=pathlib.Path(d);(d/'a.cpp').write_text('#include "bx_native_trace.hpp"\nint main(){bx::Scope s("smoke",4096,8192);bx::mark("cq_observed");}\n')
   subprocess.run(['g++','-std=c++17','-pthread','-I',str(ROOT),str(d/'a.cpp'),'-o',str(d/'smoke')],check=True,capture_output=True)
   env=dict(os.environ,BX_TRACE_DIR=str(d));subprocess.run([str(d/'smoke')],check=True,env=env)
   es=seq.load(list(d.glob('native-*.jsonl')));self.assertEqual(len(es),3);self.assertIn('smoke',seq.render(es))
 def test_instrumentation_source_drift(self):
  with tempfile.TemporaryDirectory() as d:
   r=pathlib.Path(d);(r/'src').mkdir();(r/'src/ugds_io.cpp').write_text('int x;')
   p=subprocess.run([sys.executable,str(ROOT/'bx_instrument_ugds.py'),str(r)],capture_output=True)
   self.assertNotEqual(p.returncode,0);self.assertEqual((r/'src/ugds_io.cpp').read_text(),'int x;')
 def test_generator_async_threads_exception(self):
  with tempfile.TemporaryDirectory() as d:
   d=pathlib.Path(d)
   (d/'fixture.py').write_text('''import asyncio, threading

def leaf(value): return value

def boom(): raise ValueError('expected')

def gen():
 yield leaf(1)
 yield leaf(2)

async def job(i):
 leaf(i)
 await asyncio.sleep(0)
 leaf(i+1)
 return i
async def main():
 assert await asyncio.gather(job(1),job(2)) == [1,2]
 assert list(gen()) == [1,2]
 try: boom()
 except ValueError: pass
 t=threading.Thread(target=leaf,args=(3,));t.start();t.join()
 leaf(float('nan'))
''')
   cmd=[sys.executable,'-c','import asyncio, fixture, bxtrace; asyncio.run(fixture.main()); bxtrace.stop()']
   env=dict(os.environ,BX_TRACE='1',BX_TRACE_ROOTS=str(d/'fixture.py'),BX_TRACE_DIR=str(d),PYTHONPATH=str(ROOT)+os.pathsep+str(d))
   p=subprocess.run(cmd,env=env,capture_output=True,text=True)
   self.assertEqual(p.returncode,0,p.stderr);self.assertNotIn('BX_TRACE_FAILURE',p.stderr)
   es=seq.load(list(d.glob('python-*.jsonl')));s=seq.render(es)
   self.assertIn('boom',s);self.assertGreater(len({x['tid'] for x in es}),1)
   self.assertGreater(sum(x['fn']=='job' and x['phase']=='B' for x in es),2)
   self.assertFalse(any(x['component']=='GPU' for x in es))
 def test_spark_ugds_gate(self):
  p=subprocess.run([sys.executable,str(ROOT/'bx_plan_commands.py'),'--path','ugds_raw','--storage','/dev/unused'],capture_output=True,text=True)
  self.assertNotEqual(p.returncode,0);self.assertNotIn('lmcache server',p.stdout)
 def test_raw_model_geometry(self):
  for model,expected in [('facebook/opt-125m',9441280),('Qwen/Qwen2.5-0.5B',3149824),('Qwen/Qwen3-30B-A3B',25169920)]:
   p=subprocess.run([sys.executable,str(ROOT/'bx_plan_commands.py'),'--path','raw_cpu','--storage','/dev/unused','--model',model],capture_output=True,text=True)
   self.assertEqual(p.returncode,0,p.stderr);self.assertIn('"slot_bytes":'+str(expected),p.stdout)
 def test_workload_context_reject(self):
  p=subprocess.run([sys.executable,str(ROOT/'bx_workload.py'),'--model','facebook/opt-125m','--tokens','2048'],capture_output=True,text=True)
  self.assertNotEqual(p.returncode,0);self.assertIn('exceeds',p.stderr)
 def test_top_level_dispatch_and_plan(self):
  p=subprocess.run([sys.executable,str(ROOT/'bx_gds_test_top.py'),'pilot','--path','raw_cpu','--storage','/dev/never'],capture_output=True,text=True)
  self.assertEqual(p.returncode,0,p.stderr);self.assertIn('PLAN ONLY',p.stdout)
  p=subprocess.run([sys.executable,str(ROOT/'bx_gds_test_top.py'),'unknown-stage'],capture_output=True,text=True)
  self.assertEqual(p.returncode,2)
 def _mock_pilot_lifecycle(self,node,arch,gpu):
  # Mock servers exercise lifecycle/HTTP/cleanup only, never GPU or storage APIs.
  tempbase=ROOT/'tests/results/tmp';tempbase.mkdir(parents=True,exist_ok=True)
  with tempfile.TemporaryDirectory(dir=tempbase) as d:
   d=pathlib.Path(d);mock=d/'bin';mock.mkdir()
   common='#!'+sys.executable+'\n'
   programs={
    'nvidia-smi':f"print('{gpu}, mock-uuid, mock-bus, mock-driver, 96000 MiB')\n",
    'lmcache':"import socket,time\ns=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',5555));s.listen();time.sleep(60)\n",
    'vllm':"import http.server,json\nclass H(http.server.BaseHTTPRequestHandler):\n def log_message(self,*args):pass\n def do_GET(self):\n  self.send_response(200);self.end_headers();self.wfile.write(b'OK')\n def do_POST(self):\n  n=int(self.headers['Content-Length']);a=json.loads(self.rfile.read(n));b=json.dumps({'usage':{'prompt_tokens':len(a['prompt'])},'choices':[]}).encode();self.send_response(200);self.end_headers();self.wfile.write(b)\nhttp.server.HTTPServer(('127.0.0.1',8000),H).serve_forever()\n"}
   for name,body in programs.items():
    f=mock/name;f.write_text(common+body);f.chmod(0o700)
   storage=d/'dedicated-file';storage.write_bytes(b'0'*4096)
   env=dict(os.environ,PATH=str(mock)+os.pathsep+os.environ['PATH'])
   p=subprocess.run(simulated_command(ROOT/'bx_run_pilot.py',arch,'--node',node,'--path','file_cpu','--storage',str(storage),'--requests','2','--tokens','256','--startup-timeout','5','--execute','--run-dir',str(d/'run')),env=env,capture_output=True,text=True,timeout=25)
   self.assertEqual(p.returncode,0,p.stderr)
   m=json.loads((d/'run/run_manifest.json').read_text());self.assertEqual(m['status'],'WORKLOAD_COMPLETED_IO_UNVERIFIED')
   self.assertEqual(len((d/'run/workload.jsonl').read_text().splitlines()),4)
 def test_mock_pilot_lifecycle(self):
  for node,arch,gpu in MOCK_HOSTS:
   with self.subTest(node=node,arch=arch):self._mock_pilot_lifecycle(node,arch,gpu)
if __name__=='__main__':unittest.main(verbosity=2)
