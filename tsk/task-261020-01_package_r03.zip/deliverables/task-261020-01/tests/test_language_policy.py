"""Language-policy regression checks for maintained artifacts and CLI output."""
import pathlib,subprocess,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]

class LanguagePolicy(unittest.TestCase):
    def test_maintained_artifacts_are_ascii_english(self):
        exceptions={ROOT/'reports/Technical_Report_KO.md'}
        suffixes={'.py','.sh','.mmd','.md','.json','.cu','.hpp','.patch','.csv','.txt'}
        failures=[]
        for path in ROOT.rglob('*'):
            if not path.is_file() or path.suffix not in suffixes or path in exceptions:continue
            if any(part in ('source_evidence','source_repos','__pycache__','runtime','tmp') for part in path.relative_to(ROOT).parts):continue
            text=path.read_text()
            if not text.isascii():failures.append(str(path.relative_to(ROOT)))
        self.assertEqual(failures,[],f'Non-ASCII content outside the Korean technical report: {failures}')

    def test_cli_help_is_english(self):
        result=subprocess.run([sys.executable,str(ROOT/'bx_gds_test_top.py'),'--help'],capture_output=True,text=True,check=True)
        self.assertTrue(result.stdout.isascii());self.assertIn('Typical examples',result.stdout)

    def test_korean_technical_report_is_retained(self):
        report=ROOT/'reports/Technical_Report_KO.md'
        self.assertTrue(report.is_file())
        self.assertTrue(any('\uac00'<=c<='\ud7af' for c in report.read_text()))

if __name__=='__main__':unittest.main(verbosity=2)
