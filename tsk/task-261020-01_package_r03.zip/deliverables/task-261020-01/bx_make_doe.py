#!/usr/bin/env python3
"""Node-specific plans with common baselines and gated native extensions."""
import argparse,csv,itertools,pathlib,random
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--node',choices=['node2','node3'],default='node3');a=p.parse_args()
out=pathlib.Path(__file__).resolve().parent/'doe';out.mkdir(exist_ok=True)
models=['facebook/opt-125m','Qwen/Qwen2.5-0.5B','Qwen/Qwen3-30B-A3B']
paths=[('raw_cpu','host'),('file_cpu','host'),('cufile_fs','compat')]
if a.node=='node2':paths += [('cufile_fs','native'),('ugds_raw','native')]
rows=[]
for stage,model in enumerate(models,1):
    conditions=[(256,1024,1,reuse) for reuse in ('cold','full','partial')]
    if stage==1:conditions+=list(itertools.product([128,512],[257,1792],[1,4],['full']))
    for repeat in range(1,4):
        cases=list(itertools.product(paths,conditions));random.Random(261020+stage*100+repeat).shuffle(cases)
        for (backend,mode),(chunk,tokens,concurrency,reuse) in cases:
            rows.append([f'{a.node}-{len(rows)+1:04d}',a.node,stage,repeat,model,backend,mode,chunk,tokens,concurrency,reuse,32,1,16,'float16' if stage==1 else 'bfloat16','none','UNMEASURED','PROBE_REQUIRED' if mode=='native' else 'PILOT_PENDING'])
fields=['case_id','node_id','stage','replicate','model','path','requested_mode','requested_chunk_tokens','prompt_tokens','concurrency','reuse','output_tokens','tp','vllm_block_tokens','kv_dtype','profiler','status','eligibility']
with (out/f'{a.node}_cases.csv').open('w') as f:w=csv.writer(f);w.writerow(fields);w.writerows(rows)
print(f'{a.node}: {len(rows)} planned, UNMEASURED; none profiler is the performance baseline. nsys/ncu are separate diagnostic runs.')
