#!/usr/bin/env bash
# Read-only. Does not mount, format, unbind, change ACS/IOMMU, or write devices.
set -u
uname -a
command -v nvidia-smi >/dev/null && nvidia-smi -q
command -v nvidia-smi >/dev/null && nvidia-smi topo -m
command -v lspci >/dev/null && lspci -tv
command -v lsblk >/dev/null && lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL
command -v findmnt >/dev/null && findmnt -t xfs,ext4
if test -x /usr/local/cuda/gds/tools/gdscheck; then /usr/local/cuda/gds/tools/gdscheck -p; fi
if test -r /proc/driver/nvidia-fs/stats; then cat /proc/driver/nvidia-fs/stats; fi
python3 -m pip show vllm lmcache torch cufile-python 2>/dev/null || true
