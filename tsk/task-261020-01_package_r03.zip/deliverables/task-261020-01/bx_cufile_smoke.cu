// Hardware smoke only; not compiled/run in the CPU-only authoring environment.
// cuFile API success does NOT prove P2P DMA. DGX Spark is compatibility-only.
#include <cuda_runtime.h>
#include <cufile.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <vector>
#include "bx_native_trace.hpp"
int main(int argc,char**argv){
 if(argc!=2){fprintf(stderr,"usage: %s NEW_DISPOSABLE_FILE (must not exist)\n",argv[0]);return 2;}
 constexpr size_t n=4*1024*1024;
 int fd=-1;void* a=nullptr;void* b=nullptr;CUfileHandle_t h{};bool registered=false,opened=false;int result=1;
 try{
  auto check=[](cudaError_t e){if(e!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(e));};
  auto ce=cuFileDriverOpen();if(ce.err!=CU_FILE_SUCCESS)throw std::runtime_error("cuFileDriverOpen failed");opened=true;
  fd=open(argv[1],O_CREAT|O_EXCL|O_RDWR|O_DIRECT,0600);if(fd<0)throw std::runtime_error("exclusive file open failed");
  if(posix_fallocate(fd,0,n)!=0)throw std::runtime_error("preallocation failed");
  check(cudaMalloc(&a,n));check(cudaMalloc(&b,n));check(cudaMemset(a,0x5a,n));check(cudaMemset(b,0,n));check(cudaDeviceSynchronize());
  CUfileDescr_t desc{};desc.type=CU_FILE_HANDLE_TYPE_OPAQUE_FD;desc.handle.fd=fd;
  ce=cuFileHandleRegister(&h,&desc);if(ce.err!=CU_FILE_SUCCESS)throw std::runtime_error("cuFileHandleRegister failed");registered=true;
  ssize_t done;
  {bx::Scope scope("cuFileWrite_sync_smoke",0,n);done=cuFileWrite(h,a,n,0,0);}
  if(done!=(ssize_t)n)throw std::runtime_error("short/error write");
  {bx::Scope scope("cuFileRead_sync_smoke",0,n);done=cuFileRead(h,b,n,0,0);}
  if(done!=(ssize_t)n)throw std::runtime_error("short/error read");
  std::vector<unsigned char>host(n);check(cudaMemcpy(host.data(),b,n,cudaMemcpyDeviceToHost));
  for(auto x:host)if(x!=0x5a)throw std::runtime_error("payload mismatch");
  puts("{\"status\":\"pass\",\"bytes\":4194304,\"scope\":\"API roundtrip only\",\"observed_path\":\"unverified\",\"dma_path_verified\":false}");result=0;
 }catch(const std::exception&e){fprintf(stderr,"smoke failed: %s\n",e.what());}
 if(registered)cuFileHandleDeregister(h);if(a)cudaFree(a);if(b)cudaFree(b);if(fd>=0)close(fd);if(opened)cuFileDriverClose();
 return result;
}
