#!/usr/bin/env python3
"""Profile a finite managed pilot. Never run nsys and ncu together."""
import argparse,json,pathlib,shlex,shutil,subprocess,sys
from bx_platform import ROOT,utc_id,mode_for,check_arch

def profiler_command(tool,report,child,kernel_regex=None,launch_count=8):
    if tool=='nsys':return ['nsys','profile','--trace=cuda,nvtx,osrt','--sample=none','--cpuctxsw=none','--wait=all','--output',str(report),*child]
    if not kernel_regex:raise ValueError('ncu requires --kernel-regex from a prior nsys capture; no whole-model default')
    return ['ncu','--target-processes','all','--kernel-name','regex:'+kernel_regex,'--launch-count',str(launch_count),'--set','basic','--section','SpeedOfLight','--section','Occupancy','--section','MemoryWorkloadAnalysis','--replay-mode','kernel','--export',str(report),*child]

def run_logged(cmd,path):
    with path.open('w') as f:return subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--node',choices=['node2','node3'],default='node3');p.add_argument('--tool',choices=['nsys','ncu'],required=True);p.add_argument('--kernel-regex');p.add_argument('--launch-count',type=int,default=8);p.add_argument('--execute',action='store_true');p.add_argument('--output-dir',type=pathlib.Path)
    a,rest=p.parse_known_args()
    if a.launch_count<1:p.error('launch-count must be positive')
    if a.tool=='ncu' and not a.kernel_regex:p.error('select --kernel-regex after nsys; e.g. a measured KV transfer kernel name')
    if '--run-dir' in rest:p.error('profile owns run-dir')
    run=a.output_dir.resolve() if a.output_dir else ROOT/'runtime'/a.node/(a.tool+'-'+utc_id())
    if not run.is_relative_to(ROOT):p.error('output-dir must be below deliverables task directory')
    report=run/a.tool
    child=[sys.executable,str(ROOT/'bx_run_pilot.py'),'--node',a.node,'--run-dir',str(run/'pilot'),'--nvtx','--stream',*rest]
    if a.execute:child+=['--execute']
    # Validate backend/node/arguments even when producing a plan, without launching anything.
    validation=subprocess.run([sys.executable,str(ROOT/'bx_run_pilot.py'),'--node',a.node,*rest],capture_output=True,text=True)
    if validation.returncode:print(validation.stderr,file=sys.stderr);return validation.returncode
    cmd=profiler_command(a.tool,report,child,a.kernel_regex,a.launch_count)
    print(shlex.join(cmd))
    if not a.execute:print('PLAN ONLY. --execute runs a diagnostic capture, not a latency baseline.');return 0
    check_arch(a.node)
    if not shutil.which(a.tool):p.error(a.tool+' is unavailable; install matching host-architecture build')
    run.mkdir(parents=True,exist_ok=False)
    metadata={'node_id':a.node,'tool':a.tool,'command':cmd,'scope':'whole managed pilot incl startup/warmup; filter timeline before steady-state attribution','native_dma_verified':False,'performance_baseline':False}
    metadata['profile_returncode']=run_logged(cmd,run/'profiler.log')
    exports=[]
    if a.tool=='nsys':
        source=report.with_suffix('.nsys-rep')
        if source.exists():
            for name in ('cuda_gpu_kern_sum','cuda_gpu_mem_time_sum','cuda_gpu_mem_size_sum','cuda_api_sum','nvtx_sum'):
                output=run/(name+'.csv');rc=run_logged(['nsys','stats','--report',name,'--format','csv',str(source)],output);exports.append({'file':output.name,'returncode':rc})
            rc=run_logged(['nsys','export','--type','sqlite','--output',str(run/'timeline.sqlite'),str(source)],run/'sqlite_export.log');exports.append({'file':'timeline.sqlite','returncode':rc})
        else:metadata['warning']='No .nsys-rep; capture failed or did not finalize';metadata['profile_returncode']=metadata['profile_returncode'] or 1
    else:
        source=report.with_suffix('.ncu-rep')
        if source.exists():exports.append({'file':'ncu_metrics.csv','returncode':run_logged(['ncu','--import',str(source),'--page','raw','--csv'],run/'ncu_metrics.csv')})
        else:metadata['warning']='No .ncu-rep; permissions, GPU support, filter or capture failure';metadata['profile_returncode']=metadata['profile_returncode'] or 1
    pilot_manifest=run/'pilot/run_manifest.json'
    if pilot_manifest.exists():
        metadata['pilot_status']=json.loads(pilot_manifest.read_text()).get('status')
    else:metadata['pilot_status']='MISSING'
    if metadata['pilot_status']!='WORKLOAD_COMPLETED_IO_UNVERIFIED':metadata['profile_returncode']=metadata['profile_returncode'] or 1
    metadata['exports']=exports
    (run/'profile_manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
    result=run_logged([sys.executable,str(ROOT/'bx_analyze.py'),'--node',a.node,'--run-dir',str(run)],run/'analysis.log')
    print(run);return metadata['profile_returncode'] or next((e['returncode'] for e in exports if e['returncode']),0) or result
if __name__=='__main__':raise SystemExit(main())
