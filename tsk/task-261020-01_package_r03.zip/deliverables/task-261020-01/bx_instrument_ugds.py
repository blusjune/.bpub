#!/usr/bin/env python3
"""Exact-anchor source instrumentation, refuses drift; original backup enables rollback."""
import argparse, pathlib, shutil
p=argparse.ArgumentParser();p.add_argument('repo',type=pathlib.Path);a=p.parse_args()
f=a.repo/'src/ugds_io.cpp';s=f.read_text()
if '#include "bx_native_trace.hpp"' in s: raise SystemExit('Already instrumented')
anchors=[('    HandleState* hs = static_cast<HandleState*>(fh);','    bx::Scope bx_scope("do_io_internal", file_offset, size);\n    bx::mark(opcode == 1 ? "NVMe_WRITE_host_start" : "NVMe_READ_host_start",file_offset,size);\n'),('            nvm_sq_submit(&qp.sq);','            bx::mark("SQ_tail_doorbell_before",current_lba * hs->block_size,chunk_size);\n'),('            uint16_t status = UGDS_CPL_SCT_SC(cpl);','            bx::mark("CQ_entry_observed_not_yet_status_checked",current_lba * hs->block_size,chunk_size);\n')]
for anchor,insert in anchors:
    if s.count(anchor)!=1: raise SystemExit('Source drift: '+anchor)
    s=s.replace(anchor,insert+anchor)
s='#include "bx_native_trace.hpp"\n'+s
shutil.copy2(f,str(f)+'.bx-original')
shutil.copy2(pathlib.Path(__file__).with_name('bx_native_trace.hpp'),a.repo/'src/bx_native_trace.hpp')
f.write_text(s)
print('Instrumented synchronous core used by async worker; batch path not covered. Rebuild uGDS. Restore .bx-original to undo.')
