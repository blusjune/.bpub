# BX trace sequence

**SYNTHETIC TEST DATA**

Events: 4; incomplete spans: 0. Same-host monotonic clock only.

## Page 1

```mermaid
sequenceDiagram
autonumber
participant vLLM as vLLM
participant LMCache as LMCache
vLLM->>vLLM: 0.000000ms p1/t1 synthetic_request span=s1 args=  request_id    example  
vLLM->>LMCache: 0.100000ms p1/t1 synthetic_submit_load span=s2 args=  file_offset   4096,  size   9437184 
Note over LMCache: 0.200000ms p1/t1 synthetic_submit_load span=s2 segment end 0.100000ms
Note over vLLM: 0.300000ms p1/t1 synthetic_request span=s1 segment end 0.300000ms
```
