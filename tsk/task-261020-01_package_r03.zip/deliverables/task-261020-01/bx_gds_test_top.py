#!/usr/bin/env python3
"""Single maintained top-level entry point. Bash utilities are leaf helpers only."""
import argparse,json,os,pathlib,shutil,subprocess,sys
from bx_platform import ROOT,profile,observe,check_arch,utc_id,run_environment,mode_for
EXAMPLES='''Typical examples (pilot/profile print plans unless --execute is supplied):
  python3 bx_gds_test_top.py --node node2 preflight
  python3 bx_gds_test_top.py --node node3 suite
  python3 bx_gds_test_top.py --node node2 plan --path raw_cpu --storage /dev/DISPOSABLE_ONLY
  python3 bx_gds_test_top.py --node node2 pilot --path raw_cpu --storage /dev/DISPOSABLE_ONLY --execute --trace --stream
  python3 bx_gds_test_top.py --node node3 pilot --path cufile_fs --storage /mnt/experiment --execute
  python3 bx_gds_test_top.py --node node2 profile --tool nsys --path raw_cpu --storage /dev/DISPOSABLE_ONLY --execute
  python3 bx_gds_test_top.py --node node2 profile --tool ncu --kernel-regex '.*kv_transfer.*' --path raw_cpu --storage /dev/DISPOSABLE_ONLY --execute
  python3 bx_gds_test_top.py --node node2 analyze --run-dir runtime/node2/RUN
  python3 bx_gds_test_top.py --node node3 smoke --execute
  python3 bx_gds_test_top.py --node node2 doe
  python3 bx_gds_test_top.py diagram logs.jsonl -o observed.md
  python3 bx_gds_test_top.py validate
node2 native GDS: --path cufile_fs --gds-mode native (probe required; success is NOT DMA proof).
node3 native GDS/uGDS are blocked. Never load nvidia-fs on Spark.
Profiler runs are diagnostic; collect an unprofiled baseline separately.
'''
def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__,epilog=EXAMPLES,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--node',choices=['node2','node3'],default='node3',help='node2 Intel/RTX PRO 6000; node3 DGX Spark (default)')
    parser.add_argument('stage',nargs='?',default='help',choices=['help','suite','validate','preflight','fetch','doe','plan','pilot','workload','diagram','instrument','smoke','profile','analyze'])
    parser.add_argument('arguments',nargs=argparse.REMAINDER,help='stage options; use STAGE --help')
    a=parser.parse_args(argv);args=a.arguments
    if a.stage=='help':parser.print_help();return 0
    if a.stage in ('suite','validate','preflight'):
        descriptions={
            'suite':'Run tool validation, read-only preflight, then node-specific DoE generation. Stops on the first failure.',
            'validate':'Run CPU/mock regression tests and save validation logs. No physical GPU/storage experiment is performed.',
            'preflight':'Collect read-only host/GPU/tool observations and compare them with the selected node profile.'}
        stage_parser=argparse.ArgumentParser(
            prog=f'{parser.prog} --node {a.node} {a.stage}',
            description=descriptions[a.stage],
            epilog='Example: python3 bx_gds_test_top.py --node '+a.node+' '+a.stage)
        # Parse before any stage action: --help exits without tests or writes.
        stage_parser.parse_args(args)
    if a.stage=='suite':
        for stage in ('validate','preflight','doe'):
            result=main(['--node',a.node,stage])
            if result:return result
        return 0
    if a.stage=='preflight':
        dest=ROOT/'runtime'/a.node/('preflight-'+utc_id());dest.mkdir(parents=True)
        data=observe(a.node);(dest/'capabilities.json').write_text(json.dumps(data,indent=2)+'\n')
        with (dest/'environment.txt').open('w') as f:subprocess.run(['bash',str(ROOT/'bx_preflight.sh')],stdout=f,stderr=subprocess.STDOUT)
        print(dest);return 0 if data['architecture_matches_profile'] and data['gpu_matches_profile'] else 2
    if a.stage=='smoke':
        sp=argparse.ArgumentParser();sp.add_argument('--execute',action='store_true');sp.add_argument('--gds-mode',choices=['auto','compat','native'],default='auto');s=sp.parse_args(args)
        mode=mode_for(a.node,'cufile_fs',s.gds_mode)
        if not s.execute:print('PLAN ONLY: compile and run 4 MiB cuFile API roundtrip; mode='+mode);return 0
        check_arch(a.node)
        if not shutil.which('nvcc'):raise RuntimeError('nvcc unavailable')
        dest=ROOT/'runtime'/a.node/('smoke-'+utc_id());dest.mkdir(parents=True)
        env=run_environment(a.node,dest,'cufile_fs',mode);env.update(BX_TRACE_DIR=str(dest))
        subprocess.run(['nvcc','-std=c++17','-I'+str(ROOT),str(ROOT/'bx_cufile_smoke.cu'),'-lcufile','-o',str(dest/'smoke')],check=True)
        with (dest/'smoke.log').open('w') as f:r=subprocess.run([str(dest/'smoke'),str(dest/'new-file.bin')],env=env,stdout=f,stderr=subprocess.STDOUT)
        (dest/'result.json').write_text(json.dumps({'node_id':a.node,'requested_path':mode,'api_roundtrip_returncode':r.returncode,'native_dma_verified':False},indent=2));print(dest);return r.returncode
    mapping={'validate':('bash','bx_run_validation.sh'),'fetch':(sys.executable,'bx_fetch_sources.py'),'doe':(sys.executable,'bx_make_doe.py'),'plan':(sys.executable,'bx_plan_commands.py'),'pilot':(sys.executable,'bx_run_pilot.py'),'workload':(sys.executable,'bx_workload.py'),'diagram':(sys.executable,'bx_gen_seqdiag_from_tracelog.py'),'instrument':(sys.executable,'bx_instrument_ugds.py'),'profile':(sys.executable,'bx_profile.py'),'analyze':(sys.executable,'bx_analyze.py')}
    exe,script=mapping[a.stage]
    if a.stage in ('doe','plan','pilot','profile','analyze'):args=['--node',a.node,*args]
    if a.stage=='fetch' and not args:args=['--dest',str(ROOT/'source_repos')]
    return subprocess.run([exe,str(ROOT/script),*args]).returncode
if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,ValueError,OSError) as e:print('ERROR: '+str(e),file=sys.stderr);raise SystemExit(2)
