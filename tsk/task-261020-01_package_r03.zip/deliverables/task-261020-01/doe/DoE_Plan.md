# Node 2 / node 3 Design of Experiments

Single entry point: `python3 bx_gds_test_top.py --node node2|node3 doe`.

| Target | Planned cases | Included paths |
|---|---:|---|
| node 2 | 255 | raw_cpu, file_cpu, cuFile compatibility, cuFile native, ugds_raw |
| node 3 | 153 | raw_cpu, file_cpu, cuFile compatibility |

All cases are UNMEASURED. Native cases are PROBE_REQUIRED, not certified as supported. Node 3 native/uGDS cases are not generated and explicit requests are rejected. Compare the 153 common conditions, but do not attribute cross-node differences exclusively to GDS: the hardware also differs.

Stages progress from OPT-125M (MHA + dense) to Qwen2.5-0.5B (GQA + dense) and Qwen3-30B-A3B (GQA + MoE). Defaults are chunk size 256, context length 1024, concurrency 1, three candidate reuse conditions (cold/full/partial), and three repeats. The MHA stage adds boundary experiments with chunks 128/512, inputs 257/1792, and concurrency 1/4.

Use raw_cpu for the first storage experiment. Follow with a pre-sized, physically allocated file using the same RawBlock backend, then add cuFile paths. Control slots, headers, checkpoints, SSD state, and LBA placement in raw/file comparisons. Separate metadata/checkpoint I/O from KV payload.

Record actual negotiated chunk size, KV dtype, node/run IDs, source/package versions, device/firmware, memory budget, profiler, errors, checksums, and cache-hit tier. Recompute slot size when negotiation changes the requested chunk. A second round does not prove an SSD hit; exceed the L1 working set while preserving L2 and verify actual L2 completion.

CSV `profiler=none` identifies the serving-performance baseline. Run nsys/ncu diagnostics separately and match cache state before comparison. Do not use NCU serving latency as a baseline. Because the selected models have different geometries, isolated causal claims about attention or MoE require additional matched control models.
