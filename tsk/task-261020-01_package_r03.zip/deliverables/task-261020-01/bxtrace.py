"""CPU Python function execution segments; never labels API return as DMA completion."""
import atexit, asyncio, hashlib, json, math, os, re, socket, sys, threading, time
_lock = threading.RLock()
_state = {}
_roots = ()
_nvtx = None
_installed = False
_match = None

def _safe(v, depth=0):
    if type(v) is float and not math.isfinite(v): return str(v)
    if v is None or type(v) in (int, float, bool): return v
    if isinstance(v, str): return v[:160]
    if depth < 2 and isinstance(v, (list, tuple)):
        return [_safe(x, depth+1) for x in v[:8]]
    if depth < 2 and isinstance(v, dict):
        return {str(k)[:60]: _safe(x, depth+1) for k,x in list(v.items())[:12]}
    # Do not call repr(), tensor.cpu(), item(), or data_ptr() in the profiler.
    return {"type": type(v).__name__}

def _task():
    try:
        t = asyncio.current_task()
        return str(id(t)) if t else None
    except RuntimeError: return None

def _get_state():
    pid = os.getpid()
    if pid not in _state:
        directory = os.environ.get('BX_TRACE_DIR', './traces')
        os.makedirs(directory, exist_ok=True)
        _state[pid] = {'fd': os.open(f'{directory}/python-{pid}.jsonl', os.O_WRONLY|os.O_CREAT|os.O_APPEND, 0o600), 'seq':0, 'active':{}}
    return _state[pid]

def _write(s, event):
    b = (json.dumps(event, ensure_ascii=True, allow_nan=False)+'\n').encode()
    # Lock serializes all thread writers; handle short writes explicitly.
    while b:
        n = os.write(s['fd'], b)
        if n <= 0: raise OSError('trace short write')
        b = b[n:]

def _profile(frame, event, arg):
    if event not in ('call','return'): return
    filename = os.path.abspath(frame.f_code.co_filename)
    if not any(filename == root or filename.startswith(root+os.sep) for root in _roots): return
    if _match and not _match.search(frame.f_code.co_qualname): return
    try:
        with _lock:
            s = _get_state(); key = id(frame)
            if event == 'call':
                s['seq'] += 1
                span = f"py-{os.getpid()}-{s['seq']}"
                parent_frame = frame.f_back
                parent = None
                while parent_frame:
                    info = s['active'].get(id(parent_frame))
                    if info: parent = info['span']; break
                    parent_frame = parent_frame.f_back
                component = 'vLLM' if '/vllm/' in filename else ('ModelHost' if '/transformers/' in filename else 'LMCache')
                info = dict(schema=1, node_id=os.environ.get('BX_NODE_ID','unknown'), run_id=os.environ.get('BX_RUN_ID','unknown'), host=socket.gethostname(), clock='monotonic_ns', pid=os.getpid(), tid=threading.get_native_id(), task=_task(), span=span, parent=parent, component=component, fn=frame.f_code.co_qualname, file=filename, line=frame.f_code.co_firstlineno, evidence='observed_cpu_segment')
                s['active'][key] = info
                argc = frame.f_code.co_argcount + frame.f_code.co_kwonlyargcount
                args = {n:_safe(frame.f_locals[n]) for n in frame.f_code.co_varnames[:argc] if n in frame.f_locals and n not in ('self','cls','tokens','input_ids','prompt')}
                _write(s, dict(info, phase='B', ts_ns=time.monotonic_ns(), args=args))
                if _nvtx: _nvtx.push_range(span+' '+info['fn'])
            else:
                info = s['active'].pop(key, None)
                if info:
                    if _nvtx: _nvtx.pop_range()
                    _write(s, dict(info, phase='E', ts_ns=time.monotonic_ns(), result=_safe(arg)))
    except Exception as exc:
        # Make instrumentation failures visible. Preserve application execution.
        sys.stderr.write('BX_TRACE_FAILURE '+type(exc).__name__+'\n')

def install(roots):
    global _roots, _nvtx, _installed, _match
    if _installed: return
    if sys.getprofile() is not None or threading.getprofile() is not None:
        raise RuntimeError('Existing profiler found; use a separate diagnostic run')
    _roots = tuple(os.path.realpath(x) for x in roots)
    _match = re.compile(os.environ['BX_TRACE_MATCH']) if os.environ.get('BX_TRACE_MATCH') else None
    if os.environ.get('BX_NVTX') == '1':
        import nvtx
        _nvtx = nvtx
    _installed = True
    sys.setprofile(_profile); threading.setprofile(_profile)

def stop():
    global _installed
    sys.setprofile(None); threading.setprofile(None)
    _installed = False
    # Active suspended generators remain incomplete; parser reports them.
    for s in list(_state.values()):
        try: os.close(s['fd'])
        except OSError: pass
    _state.clear()
atexit.register(stop)
