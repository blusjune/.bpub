# Nsight analysis of KV offload/onboard flow and bottlenecks

build: brianmjung_20261021_001015

## Responsibilities and observability

| Tool | Observations | What it cannot directly establish |
|---|---|---|
| BX JSONL + NVTX | CPU function execution segments, argument summaries, native SQ/CQ markers | GPU completion, actual NVMe bytes, NAND latency |
| Nsight Systems | CPU CUDA APIs, GPU kernels/copies, stream dependencies, NVTX/OSRT | Every internal cuFile/NVMe stage or a complete SSD DMA timeline |
| Nsight Compute | Selected gather/scatter/transfer kernel time, memory throughput, occupancy | SSD controller DMA, NVMe queue depth, serving latency |
| Block/native/device traces | Block issue/completion, user-space NVMe SQ/CQ, SSD host counters | Internal NAND write amplification without device telemetry |

Use nsys first to locate relevant processes, kernels, and streams, then apply ncu to selected kernels. GDS includes staging kernels, copy engines, and storage DMA; ncu alone cannot explain the complete I/O path. The MP server can also launch GPU kernels, so capture children of the root controller.

## Recommended three-run workflow

1. `pilot --execute --stream`: untraced baseline. Fix the model, seed, cache state, working set, and L1 size.
2. `profile --tool nsys ... --execute`: CUDA/NVTX/OSRT diagnostics with additional Python instrumentation/NVTX overhead.
3. `profile --tool ncu --kernel-regex 'MEASURED_KERNEL_NAME' --requests 2 ... --execute`: limited kernel-counter collection; default launch count is eight.

Use separate runs and match startup, warmup, steady-state, and cold/hit conditions on the same node. If cache state also changes, the performance difference cannot be attributed solely to profiler overhead. The harness does not guarantee automatic cache-state reset.

The baseline nsys command is `nsys profile --trace=cuda,nvtx,osrt --sample=none --cpuctxsw=none --wait=all`, with CPU sampling disabled. Check support in the installed version. NCU uses `--target-processes all`, an explicit kernel regex, a limited launch count, the basic set, and SpeedOfLight/Occupancy/MemoryWorkloadAnalysis. Preserve counter permission/support errors. Kernel replay can change concurrency, cache state, and synchronization. Do not report profiled serving latency as baseline performance.

## Quantitative outputs

| Metric | Calculation and units | Interpretation |
|---|---|---|
| Request elapsed p50/p95/p99 | Client monotonic end minus start, ms | Also available for nonstreaming requests; not TTFT |
| TTFT p50/p95/p99 | Request start to first nonempty text SSE chunk, ms | Client observation including network/queue delay |
| Content-chunk gap | Time between content-bearing SSE events, ms | A chunk can contain multiple tokens; not token TPOT |
| CPU function segments | Matching PID/span B/E difference, ms | Inclusive duration; nested sums are not additive |
| Kernel union | Union of GPU kernel intervals, ms | Concurrent kernels are not double-counted |
| Copy union | Union of CUDA memcpy intervals, ms | Not a direct measurement of SSD DMA |
| Kernel/copy overlap | Intersection of the two interval unions, ms | Shows overlap, not automatically time removed from the critical path |
| Observed GPU activity fraction | Kernel/copy union divided by selected window | Not SM utilization; reflects only available activity classes |
| Weighted CUDA-copy bandwidth | Unclipped bytes divided by the sum of their copy durations | Not aggregate link bandwidth when copies overlap, and not SSD bandwidth |
| Hot kernels | Per-kernel summed duration and launch count | The sum can exceed wall time because of concurrency |
| NCU metrics | Original metric name, value, and unit per kernel | Record available counters; do not turn missing values into zero |

SQLite schemas vary between Nsight versions. The parser uses known fields from StringIds, CUPTI_ACTIVITY_KIND_KERNEL, and CUPTI_ACTIVITY_KIND_MEMCPY. Missing tables/columns produce warnings or null values. It does not automatically join NVTX ranges with kernel correlations to derive request-level critical paths. Inspect standard OSRT/CUDA API/NVTX CSV reports alongside the timeline.

The default GPU window spans the first through last observed GPU activity and can include model loading/warmup. Select steady-state in the GUI, then rerun analysis using `--gpu-window-start-ns` and `--gpu-window-end-ns` with the SQLite time origin. Do not directly pass BX monotonic timestamps as SQLite timestamps. Clock-origin calibration between these sources is not implemented.

## Forming bottleneck hypotheses

- Long CPU submit/wait segments with GPU gaps: correlate with OS/native traces to distinguish lookup/RPC, queues, CPU threads, and storage waits. Inclusive function duration alone does not identify the cause.
- Large gather/scatter kernel share: inspect ncu memory throughput, occupancy, and launch shape. Low occupancy alone is not proof of a bottleneck; determine whether memory bandwidth is limiting.
- Large CUDA-copy cost: inspect CPU staging, fallback, and buffer rearrangement. Spark can retain API copy costs even when allocations share the same physical LPDDR5x pool.
- Slow SSD reads: verify the actual cache-hit tier, chunk splitting, queue depth, metadata/checkpoints, and alignment using storage-layer evidence. An empty kernel block trace does not prove that uGDS performed no I/O.
- High hit ratio: distinguish vLLM GPU-prefix, CPU-L1, and SSD hits. A second workload round alone does not prove an SSD hit.

Do not attribute the full latency difference between node 2 native and node 3 compatibility mode to GDS. First compare native/compatibility paths within node 2.

## Verification and limitations

The authoring environment has not executed physical nsys/ncu/GPU/SSD captures. Tests cover interval unions/overlap with known synthetic values, missing schemas, metric parsing, SSE timing, mock exports, and failure handling. CUDA smoke still requires compilation against the actual toolkit. Native DMA proof, SSD latency/bandwidth, NAND write amplification, and production SLO measurements remain pending.

## Official references

- Nsight Systems User Guide: https://docs.nvidia.com/nsight-systems/UserGuide/index.html
- Nsight Systems Analysis Guide: https://docs.nvidia.com/nsight-systems/AnalysisGuide/index.html
- Nsight Compute CLI: https://docs.nvidia.com/nsight-compute/NsightComputeCli/index.html
- Nsight Compute Profiling Guide: https://docs.nvidia.com/nsight-compute/ProfilingGuide/index.html
- GDS configuration: https://docs.nvidia.com/gpudirect-storage/configuration-guide/index.html
- GDS troubleshooting: https://docs.nvidia.com/gpudirect-storage/troubleshooting-guide/index.html
- GDS release notes: https://docs.nvidia.com/gpudirect-storage/release-notes/index.html
