# Node 2/node 3 and Nsight integration changes

The original shell entry point was a thin wrapper around the Python dispatcher. Only `bx_gds_test_top.py` remains. Redundant shell dispatchers were removed; functional environment/validation Bash utilities remain leaf helpers.

- Added node profiles and CPU/GPU identity, memory, NUMA, toolkit, Nsight, and package observations.
- Matched cuFile compatibility baselines across both nodes; added the node 2 native-candidate preflight gate and node 3 native/uGDS rejection.
- Added per-run cuFile overlays without automatic global driver/GRUB/IOMMU/ACS changes.
- Added 255 node 2 and 153 node 3 planned cases, all UNMEASURED; profiling runs remain separate diagnostics.
- Added SSE TTFT, request elapsed time, and content-chunk gaps. Chunk gaps are not token TPOT.
- Added nsys controller/child-process capture and standard CSV/SQLite exports.
- Added filtered ncu capture with limited launches and SpeedOfLight, Occupancy, and MemoryWorkloadAnalysis sections.
- Kept nsys/ncu separate and rejected missing reports, failed exports, and failed pilots as successful captures.
- Added CPU inclusive-segment, GPU interval-union/overlap, kernel-time, CUDA-copy, and NCU-metric analysis.
- Rejected cross-node/run/host BX monotonic trace merging.
- Replaced the smoke test's Spark-specific result string with observed_path=unverified.
- The preceding functional revision passed 34 CPU/mock tests. Physical CUDA/Nsight paths and the dependency matrix remain unverified.
- Restricted Korean explanatory text to Technical_Report_KO.md. Converted maintained help, scripts, Mermaid content, README, DoE plan, profiling guide, and this change log to English. Added language-policy regression checks.

Upstream source snapshots and licenses retain their original bytes. function_inventory.csv lists pinned upstream functions, not harness functions. Node-specific CSV files replace the original DoE CSV. The current validation log is authoritative for the final test count.

Language-policy revision: all 37 CPU/mock tests passed, including three language checks. Korean/CJK explanatory text appears only in Technical_Report_KO.md. Hardware verification status is unchanged.


## r03: help dispatch and architecture-independent mock tests

- Fixed `suite --help`, `validate --help`, and `preflight --help` executing actions.
- Reject unknown local-stage arguments before launching tests or collecting data.
- Run mock pilot, profiler-export, and missing-report cases with both simulated
  x86_64/node2 and aarch64/node3 identities, regardless of the physical test host.
- Mock hardware observation inside test subprocesses; retain strict production
  architecture guards and verify both mismatched-node cases still fail.
- Added four regression tests. All 41 CPU/mock tests pass. Physical ARM64/CUDA
  execution remains a hardware verification step.
