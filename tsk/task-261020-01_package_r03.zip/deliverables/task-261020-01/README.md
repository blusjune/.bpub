# task-261020-01: GDS and KV I/O experiments on node 2 and node 3

build: brianmjung_20261021_001015

**`bx_gds_test_top.py` is the only top-level entry point.** The redundant shell entry point and shell dispatchers have been removed. Bash environment and validation utilities remain leaf helpers called by Python.

**Node 3 (DGX Spark) supports cuFile compatibility mode only. Do not load nvidia-fs on Spark. Node 2 (Intel + RTX PRO 6000) is a native-path candidate requiring validation.** Selecting a profile does not certify hardware support or direct DMA.

Language policy: `reports/Technical_Report_KO.md` uses Korean explanations with English technical terms. All other maintained scripts, messages, help text, Mermaid diagrams, and supporting documents use English. Upstream source snapshots and licenses retain their original bytes for provenance.

## Quick start

Run from the extracted `deliverables/task-261020-01/` directory:

```bash
python3 bx_gds_test_top.py --help
python3 bx_gds_test_top.py validate
python3 bx_gds_test_top.py --node node2 preflight
# On Spark:
python3 bx_gds_test_top.py --node node3 preflight
```

Place `--node` before the stage. `suite` runs tool validation, preflight, and node-specific DoE generation. It stops if the observed architecture or GPU does not match the selected profile. Neither physical node has been accessed from the authoring environment.

## Package layout

| Path | Purpose |
|---|---|
| `profiles/node2.json`, `node3.json` | CPU architecture, memory topology, and path policies |
| `bx_gds_test_top.py` | Single CLI with typical usage examples |
| `bx_platform.py` | Environment observation, node policies, per-process cuFile overlays |
| `bx_run_pilot.py` | LMCache/vLLM startup, readiness, workload, cleanup, trace conversion, analysis |
| `bx_profile.py` | Separate Nsight Systems/Compute captures and exports |
| `bx_analyze.py` | Quantitative JSONL, SQLite, and NCU CSV analysis |
| `bx_gen_seqdiag_from_tracelog.py` | Observed BX function events to Mermaid |
| `doe/node2_cases.csv`, `node3_cases.csv` | 255 and 153 planned cases; all UNMEASURED |
| `reports/Technical_Report_KO.md` | Korean technical report on GDS/uGDS/BaM and source analysis |
| `reports/Profiling_Guide.md` | Observability, metrics, bottleneck interpretation, limitations |
| `tests/results/` | CPU/mock verification results, not hardware performance measurements |
| `source_evidence/`, `models/` | Original source excerpts, licenses, and model configurations |

## Sources and installation

```bash
python3 bx_gds_test_top.py fetch
python3 bx_gds_test_top.py --node node2 doe
python3 bx_gds_test_top.py --node node3 doe
```

Fetching downloads pinned source SHAs; it does not install or build packages. `source_repos` contains complete repositories, while `source_evidence` contains analysis excerpts. Compatibility among independently pinned repository snapshots has not been validated. Download model weights separately.

Build/install Python and CUDA extensions separately for x86_64 on node 2 and aarch64 on node 3. Use the GPU Compute Capability reported by the actual torch/CUDA environment. If node 2 is offline, prepare matching packages, wheels, sources, and weights beforehand. Do not copy Spark binaries directly to node 2.

## Start storage experiments with Raw Block

```bash
# Plan only: no device writes.
python3 bx_gds_test_top.py --node node2 pilot --path raw_cpu --storage /dev/DISPOSABLE_ONLY
```

Verify a disposable, unmounted device before adding `--execute`. The harness rejects occupied ports 5555/8000 and mounted raw devices or child partitions. Do not target the complete boot SSD. RawBlock L2 also generates metadata/checkpoint I/O; its traffic is not exclusively KV payload.

```bash
# Replace the placeholder with a verified dedicated device before execution:
# python3 bx_gds_test_top.py --node node2 pilot --path raw_cpu --storage /dev/DEDICATED_DEVICE --execute --trace --stream
```

Select `--node node3` for the corresponding Spark experiment. After raw-device measurements, use `file_cpu` with a physically preallocated disposable file as the control. Size it for slots, headers, checkpoints, and the working set. The harness does not automatically create this file or format partitions.

Shared defaults are OPT-125M, FP16, TP=1, block size 16, requested chunk size 256, CPU L1 size 1 GiB, and GPU memory utilization 0.7. These budgets are starting points rather than optimized settings. Adjust them for actual RAM/VRAM and other processes. Recompute raw slot size if the negotiated chunk exceeds the requested size. Slot sizing assumes the baseline representation uses two bytes per element.

## cuFile compatibility, native candidates, and uGDS

```bash
# Matched compatibility controls:
python3 bx_gds_test_top.py --node node2 pilot --path cufile_fs --storage /mnt/experiment --gds-mode compat
python3 bx_gds_test_top.py --node node3 pilot --path cufile_fs --storage /mnt/experiment --gds-mode compat

# Node 2 native-candidate plan; execution requires matching preflight evidence:
python3 bx_gds_test_top.py --node node2 pilot --path cufile_fs --storage /mnt/experiment --gds-mode native --capabilities runtime/node2/PREFLIGHT/capabilities.json
```

`--gds-mode auto` resolves to compatibility mode on both nodes. Pilot/smoke runs use a per-run cuFile overlay and environment variables without changing `/etc/cufile.json`. **Copying only the LMCache/vLLM commands printed by `plan` does not apply the overlay.** Use `pilot` to preserve the path policy.

Node 2 native execution requires matching preflight identity and a current gdscheck native-path candidate. These are necessary checks, not proof that each I/O avoided fallback. Validate the installed cuFile logs/statistics and READ/WRITE results separately. Results retain `observed_path=unverified` and `native_dma_verified=false`; selecting native mode never sets these to verified automatically.

Node 2 `ugds_raw` accepts only an `ugds_drv` character device. A matching driver/library build, disposable dedicated SSD, capacity checks, and DMA mapping validation are prerequisites. Native GDS/uGDS are blocked on node 3. The harness does not automatically change IOMMU, ACS, driver bindings, or kernel modules.

## API smoke

```bash
python3 bx_gds_test_top.py --node node3 smoke --execute
```

This requires nvcc and cuFile. It writes and reads a 4 MiB pattern in a new file and refuses an existing file. CUDA compilation/execution has not been verified on either physical node. A successful API roundtrip is not direct-DMA proof.

## Tracing and profiling

`pilot --trace` enables function JSONL; `--nvtx` adds NVTX host ranges. Instrumentation targets the installed lmcache/vllm modules in the same Python environment. Use BX_TRACE_ROOTS/BX_TRACE_MATCH to narrow coverage. Complex arguments are summarized by type; instrumentation does not copy tensors to the CPU to inspect their contents.

```bash
# First inspect system flow:
python3 bx_gds_test_top.py --node node2 profile --tool nsys --path raw_cpu --storage /dev/DISPOSABLE_ONLY

# Then select the measured kernel name for NCU:
python3 bx_gds_test_top.py --node node2 profile --tool ncu --kernel-regex '.*kv_transfer.*' --path raw_cpu --storage /dev/DISPOSABLE_ONLY
```

Both examples produce plans until `--execute` is added. Nsight Systems captures CUDA/NVTX/OSRT and child processes, then exports standard CSV and SQLite. Nsight Compute collects basic metrics and SpeedOfLight, Occupancy, and MemoryWorkloadAnalysis for selected kernels. The two profilers run separately.

Install the `nvtx` Python package and Nsight builds supporting the host architecture/GPU, and ensure counter permissions are available. Permission errors are preserved; system permissions are not changed automatically. NCU replay can interact with communication/external synchronization, stall execution, or perturb latency. Start with a few requests and an exact kernel filter; reduce to an isolated kernel reproduction if necessary. After a timeout or interruption, check whether any workers started by the run remain alive.

## Quantitative results and Mermaid

Analysis runs automatically after pilot/profile cleanup and can be repeated manually:

```bash
python3 bx_gds_test_top.py --node node2 analyze --run-dir runtime/node2/RUN
# Window values use the Nsight SQLite time origin, in nanoseconds:
python3 bx_gds_test_top.py --node node2 analyze --run-dir runtime/node2/RUN --gpu-window-start-ns 1000000 --gpu-window-end-ns 2000000
python3 bx_gds_test_top.py diagram runtime/node2/RUN/traces/*.jsonl -o runtime/node2/RUN/observed_sequence.md
```

Outputs include `quantitative_summary.json`, `quantitative_report.md`, raw profiler reports, and exports. BX traces from a profile run are under `RUN/pilot/traces/`. Consult the Profiling Guide for interpretation.

- API submission/function return is not DMA completion.
- A capture including startup is not a steady-state measurement.
- The kernel/copy interval union is not SM utilization.
- CUDA memcpy statistics are not SSD DMA statistics.
- Do not directly merge monotonic traces from different nodes/runs.
- `--stream` measures client time to the first nonempty text chunk. Content-chunk gaps are not token TPOT.

## Verification status

See `tests/results/adversarial_test_results.log` and `verification_status.json`. Mock servers, profiler executables, and synthetic SQLite data do not represent physical GPU/SSD measurements. Physical node 2/3 dependency builds, CUDA smoke, native DMA, KV integrity, and performance still require hardware validation.


## Help and portable mock-test fix (r03)

`python3 bx_gds_test_top.py --node node3 suite --help` now prints help only.
The same applies to `validate --help` and `preflight --help`. Invalid local-stage
options are rejected before tests, observation, or output creation.

Mock lifecycle and profiler-export tests exercise both node2/x86_64 and
node3/aarch64 identities inside isolated test subprocesses. Hardware observation
and external tools are mocked there. Production architecture checks remain
strict; no skip-architecture flag or environment variable was added.

After replacing the package files in the existing task directory, run:

```bash
python3 bx_gds_test_top.py --node node3 suite --help
python3 bx_gds_test_top.py --node node3 validate
python3 bx_gds_test_top.py --node node3 suite
```

Expected results: the first command prints no test output; validate runs 41 tests;
suite then performs the real read-only preflight and generates node3 DoE cases
only if validation and preflight succeed. Passing mock tests does not certify
physical Spark/RTX hardware or native DMA support.
