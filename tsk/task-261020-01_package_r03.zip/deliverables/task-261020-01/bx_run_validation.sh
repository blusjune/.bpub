#!/usr/bin/env bash
set -euo pipefail
bx_task_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$bx_task_dir/tests/results/tmp"
export TMPDIR="$bx_task_dir/tests/results/tmp"
python3 -m py_compile "$bx_task_dir"/*.py
python3 -m unittest discover -s "$bx_task_dir/tests" -p "test_*.py" -v 2>&1 | tee "$bx_task_dir/tests/results/adversarial_test_results.log"
python3 "$bx_task_dir/bx_plan_commands.py" --path raw_cpu --storage /dev/DISPOSABLE_ONLY --slab-gb 1 > "$bx_task_dir/tests/results/raw_command_template.txt"
python3 "$bx_task_dir/bx_plan_commands.py" --path cufile_fs --storage /mnt/DISPOSABLE_ONLY > "$bx_task_dir/tests/results/cufile_command_template.txt"
