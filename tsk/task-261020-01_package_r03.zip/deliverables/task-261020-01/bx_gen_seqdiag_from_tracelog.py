#!/usr/bin/env python3
"""Validate BX JSONL and produce observed-only Mermaid sequences, paginated Markdown.
Python coroutine/generator yields are execution-segment returns, NOT I/O completions.
"""
import argparse, collections, json, pathlib, re

LANES = ('vLLM','LMCache','ModelHost','Native','GPU','Kernel','SSD','Harness')
def clean(value):
    # Remove Mermaid/HTML control syntax rather than accepting injected directives.
    return re.sub(r'[^\w .,/=()+?\-]', ' ', str(value), flags=re.UNICODE)[:210]

def load(paths):
    events=[]; seen=set()
    for path in paths:
        with open(path) as f:
            for line_no, line in enumerate(f,1):
                if not line.strip(): continue
                try: e=json.loads(line)
                except ValueError as exc: raise ValueError(f'{path}:{line_no}: invalid JSON') from exc
                if e.get('schema') != 1 or e.get('clock') != 'monotonic_ns': raise ValueError('unsupported schema/clock')
                if type(e.get('ts_ns')) is not int or e['ts_ns'] < 0: raise ValueError('invalid timestamp')
                if e.get('phase') not in ('B','E','I'): raise ValueError('invalid phase')
                for k in ('pid','tid'):
                    if type(e.get(k)) is not int: raise ValueError('invalid '+k)
                if e.get('component') not in LANES: raise ValueError('unknown component')
                if not isinstance(e.get('fn'),str) or not isinstance(e.get('span'),str): raise ValueError('missing function/span')
                if e.get('evidence') not in ('observed_cpu_segment','observed_native','synthetic'):
                    raise ValueError('missing evidence classification')
                key=(e['pid'],e['span'],e['phase'],e['ts_ns'])
                if key in seen: raise ValueError('duplicate record/input')
                seen.add(key); events.append(e)
    for field in ('host','node_id','run_id'):
        identities={e.get(field) for e in events if e.get(field) not in (None,'unknown')}
        if len(identities)>1: raise ValueError('cannot merge different '+field+' captures')
    return sorted(events, key=lambda e:(e['ts_ns'],e['pid'],e['tid'],0 if e['phase']=='B' else 1))

def render(events, page_size=160, allow_incomplete=False):
    if page_size<1: raise ValueError('page-size must be positive')
    active={}; info={}; incomplete=[]
    for e in events:
        k=(e['pid'],e['span'])
        if e['phase']=='B':
            if k in info: raise ValueError('duplicate span')
            active[k]=e; info[k]=e
        elif e['phase']=='E':
            b=active.pop(k,None)
            if b is None: raise ValueError('end without begin')
            if any(e.get(x)!=b.get(x) for x in ('fn','component','tid')): raise ValueError('span identity mismatch')
    incomplete=list(active)
    if incomplete and not allow_incomplete: raise ValueError(f'{len(incomplete)} incomplete spans; use --allow-incomplete for explicitly partial captures')
    synthetic=any(e['evidence']=='synthetic' for e in events)
    out=['# BX trace sequence', '', '**SYNTHETIC TEST DATA**' if synthetic else 'Observed CPU/native execution. GPU execution and physical DMA are not inferred.', '', f'Events: {len(events)}; incomplete spans: {len(incomplete)}. Same-host monotonic clock only.', '']
    for offset in range(0,len(events),page_size):
        page=events[offset:offset+page_size]; lanes=[x for x in LANES if any(e['component']==x for e in page)]
        # parent may be on prior page, include its lane if available.
        for e in page:
            p=info.get((e['pid'],e.get('parent')))
            if p and p['component'] not in lanes: lanes.append(p['component'])
        out += [f'## Page {offset//page_size+1}', '', '```mermaid','sequenceDiagram','autonumber']
        out += [f'participant {x} as {x}' for x in lanes]
        for e in page:
            rel=(e['ts_ns']-events[0]['ts_ns'])/1e6
            label=f'{rel:.6f}ms p{e["pid"]}/t{e["tid"]} {e["fn"]} span={e["span"]}'
            if e['phase']=='B':
                p=info.get((e['pid'],e.get('parent'))); src=p['component'] if p else e['component']
                label+=' args='+json.dumps(e.get('args',{}),ensure_ascii=False)
                out.append(f'{src}->>{e["component"]}: {clean(label)}')
            elif e['phase']=='E':
                b=info[(e['pid'],e['span'])]; dur=(e['ts_ns']-b['ts_ns'])/1e6
                out.append(f'Note over {e["component"]}: {clean(label)} segment end {dur:.6f}ms')
            else:
                out.append(f'Note over {e["component"]}: {clean(label)}')
        out += ['```','']
    return '\n'.join(out)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('logs',nargs='+',type=pathlib.Path); p.add_argument('-o','--output',required=True,type=pathlib.Path)
    p.add_argument('--page-size',type=int,default=160); p.add_argument('--allow-incomplete',action='store_true')
    a=p.parse_args()
    try: result=render(load(a.logs),a.page_size,a.allow_incomplete)
    except (ValueError,OSError) as exc: p.error(str(exc))
    a.output.write_text(result,encoding='utf-8')
if __name__=='__main__': main()
