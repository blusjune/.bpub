#!/usr/bin/env python3
"""Node-aware command plans. Native API success never certifies physical DMA."""
import argparse,json,pathlib,shlex
from bx_platform import profile,mode_for

def build_commands(a):
    p=profile(a.node);mode=mode_for(a.node,a.path,a.gds_mode)
    if min(a.chunk,a.slab_gb)<1:raise ValueError('sizes must be positive')
    if not 0<a.gpu_memory_utilization<1:raise ValueError('GPU memory utilization must be between 0 and 1')
    cmd=['lmcache','server','--host','127.0.0.1','--port','5555','--chunk-size',str(a.chunk),'--l1-align-bytes','4096','--l1-size-gb',str(a.slab_gb),'--eviction-policy','LRU']
    if a.path in ('ugds_raw','cufile_fs'):
        cmd+=['--gds-l1-path',a.storage,'--gds-l1-backend','ugds' if a.path=='ugds_raw' else 'cufile']
    else:
        c=json.loads((pathlib.Path(__file__).parent/'models'/(a.model.split('/')[-1]+'.config.json')).read_text())
        dim=c.get('head_dim',c['hidden_size']//c['num_attention_heads'])
        payload=2*c['num_hidden_layers']*c.get('num_key_value_heads',c['num_attention_heads'])*dim*2*a.chunk
        slot=((payload+4096+4095)//4096)*4096
        adapter=dict(type='raw_block',device_path=a.storage,slot_bytes=slot,use_odirect=True,block_align=4096,enable_zero_copy=True,io_engine='posix',use_uring_cmd=False,fdp_enabled=False)
        cmd+=['--l2-adapter',json.dumps(adapter,separators=(',',':'))]
    kv=dict(kv_connector='LMCacheMPConnector',kv_connector_module_path='lmcache.integration.vllm.lmcache_mp_connector',kv_role='kv_both',kv_connector_extra_config={'lmcache.mp.host':'127.0.0.1','lmcache.mp.port':5555,'lmcache.mp.autostart':False,'lmcache.mp.save_decode_cache':False})
    v=['vllm','serve',a.model,'--tensor-parallel-size','1','--block-size','16','--max-model-len','2048','--enforce-eager','--no-enable-prefix-caching','--gpu-memory-utilization',str(a.gpu_memory_utilization),'--kv-cache-dtype','auto','--dtype','half' if a.model=='facebook/opt-125m' else 'bfloat16','--kv-transfer-config',json.dumps(kv,separators=(',',':'))]
    return [cmd,v],mode

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--node',choices=['node2','node3'],default='node3');p.add_argument('--path',choices=['raw_cpu','file_cpu','ugds_raw','cufile_fs'],required=True);p.add_argument('--storage',required=True);p.add_argument('--model',default='facebook/opt-125m');p.add_argument('--chunk',type=int,default=256);p.add_argument('--slab-gb',type=int,default=1);p.add_argument('--gds-mode',choices=['auto','compat','native'],default='auto');p.add_argument('--gpu-memory-utilization',type=float,default=.7);p.add_argument('--json',action='store_true');a=p.parse_args()
    try:commands,mode=build_commands(a)
    except (ValueError,OSError) as e:p.error(str(e))
    if a.json:print(json.dumps({'node_id':a.node,'commands':commands,'requested_path':mode,'native_dma_verified':False}));return
    print(f'# {a.node}: {mode}; native DMA is NOT verified. Validate actual chunk and installed CLI.')
    print('# Raw storage is disposable. Per-process cuFile overlay is applied by pilot/smoke, not these printed command lines alone.')
    for cmd in commands:print(shlex.join(cmd))
if __name__=='__main__':main()
