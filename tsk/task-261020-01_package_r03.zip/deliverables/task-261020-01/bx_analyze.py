#!/usr/bin/env python3
"""Quantitative BX/streaming/Nsight summaries. Missing data is null, never invented zero."""
import argparse,collections,csv,io,json,math,pathlib,re,sqlite3,statistics

def distribution(values):
    values=sorted(float(x) for x in values if x is not None and math.isfinite(float(x)))
    if not values:return {'n':0,'p50':None,'p95':None,'p99':None}
    def q(p):
        x=(len(values)-1)*p;i=int(x);return values[i]+(values[min(i+1,len(values)-1)]-values[i])*(x-i)
    return {'n':len(values),'p50':q(.5),'p95':q(.95),'p99':q(.99)}

def merge(intervals):
    out=[]
    for start,end in sorted(intervals):
        if end<=start:continue
        if out and start<=out[-1][1]:out[-1]=(out[-1][0],max(end,out[-1][1]))
        else:out.append((start,end))
    return out

def duration(intervals):return sum(e-s for s,e in merge(intervals))

def overlap(a,b):
    a=merge(a);b=merge(b);i=j=0;total=0
    while i<len(a) and j<len(b):
        total+=max(0,min(a[i][1],b[j][1])-max(a[i][0],b[j][0]))
        if a[i][1]<b[j][1]:i+=1
        else:j+=1
    return total

def sqlite_summary(path,start=None,end=None):
    db=sqlite3.connect('file:'+str(path.resolve())+'?mode=ro',uri=True)
    try:
        tables={r[0] for r in db.execute("select name from sqlite_master where type='table'")};warnings=[];available={'kernels':'CUPTI_ACTIVITY_KIND_KERNEL' in tables,'copies':'CUPTI_ACTIVITY_KIND_MEMCPY' in tables};perdev=collections.defaultdict(lambda:{'kernels':[],'copies':[],'copy_bytes':0,'copy_sum_ns':0});hot=collections.defaultdict(lambda:[0,0])
        strings=dict(db.execute('select id,value from StringIds')) if 'StringIds' in tables else {}
        for table,kind in [('CUPTI_ACTIVITY_KIND_KERNEL','kernels'),('CUPTI_ACTIVITY_KIND_MEMCPY','copies')]:
            if table not in tables:warnings.append('Missing '+table);continue
            cols={x[1] for x in db.execute(f'pragma table_info({table})')}
            if not {'start','end','deviceId'}<=cols:available[kind]=False;warnings.append('Unsupported columns: '+table);continue
            names=['start','end','deviceId']
            for x in ('bytes','demangledName','shortName','copyKind'):
                if x in cols:names.append(x)
            for row in db.execute('select '+','.join('"'+n+'"' for n in names)+' from '+table):
                r=dict(zip(names,row));s,e=int(r['start']),int(r['end']);original=e-s
                if start is not None:s=max(s,start)
                if end is not None:e=min(e,end)
                if e<=s:continue
                d=perdev[str(r['deviceId'])];d[kind].append((s,e))
                if kind=='copies':
                    # Bytes cannot be reliably prorated for a clipped copy.
                    if e-s==original:d['copy_bytes']+=r.get('bytes',0);d['copy_sum_ns']+=original
                else:
                    name=strings.get(r.get('demangledName',r.get('shortName')),'unknown');h=hot[name];h[0]+=e-s;h[1]+=1
        devices={}
        for dev,d in perdev.items():
            all_events=d['kernels']+d['copies'];lo=start if start is not None else min(s for s,e in all_events);hi=end if end is not None else max(e for s,e in all_events);window=hi-lo
            devices[dev]={'window_start_ns':lo,'window_end_ns':hi,'window_ms':window/1e6,'kernel_union_ms':duration(d['kernels'])/1e6 if available['kernels'] else None,'copy_union_ms':duration(d['copies'])/1e6 if available['copies'] else None,'kernel_copy_overlap_ms':overlap(d['kernels'],d['copies'])/1e6 if all(available.values()) else None,'gpu_activity_union_pct':100*duration(all_events)/window if window else None,'cuda_copy_bytes_unclipped':d['copy_bytes'] if available['copies'] else None,'cuda_copy_weighted_GiB_per_s':d['copy_bytes']/2**30/(d['copy_sum_ns']/1e9) if d['copy_sum_ns'] else None}
        return {'available_activity_tables':available,'scope':'selected SQLite window, else first-to-last observed GPU activity; includes startup if not filtered','devices':devices,'hot_kernels_by_summed_gpu_time':[{'name':k,'sum_ms':v[0]/1e6,'launches':v[1]} for k,v in sorted(hot.items(),key=lambda x:-x[1][0])[:20]],'warnings':warnings,'note':'CUDA memcpy is NOT SSD DMA; summed kernel times can overlap. Busy is event union, not SM utilization.'}
    finally:db.close()

def ncu_csv(path):
    text=path.read_text();lines=text.splitlines();idx=next((i for i,line in enumerate(lines) if 'Metric Name' in line and 'Metric Value' in line),None)
    if idx is None:return {'status':'UNSUPPORTED_OR_EMPTY_CSV','metrics':[]}
    metrics=[]
    for row in csv.DictReader(io.StringIO('\n'.join(lines[idx:]))):
        if not row.get('Metric Name'):continue
        value=row.get('Metric Value','')
        try:number=float(value.replace(',',''))
        except ValueError:number=None
        if number is not None and not math.isfinite(number):number=None
        metrics.append({'kernel':row.get('Kernel Name'),'metric':row['Metric Name'],'unit':row.get('Metric Unit'),'value':number,'raw_value':value})
    return {'status':'PARSED','metrics':metrics,'note':'NCU replay/serialization perturbs execution; no serving-latency attribution.'}

def analyze(run,node,window_start=None,window_end=None):
    pilot=run/'pilot' if (run/'pilot').is_dir() else run
    result={'node_id':node,'run':str(run),'native_dma_verified':False,'warnings':[]}
    manifest_path=pilot/'run_manifest.json'
    if manifest_path.exists():
        m=json.loads(manifest_path.read_text())
        if m.get('node_id') and m['node_id']!=node:raise ValueError('node does not match run manifest')
        result['run_status']=m.get('status');result['requested_path']=m.get('requested_path')
    workload=pilot/'workload.jsonl'
    if workload.exists():
        rows=[json.loads(x) for x in workload.read_text().splitlines() if x.strip()];good=[r for r in rows if r.get('status')=='ok'];byround={}
        for n in sorted({r['round'] for r in rows}):
            group=[r for r in good if r['round']==n]
            makespan=(max(r['end_ns'] for r in group)-min(r['start_ns'] for r in group))/1e9 if group else None
            completions=[(r.get('usage') or {}).get('completion_tokens') for r in group]
            byround[str(n)]={'requests_per_second':len(group)/makespan if makespan else None,'output_tokens_per_second':sum(completions)/makespan if makespan and all(isinstance(x,int) for x in completions) else None,'request_elapsed_ms':distribution([(r['end_ns']-r['start_ns'])/1e6 for r in group]),'ttft_ms':distribution([r.get('ttft_ms') for r in group]),'content_chunk_gap_ms_NOT_TPOT':distribution([x for r in group for x in r.get('content_chunk_gaps_ms',[])])}
        result['workload']={'requests':len(rows),'errors':len(rows)-len(good),'by_round':byround,'note':'Rounds are candidate reuse, not proof of SSD hits. TTFT is client first nonempty text chunk.'}
    else:result['warnings'].append('No workload trace')
    groups=collections.defaultdict(list);active={};bad=0
    for f in (pilot/'traces').glob('*.jsonl'):
        events=[json.loads(x) for x in f.read_text().splitlines() if x.strip()]
        for e in sorted(events,key=lambda e:e['ts_ns']):
            if e.get('node_id') not in (None,'unknown',node):raise ValueError('trace node mismatch')
            key=(str(f),e.get('pid'),e.get('span'))
            if e.get('phase')=='B':active[key]=e
            elif e.get('phase')=='E':
                begin=active.pop(key,None)
                if begin and e['ts_ns']>=begin['ts_ns']:groups[e['fn']].append((e['ts_ns']-begin['ts_ns'])/1e6)
                else:bad+=1
    result['cpu_segments']={'incomplete':len(active),'orphan_or_invalid':bad,'top_by_summed_inclusive_ms':[dict(function=k,sum_inclusive_ms=sum(v),**distribution(v)) for k,v in sorted(groups.items(),key=lambda x:-sum(x[1]))[:30]],'note':'Nested/suspended CPU segments; sums must NOT be added or treated as GPU/IO completion or critical path.'}
    result['nsys']=[]
    for f in run.glob('*.sqlite'):result['nsys'].append({'file':f.name,**sqlite_summary(f,window_start,window_end)})
    result['ncu']=[{'file':f.name,**ncu_csv(f)} for f in run.glob('*metrics.csv')]
    if not result['nsys']:result['warnings'].append('No Nsight SQLite: GPU timing/overlap unavailable')
    if not result['ncu']:result['warnings'].append('No Nsight Compute CSV: kernel hardware counters unavailable')
    result['interpretation']=['Inspect high inclusive CPU submit/wait spans against GPU timeline; no automatic causal bottleneck claim.','Inspect hot gather/scatter kernels with NCU memory throughput and occupancy metrics. Copy-engine/GDS DMA is outside NCU kernel metrics.','Compare a separate unprofiled run with identical node/model/seed/cache state. Do not compare NCU time as service latency.','Physical SSD bytes/latency/queue depth require independent block/native/SSD evidence. No observed I/O is not zero I/O.']
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--node',choices=['node2','node3'],default='node3');p.add_argument('--run-dir',type=pathlib.Path,required=True);p.add_argument('--gpu-window-start-ns',type=int);p.add_argument('--gpu-window-end-ns',type=int);a=p.parse_args()
    if not a.run_dir.is_dir():p.error('run directory missing')
    if a.gpu_window_start_ns is not None and a.gpu_window_end_ns is not None and a.gpu_window_end_ns<=a.gpu_window_start_ns:p.error('invalid GPU window')
    result=analyze(a.run_dir,a.node,a.gpu_window_start_ns,a.gpu_window_end_ns)
    (a.run_dir/'quantitative_summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    def fmt(v):return 'N/A' if v is None else f'{v:.4f}' if isinstance(v,(int,float)) else str(v)
    lines=['# Quantitative diagnostic report','',f"Node: {a.node}. Native DMA verified: false.",'','API success is not physical-path or KV-integrity proof. Missing data is N/A.','', '## Client workload','', '| Round | requests/s | output tokens/s | elapsed p50 ms | elapsed p95 ms | TTFT p50 ms | TTFT p95 ms |','|---|---:|---:|---:|---:|---:|---:|']
    for rnd,r in result.get('workload',{}).get('by_round',{}).items():
        lines.append('| '+' | '.join(map(fmt,[rnd,r['requests_per_second'],r['output_tokens_per_second'],r['request_elapsed_ms']['p50'],r['request_elapsed_ms']['p95'],r['ttft_ms']['p50'],r['ttft_ms']['p95']]))+' |')
    lines+=['','Content chunk gaps are not per-token TPOT. Repeated rounds do not prove SSD hits.','', '## GPU timeline','', '| Capture/device | window ms | kernel union ms | CUDA copy union ms | overlap ms | observed activity % |','|---|---:|---:|---:|---:|---:|']
    for capture in result['nsys']:
        for dev,r in capture['devices'].items():lines.append('| '+' | '.join(map(fmt,[capture['file']+'/'+dev,r['window_ms'],r['kernel_union_ms'],r['copy_union_ms'],r['kernel_copy_overlap_ms'],r['gpu_activity_union_pct']]))+' |')
    lines+=['','Activity fraction is not SM utilization. CUDA copy is not SSD DMA. Select a steady-state SQLite window before attribution.','', '## CPU execution segments','', '| Function | inclusive sum ms | p50 ms | p95 ms |','|---|---:|---:|---:|']
    for r in result['cpu_segments']['top_by_summed_inclusive_ms'][:12]:lines.append('| '+' | '.join(map(fmt,[r['function'],r['sum_inclusive_ms'],r['p50'],r['p95']]))+' |')
    lines+=['','Nested inclusive times must not be added or called GPU completion time.','', '## Selected NCU counters','', '| Kernel | Metric | Unit | Value |','|---|---|---|---:|']
    for capture in result['ncu']:
        for r in capture['metrics']:
            if any(x in r['metric'].lower() for x in ('throughput','warps_active','occupancy','time_duration')):lines.append('| '+' | '.join(map(fmt,[r['kernel'],r['metric'],r['unit'],r['value']]))+' |')
    lines+=['','NCU replay changes execution. Do not use its serving times as the baseline.','', '## Interpretation and coverage','']
    lines+=['- '+x for x in result['interpretation']+result['warnings']]
    for capture in result['nsys']:lines+=['- '+x for x in capture['warnings']]
    lines+=['','Full numbers and raw metric names: quantitative_summary.json.']
    (a.run_dir/'quantitative_report.md').write_text('\n'.join(lines)+'\n');print(a.run_dir/'quantitative_report.md')
if __name__=='__main__':main()
