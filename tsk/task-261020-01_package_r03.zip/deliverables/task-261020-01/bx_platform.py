"""Node policy, observation and reproducible process environment. Standard library only."""
import datetime,json,os,pathlib,platform,shutil,socket,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parent

def profile(node):
    if node not in ('node2','node3'):raise ValueError('unknown node')
    return json.loads((ROOT/'profiles'/f'{node}.json').read_text())

def utc_id():return datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')

def command_observation(argv):
    try:
        r=subprocess.run(argv,capture_output=True,text=True,timeout=30)
        return {'argv':argv,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    except (OSError,subprocess.TimeoutExpired) as e:return {'argv':argv,'error':str(e)}

def observe(node):
    p=profile(node)
    data={'node_id':node,'host':socket.gethostname(),'cpu_arch':platform.machine(),'kernel':platform.release(),'python':sys.version,'profile':p,'native_dma_verified':False}
    for label,cmd in [('gpu',['nvidia-smi','--query-gpu=name,uuid,pci.bus_id,driver_version,memory.total','--format=csv']),('topology',['nvidia-smi','topo','-m']),('nvcc',['nvcc','--version']),('nsys',['nsys','--version']),('ncu',['ncu','--version']),('pci',['lspci','-tv']),('cpu',['lscpu']),('host_memory',['free','-b']),('numa',['numactl','--hardware']),('devices',['lsblk','-J','-o','NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL']),('packages',[sys.executable,'-m','pip','show','torch','vllm','lmcache','nvtx'])]:
        data[label]=command_observation(cmd)
    gds_candidates=[pathlib.Path('/usr/local/cuda/gds/tools')/x for x in ('gdscheck','gdscheck.py')]
    data['gdscheck']={'status':'NOT_FOUND'}
    for tool in gds_candidates:
        if tool.is_file():
            data['gdscheck']=command_observation(([sys.executable] if tool.suffix=='.py' else [])+[str(tool),'-p']);break
    data['gpu_matches_profile']=('RTX PRO 6000' in data['gpu'].get('stdout','')) if node=='node2' else ('GB10' in data['gpu'].get('stdout',''))
    data['gpu_compute']=command_observation([sys.executable,'-c',"import json,torch; print(json.dumps({'devices':[{'name':torch.cuda.get_device_name(i),'capability':torch.cuda.get_device_capability(i),'memory_bytes':torch.cuda.get_device_properties(i).total_memory} for i in range(torch.cuda.device_count())]}))"])
    data['architecture_matches_profile']=data['cpu_arch']==p['cpu_arch']
    return data

def check_arch(node):
    expected=profile(node)['cpu_arch']
    if platform.machine()!=expected:raise RuntimeError(f'{node} expects {expected}; actual host is {platform.machine()}')

def mode_for(node,path,mode='auto'):
    if path=='ugds_raw':
        if node=='node3':raise ValueError('node3 Spark: uGDS native path unsupported/unvalidated')
        return 'ugds_requested_unverified'
    if path!='cufile_fs':return 'host_raw_or_file'
    if mode=='auto':mode='compat'  # Reproducible common baseline, including node2.
    if node=='node3' and mode=='native':raise ValueError('node3 Spark: native GDS unsupported; do not load nvidia-fs')
    return mode

def run_environment(node,run,path,mode):
    env=dict(os.environ,BX_NODE_ID=node,BX_RUN_ID=run.name,BX_TRACE='0',BX_NVTX='0')
    if path=='cufile_fs':
        # Per-process overlay; no modification of /etc/cufile.json or kernel settings.
        config={'properties':{'allow_compat_mode':mode!='native','force_compat_mode':mode=='compat'}}
        f=run/'cufile.overlay.json';f.write_text(json.dumps(config,indent=2)+'\n')
        env['CUFILE_ENV_PATH_JSON']=str(f)
        if mode=='compat':env['CUFILE_FORCE_COMPAT_MODE']='true'
        else:
            if os.environ.get('CUFILE_FORCE_COMPAT_MODE','').lower() in ('1','true','yes'):
                raise ValueError('inherited CUFILE_FORCE_COMPAT_MODE conflicts with requested native mode')
            env.pop('CUFILE_FORCE_COMPAT_MODE',None)
    return env
