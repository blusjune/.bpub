#!/usr/bin/env python3
"""Start LMCache/vLLM, wait for readiness, run workload, stop owned processes, convert trace.
Plans only unless --execute. Completion of this harness is NOT a DMA/correctness pass.
"""
import argparse,datetime,json,os,pathlib,shlex,shutil,signal,socket,stat,subprocess,sys,time,urllib.request
from bx_platform import check_arch,observe,profile,run_environment,mode_for,utc_id
ROOT=pathlib.Path(__file__).resolve().parent

def validate_storage(path,backend):
 target=pathlib.Path(path).resolve()
 if backend=='ugds_raw':
  if not stat.S_ISCHR(target.stat().st_mode):raise ValueError('uGDS requires ugds_drv character device')
  st=target.stat();subsystem=os.path.realpath(f'/sys/dev/char/{os.major(st.st_rdev)}:{os.minor(st.st_rdev)}/subsystem')
  if os.path.basename(subsystem)!='ugds_drv':raise ValueError('not a ugds_drv device')
 elif backend=='raw_cpu':
  if not stat.S_ISBLK(target.stat().st_mode):raise ValueError('raw_cpu requires an existing block device')
  result=subprocess.run(['lsblk','-J','-p','-o','NAME,TYPE,MOUNTPOINTS',str(target)],check=True,capture_output=True,text=True)
  def mounted(node):return any(node.get('mountpoints') or []) or any(mounted(c) for c in node.get('children',[]))
  nodes=json.loads(result.stdout)['blockdevices']
  if not nodes or any(mounted(n) for n in nodes):raise ValueError('raw device or child is mounted; refusing')
 elif backend=='file_cpu':
  if not target.is_file():raise ValueError('file_cpu requires an existing dedicated pre-sized file')
 elif not target.is_dir():raise ValueError('cufile_fs requires an existing disposable directory')
 return str(target)

def wait_ready(check,proc,deadline):
 while time.monotonic()<deadline:
  if proc.poll() is not None:raise RuntimeError('server exited before readiness; inspect logs')
  try:
   if check():return
  except (OSError,ValueError):pass
  time.sleep(.5)
 raise TimeoutError('server readiness timed out')

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--node',choices=['node2','node3'],default='node3');p.add_argument('--gds-mode',choices=['auto','compat','native'],default='auto');p.add_argument('--capabilities',type=pathlib.Path);p.add_argument('--gpu-memory-utilization',type=float,default=.7);p.add_argument('--stream',action='store_true');p.add_argument('--nvtx',action='store_true');p.add_argument('--path',choices=['raw_cpu','file_cpu','cufile_fs','ugds_raw'],required=True);p.add_argument('--storage',required=True);p.add_argument('--model',default='facebook/opt-125m');p.add_argument('--chunk',type=int,default=256);p.add_argument('--l1-gb',type=int,default=1);p.add_argument('--requests',type=int,default=64);p.add_argument('--tokens',type=int,default=1024);p.add_argument('--concurrency',type=int,default=1);p.add_argument('--reuse',choices=['cold','full','partial'],default='full');p.add_argument('--startup-timeout',type=int,default=900);p.add_argument('--execute',action='store_true');p.add_argument('--trace',action='store_true');p.add_argument('--run-dir');a=p.parse_args()
 if min(a.requests,a.tokens,a.concurrency,a.startup_timeout)<1:p.error('positive values required')
 if a.model=='facebook/opt-125m' and a.tokens+32>2048:p.error('OPT context exceeds 2048')
 requested=mode_for(a.node,a.path,a.gds_mode)
 command_output=subprocess.check_output([sys.executable,str(ROOT/'bx_plan_commands.py'),'--node',a.node,'--gds-mode',a.gds_mode,'--gpu-memory-utilization',str(a.gpu_memory_utilization),'--path',a.path,'--storage',a.storage,'--model',a.model,'--chunk',str(a.chunk),'--slab-gb',str(a.l1_gb)],text=True)
 print(command_output)
 if not a.execute:print('PLAN ONLY. Add --execute to run on your hardware.');return 0
 check_arch(a.node)
 if not shutil.which('nvidia-smi') or not shutil.which('lmcache') or not shutil.which('vllm'):raise RuntimeError('GPU runtime and installed lmcache/vllm executables required')
 target=validate_storage(a.storage,a.path)
 capabilities=observe(a.node)
 if not capabilities['gpu_matches_profile']:raise ValueError('observed GPU does not match selected node profile')
 if requested=='native':
  if not a.capabilities:raise ValueError('native requires --capabilities from this node preflight')
  previous=json.loads(a.capabilities.read_text())
  for field in ('node_id','host','cpu_arch','kernel'):
   if previous.get(field)!=capabilities.get(field):raise ValueError('stale or wrong-node capabilities: '+field)
  if previous.get('gpu')!=capabilities.get('gpu'):raise ValueError('GPU observation changed since preflight')
  text=capabilities.get('gdscheck',{}).get('stdout','').lower()
  if capabilities.get('gdscheck',{}).get('returncode')!=0 or not any(x in text for x in ('nvfs','p2pdma')):raise ValueError('native candidate not found by gdscheck; physical path still requires separate verification')
 # Readiness must belong to processes launched by this harness, not old servers.
 for port in (5555,8000):
  with socket.socket() as sock:
   if sock.connect_ex(('127.0.0.1',port))==0:raise RuntimeError(f'port {port} already in use')
 commands=[shlex.split(line) for line in command_output.splitlines() if line and not line.startswith('#')]
 if len(commands)!=2:raise RuntimeError('unexpected command generator output')
 run=pathlib.Path(a.run_dir).resolve() if a.run_dir else ROOT/'runtime'/a.node/('pilot-'+utc_id())
 if not run.is_relative_to(ROOT):raise ValueError('run-dir must be below this deliverables task directory')
 run.mkdir(parents=True,exist_ok=False);trace=run/'traces';trace.mkdir()
 env=run_environment(a.node,run,a.path,requested);env.update(BX_TRACE_DIR=str(trace));processes=[];files=[]
 (run/'capabilities.json').write_text(json.dumps(capabilities,indent=2)+'\n')
 if a.nvtx:env.update(BX_NVTX='1')
 if a.trace or a.nvtx:
  if a.nvtx and __import__('importlib.util',fromlist=['find_spec']).find_spec('nvtx') is None:raise RuntimeError('nvtx package required for NVTX profiling')
  import importlib.util
  paths=[]
  for name in ('lmcache','vllm'):
   spec=importlib.util.find_spec(name)
   if spec is None or not spec.submodule_search_locations:raise RuntimeError('Trace needs installed '+name+' in this Python environment')
   paths.extend(spec.submodule_search_locations)
  env.update(BX_TRACE='1',BX_TRACE_ROOTS=os.environ.get('BX_TRACE_ROOTS',os.pathsep.join(paths)),PYTHONPATH=str(ROOT)+os.pathsep+os.environ.get('PYTHONPATH',''))
 manifest=dict(arguments=vars(a),storage_realpath=target,status='STARTING',node_id=a.node,requested_path=requested,observed_path='unverified',native_dma_verified=False,scope='Harness success is not physical path or KV integrity verification',commands=commands)
 def save(): (run/'run_manifest.json').write_text(json.dumps(manifest,indent=2,default=str)+'\n')
 save();code=1
 try:
  for name,cmd in zip(('lmcache','vllm'),commands):
   f=(run/(name+'.log')).open('w');files.append(f);proc=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True);processes.append(proc)
   if name=='lmcache':
    def ready():
     with socket.create_connection(('127.0.0.1',5555),timeout=1):return True
   else:
    def ready():
     with urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=1) as r:return r.status==200
   wait_ready(ready,proc,time.monotonic()+a.startup_timeout)
  cmd=[sys.executable,str(ROOT/'bx_workload.py'),'--model',a.model,'--tokens',str(a.tokens),'--chunk',str(a.chunk),'--requests',str(a.requests),'--concurrency',str(a.concurrency),'--reuse',a.reuse,'--output',str(run/'workload.jsonl')]
  if a.stream:cmd+=['--stream']
  subprocess.run(cmd,check=True,env=env);manifest['status']='WORKLOAD_COMPLETED_IO_UNVERIFIED';code=0
 except BaseException as exc:
  manifest['status']='FAILED';manifest['error']=type(exc).__name__+': '+str(exc);print(manifest['error'],file=sys.stderr)
 finally:
  for proc in reversed(processes):
   try:os.killpg(proc.pid,signal.SIGTERM)
   except ProcessLookupError:pass
  for proc in reversed(processes):
   try:proc.wait(timeout=30)
   except subprocess.TimeoutExpired:
    try:os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    proc.wait()
  for f in files:f.close()
  logs=sorted(trace.glob('*.jsonl'))
  if logs:
   r=subprocess.run([sys.executable,str(ROOT/'bx_gen_seqdiag_from_tracelog.py'),*[str(x) for x in logs],'-o',str(run/'observed_sequence.md'),'--allow-incomplete'],capture_output=True,text=True)
   manifest['trace_conversion_returncode']=r.returncode
   (run/'trace_conversion.log').write_text(r.stdout+r.stderr)
  else:manifest['trace_warning']='No BX logs; ensure BX_TRACE, PYTHONPATH and imported source roots match'
  save()
 analysis=subprocess.run([sys.executable,str(ROOT/'bx_analyze.py'),'--node',a.node,'--run-dir',str(run)],capture_output=True,text=True)
 (run/'analysis.log').write_text(analysis.stdout+analysis.stderr)
 manifest['analysis_returncode']=analysis.returncode;save()
 print(str(run));return code
if __name__=='__main__':raise SystemExit(main())
