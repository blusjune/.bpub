#!/usr/bin/env python3
"""Deterministic token-ID prompt pilot for local OpenAI-compatible vLLM endpoint.
Two rounds generate candidate hits; counters/traces, not round number, prove SSD reads.
"""
import argparse,concurrent.futures,hashlib,json,pathlib,random,time,urllib.request
p=argparse.ArgumentParser();p.add_argument('--stream',action='store_true',help='SSE content-chunk timing and TTFT; chunk gaps are not token gaps');p.add_argument('--url',default='http://127.0.0.1:8000/v1/completions');p.add_argument('--model',required=True);p.add_argument('--tokens',type=int,default=1024);p.add_argument('--chunk',type=int,default=256);p.add_argument('--reuse',choices=['cold','full','partial'],default='full');p.add_argument('--requests',type=int,default=4);p.add_argument('--concurrency',type=int,default=1);p.add_argument('--rounds',type=int,default=2);p.add_argument('--output',type=pathlib.Path,default=pathlib.Path('workload.jsonl'));p.add_argument('--seed',type=int,default=261020);p.add_argument('--max-tokens',type=int,default=32)
a=p.parse_args()
if min(a.tokens,a.chunk,a.requests,a.concurrency,a.rounds,a.max_tokens)<1:p.error('positive values required')
if a.model=='facebook/opt-125m' and a.tokens+a.max_tokens>2048:p.error('OPT context exceeds 2048')
if a.output.exists():p.error('output exists; use a fresh run path')
def prompt(idx,round_no):
 seed=a.seed+idx
 if a.reuse=='cold':seed+=round_no*100000
 ids=[random.Random(seed+i*7919).randrange(100,40000) for i in range(a.tokens)]
 if a.reuse=='partial' and round_no:
  prefix=(a.tokens//(2*a.chunk))*a.chunk
  rng=random.Random(seed+round_no*700001)
  ids[prefix:]=[rng.randrange(100,40000) for _ in ids[prefix:]]
 return ids

def request(idx,round_no):
 ids=prompt(idx,round_no);start=time.monotonic_ns()
 body=dict(model=a.model,prompt=ids,max_tokens=a.max_tokens,temperature=0,ignore_eos=True,stream=a.stream,**({'stream_options':{'include_usage':True}} if a.stream else {}))
 req=urllib.request.Request(a.url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','X-Request-Id':f'bx-{a.seed}-{round_no}-{idx}'})
 try:
  chunks=[];usage=None;first=None;last=None;gaps=[]
  with urllib.request.urlopen(req,timeout=600) as r:
   if a.stream:
    for raw in r:
     line=raw.decode().strip()
     if not line.startswith('data:'):continue
     payload=line[5:].strip()
     if payload=='[DONE]':break
     e=json.loads(payload)
     if e.get('error'):raise RuntimeError(str(e['error']))
     if e.get('usage'):usage=e['usage']
     text=''.join(c.get('text','') for c in e.get('choices',[]))
     if text:
      now=time.monotonic_ns()
      if first is None:first=now
      if last is not None:gaps.append((now-last)/1e6)
      last=now;chunks.append(text)
    result={'usage':usage,'choices':chunks}
   else:result=json.load(r)
  return dict(round=round_no,index=idx,seed=a.seed,start_ns=start,end_ns=time.monotonic_ns(),prompt_sha256=hashlib.sha256(json.dumps(ids).encode()).hexdigest(),usage=result.get('usage'),choices_sha256=hashlib.sha256(json.dumps(result.get('choices')).encode()).hexdigest(),status='ok',stream=a.stream,first_content_ns=first,last_content_ns=last,ttft_ms=(first-start)/1e6 if first is not None else None,content_chunk_gaps_ms=gaps,note='TTFT is first nonempty text chunk; chunk gaps are NOT per-token TPOT' if a.stream else 'Nonstreaming elapsed time is NOT TTFT')
 except Exception as exc:return dict(round=round_no,index=idx,start_ns=start,end_ns=time.monotonic_ns(),status='error',error=str(exc))
failures=0
with a.output.open('w') as f:
 for round_no in range(a.rounds):
  with concurrent.futures.ThreadPoolExecutor(a.concurrency) as ex:
   for r in ex.map(lambda idx:request(idx,round_no),range(a.requests)):
    failures += r['status'] != 'ok'
    f.write(json.dumps(r)+'\n');f.flush()
print('Candidate reuse only. Confirm LMCache hit counters, completed SSD I/O, and KV bytes before classifying.')

if failures: raise SystemExit(f"{failures} requests failed; inspect output")
