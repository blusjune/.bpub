"""Opt-in automatic profiling in vLLM worker / LMCache spawned Python processes."""
import os
if os.environ.get('BX_TRACE') == '1':
    import bxtrace
    roots = os.environ.get('BX_TRACE_ROOTS', '').split(os.pathsep)
    if not roots or not all(roots): raise RuntimeError('Set BX_TRACE_ROOTS to selected source directories')
    bxtrace.install(roots)
