# Load required packages
library(ggplot2)
library(lubridate)
library(plotly)

# Read milestones from CSV file
milestones <- read.csv("milestones.csv", stringsAsFactors = FALSE)
milestones$Date <- as.Date(milestones$Date)  # Convert Date column to Date class
milestones$Y <- as.numeric(milestones$Y)  # Ensure Y is numeric

# Read dependencies from CSV file
dependencies <- read.csv("dependencies.csv", stringsAsFactors = FALSE)

# Process dependencies to extract start and end coordinates
dependencies$Start_Date <- as.Date(sapply(dependencies$Source, function(x) milestones$Date[milestones$Name == x]), origin = "1970-01-01") + 1  # Offset by 1 day
dependencies$End_Date <- as.Date(sapply(dependencies$Destination, function(x) milestones$Date[milestones$Name == x]), origin = "1970-01-01") - 1  # Offset by 1 day
dependencies$Start_Y <- sapply(dependencies$Source, function(x) milestones$Y[milestones$Name == x])
dependencies$End_Y <- sapply(dependencies$Destination, function(x) milestones$Y[milestones$Name == x])

# Create Gantt chart with ggplot2
p <- ggplot() +
  # Plot milestones as points
  geom_point(data = milestones, aes(x = Date, y = Y, text = paste(Name, "\nDate:", Date)), 
             size = 4, color = "blue", shape = 19) +
  # Plot dependencies as arrows
  geom_segment(data = dependencies, 
               aes(x = Start_Date, xend = End_Date, y = Start_Y, yend = End_Y),
               arrow = arrow(type = "closed", length = unit(0.3, "cm")), 
               color = "red", linewidth = 1, lineend = "round") +
  # Add milestone names and dates as labels
  geom_text(data = milestones, 
            aes(x = Date + 0, y = Y - 0.1, label = paste(Name, "\n", Date)), 
            size = 3, hjust = 0, vjust = 0.5, color = "black") +
  # Customize axes
  scale_y_continuous(breaks = milestones$Y, labels = milestones$Name, name = "Milestones") +
  scale_x_date(name = "Timeline", date_breaks = "1 month", date_labels = "%b %Y",
               limits = as.Date(c("2025-05-01", "2025-12-31"))) +
  # Theme and title
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 10),
    axis.text.x = element_text(angle = 45, hjust = 1),
    plot.title = element_text(hjust = 0.5)
  ) +
  ggtitle("Project Gantt Chart")

# Convert to interactive plotly plot
interactive_plot <- ggplotly(p, tooltip = "text")

# Save as interactive HTML
htmlwidgets::saveWidget(interactive_plot, "gantt_chart.html")

# Optionally save as static PNG
ggsave("gantt_chart.png", plot = p, width = 8, height = 6, units = "in", dpi = 300)

# Display plot in R viewer (if running interactively)
print(interactive_plot)
