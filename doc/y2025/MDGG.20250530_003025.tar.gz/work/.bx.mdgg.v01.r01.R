## MDGG: Milestone and Dependency Graph Generator
## 20250529_232649: v1 r005: added 'Notes' field in .bxcf.mdgg.milestone.csv
## 20250528_003328: v1 r001 (initial version)


## MDGG configuration files:
##	.bxcf.mdgg.milestone.csv
##	.bxcf.mdgg.dependency.csv
##


## Examples: .bxcf.mdgg.milestone.csv
##
## Group, Name, Date, Notes
## 
## 10.SS.sHBM, sHBM4E.12H.MTV_MTO, 2025-03-31, "."
## 10.SS.sHBM, sHBM4E.12H.MTO, 2025-09-30, "."
## 10.SS.sHBM, sHBM4E.12H.Final_DB, 2025-11-30, "."
## 10.SS.sHBM, sHBM4E.12H.ES, 2026-06-30, "."
## 10.SS.sHBM, sHBM4E.12H.CS, 2026-09-30, "."
## 
## 11.SS.sHBM.B_model, sHBM4E.B_model.initial, 2025-07-31, "."
## 11.SS.sHBM.B_model, sHBM4E.B_model.final, 2025-10-31, "."
## 
## 12.SS.sHBM.S_model, sHBM4E.S_model.alpha, 2025-05-31, "."
## 12.SS.sHBM.S_model, sHBM4E.S_model.beta, 2025-07-31, "."
## 12.SS.sHBM.S_model, sHBM4E.S_model.final, 2025-10-31, "."
## 
## 15.SS.cHBM, cHBM4.CTPHY, 2025-04-30, "."
## 15.SS.cHBM, cHBM4E.CTPHY.alpha, 2025-06-30, "."
## 15.SS.cHBM, cHBM4E.CTPHY.beta, 2025-08-31, "."
## 15.SS.cHBM, cHBM4E.CTPHY.final, 2025-10-31, "."
## 
## 20.SS.B-die, B-die.ML2, 2025-06-18, "."
## 20.SS.B-die, B-die.ML3, 2025-09-03, "."
## 20.SS.B-die, B-die.FC, 2025-10-31, "."
## 20.SS.B-die, B-die.ML4, 2025-11-30, "."
## 20.SS.B-die, B-die.MTO, 2026-03-26, "."
## 20.SS.B-die, B-die.FO, 2026-07-31, "."
## 20.SS.B-die, B-die.FS, 2026-11-30, "."
## 20.SS.B-die, B-die.ES, 2027-03-31, "."
## 20.SS.B-die, B-die.CS, 2027-06-30, "."
## 
## 30.Google, GG.R0.3, 2025-04-30, "."
## 30.Google, GG.D0.3, 2025-05-21, "Initial Design Milestone: ARCH 0.5? / PGM 0.3 / DFT 0.3 / PD 0.1"
## 30.Google, GG.R0.5, 2025-07-15, "."
## 30.Google, GG.D0.5, 2025-08-05, "Basic Functionality Milestone: ARCH 0.8 / PGM 0.5 / DFT 0.5 / PD 0.3 / EMU 0.5"
## 30.Google, GG.R0.8, 2025-09-10, "."
## 30.Google, GG.D0.8, 2025-10-01, "Feature Complete Milestone: ARCH 1.0? / PGM 0.8 / DFT 0.8 / PD 0.5 / EMU *.*?"
## 30.Google, GG.R1.0, 2025-10-22, "."
## 30.Google, GG.D1.0, 2025-11-12, "Final Netlist Milestone: final complete netlist delivery to PD. Chip RTL and testing should be complete. Floorplan should be complete, all PD feedback should be incorporated"
## 
## 40.IP, SNPS.HBMC, 2025-05-21, "."
## 40.IP, SNPS.QSPI, 2025-05-21, "."
## 40.IP, SNPS.PDM, 2025-05-21, "."
## 40.IP, AW.UCIe, 2025-05-21, "."
## 40.IP, 4Lynx.UCIe, 2025-05-21, "."


## Examples: .bxcf.mdgg.dependency.csv
## 
## Source, Destination
## 
## B-die.ML2, B-die.ML3
## B-die.ML3, B-die.FC
## B-die.FC, B-die.ML4
## B-die.ML4, B-die.MTO
## B-die.MTO, B-die.FO
## B-die.FO, B-die.FS
## B-die.FS, B-die.ES
## B-die.ES, B-die.CS
## 
## cHBM4.CTPHY, B-die.ML2
## GG.D0.3, B-die.ML2
## cHBM4E.CTPHY.alpha, B-die.ML3
## GG.D0.5, B-die.ML3
## cHBM4E.CTPHY.beta, B-die.FC
## cHBM4E.CTPHY.final, B-die.ML4
## GG.D0.8, B-die.FC
## GG.D1.0, B-die.ML4
## 
## GG.D0.3, GG.D0.5
## GG.D0.5, GG.D0.8
## GG.D0.8, GG.D1.0




# Load required packages
library(ggplot2)
library(lubridate)
library(plotly)

# Read milestones from CSV file: (Group, Name, Date)
milestones <- read.csv(".bxcf.mdgg.milestone.csv", stringsAsFactors = FALSE)
milestones$Group <- trimws(milestones$Group)  # Strip whitespace from Group
milestones$Name <- trimws(milestones$Name)  # Strip whitespace from Name
milestones$Date <- as.Date(trimws(milestones$Date))  # Convert Date to Date class
milestones$Notes <- trimws(milestones$Notes)  # Strip whitespace from Notes

# Check for invalid or missing dates
if (any(is.na(milestones$Date))) {
  stop("Error: Invalid or missing dates in milestones.csv: ",
       paste(milestones$Name[is.na(milestones$Date)], collapse = ", "))
}

# Assign Y values for swimlanes
# Group milestones by Group, assign Y within each group, and offset groups
milestones <- milestones[order(milestones$Group, milestones$Date), ]  # Sort by Group, then Date
# groups <- unique(milestones$Group)
groups <- sort(unique(milestones$Group), decreasing=TRUE)
y_offset <- 0
milestones$Y <- numeric(nrow(milestones))
for (g in groups) {
  group_indices <- which(milestones$Group == g)
  n_group_milestones <- length(group_indices)
  # Assign Y values within group (decreasing from n to 1)
  milestones$Y[group_indices] <- (n_group_milestones:1) + y_offset
  # Add larger offset for next group (group size + 3 for gap)
  y_offset <- y_offset + n_group_milestones + 1
}

# Read dependencies from CSV file: (Source, Destination)
dependencies <- read.csv(".bxcf.mdgg.dependency.csv", stringsAsFactors = FALSE)
dependencies$Source <- trimws(dependencies$Source)
dependencies$Destination <- trimws(dependencies$Destination)

# Check for unmatched Source or Destination names
unmatched_sources <- dependencies$Source[!dependencies$Source %in% milestones$Name]
unmatched_destinations <- dependencies$Destination[!dependencies$Destination %in% milestones$Name]
if (length(unmatched_sources) > 0 || length(unmatched_destinations) > 0) {
  stop("Error: The following names in dependencies.csv do not match any milestone names:\n",
       "Unmatched Sources: ", paste(unmatched_sources, collapse = ", "), "\n",
       "Unmatched Destinations: ", paste(unmatched_destinations, collapse = ", "))
}

# Process dependencies to extract start and end coordinates
dependencies$Start_Date <- as.Date(sapply(dependencies$Source, function(x) milestones$Date[milestones$Name == x]), origin = "1970-01-01") + 1  # Offset by 1 day
dependencies$End_Date <- as.Date(sapply(dependencies$Destination, function(x) milestones$Date[milestones$Name == x]), origin = "1970-01-01") - 1  # Offset by 1 day
dependencies$Start_Y <- sapply(dependencies$Source, function(x) milestones$Y[milestones$Name == x])
dependencies$End_Y <- sapply(dependencies$Destination, function(x) milestones$Y[milestones$Name == x])

# Calculate dynamic x-range based on milestone dates
date_range <- as.numeric(max(milestones$Date) - min(milestones$Date))
padding_days <- max(7, ceiling(date_range * 0.1))  # At least 7 days, or 10% of range
x_min <- min(milestones$Date) - padding_days
x_max <- max(milestones$Date) + padding_days

# Create swimlane backgrounds (rectangles and labels)
swimlanes <- data.frame(
  Group = groups,
  Y_min = sapply(groups, function(g) min(milestones$Y[milestones$Group == g]) - 0.5),  # Below bottom milestone
  Y_max = sapply(groups, function(g) max(milestones$Y[milestones$Group == g]) + 0.5)   # Above top milestone
)
swimlanes$Label_Y <- swimlanes$Y_max + 0.2  # Position group labels further above swimlane

# Create Gantt chart with ggplot2
p <- ggplot() +
  # Draw swimlane background rectangles
  geom_rect(data = swimlanes,
            aes(xmin = x_min, xmax = x_max, ymin = Y_min, ymax = Y_max, fill = Group),
            alpha = 0.2) +
  # Plot milestones as points (with mouse-over text)
  geom_point(data = milestones, aes(x = Date, y = Y, text = paste("Name: ", Name, "\nDate: ", Date, "\nNotes: ", Notes)),
             size = 2, color = "blue", shape = 19) +
  # Plot dependencies as arrows
  geom_segment(data = dependencies,
               aes(x = Start_Date, xend = End_Date, y = Start_Y, yend = End_Y),
               arrow = arrow(type = "closed", ends = "last", length = unit(0.3, "cm")),
               color = "#808080", linetype = 3, linewidth = 0.3, lineend = "round") +
  # Add milestone names and dates as labels
  geom_text(data = milestones,
            aes(x = Date + 0, y = Y - 0.4, label = paste(Name, "\n", Date)),
            size = 3, hjust = 0, vjust = 0.5, color = "black") +
  # Add group labels above each swimlane
  geom_text(data = swimlanes,
            aes(x = x_min, y = Label_Y, label = Group),
            size = 6, hjust = 0, vjust = 0, color = "darkgray", fontface = "bold") +
  # Customize axes
  scale_y_continuous(breaks = milestones$Y, labels = milestones$Name, name = "Milestones") +
  scale_x_date(name = "Timeline", date_breaks = "1 month", date_labels = "%b %Y",
               limits = as.Date(c(x_min, x_max))) +
  # Customize fill for swimlane backgrounds
  scale_fill_manual(values = rep(c("#D0D0D0", "#D0D0D0"), length.out = length(groups)), guide = "none") +
  # Theme and title
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 10),
    axis.text.x = element_text(angle = 45, hjust = 1),
    plot.title = element_text(hjust = 0.5),
    panel.grid.major.y = element_blank(),  # Remove y-grid for clarity
    panel.grid.minor.y = element_blank()
  ) +
  ggtitle("Milestones & Dependencies Graph -- (c) 2025 brian.m.jung")

# Convert to interactive plotly plot
interactive_plot <- ggplotly(p, tooltip = "text")

# Save as interactive HTML
htmlwidgets::saveWidget(interactive_plot, "milestone_and_dependency.html")

# Optionally save as static PNG
ggsave("milestone_and_dependency.png", plot = p, width = 10, height = 8, units = "in", dpi = 300)

# Display plot in R viewer (if running interactively)
print(interactive_plot)




