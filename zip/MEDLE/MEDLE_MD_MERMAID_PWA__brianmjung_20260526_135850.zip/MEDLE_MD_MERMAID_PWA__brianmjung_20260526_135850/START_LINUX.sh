#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
  python3 scripts/serve.py
elif command -v python >/dev/null 2>&1; then
  python scripts/serve.py
else
  echo "Python 3 is required to run the local PWA server."
  echo "Alternative: upload this folder to any HTTPS static host and open index.html."
  exit 1
fi
