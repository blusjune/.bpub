#!/usr/bin/env python3
"""Portable local server for MEDLE Markdown + Mermaid Editor.

Runs on localhost so PWA/service-worker features work without needing a public web host.
"""
from __future__ import annotations

import http.server
import os
import socketserver
import sys
import threading
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PORT = int(os.environ.get("MEDLE_PORT", "8787"))

class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".js": "application/javascript; charset=utf-8",
        ".mjs": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".html": "text/html; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".webmanifest": "application/manifest+json; charset=utf-8",
        ".svg": "image/svg+xml; charset=utf-8",
    }

    def end_headers(self):
        # Safe localhost headers. Service workers require a secure context; localhost qualifies.
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, fmt: str, *args):
        sys.stderr.write("[MEDLE] " + fmt % args + "\n")


def serve(port: int) -> None:
    os.chdir(ROOT)
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("127.0.0.1", port), Handler) as httpd:
        url = f"http://127.0.0.1:{port}/index.html"
        print(f"MEDLE Markdown + Mermaid Editor")
        print(f"Serving: {ROOT}")
        print(f"Open:    {url}")
        threading.Thread(target=lambda: (time.sleep(0.8), webbrowser.open(url)), daemon=True).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")

if __name__ == "__main__":
    port = DEFAULT_PORT
    for candidate in range(DEFAULT_PORT, DEFAULT_PORT + 50):
        try:
            serve(candidate)
            break
        except OSError:
            continue
