#!/usr/bin/env sh
set -eu
mkdir -p vendor
curl -L -o vendor/marked.min.js https://cdn.jsdelivr.net/npm/marked/marked.min.js
curl -L -o vendor/purify.min.js https://cdn.jsdelivr.net/npm/dompurify/dist/purify.min.js
curl -L -o vendor/mermaid.min.js https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js
echo "Vendor files downloaded. The PWA can now run fully offline after first local load."
