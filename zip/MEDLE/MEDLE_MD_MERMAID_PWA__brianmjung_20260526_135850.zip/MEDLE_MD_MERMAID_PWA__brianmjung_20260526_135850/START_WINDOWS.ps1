Set-Location -LiteralPath $PSScriptRoot
if (Get-Command py -ErrorAction SilentlyContinue) {
  py -3 scripts\serve.py
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  python scripts\serve.py
} else {
  Write-Host "Python 3 is required to run the local PWA server."
  Write-Host "Alternative: upload this folder to any HTTPS static host and open index.html."
  Read-Host "Press Enter to exit"
}
