# Cross-platform deployment guide

This package is a static HTML5/JavaScript PWA. The same app code runs on iOS, Android, Windows, and Linux.

## Platform matrix

| Platform | Recommended way | Notes |
|---|---|---|
| Windows | Double-click `START_WINDOWS.bat` or run `START_WINDOWS.ps1` | Opens `http://127.0.0.1:8787/index.html`; PWA install is available in Chromium browsers. |
| Linux | Run `./START_LINUX.sh` | Opens a localhost server; PWA install is available in Chromium browsers. |
| Android | Host the folder on HTTPS, open in Chrome, use Add to Home screen / Install app | File input, paste, export downloads, and PWA install are supported by modern Chrome. |
| iOS / iPadOS | Host the folder on HTTPS, open in Safari, use Share -> Add to Home Screen | iOS supports PWA install through Safari. Some download/file APIs are more restricted than desktop. |

## Why localhost or HTTPS is required

The editor can open directly as `index.html`, but PWA offline caching requires a secure context. Browsers treat these as secure:

- `http://127.0.0.1` / `http://localhost`
- `https://...`

A plain `file://.../index.html` page usually cannot register a Service Worker.

## Input strategy without browser Ctrl+O

Browser vendors may reserve or block the native Ctrl+O file-open shortcut. This app avoids relying on it:

1. `Open File` button
2. drag-and-drop file onto the page
3. direct paste into the editor
4. `Paste` button when clipboard permission is allowed
5. autosaved draft in IndexedDB

Where supported, `Open File` first tries the File System Access API. If that is unavailable or blocked, it falls back to a normal file input control.

## Export strategy

| Export | Mechanism | Cross-platform note |
|---|---|---|
| Markdown | Browser download | Works broadly; iOS may place files in Downloads/iCloud Drive. |
| HTML | Browser download of a rendered snapshot | The exported HTML contains the rendered content, not an editor runtime. |
| SVG | One SVG download per rendered Mermaid chart | Some mobile browsers ask for confirmation per file. |
| PDF | Browser print dialog | Choose Save as PDF / Print to PDF. iOS uses the Safari share/print workflow. |

## Making Mermaid fully offline

This ZIP includes local placeholders for Mermaid and DOMPurify if the build environment could not download vendor files. To make the package fully offline before distribution, run this once on an internet-connected machine:

```bash
./download_vendor.sh
```

Then verify these files are non-trivial JavaScript bundles:

```text
vendor/marked.min.js
vendor/purify.min.js
vendor/mermaid.min.js
```

After that, the PWA does not need external network access for Markdown + Mermaid rendering.

## Hosting options for mobile

For iOS and Android, the cleanest option is any HTTPS static hosting path. Examples:

- internal company static web server
- GitHub Pages / Cloudflare Pages / Netlify / Vercel
- Nginx or Apache with HTTPS

Upload the folder contents exactly as-is, then open `index.html` from the HTTPS URL.

## Security posture

- Mermaid is initialized with `securityLevel: 'strict'`.
- Rendered Markdown is sanitized by DOMPurify when available.
- The app is static and does not upload user content anywhere.
- Autosave uses browser-local IndexedDB.


## PNG/JPG export note

PNG/JPG export uses the browser Canvas API to rasterize rendered Mermaid SVG diagrams. This works offline and does not require Ctrl+O or external services. JPG export uses a white background because JPEG does not support transparency.

## Build Number Refresh

Before distributing a new PWA package, refresh the build number.

Linux/macOS:

```bash
./build.sh
```

Windows PowerShell:

```powershell
./BUILD_WINDOWS.ps1
```

This uses the same format as:

```bash
$(date +%Y%m%d_%H%M%S)
```

The value appears in the upper-right corner of the PWA screen in very small text and is also embedded into the Service Worker cache name so users receive the latest cached assets after deployment.
