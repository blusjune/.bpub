(() => {
  'use strict';

  const BUILD_ID = window.MEDLE_BUILD_NUMBER || 'build: brianmjung_dev_local';
  const FILE_BUILD_ID = BUILD_ID.replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
  const CDN = {
    marked: 'https://cdn.jsdelivr.net/npm/marked/marked.min.js',
    purify: 'https://cdn.jsdelivr.net/npm/dompurify/dist/purify.min.js',
    mermaid: 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js'
  };

  const $ = (id) => document.getElementById(id);
  const editor = $('editor');
  const preview = $('preview');
  const status = $('status');
  const stats = $('stats');
  const fileInput = $('fileInput');
  const dropOverlay = $('dropOverlay');
  const platformStatus = $('platformStatus');
  const installBtn = $('installBtn');

  let deferredInstallPrompt = null;
  let renderTimer = 0;
  let lastRenderSeq = 0;
  let db = null;

  $('buildId').textContent = BUILD_ID;
  if ($('buildNumberBadge')) $('buildNumberBadge').textContent = BUILD_ID;

  function setStatus(text) { status.textContent = text; }
  function detectPlatform() {
    const ua = navigator.userAgent || '';
    const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const isAndroid = /Android/.test(ua);
    const isWindows = /Win/.test(navigator.platform || ua);
    const isLinux = /Linux/.test(navigator.platform || ua) && !isAndroid;
    const standalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    const picker = 'showOpenFilePicker' in window ? 'FS API' : 'file input';
    const sw = 'serviceWorker' in navigator ? 'SW' : 'no SW';
    let os = isIOS ? 'iOS' : isAndroid ? 'Android' : isWindows ? 'Windows' : isLinux ? 'Linux' : 'Browser';
    platformStatus.textContent = `${os} · ${standalone ? 'installed' : 'browser'} · ${picker} · ${sw}`;
  }
  function updateStats() {
    const bytes = new Blob([editor.value]).size;
    stats.textContent = `${editor.value.length.toLocaleString()} chars · ${formatBytes(bytes)}`;
  }
  function formatBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1024 / 1024).toFixed(2) + ' MB';
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function slug(s) { return String(s).toLowerCase().replace(/[^a-z0-9가-힣]+/gi, '-').replace(/^-|-$/g, '').slice(0, 70); }

  async function loadScriptIfMissing(globalName, src) {
    if (window[globalName]) return true;
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.async = true;
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    }).catch(() => null);
    return !!window[globalName];
  }

  async function ensureLibraries() {
    const tasks = [];
    if (!window.marked) tasks.push(loadScriptIfMissing('marked', CDN.marked));
    if (!window.DOMPurify) tasks.push(loadScriptIfMissing('DOMPurify', CDN.purify));
    if (!window.mermaid) tasks.push(loadScriptIfMissing('mermaid', CDN.mermaid));
    if (tasks.length) await Promise.all(tasks);
    if (window.mermaid && !window.__mermaidReady) {
      window.mermaid.initialize({ startOnLoad: false, securityLevel: 'strict', theme: 'default' });
      window.__mermaidReady = true;
    }
  }

  function fallbackMarkdown(md) {
    const blocks = [];
    md = md.replace(/```(\w+)?\n([\s\S]*?)```/g, (_, lang = '', code) => {
      const i = blocks.push(`<pre><code class="language-${escapeHtml(lang)}">${escapeHtml(code)}</code></pre>`) - 1;
      if (lang.toLowerCase() === 'mermaid') blocks[i] = `<div class="mermaid">${escapeHtml(code)}</div>`;
      return `\n@@BLOCK_${i}@@\n`;
    });
    let html = escapeHtml(md)
      .replace(/^###### (.*)$/gm, '<h6>$1</h6>')
      .replace(/^##### (.*)$/gm, '<h5>$1</h5>')
      .replace(/^#### (.*)$/gm, '<h4>$1</h4>')
      .replace(/^### (.*)$/gm, '<h3>$1</h3>')
      .replace(/^## (.*)$/gm, '<h2>$1</h2>')
      .replace(/^# (.*)$/gm, '<h1>$1</h1>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    html = html.split(/\n{2,}/).map(part => {
      if (/^\s*<h\d|^\s*@@BLOCK_/.test(part)) return part;
      return `<p>${part.replace(/\n/g, '<br>')}</p>`;
    }).join('\n');
    return html.replace(/@@BLOCK_(\d+)@@/g, (_, i) => blocks[Number(i)]);
  }

  function normalizeMermaidBlocks(md) {
    // marked already emits code blocks, but this guarantees mermaid fences become renderable blocks even without extension support.
    return md.replace(/```mermaid\s*\n([\s\S]*?)```/gi, (_, code) => `<div class="mermaid">${escapeHtml(code.trim())}</div>`);
  }

  function renderMarkdown(md) {
    let html;
    if (window.marked) {
      try {
        window.marked.setOptions({ gfm: true, breaks: false, mangle: false, headerIds: true });
        html = window.marked.parse(normalizeMermaidBlocks(md));
      } catch (e) { html = fallbackMarkdown(md); }
    } else {
      html = fallbackMarkdown(md);
    }
    if (window.DOMPurify) {
      return window.DOMPurify.sanitize(html, { ADD_TAGS: ['svg', 'path', 'g', 'defs', 'marker', 'style', 'text', 'tspan', 'polygon', 'polyline', 'rect', 'circle', 'ellipse', 'line'], ADD_ATTR: ['target', 'rel', 'viewBox', 'd', 'x', 'y', 'x1', 'x2', 'y1', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'points', 'marker-end', 'marker-start', 'transform', 'style', 'class', 'id', 'xmlns'] });
    }
    return html.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '');
  }

  async function renderNow() {
    const seq = ++lastRenderSeq;
    const md = editor.value;
    updateStats();
    setStatus('Rendering...');
    await ensureLibraries();
    if (seq !== lastRenderSeq) return;
    preview.innerHTML = renderMarkdown(md);
    await renderMermaid(seq);
    setStatus(`Rendered · ${new Date().toLocaleTimeString()}`);
    saveDraft(md);
  }

  async function renderMermaid(seq) {
    const nodes = [...preview.querySelectorAll('.mermaid')];
    if (!nodes.length) return;
    if (!window.mermaid) {
      nodes.forEach(n => n.innerHTML = `<div class="mermaid-error">Mermaid library is not available.\n\nFor full offline use, place mermaid.min.js in ./vendor/mermaid.min.js or allow the first online load.</div>`);
      return;
    }
    for (let i = 0; i < nodes.length; i++) {
      if (seq !== lastRenderSeq) return;
      const node = nodes[i];
      const source = node.textContent.trim();
      const id = 'mmd-' + Date.now() + '-' + i;
      try {
        const result = await window.mermaid.render(id, source);
        node.innerHTML = result.svg;
        node.dataset.source = source;
      } catch (e) {
        node.innerHTML = `<div class="mermaid-error">Mermaid render error:\n${escapeHtml(e.message || e)}</div><pre><code>${escapeHtml(source)}</code></pre>`;
      }
    }
  }

  function scheduleRender() {
    clearTimeout(renderTimer);
    const size = new Blob([editor.value]).size;
    if (size > 1024 * 1024) {
      setStatus('Large input loaded · press Render');
      saveDraft(editor.value);
      return;
    }
    renderTimer = setTimeout(renderNow, size > 250 * 1024 ? 900 : 350);
  }

  function downloadBlob(filename, blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  function safeFilename(ext) { return `markdown_mermaid_${FILE_BUILD_ID}.${ext}`; }

  function exportHtml() {
    const source = editor.value;
    const content = preview.innerHTML;
    const html = `<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Exported Markdown Mermaid</title><style>${document.querySelector('style')?.textContent || ''}${getEmbeddedCss()}</style></head><body><main class="markdown-body">${content}</main><template id="source-md">${escapeHtml(source)}</template></body></html>`;
    downloadBlob(safeFilename('html'), new Blob([html], { type: 'text/html;charset=utf-8' }));
  }
  function getEmbeddedCss() {
    const css = [...document.styleSheets].map(ss => {
      try { return [...ss.cssRules].map(r => r.cssText).join('\n'); } catch { return ''; }
    }).join('\n');
    return css;
  }

  function getRenderedMermaidSvgs() {
    return [...preview.querySelectorAll('.mermaid svg')];
  }

  function prepareSvgForExport(svg) {
    const copy = svg.cloneNode(true);
    copy.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    copy.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');

    const box = svg.getBoundingClientRect();
    let width = Math.ceil(box.width || Number(svg.getAttribute('width')) || 1200);
    let height = Math.ceil(box.height || Number(svg.getAttribute('height')) || 800);

    const viewBox = svg.getAttribute('viewBox');
    if (viewBox) {
      const parts = viewBox.trim().split(/[\s,]+/).map(Number);
      if (parts.length === 4 && parts.every(Number.isFinite)) {
        width = Math.ceil(parts[2]);
        height = Math.ceil(parts[3]);
      }
    }

    width = Math.max(1, width);
    height = Math.max(1, height);
    copy.setAttribute('width', String(width));
    copy.setAttribute('height', String(height));
    if (!copy.getAttribute('viewBox')) copy.setAttribute('viewBox', `0 0 ${width} ${height}`);

    return {
      svg: copy,
      width,
      height,
      text: '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(copy)
    };
  }

  function exportSvg() {
    const svgs = getRenderedMermaidSvgs();
    if (!svgs.length) { alert('No rendered Mermaid SVG found. Render first.'); return; }
    svgs.forEach((svg, i) => {
      const { text } = prepareSvgForExport(svg);
      setTimeout(() => downloadBlob(`mermaid_${String(i + 1).padStart(2, '0')}_${FILE_BUILD_ID}.svg`, new Blob([text], { type: 'image/svg+xml;charset=utf-8' })), i * 250);
    });
  }

  function svgToRasterBlob(svg, mimeType, quality = 0.92) {
    return new Promise((resolve, reject) => {
      const { text, width, height } = prepareSvgForExport(svg);
      const blob = new Blob([text], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => {
        try {
          const scale = Math.min(3, Math.max(1, window.devicePixelRatio || 1));
          const canvas = document.createElement('canvas');
          canvas.width = Math.ceil(width * scale);
          canvas.height = Math.ceil(height * scale);
          const ctx = canvas.getContext('2d');
          ctx.setTransform(scale, 0, 0, scale, 0, 0);
          if (mimeType === 'image/jpeg') {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, width, height);
          }
          ctx.drawImage(img, 0, 0, width, height);
          URL.revokeObjectURL(url);
          canvas.toBlob(out => {
            if (out) resolve(out);
            else reject(new Error('Canvas export failed.'));
          }, mimeType, quality);
        } catch (e) {
          URL.revokeObjectURL(url);
          reject(e);
        }
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('SVG image load failed.')); };
      img.src = url;
    });
  }

  async function exportRaster(format) {
    const svgs = getRenderedMermaidSvgs();
    if (!svgs.length) { alert('No rendered Mermaid SVG found. Render first.'); return; }
    const isJpg = format === 'jpg' || format === 'jpeg';
    const mimeType = isJpg ? 'image/jpeg' : 'image/png';
    const ext = isJpg ? 'jpg' : 'png';
    setStatus(`Exporting ${ext.toUpperCase()}...`);
    let ok = 0;
    for (let i = 0; i < svgs.length; i++) {
      try {
        const blob = await svgToRasterBlob(svgs[i], mimeType, 0.94);
        downloadBlob(`mermaid_${String(i + 1).padStart(2, '0')}_${FILE_BUILD_ID}.${ext}`, blob);
        ok++;
        await new Promise(resolve => setTimeout(resolve, 250));
      } catch (e) {
        console.error(e);
        alert(`Failed to export diagram ${i + 1} as ${ext.toUpperCase()}: ${e.message || e}`);
      }
    }
    setStatus(`Exported ${ok}/${svgs.length} ${ext.toUpperCase()} file(s)`);
  }

  function exportPdf() { window.print(); }
  function saveMarkdown() { downloadBlob(safeFilename('md'), new Blob([editor.value], { type: 'text/markdown;charset=utf-8' })); }

  async function openWithFileSystemAccess() {
    if (!('showOpenFilePicker' in window)) return false;
    try {
      const [handle] = await window.showOpenFilePicker({
        types: [{ description: 'Markdown or text', accept: { 'text/markdown': ['.md', '.markdown'], 'text/plain': ['.txt'] } }],
        multiple: false
      });
      const file = await handle.getFile();
      await readFile(file);
      return true;
    } catch (e) {
      return e && e.name === 'AbortError' ? true : false;
    }
  }

  async function readFile(file) {
    if (!file) return;
    setStatus(`Reading ${file.name} · ${formatBytes(file.size)}`);
    const text = await file.text();
    editor.value = text;
    updateStats();
    scheduleRender();
  }

  async function pasteClipboard() {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        const start = editor.selectionStart ?? editor.value.length;
        const end = editor.selectionEnd ?? editor.value.length;
        editor.value = editor.value.slice(0, start) + text + editor.value.slice(end);
        editor.selectionStart = editor.selectionEnd = start + text.length;
        scheduleRender();
      }
    } catch (e) {
      alert('Clipboard access was blocked. Use normal paste into the editor instead.');
    }
  }

  function loadSample() {
    editor.value = `# Markdown + Mermaid Sample\n\n- Paste, drag-and-drop, or press **Open File**.\n- Export to **HTML**, **SVG**, **PNG**, **JPG**, or **PDF**.\n\n## Flowchart\n\n\`\`\`mermaid\nflowchart TD\n  A[Large Markdown Input] --> B{Render mode}\n  B -->|Small/medium| C[Auto render]\n  B -->|Large > 1MB| D[Manual Render]\n  C --> E[Preview]\n  D --> E\n  E --> F[Export HTML/PDF/SVG/PNG/JPG]\n\`\`\`\n\n## Sequence\n\n\`\`\`mermaid\nsequenceDiagram\n  participant U as User\n  participant A as PWA\n  participant B as Browser APIs\n  U->>A: Paste or drag file\n  A->>B: Read as text\n  A->>A: Markdown parse + Mermaid render\n  U->>A: Export\n\`\`\`\n\n## Table\n\n| Feature | Supported |\n|---|---:|\n| Markdown preview | Yes |\n| Mermaid code fence | Yes |\n| Ctrl+O bypass | File button / drop / paste |\n| Large input | Manual render fallback |\n`;
    scheduleRender();
  }

  function initDb() {
    return new Promise((resolve) => {
      const req = indexedDB.open('medle-md-mermaid', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('kv');
      req.onsuccess = () => { db = req.result; resolve(); };
      req.onerror = () => resolve();
    });
  }
  function idbSet(key, value) {
    if (!db) return;
    const tx = db.transaction('kv', 'readwrite');
    tx.objectStore('kv').put(value, key);
  }
  function idbGet(key) {
    return new Promise((resolve) => {
      if (!db) return resolve(null);
      const tx = db.transaction('kv', 'readonly');
      const req = tx.objectStore('kv').get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  }
  let saveTimer = 0;
  function saveDraft(text) { clearTimeout(saveTimer); saveTimer = setTimeout(() => idbSet('draft', text), 300); }

  editor.addEventListener('input', () => { updateStats(); scheduleRender(); });
  $('renderBtn').addEventListener('click', renderNow);
  $('openBtn').addEventListener('click', async () => { if (!(await openWithFileSystemAccess())) fileInput.click(); });
  $('pasteBtn').addEventListener('click', pasteClipboard);
  $('saveMdBtn').addEventListener('click', saveMarkdown);
  $('exportHtmlBtn').addEventListener('click', exportHtml);
  $('exportSvgBtn').addEventListener('click', exportSvg);
  $('exportPngBtn').addEventListener('click', () => exportRaster('png'));
  $('exportJpgBtn').addEventListener('click', () => exportRaster('jpg'));
  $('exportPdfBtn').addEventListener('click', exportPdf);
  $('sampleBtn').addEventListener('click', loadSample);
  $('viewSourceBtn').addEventListener('click', () => { document.body.classList.remove('view-preview'); document.body.classList.add('view-source'); });
  $('viewSplitBtn').addEventListener('click', () => { document.body.classList.remove('view-source', 'view-preview'); });
  $('viewPreviewBtn').addEventListener('click', () => { document.body.classList.remove('view-source'); document.body.classList.add('view-preview'); renderNow(); });
  installBtn.addEventListener('click', async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice.catch(() => null);
    deferredInstallPrompt = null;
    installBtn.hidden = true;
  });
  $('clearBtn').addEventListener('click', () => { if (confirm('Clear editor and draft?')) { editor.value = ''; preview.innerHTML = ''; idbSet('draft', ''); updateStats(); } });
  fileInput.addEventListener('change', e => readFile(e.target.files[0]));
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredInstallPrompt = e;
    installBtn.hidden = false;
  });
  window.addEventListener('appinstalled', () => { installBtn.hidden = true; deferredInstallPrompt = null; detectPlatform(); });
  window.addEventListener('online', detectPlatform);
  window.addEventListener('offline', detectPlatform);

  ['dragenter', 'dragover'].forEach(type => document.addEventListener(type, e => { e.preventDefault(); dropOverlay.classList.add('active'); }));
  ['dragleave', 'drop'].forEach(type => document.addEventListener(type, e => { e.preventDefault(); if (type === 'drop') readFile(e.dataTransfer.files[0]); dropOverlay.classList.remove('active'); }));

  window.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'o') {
      e.preventDefault();
      openWithFileSystemAccess().then(used => { if (!used) fileInput.click(); });
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      renderNow();
    }
  });

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(() => null);
  }

  (async function boot() {
    detectPlatform();
    await initDb();
    const draft = await idbGet('draft');
    if (draft) editor.value = draft;
    else loadSample();
    updateStats();
    scheduleRender();
  })();
})();
