# MEDLE Markdown + Mermaid Editor

Offline-first Markdown + Mermaid Editor/Viewer PWA for iOS, Android, Windows, and Linux.

## What is included

- `index.html`: application shell
- `app.js`: editor, renderer, autosave, export logic
- `styles.css`: responsive desktop/mobile UI
- `manifest.json`: PWA metadata, icons, file/share hints
- `sw.js`: Service Worker for offline caching
- `vendor/`: local JavaScript libraries
- `icons/`: PWA icons
- `scripts/serve.py`: portable localhost server
- `START_WINDOWS.bat`, `START_WINDOWS.ps1`: Windows launchers
- `START_LINUX.sh`: Linux launcher
- `DEPLOYMENT.md`: platform-specific deployment guide

## Windows

Double-click:

```text
START_WINDOWS.bat
```

Or run PowerShell:

```powershell
.\START_WINDOWS.ps1
```

## Linux

```bash
chmod +x START_LINUX.sh
./START_LINUX.sh
```

## Manual local run

```bash
python3 scripts/serve.py
```

Then open:

```text
http://127.0.0.1:8787/index.html
```

## iOS and Android

For mobile PWA install, upload this folder to an HTTPS static host and open it in the platform browser.

- iOS / iPadOS: Safari -> Share -> Add to Home Screen
- Android: Chrome -> Install app or Add to Home screen

## Input methods that bypass Ctrl+O restrictions

- Open File button
- drag-and-drop
- direct paste into the editor
- Paste button, when browser permission allows it
- autosaved draft in IndexedDB

## Export

- Save MD
- Export HTML
- Export SVG, one file per rendered Mermaid diagram
- Export PDF through the browser print dialog

## Full offline vendor setup

Run once on a machine with internet access:

```bash
./download_vendor.sh
```

Expected local files:

```text
vendor/marked.min.js
vendor/purify.min.js
vendor/mermaid.min.js
```

If `purify.min.js` or `mermaid.min.js` are still tiny placeholder files, the app will attempt CDN fallback when online. For a fully self-contained offline build, replace them with the real library files.


## Raster export

- `Export PNG` saves each rendered Mermaid diagram as a PNG file.
- `Export JPG` saves each rendered Mermaid diagram as a JPG file with a white background.
- Render first before exporting raster images. Very large diagrams may be limited by the browser canvas size.

## Build Number

Every PWA build should update the Build Number in `build: brianmjung_YYYYMMDD_HHMMSS` format.

Linux/macOS:

```bash
./build.sh
```

Windows PowerShell:

```powershell
./BUILD_WINDOWS.ps1
```

The build number is written to:

- `BUILD_NUMBER`
- `build-info.js`
- the Service Worker cache name in `sw.js`
- the small fixed badge at the top-right of the application screen

The top-right badge uses approximately 6px text so it remains visible without disturbing the editor UI.
