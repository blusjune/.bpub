@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 scripts\serve.py
  exit /b %errorlevel%
)
where python >nul 2>nul
if %errorlevel%==0 (
  python scripts\serve.py
  exit /b %errorlevel%
)
echo Python 3 is required to run the local PWA server.
echo Alternative: upload this folder to any HTTPS static host and open index.html.
pause
