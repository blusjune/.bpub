$BuildNumber = "build: brianmjung_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
Set-Content -Path "BUILD_NUMBER" -Value $BuildNumber -NoNewline
@"
// Auto-generated at build time. Do not edit manually.
window.MEDLE_BUILD_NUMBER = "$BuildNumber";
"@ | Set-Content -Path "build-info.js" -NoNewline
$sw = Get-Content -Raw -Path "sw.js"
$sw = [regex]::Replace($sw, "const CACHE = 'medle-md-mermaid-v4-[^']*';|const CACHE = 'medle-md-mermaid-v4-' \+ \(self\.MEDLE_BUILD_NUMBER \|\| 'static'\);", "const CACHE = 'medle-md-mermaid-v4-$($BuildNumber -replace ': ','-' -replace ' ','-')';")
Set-Content -Path "sw.js" -Value $sw -NoNewline
Write-Host "Build Number updated: $BuildNumber"
