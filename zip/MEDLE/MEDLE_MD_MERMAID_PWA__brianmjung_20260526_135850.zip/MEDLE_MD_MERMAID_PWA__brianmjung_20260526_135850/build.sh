#!/usr/bin/env bash
set -euo pipefail
BUILD_NUMBER="build: brianmjung_$(date +%Y%m%d_%H%M%S)"
printf '%s\n' "$BUILD_NUMBER" > BUILD_NUMBER
cat > build-info.js <<JS
// Auto-generated at build time. Do not edit manually.
window.MEDLE_BUILD_NUMBER = "$BUILD_NUMBER";
JS
python3 - <<'PY'
from pathlib import Path
build = Path('BUILD_NUMBER').read_text().strip()
sw = Path('sw.js')
s = sw.read_text()
import re
s = re.sub(r"const CACHE = 'medle-md-mermaid-v4-[^']*';|const CACHE = 'medle-md-mermaid-v4-' \+ \(self\.MEDLE_BUILD_NUMBER \|\| 'static'\);", f"const CACHE = 'medle-md-mermaid-v4-{build.replace(': ', '-').replace(' ', '-')}';", s)
sw.write_text(s)
PY
echo "Build Number updated: $BUILD_NUMBER"
