# MEDLE Markdown + Mermaid Mobile Single-file

Build Number: `build: brianmjung_20260527_070511`

## 목적

Android/iOS에서 별도 HTTP server 없이 `MEDLE_MD_MERMAID_MOBILE_SINGLE_FILE.html` 파일 하나로 Markdown + Mermaid Editor/Viewer를 실행합니다.

## 사용 방법

- Android: Files/Downloads에서 HTML 파일을 Chrome 또는 Samsung Internet으로 엽니다.
- iOS/iPadOS: Files 앱에서 HTML 파일을 열거나 Safari로 공유해 엽니다.
- Markdown 입력은 붙여넣기 또는 Open File 버튼을 사용합니다.
- Export HTML/SVG/PNG/JPG/PDF 기능을 사용할 수 있습니다.

## Mermaid 호환성

- 이 단일 파일은 서버 없이 열리는 것을 우선하므로, 기본 상태에서는 flowchart/sequenceDiagram에 대한 lightweight offline fallback renderer를 포함합니다.
- Mermaid 전체 문법 호환성이 필요하면 인터넷 연결 후 앱 안의 `Load Mermaid CDN` 버튼을 누르세요. 이 경우에도 HTTP server는 필요하지 않습니다.
- 완전한 공식 Mermaid renderer까지 HTML 안에 내장하려면 공식 `mermaid.min.js`를 build 환경에서 받아 inline bundle로 다시 생성해야 합니다.

## Build Number 정책

- 형식: `build: brianmjung_YYYYMMDD_HHMMSS`
- 화면 우측 상단에 8px 글씨로 표시됩니다.
