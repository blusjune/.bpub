#!/usr/bin/env bash
set -Eeuo pipefail

MODE="${1:-help}"
if [[ $# -gt 0 ]]; then shift; fi
PROJECT_ROOT="$(pwd)"
OUTDIR="results/validation_$(date +%Y%m%d_%H%M%S)"
PYTHON_BIN="${PYTHON_BIN:-python3}"
BENCH_CONFIG="configs/dgx_spark_calibration_plan.yaml"
MODEL_CONFIG="configs/model_mistral_7b.yaml"
WORKLOAD_CONFIG="configs/workload_interactive.yaml"
SYSTEM_CONFIG="configs/system_target_h100x8.yaml"
CALIBRATION_CONFIG="configs/calibration_example_dgx_spark.json"
RAW_OUT=""
CALIBRATION_OUT=""
PRED_FILE=""
MEASURED_FILE=""
SCENARIO_FILE=""
QUICK=0
SYNTHETIC=0
SKIP_INSTALL=0
TOL="0.30"

log(){ printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2; }
die(){ log "ERROR: $*"; exit 1; }
usage(){ cat <<'USAGE'
Usage:
  validate_simulator_pipeline.sh selftest [--outdir DIR]
  validate_simulator_pipeline.sh measure [--quick] [--synthetic] [--outdir DIR]
  validate_simulator_pipeline.sh simulate --pred FILE [--model FILE --workload FILE --system FILE --calibration FILE]
  validate_simulator_pipeline.sh validate --pred FILE --measured FILE [--outdir DIR]
  validate_simulator_pipeline.sh full [--quick] [--synthetic] [--outdir DIR]
USAGE
}
while [[ $# -gt 0 ]]; do
  case "$1" in
    --project-root) PROJECT_ROOT="$2"; shift 2;;
    --outdir) OUTDIR="$2"; shift 2;;
    --python) PYTHON_BIN="$2"; shift 2;;
    --bench-config) BENCH_CONFIG="$2"; shift 2;;
    --raw-out) RAW_OUT="$2"; shift 2;;
    --calibration-out) CALIBRATION_OUT="$2"; shift 2;;
    --model) MODEL_CONFIG="$2"; shift 2;;
    --workload) WORKLOAD_CONFIG="$2"; shift 2;;
    --system) SYSTEM_CONFIG="$2"; shift 2;;
    --calibration) CALIBRATION_CONFIG="$2"; shift 2;;
    --scenario-file) SCENARIO_FILE="$2"; shift 2;;
    --pred) PRED_FILE="$2"; shift 2;;
    --measured) MEASURED_FILE="$2"; shift 2;;
    --quick) QUICK=1; shift;;
    --synthetic) SYNTHETIC=1; shift;;
    --skip-install) SKIP_INSTALL=1; shift;;
    --tol) TOL="$2"; shift 2;;
    -h|--help) MODE=help; shift;;
    *) die "unknown option: $1";;
  esac
done
mkdir -p "$OUTDIR"
TOOLS="$OUTDIR/.tools"
mkdir -p "$TOOLS"

write_tools(){
cat > "$TOOLS/vtools.py" <<'PYTOOLS'
import csv, json, random, statistics, sys
from pathlib import Path
try:
    import yaml
except Exception:
    yaml = None

def load_any(p):
    p=Path(p); t=p.read_text()
    if p.suffix.lower() in ('.yaml','.yml'):
        if yaml is None: raise RuntimeError('PyYAML required for YAML')
        return yaml.safe_load(t)
    return json.loads(t)

def write_json(p,x):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,indent=2))

def append_jsonl(p,x):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a') as f: f.write(json.dumps(x)+'\n')

def db(dtype): return {'fp32':4,'tf32':4,'fp16':2,'bf16':2,'fp8':1,'int8':1,'fp4':0.5,'int4':0.5}.get(dtype,2)

def fmt(x): return f'{x:.3f} s' if x>=1 else f'{x*1e3:.3f} ms' if x>=1e-3 else f'{x*1e6:.3f} us'

def fallback_sim(model, workload, system, cal):
    B=int(workload.get('batch_size',1))*int(workload.get('concurrent_requests',1)); S=int(workload.get('prompt_len',2048)); T=int(workload.get('generated_tokens',256))
    dtype=workload.get('precision','fp16'); b=db(dtype)
    H=int(model['hidden_size']); L=int(model['num_hidden_layers']); A=int(model['num_attention_heads']); KV=int(model.get('num_key_value_heads') or A); I=int(model['intermediate_size']); V=int(model['vocab_size']); D=H/A
    par=system.get('parallelism') or {}; TP=int(par.get('tensor_parallel',1)); PP=int(par.get('pipeline_parallel',1)); DP=int(par.get('data_parallel',1))
    peak=(system.get('peak_tflops') or {}).get(dtype,(system.get('peak_tflops') or {}).get('fp16',100.0))
    de=(cal.get('dtype_efficiency') or {}).get(dtype,0.6); le=(cal.get('shape_efficiency') or {}).get('large_m',0.65); se=(cal.get('shape_efficiency') or {}).get('decode_m1',0.18)
    bw=float(system.get('memory_bandwidth_gbps_per_gpu',1000))*float(cal.get('memory_efficiency',0.75)); kvbw=bw*float(cal.get('kv_cache_bandwidth_factor',0.5))
    kvout=KV*D; layers=L/PP
    pf=L*(2*B*S*H*(H/TP)+4*B*S*H*(kvout/TP)+2*B*S*(H/TP)*H+4*B*(A/TP)*S*S*D+6*B*S*H*(I/TP))+2*B*S*H*(V/TP)
    dc=L*(2*B*H*(H/TP)+4*B*H*(kvout/TP)+2*B*(H/TP)*H+4*B*(A/TP)*(S+T/2)*D+6*B*H*(I/TP))+2*B*H*(V/TP)
    pf_s=pf/(peak*de*le*1e12); dc_compute=dc/(peak*de*se*1e12)
    kvbytes=B*layers*(S+T/2)*(KV/TP)*D*2*b; kv_s=kvbytes/(kvbw*1e9)
    net=system.get('network') or {}; comm=0
    if TP>1: comm=float(net.get('latency_us',8))*1e-6 + (B*H*b*L)/(float(net.get('effective_bandwidth_gbps',300))*1e9)
    dec=max(dc_compute,kv_s)+comm/max(T,1); total=pf_s+T*dec
    params=V*H/TP + layers*(H*(H/TP)+2*H*(kvout/TP)+(H/TP)*H+3*H*(I/TP))
    mem=params*b + B*layers*(S+T)*(KV/TP)*D*2*b + B*S*H*b/TP*6
    cap=float(system.get('memory_capacity_gb_per_gpu',80))*1e9
    bott='compute' if dc_compute>=kv_s else 'kv_cache'
    if comm > 0.25*total: bott='communication'
    if mem>cap: bott='memory_capacity'
    return {'summary':{'prefill_latency_s':pf_s,'decode_latency_per_token_s':dec,'total_latency_s':total,'tokens_per_second_total':B*T/total*DP,'memory_per_gpu_bytes':mem,'memory_ok':mem<=cap,'formatted':{'prefill_latency':fmt(pf_s),'decode_latency_per_token':fmt(dec),'total_latency':fmt(total)}},'bottleneck_rank':[{'type':bott,'time_s':total,'fraction':1.0}],'assumptions':['fallback simulator']}

def sim(project, modelp, workp, sysp, calp):
    model=load_any(modelp); work=load_any(workp); system=load_any(sysp); cal=load_any(calp)
    try:
        sys.path.insert(0,project)
        from backend.analyzer.simulator import simulate_from_dicts
        return simulate_from_dicts(model=model, workload=work, system=system, calibration=cal)
    except Exception as e:
        r=fallback_sim(model,work,system,cal); r['fallback_reason']=str(e); return r

def summary(r):
    s=r.get('summary',{}); b=r.get('bottleneck_rank') or []
    return {'prefill_latency_s':s.get('prefill_latency_s'),'decode_latency_per_token_s':s.get('decode_latency_per_token_s'),'total_latency_s':s.get('total_latency_s'),'tokens_per_second_total':s.get('tokens_per_second_total'),'memory_per_gpu_bytes':s.get('memory_per_gpu_bytes'),'memory_ok':s.get('memory_ok'),'predicted_bottleneck':b[0]['type'] if b else None}

def self_configs(out):
    c=Path(out)/'configs'; c.mkdir(parents=True,exist_ok=True)
    data={'model':{'name':'selftest','hidden_size':1024,'num_hidden_layers':8,'num_attention_heads':16,'num_key_value_heads':4,'intermediate_size':2816,'vocab_size':32000},'workload':{'batch_size':1,'prompt_len':512,'generated_tokens':64,'concurrent_requests':4,'precision':'fp16'},'system':{'name':'self','num_nodes':1,'gpus_per_node':2,'peak_tflops':{'fp16':100,'fp32':10},'memory_bandwidth_gbps_per_gpu':1200,'memory_capacity_gb_per_gpu':24,'network':{'effective_bandwidth_gbps':100,'latency_us':8},'parallelism':{'tensor_parallel':2,'pipeline_parallel':1,'data_parallel':1}},'calibration':{'name':'selfcal','dtype_efficiency':{'fp16':0.75},'shape_efficiency':{'decode_m1':0.18,'small_m':0.32,'medium_m':0.55,'large_m':0.70},'memory_efficiency':0.75,'kv_cache_bandwidth_factor':0.50}}
    paths={}
    for k,v in data.items():
        p=c/(k+'.json'); write_json(p,v); paths[k]=str(p)
    print(json.dumps(paths))

def unit():
    L,KV,D,b=80,8,128,2; kv=L*KV*D*2*b
    rows=[{'name':'kv_bytes_per_token','status':'PASS' if kv==327680 else 'FAIL','value':kv},{'name':'hit_ratio_monotonic','status':'PASS' if 0.75*4096*kv > 0.25*4096*kv else 'FAIL'}]
    hbm=192e9; dense=35e9; reserve=8e9; moe=96e9
    rows.append({'name':'hbf_expert_headroom_gain','status':'PASS' if (hbm-dense-reserve)-(hbm-dense-reserve-moe)==moe else 'FAIL'})
    print(json.dumps(rows,indent=2));
    if any(x['status']!='PASS' for x in rows): sys.exit(1)

def synth_measured(pred,out,noise=0.05):
    random.seed(13); Path(out).unlink(missing_ok=True)
    for line in Path(pred).read_text().splitlines():
        if not line.strip(): continue
        row=json.loads(line); sid=row['scenario_id']; sm=summary(row['report'])
        for m in ['prefill_latency_s','decode_latency_per_token_s','total_latency_s','tokens_per_second_total','memory_per_gpu_bytes']:
            val=sm.get(m)
            if val is not None: append_jsonl(out,{'scenario_id':sid,'metric':m,'measured':float(val)*(1+random.uniform(-noise,noise)),'measured_bottleneck':sm.get('predicted_bottleneck')})

def read_meas(p):
    p=Path(p)
    if p.suffix.lower()=='.csv': return list(csv.DictReader(p.open()))
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]

def validate(pred,measured,outdir,tol):
    pmap={}
    for line in Path(pred).read_text().splitlines():
        if line.strip():
            r=json.loads(line); pmap[r['scenario_id']]=summary(r['report'])
    details=[]; errs={}; passed=failed=0
    for m in read_meas(measured):
        sid=str(m['scenario_id']); metric=str(m['metric']); meas=float(m['measured']); predv=pmap.get(sid,{}).get(metric)
        if predv is None:
            err=None; status='FAIL'; failed+=1
        else:
            err=abs(float(predv)-meas)/max(abs(meas),1e-12); status='PASS' if err<=tol else 'FAIL'; passed += status=='PASS'; failed += status=='FAIL'; errs.setdefault(metric,[]).append(err)
        details.append({'scenario_id':sid,'metric':metric,'predicted':predv,'measured':meas,'relative_error':err,'status':status})
    od=Path(outdir); od.mkdir(parents=True,exist_ok=True)
    summ={'passed':passed,'failed':failed,'pass_rate':passed/max(passed+failed,1),'metric_error_summary':{k:{'count':len(v),'median':statistics.median(v),'mean':statistics.mean(v),'max':max(v)} for k,v in errs.items()}}
    write_json(od/'validation_report.json',{'summary':summ,'detail':details})
    with (od/'validation_detail.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['scenario_id','metric','predicted','measured','relative_error','status']); w.writeheader(); w.writerows(details)
    md=['# Validation Report','',f'- Passed: {passed}',f'- Failed: {failed}',f'- Pass rate: {summ["pass_rate"]:.1%}','','## Error summary']
    for k,v in summ['metric_error_summary'].items(): md.append(f'- `{k}` median={v["median"]:.3f}, mean={v["mean"]:.3f}, max={v["max"]:.3f}')
    (od/'validation_report.md').write_text('\n'.join(md)+'\n')
    print(json.dumps(summ,indent=2)); return failed

def synthetic_cal(raw,cal):
    Path(raw).parent.mkdir(parents=True,exist_ok=True)
    Path(raw).write_text('\n'.join([json.dumps({'type':'metadata','cuda':False,'platform':'synthetic'}),json.dumps({'type':'gemm','dtype':'fp16','M':1,'K':1024,'N':1024,'effective_tflops_p50':180}),json.dumps({'type':'gemm','dtype':'fp16','M':2048,'K':1024,'N':1024,'effective_tflops_p50':700}),json.dumps({'type':'memory','dtype':'fp16','pattern':'copy','bandwidth_gbps_p50':700}),json.dumps({'type':'memory','dtype':'fp16','pattern':'strided','bandwidth_gbps_p50':330})])+'\n')
    write_json(cal,{'name':'synthetic_calibration','source_machine':'synthetic','dtype_efficiency':{'fp16':0.9},'shape_efficiency':{'decode_m1':0.18,'small_m':0.32,'medium_m':0.52,'large_m':0.70},'memory_efficiency':0.8,'kv_cache_bandwidth_factor':0.47,'launch_overhead_us':8,'communication':{'all_reduce':{'alpha_us':8,'beta_ns_per_byte':0.002}},'notes':['synthetic fallback']})

if __name__=='__main__':
    cmd=sys.argv[1]
    if cmd=='unit': unit()
    elif cmd=='self-configs': self_configs(sys.argv[2])
    elif cmd=='simulate':
        _,_,project,model,work,system,cal,pred,sid=sys.argv
        r=sim(project,model,work,system,cal); Path(pred).unlink(missing_ok=True); append_jsonl(pred,{'scenario_id':sid,'report':r})
    elif cmd=='simulate-append':
        _,_,project,model,work,system,cal,pred,sid=sys.argv
        r=sim(project,model,work,system,cal); append_jsonl(pred,{'scenario_id':sid,'report':r})
    elif cmd=='synth-measured': synth_measured(sys.argv[2],sys.argv[3],float(sys.argv[4]))
    elif cmd=='validate': sys.exit(validate(sys.argv[2],sys.argv[3],sys.argv[4],float(sys.argv[5])))
    elif cmd=='synthetic-cal': synthetic_cal(sys.argv[2],sys.argv[3])
    else: raise SystemExit('unknown cmd '+cmd)
PYTOOLS
}

ensure(){ command -v "$PYTHON_BIN" >/dev/null 2>&1 || die "python not found: $PYTHON_BIN"; }
install_req(){ [[ "$SKIP_INSTALL" -eq 1 ]] && return; [[ -f "$PROJECT_ROOT/requirements.txt" ]] && "$PYTHON_BIN" -m pip install -q -r "$PROJECT_ROOT/requirements.txt" || true; }

cmd_selftest(){
  ensure
  mkdir -p "$OUTDIR"
  log "running standalone self-test"
  "$PYTHON_BIN" - "$OUTDIR" <<'PYSELF'
import json, sys, random
from pathlib import Path
out=Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
# Unit sanity checks
L, KV, D, b = 80, 8, 128, 2
kv_bpt = L * KV * D * 2 * b
unit = [
  {"name":"kv_bytes_per_token", "status":"PASS" if kv_bpt == 327680 else "FAIL", "value":kv_bpt},
  {"name":"hit_ratio_monotonic", "status":"PASS" if 0.75*4096*kv_bpt > 0.25*4096*kv_bpt else "FAIL"},
  {"name":"hbf_expert_headroom_gain", "status":"PASS" if (192e9-35e9-8e9)-(192e9-35e9-8e9-96e9)==96e9 else "FAIL"}
]
(out/'unit_sanity.json').write_text(json.dumps(unit, indent=2))
if any(x['status']!='PASS' for x in unit):
    raise SystemExit('unit sanity failed')
# Minimal prediction and measured trace
pred = {
  "scenario_id":"selftest_default",
  "report":{
    "summary":{
      "prefill_latency_s":0.12,
      "decode_latency_per_token_s":0.0015,
      "total_latency_s":0.216,
      "tokens_per_second_total":1185.18,
      "memory_per_gpu_bytes":2.5e9,
      "memory_ok":True
    },
    "bottleneck_rank":[{"type":"compute","time_s":0.216,"fraction":1.0}]
  }
}
(out/'selftest_predictions.jsonl').write_text(json.dumps(pred)+'\n')
random.seed(13)
metrics=['prefill_latency_s','decode_latency_per_token_s','total_latency_s','tokens_per_second_total','memory_per_gpu_bytes']
meas=[]
for m in metrics:
    val=pred['report']['summary'][m]*(1+random.uniform(-0.05,0.05))
    meas.append({"scenario_id":"selftest_default","metric":m,"measured":val,"measured_bottleneck":"compute"})
(out/'selftest_measured.jsonl').write_text('\n'.join(json.dumps(x) for x in meas)+'\n')
passed=failed=0; detail=[]
for m in meas:
    pval=pred['report']['summary'][m['metric']]
    err=abs(pval-m['measured'])/max(abs(m['measured']),1e-12)
    status='PASS' if err <= 0.30 else 'FAIL'
    passed += status=='PASS'; failed += status=='FAIL'
    detail.append({"metric":m['metric'],"relative_error":err,"status":status})
report={"summary":{"passed":passed,"failed":failed,"pass_rate":passed/max(passed+failed,1)},"detail":detail}
(out/'validation_report.json').write_text(json.dumps(report, indent=2))
(out/'validation_report.md').write_text(f"# Self-test Validation Report\n\n- Passed: {passed}\n- Failed: {failed}\n- Pass rate: {passed/max(passed+failed,1):.1%}\n")
(out/'selftest_summary.json').write_text(json.dumps(report['summary'], indent=2))
print(json.dumps(report['summary'], indent=2))
if failed:
    raise SystemExit(1)
PYSELF
  log "SELF_TEST_PASS outputs=$OUTDIR"
}

cmd_measure(){
  ensure; install_req; write_tools
  RAW_OUT="${RAW_OUT:-$OUTDIR/dgx_spark_raw.jsonl}"; CALIBRATION_OUT="${CALIBRATION_OUT:-$OUTDIR/calibration_dgx_spark_measured.json}"
  if [[ "$SYNTHETIC" -eq 1 || ! -f "$PROJECT_ROOT/benchmarks/run_calibration.py" || ! -f "$PROJECT_ROOT/benchmarks/build_calibration.py" ]]; then
    log "using synthetic calibration fallback"
    "$PYTHON_BIN" "$TOOLS/vtools.py" synthetic-cal "$RAW_OUT" "$CALIBRATION_OUT"
    return
  fi
  bench="$BENCH_CONFIG"
  if [[ "$QUICK" -eq 1 ]]; then
    bench="$OUTDIR/quick_calibration_plan.yaml"
    cat > "$bench" <<'YAML'
warmup: 2
repeat: 5
dtypes: [fp16]
gemm:
  M: [1, 16, 256]
  K: [1024]
  N: [1024, 4096]
memory:
  size_mb: [16, 64]
  patterns: [copy, read, strided]
YAML
  fi
  log "run benchmark $bench"
  (cd "$PROJECT_ROOT" && "$PYTHON_BIN" benchmarks/run_calibration.py --bench-config "$bench" --out "$RAW_OUT")
  log "build calibration $CALIBRATION_OUT"
  (cd "$PROJECT_ROOT" && "$PYTHON_BIN" benchmarks/build_calibration.py --raw "$RAW_OUT" --out "$CALIBRATION_OUT")
}

cmd_simulate(){
  ensure; install_req; write_tools; PRED_FILE="${PRED_FILE:-$OUTDIR/predictions.jsonl}"; rm -f "$PRED_FILE"
  if [[ -n "$SCENARIO_FILE" ]]; then
    "$PYTHON_BIN" - "$TOOLS/vtools.py" "$PROJECT_ROOT" "$SCENARIO_FILE" "$PRED_FILE" <<'PYSIM'
import json, subprocess, sys
from pathlib import Path
tool,project,scfile,pred=sys.argv[1:]
for sc in json.loads(Path(scfile).read_text()):
    subprocess.check_call([sys.executable,tool,'simulate-append',project,sc['model'],sc['workload'],sc['system'],sc['calibration'],pred,sc.get('scenario_id','scenario')])
PYSIM
  else
    "$PYTHON_BIN" "$TOOLS/vtools.py" simulate "$PROJECT_ROOT" "$MODEL_CONFIG" "$WORKLOAD_CONFIG" "$SYSTEM_CONFIG" "$CALIBRATION_CONFIG" "$PRED_FILE" single_default
  fi
  log "predictions written $PRED_FILE"
}

cmd_validate(){
  ensure; write_tools; [[ -n "$PRED_FILE" ]] || die '--pred required'; [[ -n "$MEASURED_FILE" ]] || die '--measured required'
  "$PYTHON_BIN" "$TOOLS/vtools.py" validate "$PRED_FILE" "$MEASURED_FILE" "$OUTDIR" "$TOL" > "$OUTDIR/validation_summary.json"
  cat "$OUTDIR/validation_summary.json"
  log "validation report $OUTDIR/validation_report.md"
}

cmd_full(){
  cmd_measure
  CALIBRATION_CONFIG="${CALIBRATION_OUT:-$OUTDIR/calibration_dgx_spark_measured.json}"
  cmd_simulate
  MEASURED_FILE="$OUTDIR/synthetic_measured.jsonl"
  "$PYTHON_BIN" "$TOOLS/vtools.py" synth-measured "${PRED_FILE:-$OUTDIR/predictions.jsonl}" "$MEASURED_FILE" 0.08
  cmd_validate
}

case "$MODE" in
  selftest) cmd_selftest;;
  measure) cmd_measure;;
  simulate) cmd_simulate;;
  validate) cmd_validate;;
  full) cmd_full;;
  help|--help|-h) usage;;
  *) usage; die "unknown mode $MODE";;
esac
