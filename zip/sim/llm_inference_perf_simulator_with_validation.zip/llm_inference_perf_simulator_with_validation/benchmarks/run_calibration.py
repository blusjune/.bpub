from __future__ import annotations

import argparse
import json
import math
import os
import platform
import random
import statistics
import time
from pathlib import Path
import yaml


def now_meta():
    return {
        "time": time.time(),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "machine": platform.machine(),
    }


def has_torch_cuda():
    try:
        import torch
        return torch.cuda.is_available()
    except Exception:
        return False


def run_torch_gemm(dtype_name: str, M: int, K: int, N: int, warmup: int, repeat: int):
    import torch
    dtype_map = {
        "fp16": torch.float16,
        "bf16": torch.bfloat16,
        "fp32": torch.float32,
    }
    dtype = dtype_map.get(dtype_name, torch.float16)
    device = "cuda"

    a = torch.randn((M, K), device=device, dtype=dtype)
    b = torch.randn((K, N), device=device, dtype=dtype)
    for _ in range(warmup):
        _ = a @ b
    torch.cuda.synchronize()

    times = []
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)

    for _ in range(repeat):
        start.record()
        _ = a @ b
        end.record()
        torch.cuda.synchronize()
        times.append(start.elapsed_time(end) / 1000.0)

    flops = 2 * M * K * N
    return {
        "latency_s_p50": statistics.median(times),
        "latency_s_mean": statistics.mean(times),
        "latency_s_p90": sorted(times)[int(0.9 * (len(times)-1))],
        "effective_tflops_p50": flops / statistics.median(times) / 1e12,
        "effective_tflops_mean": flops / statistics.mean(times) / 1e12,
        "samples": len(times),
    }


def run_torch_memory(dtype_name: str, size_mb: int, warmup: int, repeat: int, pattern: str):
    import torch
    dtype_map = {"fp16": torch.float16, "bf16": torch.bfloat16, "fp32": torch.float32, "int8": torch.int8}
    dtype = dtype_map.get(dtype_name, torch.float16)
    device = "cuda"
    elem_size = torch.empty([], dtype=dtype).element_size()
    n = max(1, size_mb * 1024 * 1024 // elem_size)
    x = torch.randn((n,), device=device, dtype=dtype) if dtype != torch.int8 else torch.randint(-128, 127, (n,), device=device, dtype=dtype)
    y = torch.empty_like(x)

    if pattern == "copy":
        fn = lambda: y.copy_(x)
        bytes_moved = n * elem_size * 2
    elif pattern == "strided":
        stride = 16
        fn = lambda: x[::stride].contiguous()
        bytes_moved = (n // stride) * elem_size
    else:
        fn = lambda: x.sum()
        bytes_moved = n * elem_size

    for _ in range(warmup):
        _ = fn()
    torch.cuda.synchronize()

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    times = []
    for _ in range(repeat):
        start.record()
        _ = fn()
        end.record()
        torch.cuda.synchronize()
        times.append(start.elapsed_time(end) / 1000.0)

    med = statistics.median(times)
    return {
        "latency_s_p50": med,
        "latency_s_mean": statistics.mean(times),
        "bandwidth_gbps_p50": bytes_moved / med / 1e9,
        "bytes_moved": bytes_moved,
        "samples": len(times),
    }


def synthetic_gemm(dtype: str, M: int, K: int, N: int):
    # Functional fallback for machines without CUDA. Not a real benchmark.
    shape_eff = 0.25 if M <= 1 else 0.35 if M <= 16 else 0.50 if M <= 128 else 0.62
    dtype_peak = {"fp16": 900.0, "bf16": 850.0, "fp32": 45.0}.get(dtype, 700.0)
    eff = dtype_peak * shape_eff * random.uniform(0.92, 1.08)
    flops = 2 * M * K * N
    return {
        "latency_s_p50": flops / (eff * 1e12),
        "latency_s_mean": flops / (eff * 1e12),
        "latency_s_p90": flops / (eff * 1e12) * 1.1,
        "effective_tflops_p50": eff,
        "effective_tflops_mean": eff,
        "samples": 1,
        "synthetic": True,
    }


def synthetic_memory(dtype: str, size_mb: int, pattern: str):
    base = 650.0
    factor = 1.0 if pattern == "copy" else 0.72 if pattern == "read" else 0.45
    bw = base * factor * random.uniform(0.9, 1.08)
    bytes_moved = size_mb * 1024 * 1024
    return {
        "latency_s_p50": bytes_moved / (bw * 1e9),
        "latency_s_mean": bytes_moved / (bw * 1e9),
        "bandwidth_gbps_p50": bw,
        "bytes_moved": bytes_moved,
        "samples": 1,
        "synthetic": True,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bench-config", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.bench_config).read_text(encoding="utf-8"))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    cuda = has_torch_cuda()
    warmup = int(cfg.get("warmup", 10))
    repeat = int(cfg.get("repeat", 30))

    with out.open("w", encoding="utf-8") as f:
        meta = {"type": "metadata", "cuda": cuda, **now_meta()}
        f.write(json.dumps(meta) + "\n")

        for dtype in cfg.get("dtypes", ["fp16"]):
            for M in cfg["gemm"]["M"]:
                for K in cfg["gemm"]["K"]:
                    for N in cfg["gemm"]["N"]:
                        try:
                            result = run_torch_gemm(dtype, int(M), int(K), int(N), warmup, repeat) if cuda and dtype in ("fp16", "bf16", "fp32") else synthetic_gemm(dtype, int(M), int(K), int(N))
                        except Exception as e:
                            result = {"error": str(e), **synthetic_gemm(dtype, int(M), int(K), int(N))}
                        row = {"type": "gemm", "dtype": dtype, "M": int(M), "K": int(K), "N": int(N), **result}
                        f.write(json.dumps(row) + "\n")
                        print(row)

            for size_mb in cfg["memory"]["size_mb"]:
                for pattern in cfg["memory"].get("patterns", ["copy", "read", "strided"]):
                    try:
                        result = run_torch_memory(dtype, int(size_mb), warmup, repeat, pattern) if cuda and dtype in ("fp16", "bf16", "fp32", "int8") else synthetic_memory(dtype, int(size_mb), pattern)
                    except Exception as e:
                        result = {"error": str(e), **synthetic_memory(dtype, int(size_mb), pattern)}
                    row = {"type": "memory", "dtype": dtype, "size_mb": int(size_mb), "pattern": pattern, **result}
                    f.write(json.dumps(row) + "\n")
                    print(row)

    print(f"wrote {out}")

if __name__ == "__main__":
    main()
