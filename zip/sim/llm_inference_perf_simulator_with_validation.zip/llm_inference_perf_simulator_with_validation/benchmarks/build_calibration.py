from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path

import yaml


def classify_m(M):
    M = int(M)
    if M <= 1:
        return "decode_m1"
    if M <= 16:
        return "small_m"
    if M <= 128:
        return "medium_m"
    return "large_m"


def median(xs, default):
    xs = [x for x in xs if x is not None]
    return statistics.median(xs) if xs else default


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rows = []
    for line in Path(args.raw).read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))

    gemm = [r for r in rows if r.get("type") == "gemm" and "effective_tflops_p50" in r]
    mem = [r for r in rows if r.get("type") == "memory" and "bandwidth_gbps_p50" in r]

    # Estimate relative efficiency by M-shape class and dtype.
    # Since target system peak is user-provided separately, store normalized class factors.
    dtype_tflops = defaultdict(list)
    class_tflops = defaultdict(list)
    for r in gemm:
        dtype_tflops[r["dtype"]].append(float(r["effective_tflops_p50"]))
        class_tflops[classify_m(r["M"])].append(float(r["effective_tflops_p50"]))

    # Normalize to best observed for relative shape efficiency.
    best = max([float(r["effective_tflops_p50"]) for r in gemm], default=1.0)
    dtype_eff = {k: max(0.05, min(0.95, median(v, best) / best)) for k, v in dtype_tflops.items()}
    shape_eff = {k: max(0.03, min(0.95, median(v, best) / best)) for k, v in class_tflops.items()}

    copy_bw = [float(r["bandwidth_gbps_p50"]) for r in mem if r.get("pattern") == "copy"]
    read_bw = [float(r["bandwidth_gbps_p50"]) for r in mem if r.get("pattern") == "read"]
    strided_bw = [float(r["bandwidth_gbps_p50"]) for r in mem if r.get("pattern") == "strided"]

    best_bw = max([float(r["bandwidth_gbps_p50"]) for r in mem], default=1.0)
    mem_eff = max(0.1, min(0.95, median(copy_bw or read_bw, best_bw) / best_bw))
    kv_factor = max(0.1, min(0.95, median(strided_bw or read_bw, best_bw * 0.5) / max(median(copy_bw, best_bw), 1e-9)))

    metadata = next((r for r in rows if r.get("type") == "metadata"), {})

    cal = {
        "name": "dgx_spark_measured_calibration",
        "source_machine": metadata.get("platform", "unknown"),
        "dtype_efficiency": dtype_eff or {"fp16": 0.55},
        "shape_efficiency": {
            "decode_m1": shape_eff.get("decode_m1", 0.20),
            "small_m": shape_eff.get("small_m", 0.35),
            "medium_m": shape_eff.get("medium_m", 0.50),
            "large_m": shape_eff.get("large_m", 0.65),
        },
        "memory_efficiency": mem_eff,
        "kv_cache_bandwidth_factor": kv_factor,
        "launch_overhead_us": 8.0,
        "attention_efficiency": 0.55,
        "communication": {
            "all_reduce": {"alpha_us": 8.0, "beta_ns_per_byte": 0.002},
            "all_gather": {"alpha_us": 8.0, "beta_ns_per_byte": 0.002},
        },
        "notes": [
            "Generated from local microbenchmarks.",
            "Shape efficiency is normalized to the best observed GEMM throughput on the calibration machine.",
            "Use target system peak_tflops and memory bandwidth to extrapolate production performance.",
        ],
        "raw_summary": {
            "gemm_rows": len(gemm),
            "memory_rows": len(mem),
            "best_observed_tflops": best,
            "best_observed_bandwidth_gbps": best_bw,
        },
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(cal, indent=2), encoding="utf-8")
    print(json.dumps(cal, indent=2))
    print(f"wrote {out}")

if __name__ == "__main__":
    main()
