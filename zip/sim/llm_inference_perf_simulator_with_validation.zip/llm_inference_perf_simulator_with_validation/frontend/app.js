"use strict";

let report = null;
const $ = id => document.getElementById(id);

function esc(s) {
  return String(s ?? "").replace(/[&<>'"]/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;" }[c]));
}

async function loadExample(name) {
  const res = await fetch(`/api/example/${name}`);
  const data = await res.json();
  const text = JSON.stringify(data, null, 2);
  if (name === "model") $("modelBox").value = text;
  if (name === "workload") $("workloadBox").value = text;
  if (name === "system") $("systemBox").value = text;
  if (name === "calibration") $("calibrationBox").value = text;
}

async function simulate() {
  const payload = {
    model: JSON.parse($("modelBox").value),
    workload: JSON.parse($("workloadBox").value),
    system: JSON.parse($("systemBox").value),
    calibration: JSON.parse($("calibrationBox").value || "{}")
  };
  const res = await fetch("/api/simulate", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(await res.text());
  report = await res.json();
  render();
}

function render() {
  const s = report.summary;
  const f = s.formatted;
  const cards = [
    ["Prefill", f.prefill_latency],
    ["Decode / token", f.decode_latency_per_token],
    ["Total latency", f.total_latency],
    ["Throughput", f.tokens_per_second_total],
    ["Memory / GPU", f.memory_per_gpu],
    ["Memory capacity", f.memory_capacity_per_gpu],
    ["Memory OK", s.memory_ok ? "YES" : "NO"],
    ["Meets target", s.meets_target_latency === null ? "N/A" : (s.meets_target_latency ? "YES" : "NO")]
  ];
  $("summaryCards").innerHTML = cards.map(([k,v]) => `<div class="metric"><div class="metric-label">${esc(k)}</div><div class="metric-value">${esc(v)}</div></div>`).join("");

  renderFractionBar("bottleneckChart", report.bottleneck_rank.map(x => ({name:x.type, value:x.time_s, label:`${(x.fraction*100).toFixed(1)}%`})));
  renderTimeBar("prefillChart", report.prefill_components);
  renderTimeBar("decodeChart", report.decode_components_per_token);
  renderFractionBar("memoryChart", [
    {name:"weights", value: report.memory_breakdown.weight_bytes_per_gpu, label: report.memory_breakdown.formatted.weights},
    {name:"kv_cache", value: report.memory_breakdown.kv_cache_bytes_per_gpu, label: report.memory_breakdown.formatted.kv_cache},
    {name:"activations", value: report.memory_breakdown.activation_bytes_per_gpu, label: report.memory_breakdown.formatted.activations},
  ]);

  renderTable("componentTable", ["Component", "Total", "Bottleneck", "Compute", "Memory", "Comm", "FLOPs", "Bytes"], report.top_components.map(c => [
    c.name, c.formatted.total, c.bottleneck, c.formatted.compute, c.formatted.memory, c.formatted.communication, c.formatted.flops, c.formatted.bytes
  ]));

  $("parallelismBox").textContent = JSON.stringify(report.parallelism, null, 2);
  $("jsonBox").textContent = JSON.stringify(report, null, 2);

  const top = report.bottleneck_rank[0];
  const memoryOk = s.memory_ok;
  $("interpretation").innerHTML = `
    <p>가장 큰 병목 유형은 <b>${esc(top?.type || "-")}</b>이며, component time 합산 기준 약 <b>${((top?.fraction || 0)*100).toFixed(1)}%</b>를 차지합니다.</p>
    <p>GPU memory는 <b class="${memoryOk ? "good" : "bad"}">${memoryOk ? "수용 가능" : "초과"}</b>으로 예측됩니다.</p>
    <ul>${report.assumptions.map(a => `<li>${esc(a)}</li>`).join("")}</ul>
  `;
}

function renderTable(id, headers, rows) {
  $(id).innerHTML = `
    <thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join("")}</tr></thead>
    <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody>`;
}

function renderTimeBar(id, rows) {
  renderFractionBar(id, rows.map(x => ({name:x.name, value:x.total_s, label:x.formatted.total})));
}

function renderFractionBar(id, rows) {
  rows = [...rows].sort((a,b) => b.value - a.value).slice(0, 12);
  const width = 780, left = 210, right = 150, h = Math.max(100, rows.length * 38 + 30);
  const max = Math.max(...rows.map(x => x.value || 0), 1e-12);
  const bars = rows.map((x,i) => {
    const y = 18 + i * 38;
    const w = (width-left-right) * ((x.value || 0) / max);
    return `<text x="8" y="${y+20}" class="bar-label">${esc(x.name)}</text>
      <rect x="${left}" y="${y}" width="${Math.max(2,w)}" height="26" rx="8" fill="url(#g)" />
      <text x="${left+w+8}" y="${y+18}" class="bar-value">${esc(x.label)}</text>`;
  }).join("");
  $(id).innerHTML = `<svg viewBox="0 0 ${width} ${h}">
    <defs><linearGradient id="g"><stop offset="0" stop-color="#8db2ff"/><stop offset="1" stop-color="#9effd0"/></linearGradient></defs>
    ${bars}
  </svg>`;
}

function setupTabs() {
  document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(x => x.classList.add("hidden"));
    btn.classList.add("active");
    $(`tab-${btn.dataset.tab}`).classList.remove("hidden");
  }));
}

function downloadReport() {
  const blob = new Blob([JSON.stringify(report, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "llm_inference_simulation_report.json"; a.click();
  URL.revokeObjectURL(url);
}

document.querySelectorAll("[data-load]").forEach(btn => btn.addEventListener("click", () => loadExample(btn.dataset.load)));
$("simulateBtn").addEventListener("click", () => simulate().catch(e => alert(e.message)));
$("downloadBtn").addEventListener("click", downloadReport);
setupTabs();
Promise.all(["model","workload","system","calibration"].map(loadExample)).then(simulate).catch(console.error);
