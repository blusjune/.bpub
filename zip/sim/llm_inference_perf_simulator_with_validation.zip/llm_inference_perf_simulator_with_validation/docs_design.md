# Design Notes

## Calibration logic

DGX Spark에서 얻는 측정값은 target production GPU의 절대 성능값으로 직접 사용하지 않습니다.
대신 shape별 efficiency를 추정합니다.

```text
target_effective_TFLOPS(shape, dtype)
= target_peak_TFLOPS(dtype)
  × calibration.dtype_efficiency[dtype]
  × calibration.shape_efficiency[shape_class]
  × system.runtime_efficiency_overrides[shape_class]
```

이 접근은 calibration machine과 target system의 peak 성능이 다르더라도
작은-M decode GEMM과 큰-M prefill GEMM의 효율 차이를 보존하기 위한 것입니다.

## Component model

각 component는 아래 식으로 시간 예측합니다.

```text
component_time
= max(compute_time, memory_time)
  + communication_time
  + launch_overhead
```

```text
compute_time = FLOPs / effective_TFLOPS
memory_time = bytes / effective_memory_bandwidth
```

## Bottleneck classification

- `compute`: compute_time >= memory_time and communication is not dominant
- `memory`: memory_time > compute_time for general memory traffic
- `kv_cache`: memory_time > compute_time for KV-cache traffic
- `communication`: communication_time dominates base component time

## Scale-up/scale-out model

Tensor parallelism:
- per-GPU GEMM output dimension is divided by TP
- post-projection all-reduce/all-gather approximated with alpha-beta model

Pipeline parallelism:
- layers are split by PP
- request latency includes all stages
- simple bubble overhead term is added

Data parallelism:
- throughput scales by DP if enough independent requests exist

## Known limitations

- No exact CUDA kernel modeling
- No exact vLLM/TensorRT-LLM scheduler model
- No exact paged-attention block table overhead
- MoE active expert routing not fully modeled
- Production network topology is approximated by alpha-beta communication model
