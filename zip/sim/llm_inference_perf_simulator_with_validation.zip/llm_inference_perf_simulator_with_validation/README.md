# LLM Inference Performance Simulator

DGX Spark 같은 제한된 local machine에서 LLM inference primitive 성능계수를 실측하고,
그 결과를 calibration config로 저장한 뒤, 가상의 production scale GPU system에서
open-source LLM inference를 수행할 때의 예상 inference speed와 병목 지점을 정량 예측하는 simulator입니다.

## What this project does

```mermaid
flowchart TD
    A[DGX Spark Microbenchmarks] --> B[Calibration JSON]
    B --> C[Performance Simulator]
    D[Open-source LLM Config] --> C
    E[Target System Profile] --> C
    F[Inference Workload] --> C
    C --> G[Predicted Latency / Throughput]
    C --> H[Bottleneck Breakdown]
    C --> I[Scale-up / Scale-out Efficiency]
```

## Key capabilities

1. **Measure on DGX Spark**
   - GEMM effective TFLOPS by `(M,K,N,dtype)`
   - memory bandwidth by tensor size/access pattern
   - KV-cache read/write bandwidth
   - optional PyTorch SDPA attention benchmark
   - stores results as JSONL
   - builds calibration JSON

2. **Build calibrated performance coefficients**
   - shape-class efficiency
   - dtype-specific compute efficiency
   - memory bandwidth curve
   - KV-cache bandwidth curve
   - launch overhead estimate
   - optional communication alpha/beta coefficients

3. **Simulate production LLM inference**
   - dense decoder-only Transformer
   - GQA/MQA
   - sliding-window attention
   - prefill latency
   - decode latency/token
   - total end-to-end latency
   - tokens/sec
   - GPU memory use
   - bottleneck classification:
     - compute-bound
     - memory-bound
     - KV-cache-bound
     - communication-bound
     - storage/offload-bound

4. **Inputs**
   - model config
   - workload config
   - target hardware profile
   - parallelism profile
   - calibration profile measured on DGX Spark

## Quick start

```bash
cd llm_inference_perf_simulator
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 1. Run microbenchmark on DGX Spark

```bash
python benchmarks/run_calibration.py \
  --bench-config configs/dgx_spark_calibration_plan.yaml \
  --out results/dgx_spark_raw.jsonl
```

If no CUDA GPU or PyTorch CUDA is available, the script writes a small synthetic fallback profile for functional testing.

### 2. Build calibration config

```bash
python benchmarks/build_calibration.py \
  --raw results/dgx_spark_raw.jsonl \
  --out configs/calibration_dgx_spark_measured.json
```

### 3. Run simulation CLI

```bash
python -m backend.analyzer.simulate_cli \
  --model configs/model_mistral_7b.yaml \
  --workload configs/workload_interactive.yaml \
  --system configs/system_target_h100x8.yaml \
  --calibration configs/calibration_dgx_spark_measured.json \
  --out results/simulation_report.json
```

### 4. Run Web UI

```bash
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Then open:

```text
http://127.0.0.1:8000
```

## Simulator model

For each inference component, the simulator estimates both compute time and memory time.

```text
component_time = max(
  FLOPs / effective_compute_throughput,
  bytes / effective_memory_bandwidth
) + launch_overhead + communication_time
```

Total inference:

```text
T_total = T_prefill + generated_tokens × T_decode_per_token
```

Throughput:

```text
tokens_per_second ≈ batch_size × generated_tokens / T_total
```

## Important notes

This is an analytical simulator, not an exact profiler.

It is useful for:
- comparing target hardware profiles
- identifying likely bottlenecks
- estimating scale-up/scale-out efficiency
- deciding whether inference is compute, memory, KV-cache, or communication bound

It is not a substitute for:
- TensorRT-LLM benchmark
- vLLM benchmark
- Nsight Systems / Nsight Compute
- production load test
