from __future__ import annotations

from typing import Any
from pydantic import BaseModel, Field


class ModelConfig(BaseModel):
    name: str = "unknown"
    architecture: str = "dense_decoder_only_transformer"
    hidden_size: int
    num_hidden_layers: int
    num_attention_heads: int
    num_key_value_heads: int | None = None
    intermediate_size: int
    vocab_size: int
    max_position_embeddings: int | None = None
    sliding_window: int | None = None
    tied_embeddings: bool = False
    moe: dict[str, Any] | None = None


class WorkloadConfig(BaseModel):
    batch_size: int = Field(1, ge=1)
    prompt_len: int = Field(2048, ge=1)
    generated_tokens: int = Field(256, ge=1)
    concurrent_requests: int = Field(1, ge=1)
    precision: str = "fp16"
    kv_cache_precision: str | None = None
    target_latency_s: float | None = None


class ParallelismConfig(BaseModel):
    tensor_parallel: int = 1
    pipeline_parallel: int = 1
    data_parallel: int = 1
    expert_parallel: int = 1


class SystemConfig(BaseModel):
    name: str
    num_nodes: int = 1
    gpus_per_node: int = 1
    peak_tflops: dict[str, float] = Field(default_factory=dict)
    memory_bandwidth_gbps_per_gpu: float
    memory_capacity_gb_per_gpu: float
    storage_bandwidth_gbps_per_node: float = 0.0
    network: dict[str, Any] = Field(default_factory=dict)
    parallelism: ParallelismConfig = Field(default_factory=ParallelismConfig)
    runtime_efficiency_overrides: dict[str, float] = Field(default_factory=dict)


class CalibrationProfile(BaseModel):
    name: str = "uncalibrated"
    source_machine: str = "unknown"
    dtype_efficiency: dict[str, float] = Field(default_factory=dict)
    shape_efficiency: dict[str, float] = Field(default_factory=dict)
    memory_efficiency: float = 0.75
    kv_cache_bandwidth_factor: float = 0.55
    launch_overhead_us: float = 8.0
    attention_efficiency: float = 0.55
    communication: dict[str, Any] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list)
