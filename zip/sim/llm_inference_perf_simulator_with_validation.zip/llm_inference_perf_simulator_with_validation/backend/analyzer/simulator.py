from __future__ import annotations

from collections import defaultdict
from typing import Any

from .schemas import ModelConfig, WorkloadConfig, SystemConfig, CalibrationProfile
from .perf_components import component_time, dtype_bytes, format_bytes, format_seconds


def simulate_from_dicts(
    model: dict[str, Any],
    workload: dict[str, Any],
    system: dict[str, Any],
    calibration: dict[str, Any] | None = None,
) -> dict[str, Any]:
    m = ModelConfig(**model).model_dump()
    w = WorkloadConfig(**workload).model_dump()
    s = SystemConfig(**system).model_dump()
    c = CalibrationProfile(**(calibration or {})).model_dump()
    return simulate(m, w, s, c)


def simulate(model: dict[str, Any], workload: dict[str, Any], system: dict[str, Any], calibration: dict[str, Any]) -> dict[str, Any]:
    B = int(workload["batch_size"]) * int(workload.get("concurrent_requests", 1))
    S = int(workload["prompt_len"])
    T = int(workload["generated_tokens"])
    dtype = workload["precision"].lower()
    kv_dtype = (workload.get("kv_cache_precision") or dtype).lower()
    bytes_w = dtype_bytes(dtype)
    bytes_kv = dtype_bytes(kv_dtype)

    H = int(model["hidden_size"])
    L = int(model["num_hidden_layers"])
    A = int(model["num_attention_heads"])
    KV = int(model.get("num_key_value_heads") or A)
    I = int(model["intermediate_size"])
    V = int(model["vocab_size"])
    D = H / A
    sliding = model.get("sliding_window")
    S_eff = min(S, int(sliding)) if sliding else S

    par = system["parallelism"]
    TP = max(1, int(par.get("tensor_parallel", 1)))
    PP = max(1, int(par.get("pipeline_parallel", 1)))
    DP = max(1, int(par.get("data_parallel", 1)))
    total_gpus = int(system["num_nodes"]) * int(system["gpus_per_node"])
    active_gpus = TP * PP * DP

    layers_per_stage = L / PP

    prefill_components = []
    decode_components = []

    # GEMM conventions:
    # Q: [B*S,H] x [H,H/TP] per GPU, then collectively gathered/reduced depending implementation.
    # Approximate per-GPU FLOPs by dividing output dimension by TP for sharded projections.
    M_prefill = B * S
    M_decode = B
    avg_ctx = min(S + T / 2, int(sliding)) if sliding else S + T / 2

    # Per-layer per-GPU estimates, then multiply by layers_per_stage.
    # Q projection
    q_flops = 2 * M_prefill * H * (H / TP)
    q_bytes = M_prefill * H * bytes_w + H * (H / TP) * bytes_w
    prefill_components.append(component_time("prefill.q_projection", layers_per_stage * q_flops, layers_per_stage * q_bytes, dtype, M_prefill, H, H/TP, system, calibration))

    # K/V projection
    kv_out = KV * D
    k_flops = 2 * M_prefill * H * (kv_out / TP)
    v_flops = 2 * M_prefill * H * (kv_out / TP)
    kv_proj_bytes = M_prefill * H * bytes_w + 2 * H * (kv_out / TP) * bytes_w
    prefill_components.append(component_time("prefill.kv_projection", layers_per_stage * (k_flops + v_flops), layers_per_stage * kv_proj_bytes, dtype, M_prefill, H, kv_out/TP, system, calibration))

    # Attention scores/apply. Attention heads are usually sharded over TP.
    attn_flops = 4 * B * (A / TP) * S * S_eff * D
    attn_bytes = B * (A / TP) * S * S_eff * bytes_w + B * S * H / TP * bytes_w
    prefill_components.append(component_time("prefill.attention", layers_per_stage * attn_flops, layers_per_stage * attn_bytes, dtype, S, S_eff, D, system, calibration, memory_kind="general"))

    # O projection + all-reduce
    o_flops = 2 * M_prefill * (H / TP) * H
    o_bytes = M_prefill * H * bytes_w + (H / TP) * H * bytes_w
    comm_bytes = B * S * H * bytes_w
    prefill_components.append(component_time("prefill.o_projection_reduce", layers_per_stage * o_flops, layers_per_stage * o_bytes, dtype, M_prefill, H/TP, H, system, calibration, communication_bytes=layers_per_stage * comm_bytes, participants=TP))

    # MLP gate/up/down
    gate_flops = 2 * M_prefill * H * (I / TP)
    up_flops = 2 * M_prefill * H * (I / TP)
    down_flops = 2 * M_prefill * (I / TP) * H
    mlp_bytes = M_prefill * (H + I / TP) * bytes_w + (2 * H * I / TP + I * H / TP) * bytes_w
    mlp_comm = B * S * H * bytes_w
    prefill_components.append(component_time("prefill.mlp", layers_per_stage * (gate_flops + up_flops + down_flops), layers_per_stage * mlp_bytes, dtype, M_prefill, H, I/TP, system, calibration, communication_bytes=layers_per_stage * mlp_comm, participants=TP))

    # LM head. Often vocab parallel. Approximate by TP.
    lm_flops = 2 * M_prefill * H * (V / TP)
    lm_bytes = M_prefill * H * bytes_w + H * (V / TP) * bytes_w
    prefill_components.append(component_time("prefill.lm_head", lm_flops, lm_bytes, dtype, M_prefill, H, V/TP, system, calibration, communication_bytes=B*S*V*bytes_w/TP if TP > 1 else 0.0, collective="all_gather", participants=TP))

    # Decode components per generated token.
    dq_flops = 2 * M_decode * H * (H / TP)
    dk_flops = 2 * M_decode * H * (kv_out / TP)
    dv_flops = 2 * M_decode * H * (kv_out / TP)
    do_flops = 2 * M_decode * (H / TP) * H
    dmlp_flops = 2 * M_decode * H * (I / TP) + 2 * M_decode * H * (I / TP) + 2 * M_decode * (I / TP) * H
    dlm_flops = 2 * M_decode * H * (V / TP)

    decode_components.append(component_time("decode.q_projection", layers_per_stage * dq_flops, layers_per_stage * (M_decode*H + H*(H/TP))*bytes_w, dtype, M_decode, H, H/TP, system, calibration))
    decode_components.append(component_time("decode.kv_projection", layers_per_stage * (dk_flops + dv_flops), layers_per_stage * (M_decode*H + 2*H*(kv_out/TP))*bytes_w, dtype, M_decode, H, kv_out/TP, system, calibration))

    # Decode attention is KV-cache traffic heavy.
    datt_flops = 4 * B * (A / TP) * avg_ctx * D
    kv_read_bytes = B * layers_per_stage * avg_ctx * (KV / TP) * D * 2 * bytes_kv
    decode_components.append(component_time("decode.kv_attention", layers_per_stage * datt_flops, kv_read_bytes, dtype, M_decode, avg_ctx, D, system, calibration, memory_kind="kv_cache"))

    decode_components.append(component_time("decode.o_projection_reduce", layers_per_stage * do_flops, layers_per_stage * (M_decode*H + (H/TP)*H)*bytes_w, dtype, M_decode, H/TP, H, system, calibration, communication_bytes=layers_per_stage * B * H * bytes_w, participants=TP))
    decode_components.append(component_time("decode.mlp", layers_per_stage * dmlp_flops, layers_per_stage * (M_decode*(H+I/TP) + (3*H*I/TP))*bytes_w, dtype, M_decode, H, I/TP, system, calibration, communication_bytes=layers_per_stage * B * H * bytes_w, participants=TP))
    decode_components.append(component_time("decode.lm_head", dlm_flops, (M_decode*H + H*(V/TP))*bytes_w, dtype, M_decode, H, V/TP, system, calibration, communication_bytes=B*V*bytes_w/TP if TP > 1 else 0.0, collective="all_gather", participants=TP))

    # Pipeline approximation:
    # For latency, each request passes all PP stages. Stage latency = components above per stage.
    # For throughput under steady state, bottleneck stage dominates. Since we assume balanced layers_per_stage, use same values.
    prefill_stage_s = sum(x["total_s"] for x in prefill_components)
    decode_stage_token_s = sum(x["total_s"] for x in decode_components)

    pipeline_bubble_prefill_s = prefill_stage_s * (PP - 1) / max(B, 1) if PP > 1 else 0.0
    pipeline_bubble_decode_s = decode_stage_token_s * (PP - 1) / max(B, 1) if PP > 1 else 0.0

    prefill_latency_s = prefill_stage_s * PP + pipeline_bubble_prefill_s
    decode_latency_per_token_s = decode_stage_token_s * PP + pipeline_bubble_decode_s
    total_latency_s = prefill_latency_s + T * decode_latency_per_token_s

    # Memory estimate per GPU.
    # Weight sharded by TP*PP for layers. Embedding/head may be partially replicated; use approximate.
    params_embedding = V * H
    params_per_layer = H*(H/TP) + H*(kv_out/TP)*2 + (H/TP)*H + 2*H*(I/TP) + (I/TP)*H
    params_per_gpu = params_embedding / TP + layers_per_stage * params_per_layer
    weight_mem_bytes = params_per_gpu * bytes_w

    kv_cache_bytes_per_gpu = B * layers_per_stage * (S + T) * (KV / TP) * D * 2 * bytes_kv
    activation_bytes_per_gpu = B * S * H * bytes_w / TP * 6
    total_mem_bytes_per_gpu = weight_mem_bytes + kv_cache_bytes_per_gpu + activation_bytes_per_gpu
    mem_capacity_bytes = float(system["memory_capacity_gb_per_gpu"]) * 1e9
    memory_ok = total_mem_bytes_per_gpu <= mem_capacity_bytes

    # Throughput. DP replicas scale throughput if workload can feed them.
    tokens_per_s_per_replica = (B * T) / total_latency_s if total_latency_s > 0 else 0.0
    tokens_per_s_total = tokens_per_s_per_replica * DP

    # Aggregate bottlenecks.
    all_components = prefill_components + decode_components
    bottleneck_time = defaultdict(float)
    for comp in all_components:
        bottleneck_time[comp["bottleneck"]] += comp["total_s"]
    bottleneck_rank = sorted(
        [{"type": k, "time_s": v, "fraction": v / sum(bottleneck_time.values()) if sum(bottleneck_time.values()) else 0.0}
         for k, v in bottleneck_time.items()],
        key=lambda x: x["time_s"],
        reverse=True,
    )

    components_sorted = sorted(all_components, key=lambda x: x["total_s"], reverse=True)

    target_latency = workload.get("target_latency_s")
    meets_target = None if target_latency is None else total_latency_s <= float(target_latency)

    return {
        "model": model,
        "workload": workload,
        "system": system,
        "calibration": {
            "name": calibration.get("name"),
            "source_machine": calibration.get("source_machine"),
            "notes": calibration.get("notes", []),
        },
        "parallelism": {
            "tensor_parallel": TP,
            "pipeline_parallel": PP,
            "data_parallel": DP,
            "active_gpus": active_gpus,
            "available_gpus": total_gpus,
            "layers_per_pipeline_stage": layers_per_stage,
        },
        "summary": {
            "prefill_latency_s": prefill_latency_s,
            "decode_latency_per_token_s": decode_latency_per_token_s,
            "total_latency_s": total_latency_s,
            "tokens_per_second_total": tokens_per_s_total,
            "tokens_per_second_per_replica": tokens_per_s_per_replica,
            "memory_per_gpu_bytes": total_mem_bytes_per_gpu,
            "memory_capacity_per_gpu_bytes": mem_capacity_bytes,
            "memory_ok": memory_ok,
            "meets_target_latency": meets_target,
            "formatted": {
                "prefill_latency": format_seconds(prefill_latency_s),
                "decode_latency_per_token": format_seconds(decode_latency_per_token_s),
                "total_latency": format_seconds(total_latency_s),
                "memory_per_gpu": format_bytes(total_mem_bytes_per_gpu),
                "memory_capacity_per_gpu": format_bytes(mem_capacity_bytes),
                "tokens_per_second_total": f"{tokens_per_s_total:.2f} tok/s",
            },
        },
        "memory_breakdown": {
            "weight_bytes_per_gpu": weight_mem_bytes,
            "kv_cache_bytes_per_gpu": kv_cache_bytes_per_gpu,
            "activation_bytes_per_gpu": activation_bytes_per_gpu,
            "formatted": {
                "weights": format_bytes(weight_mem_bytes),
                "kv_cache": format_bytes(kv_cache_bytes_per_gpu),
                "activations": format_bytes(activation_bytes_per_gpu),
            },
        },
        "prefill_components": prefill_components,
        "decode_components_per_token": decode_components,
        "top_components": components_sorted[:12],
        "bottleneck_rank": bottleneck_rank,
        "assumptions": [
            "Dense decoder-only Transformer analytical model.",
            "Component latency uses max(compute_time, memory_time) + communication + launch overhead.",
            "Tensor parallelism and pipeline parallelism are approximated analytically.",
            "Production extrapolation quality depends strongly on calibration and target hardware profile accuracy.",
            "Runtime kernels, quantization, paged attention, scheduler behavior, and network topology can change actual results.",
        ],
    }
