from __future__ import annotations

import argparse
import json
from pathlib import Path
import yaml

from .simulator import simulate_from_dicts


def load_any(path: str):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() in (".yaml", ".yml"):
        return yaml.safe_load(text)
    return json.loads(text)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--workload", required=True)
    ap.add_argument("--system", required=True)
    ap.add_argument("--calibration", required=True)
    ap.add_argument("--out", required=False)
    args = ap.parse_args()

    report = simulate_from_dicts(
        model=load_any(args.model),
        workload=load_any(args.workload),
        system=load_any(args.system),
        calibration=load_any(args.calibration),
    )

    text = json.dumps(report, indent=2)
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        print(f"wrote {out}")
    else:
        print(text)

    s = report["summary"]["formatted"]
    print("\n=== Summary ===")
    print(f"Prefill latency: {s['prefill_latency']}")
    print(f"Decode latency/token: {s['decode_latency_per_token']}")
    print(f"Total latency: {s['total_latency']}")
    print(f"Throughput: {s['tokens_per_second_total']}")
    print(f"Memory/GPU: {s['memory_per_gpu']} / {s['memory_capacity_per_gpu']}")
    print("\nTop bottlenecks:")
    for b in report["bottleneck_rank"]:
        print(f"- {b['type']}: {b['fraction']*100:.1f}%")

if __name__ == "__main__":
    main()
