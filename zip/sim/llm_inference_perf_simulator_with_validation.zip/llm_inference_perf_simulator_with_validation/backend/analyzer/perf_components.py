from __future__ import annotations

from typing import Any


DTYPE_BYTES = {
    "fp32": 4.0,
    "tf32": 4.0,
    "fp16": 2.0,
    "bf16": 2.0,
    "fp8": 1.0,
    "int8": 1.0,
    "fp4": 0.5,
    "int4": 0.5,
}


def dtype_bytes(dtype: str) -> float:
    return DTYPE_BYTES.get(dtype.lower(), 2.0)


def classify_gemm_shape(M: float, K: float, N: float) -> str:
    if M <= 1:
        return "decode_m1"
    if M <= 16:
        return "small_m"
    if M <= 128:
        return "medium_m"
    return "large_m"


def format_seconds(x: float) -> str:
    if x >= 1:
        return f"{x:.3f} s"
    if x >= 1e-3:
        return f"{x * 1e3:.3f} ms"
    if x >= 1e-6:
        return f"{x * 1e6:.3f} us"
    return f"{x * 1e9:.3f} ns"


def format_bytes(x: float) -> str:
    for v, u in [(2**40, "TiB"), (2**30, "GiB"), (2**20, "MiB"), (2**10, "KiB")]:
        if abs(x) >= v:
            return f"{x/v:.2f} {u}"
    return f"{x:.0f} B"


def format_flops(x: float) -> str:
    for v, u in [(1e18, "EFLOPs"), (1e15, "PFLOPs"), (1e12, "TFLOPs"), (1e9, "GFLOPs"), (1e6, "MFLOPs")]:
        if abs(x) >= v:
            return f"{x/v:.2f} {u}"
    return f"{x:.0f} FLOPs"


def effective_tflops(
    dtype: str,
    M: float,
    K: float,
    N: float,
    system: dict[str, Any],
    calibration: dict[str, Any],
) -> float:
    peak = (system.get("peak_tflops") or {}).get(dtype)
    if peak is None:
        # fallback order
        peak = (system.get("peak_tflops") or {}).get("fp16") or (system.get("peak_tflops") or {}).get("bf16") or 100.0

    dtype_eff = (calibration.get("dtype_efficiency") or {}).get(dtype, 0.55)
    shape_class = classify_gemm_shape(M, K, N)
    shape_eff = (calibration.get("shape_efficiency") or {}).get(shape_class, 0.60)
    override = (system.get("runtime_efficiency_overrides") or {}).get(shape_class, 1.0)
    return float(peak) * float(dtype_eff) * float(shape_eff) * float(override)


def memory_bandwidth_gbps(system: dict[str, Any], calibration: dict[str, Any], kind: str = "general") -> float:
    base = float(system.get("memory_bandwidth_gbps_per_gpu", 1000.0))
    mem_eff = float(calibration.get("memory_efficiency", 0.75))
    if kind == "kv_cache":
        mem_eff *= float(calibration.get("kv_cache_bandwidth_factor", 0.55))
    return base * mem_eff


def communication_time_s(bytes_: float, collective: str, participants: int, system: dict[str, Any], calibration: dict[str, Any]) -> float:
    if participants <= 1 or bytes_ <= 0:
        return 0.0

    net = system.get("network") or {}
    cal_comm = calibration.get("communication") or {}

    # Use calibrated alpha/beta if available.
    # alpha_us + beta_ns_per_byte * bytes
    key = f"{collective}_{participants}"
    params = cal_comm.get(key) or cal_comm.get(collective) or {}

    if params:
        alpha = float(params.get("alpha_us", 5.0)) * 1e-6
        beta = float(params.get("beta_ns_per_byte", 0.001)) * 1e-9
        return alpha + beta * bytes_

    # Fallback ring-like model.
    bw_gbps = float(net.get("effective_bandwidth_gbps", 300.0))
    alpha_us = float(net.get("latency_us", 8.0))
    # Ring all-reduce roughly 2*(P-1)/P data movement.
    factor = 2 * (participants - 1) / participants if collective == "all_reduce" else (participants - 1) / participants
    return alpha_us * 1e-6 + factor * (bytes_ / (bw_gbps * 1e9))


def component_time(
    name: str,
    flops: float,
    bytes_: float,
    dtype: str,
    M: float,
    K: float,
    N: float,
    system: dict[str, Any],
    calibration: dict[str, Any],
    memory_kind: str = "general",
    communication_bytes: float = 0.0,
    collective: str = "all_reduce",
    participants: int = 1,
) -> dict[str, Any]:
    tflops = effective_tflops(dtype, M, K, N, system, calibration)
    compute_s = flops / (tflops * 1e12) if flops > 0 else 0.0
    bw = memory_bandwidth_gbps(system, calibration, kind=memory_kind)
    memory_s = bytes_ / (bw * 1e9) if bytes_ > 0 else 0.0
    comm_s = communication_time_s(communication_bytes, collective, participants, system, calibration)
    launch_s = float(calibration.get("launch_overhead_us", 8.0)) * 1e-6

    base_s = max(compute_s, memory_s)
    total_s = base_s + comm_s + launch_s
    if comm_s > base_s and comm_s > 0:
        bottleneck = "communication"
    elif compute_s >= memory_s:
        bottleneck = "compute"
    else:
        bottleneck = "memory" if memory_kind != "kv_cache" else "kv_cache"

    return {
        "name": name,
        "flops": flops,
        "bytes": bytes_,
        "effective_tflops": tflops,
        "effective_bandwidth_gbps": bw,
        "compute_s": compute_s,
        "memory_s": memory_s,
        "communication_s": comm_s,
        "launch_s": launch_s,
        "total_s": total_s,
        "bottleneck": bottleneck,
        "formatted": {
            "flops": format_flops(flops),
            "bytes": format_bytes(bytes_),
            "compute": format_seconds(compute_s),
            "memory": format_seconds(memory_s),
            "communication": format_seconds(comm_s),
            "total": format_seconds(total_s),
        }
    }
