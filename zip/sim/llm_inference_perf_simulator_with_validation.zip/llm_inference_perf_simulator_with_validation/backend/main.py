from __future__ import annotations

import json
from pathlib import Path
import yaml
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .analyzer.simulator import simulate_from_dicts

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"

app = FastAPI(title="LLM Inference Performance Simulator", version="0.3.0")
app.mount("/static", StaticFiles(directory=FRONTEND), name="static")


class SimulatePayload(BaseModel):
    model: dict
    workload: dict
    system: dict
    calibration: dict | None = None


@app.get("/")
def index():
    return FileResponse(FRONTEND / "index.html")


@app.post("/api/simulate")
def api_simulate(payload: SimulatePayload):
    return simulate_from_dicts(
        model=payload.model,
        workload=payload.workload,
        system=payload.system,
        calibration=payload.calibration or {},
    )


@app.get("/api/example/{name}")
def api_example(name: str):
    allowed = {
        "model": ROOT / "configs" / "model_mistral_7b.yaml",
        "workload": ROOT / "configs" / "workload_interactive.yaml",
        "system": ROOT / "configs" / "system_target_h100x8.yaml",
        "calibration": ROOT / "configs" / "calibration_example_dgx_spark.json",
    }
    if name not in allowed:
        return {"error": "unknown example"}
    p = allowed[name]
    if p.suffix in (".yaml", ".yml"):
        return yaml.safe_load(p.read_text(encoding="utf-8"))
    return json.loads(p.read_text(encoding="utf-8"))
