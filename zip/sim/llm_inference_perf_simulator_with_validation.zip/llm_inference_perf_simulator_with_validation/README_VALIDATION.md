# LLM Performance Simulator Validation Pipeline

This package contains a bash-based validation and measurement pipeline for the LLM inference performance simulator.

## Install

Copy the `scripts` directory into the root of `llm_inference_perf_simulator`.

```bash
cp -r scripts examples README_VALIDATION.md /path/to/llm_inference_perf_simulator/
cd /path/to/llm_inference_perf_simulator
```

## Self-test

```bash
bash scripts/validate_simulator_pipeline.sh selftest
```

The self-test does not require CUDA. It checks formula sanity, runs a synthetic prediction, creates a synthetic measured trace, and validates it.

## Measure on DGX Spark

Quick smoke measurement:

```bash
bash scripts/validate_simulator_pipeline.sh measure --quick
```

Full measurement:

```bash
bash scripts/validate_simulator_pipeline.sh measure   --bench-config configs/dgx_spark_calibration_plan.yaml   --outdir results/dgx_spark_validation_$(date +%Y%m%d_%H%M%S)
```

Outputs:

- `dgx_spark_raw.jsonl`
- `calibration_dgx_spark_measured.json`

## Simulate

```bash
bash scripts/validate_simulator_pipeline.sh simulate   --model configs/model_mistral_7b.yaml   --workload configs/workload_interactive.yaml   --system configs/system_target_h100x8.yaml   --calibration results/.../calibration_dgx_spark_measured.json   --pred results/predictions.jsonl
```

## Validate against measured trace

```bash
bash scripts/validate_simulator_pipeline.sh validate   --pred results/predictions.jsonl   --measured measured_trace.jsonl   --outdir results/validation_report
```

Measured JSONL line example:

```json
{"scenario_id":"single_default","metric":"total_latency_s","measured":0.52,"measured_bottleneck":"compute"}
```

Supported metrics:

- `prefill_latency_s`
- `decode_latency_per_token_s`
- `total_latency_s`
- `tokens_per_second_total`
- `memory_per_gpu_bytes`

## Outputs

- `validation_report.json`
- `validation_detail.csv`
- `validation_report.md`
- `validation_summary.json`

## Calibration improvement loop

1. Run `measure --quick` first.
2. Run full `measure` after sanity checks.
3. Run `simulate` for target scenarios.
4. Collect real measured traces from DGX Spark or production runtime.
5. Run `validate`.
6. Update calibration profile fields:
   - `dtype_efficiency`
   - `shape_efficiency.decode_m1`
   - `shape_efficiency.large_m`
   - `memory_efficiency`
   - `kv_cache_bandwidth_factor`
   - communication alpha/beta values
7. Repeat.
