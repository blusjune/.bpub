# Integrated Package: LLM Inference Performance Simulator + Validation Pipeline

이 통합 패키지는 다음 두 구성요소를 함께 포함합니다.

1. `llm_inference_perf_simulator`
   - DGX Spark 실측 calibration profile을 기반으로 target GPU system에서 LLM inference latency, throughput, memory, bottleneck을 예측하는 simulator

2. `scripts/validate_simulator_pipeline.sh`
   - self-test
   - DGX Spark microbenchmark 실행
   - calibration config 생성
   - simulator prediction 실행
   - measured trace와 prediction 비교
   - validation report 생성

## Quick Start

```bash
cd llm_inference_perf_simulator_with_validation
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 1. Validation pipeline self-test

```bash
bash scripts/validate_simulator_pipeline.sh selftest
```

## 2. DGX Spark quick calibration

```bash
bash scripts/validate_simulator_pipeline.sh measure --quick
```

## 3. Full calibration

```bash
bash scripts/validate_simulator_pipeline.sh measure \
  --bench-config configs/dgx_spark_calibration_plan.yaml \
  --outdir results/dgx_spark_validation_$(date +%Y%m%d_%H%M%S)
```

## 4. Simulation

```bash
bash scripts/validate_simulator_pipeline.sh simulate \
  --model configs/model_mistral_7b.yaml \
  --workload configs/workload_interactive.yaml \
  --system configs/system_target_h100x8.yaml \
  --calibration configs/calibration_example_dgx_spark.json \
  --pred results/predictions.jsonl
```

## 5. Validation against measured trace

```bash
bash scripts/validate_simulator_pipeline.sh validate \
  --pred results/predictions.jsonl \
  --measured examples/measured_trace_schema.jsonl \
  --outdir results/validation_report
```

## 6. Web UI

```bash
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Open:

```text
http://127.0.0.1:8000
```

## Notes

- `examples/measured_trace_schema.jsonl`은 schema 예시입니다. 실제 validation에는 DGX Spark 또는 target runtime에서 수집한 measured trace를 사용하세요.
- CUDA/PyTorch GPU가 없는 환경에서는 일부 benchmark가 synthetic fallback으로 동작할 수 있습니다.
- Production extrapolation 정확도는 calibration profile과 target system profile의 품질에 크게 의존합니다.
